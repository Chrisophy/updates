# -*- coding: utf-8 -*-
"""Oberfläche: Kodi-Repository durchsuchen, Prüfbericht vor der Installation, Prüf-Knopf in der Quellenliste.

    python tests/repo_ui_test.py
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from http.server import HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from repo_test import MODULE, Repo, Extra, PLUG, SCRIPT, addon_xml, build, wait, zipped  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
PORT, REPO_PORT, EXTRA_PORT = 8944, 8945, 8946
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def api(path):
    return json.loads(urllib.request.urlopen('http://127.0.0.1:%d%s' % (PORT, path), timeout=30).read())


def main():
    tmp = tempfile.mkdtemp(prefix='ms_repoui_')
    Repo.items = build()
    srv = HTTPServer(('127.0.0.1', REPO_PORT), Repo)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    xz = addon_xml('plugin.video.zusatz', '1.5.0', PLUG, name='Zusatzfilm', summary='Aus dem zweiten Repo')
    Extra.items = {'plugin.video.zusatz': (xz, zipped('plugin.video.zusatz', {'addon.xml': xz, 'default.py': 'pass\n'}), '1.5.0')}
    srv2 = HTTPServer(('127.0.0.1', EXTRA_PORT), Extra)
    threading.Thread(target=srv2.serve_forever, daemon=True).start()
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_KODI_REPO='http://127.0.0.1:%d/' % REPO_PORT)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close(); break
            except OSError:
                time.sleep(0.5)
        time.sleep(1.5)
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 420, 'height': 900})
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/' % PORT); pg.wait_for_timeout(1500)
            pg.evaluate("openManager('sources')")
            pg.wait_for_selector('text=Kodi-Repository durchsuchen', timeout=10000)
            check('Quellen-Seite hat den Knopf „Kodi-Repository durchsuchen …“', True)

            print('Repo-Browser')
            pg.get_by_role('button', name='Kodi-Repository durchsuchen').click()
            pg.wait_for_selector('.repo-item', timeout=15000)
            n = pg.locator('.repo-item').count()
            info = pg.inner_text('.repo-info')
            check('Erste Seite zeigt 40 Treffer und die Seitenzahl', n == 40 and '97 Treffer' in info and 'Seite 1 von 3' in info, (n, info))
            pg.get_by_role('button', name='Weiter').click()
            pg.wait_for_function("document.querySelector('.repo-info').innerText.includes('Seite 2 von 3')", timeout=8000)
            check('Weiter blättert', True)
            pg.fill('.repo-q', 'mond')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 2", timeout=8000)
            names = pg.eval_on_selector_all('.repo-item b', 'els => els.map(e => e.textContent)')
            check('Suche „mond“: Mondfilm vor Sonnenfilm', names == ['Mondfilm', 'Sonnenfilm'], names)
            check('Art und Beschreibung stehen am Eintrag', 'Videoquellen' in pg.inner_text('.repo-item') and 'Filme vom Mond' in pg.inner_text('.repo-item'))
            pg.fill('.repo-q', '')
            pg.select_option('.repo-g', 'service')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 1 && document.querySelector('.repo-item').dataset.id === 'service.uhr'", timeout=8000)
            check('Art „Dienste“ filtert', True)
            pg.select_option('.repo-g', '')
            ow = pg.evaluate('document.documentElement.scrollWidth')
            check('Kein seitliches Scrollen auf dem Handy', ow <= 421, ow)
            pg.fill('.repo-q', 'mond')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 2", timeout=8000)
            check('Ohne weitere Seiten steht kein Blätter-Rest („null“) unter der Liste', 'null' not in pg.inner_text('#layers'), pg.inner_text('#layers')[-300:])
            pg.fill('.repo-q', '')

            print('Prüfbericht vor der Installation')
            pg.fill('.repo-q', 'fensterspiel')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 1 && document.querySelector('.repo-item').dataset.id === 'script.game.fenster'", timeout=8000)
            pg.locator('.repo-item').get_by_role('button', name='Installieren').click()
            pg.wait_for_selector('.cmp-head', timeout=20000)
            head = pg.inner_text('.cmp-head')
            verdict = pg.get_attribute('.cmp-head', 'data-verdict')
            check('Fensterspiel: Urteil „läuft voraussichtlich nicht“ mit Befund zum Desktop-Fenster', verdict == 'no' and 'nicht' in head and 'Desktop-Fenster' in pg.inner_text('.cmp-f[data-level=error]'), (verdict, head))
            check('Bericht nennt, dass es eine Einschätzung aus dem Code ist', 'ohne es auszuführen' in pg.inner_text('#layers'))
            check('Es wurde noch nichts installiert', not [a for a in api('/api/admin/addons')['addons'] if a['id'] == 'script.game.fenster'])
            pg.get_by_role('button', name='Abbrechen').click()
            pg.wait_for_selector('.cmp-head', state='detached', timeout=5000)
            check('Abbrechen führt zurück in den Browser', pg.locator('.repo-q').count() == 1)

            print('Installieren')
            pg.fill('.repo-q', 'schlicht')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 1 && document.querySelector('.repo-item').dataset.id === 'script.game.schlicht'", timeout=8000)
            pg.locator('.repo-item').get_by_role('button', name='Installieren').click()
            pg.wait_for_selector('.cmp-head[data-verdict=ok]', timeout=20000)
            check('Schlichtes Spiel: grünes Urteil', 'Läuft voraussichtlich' in pg.inner_text('.cmp-head'))
            check('Bericht nennt die nachzuladende Bibliothek', 'script.module.hilfsbau' in pg.inner_text('#layers'))
            pg.locator('.cmp-head').locator('xpath=ancestor::*[contains(@class,"panel")][1]').get_by_role('button', name='Installieren', exact=True).click()
            pg.wait_for_selector('.toast:has-text("installiert: Schlichtes Spiel")', timeout=30000)
            t = pg.inner_text('#toasts')
            check('Meldung nennt Typ, Namen und nachgeladene Bibliothek', 'Programm installiert: Schlichtes Spiel' in t and 'script.module.hilfsbau' in t, t)
            pg.wait_for_function("document.querySelector('.repo-item button') && document.querySelector('.repo-item button').textContent === 'Installiert'", timeout=10000)
            check('Browser zeigt den Eintrag danach als „Installiert“', True)
            check('Addon ist wirklich installiert', any(a['id'] == 'script.game.schlicht' for a in api('/api/admin/addons')['addons']))

            print('Repositories getrennt')
            check('Mit nur einem Repository gibt es keine Auswahl und keine Zwischenüberschriften',
                  not pg.locator('.repo-s').is_visible() and pg.locator('.repo-sh').count() == 0)
            pg.locator('summary:has-text("Repositories verwalten")').click()
            check('Verwalten: Eingabe ist da, das offizielle Repository ist aufgeführt', pg.locator('.repo-add').is_visible() and pg.locator('.repo-src').count() == 1, pg.locator('.repo-src').count())
            pg.fill('.repo-add', 'http://127.0.0.1:%d/' % (EXTRA_PORT + 50))
            pg.get_by_role('button', name='Repository hinzufügen').click()
            pg.wait_for_selector('.toast.err, .toast:has-text("Nicht erreichbar"), .toast:has-text("nicht erreichbar"), .toast:has-text("Verbindung")', timeout=40000)
            check('Unerreichbare Adresse: Fehlermeldung, nichts eingetragen', pg.locator('.repo-src').count() == 1, pg.inner_text('#toasts'))
            pg.fill('.repo-add', 'http://127.0.0.1:%d/' % EXTRA_PORT)
            pg.get_by_role('button', name='Repository hinzufügen').click()
            pg.wait_for_selector('.toast:has-text("Hinzugefügt")', timeout=40000)
            pg.wait_for_function("document.querySelectorAll('.repo-src').length === 2", timeout=10000)
            check('Hinzugefügt: zwei Repositories in der Liste, eigenes zuerst',
                  pg.eval_on_selector_all('.repo-src', 'els => els.map(e => e.dataset.key)') == ['x0', 'official'])
            pg.fill('.repo-q', '')
            pg.wait_for_function("document.querySelectorAll('.repo-sh').length === 2", timeout=10000)
            heads = pg.eval_on_selector_all('.repo-sh', 'els => els.map(e => e.textContent)')
            check('„Alle“: je Repository eine Überschrift, eigenes zuerst', '127.0.0.1:%d' % EXTRA_PORT in heads[0] and 'Kodi (offiziell)' in heads[1], heads)
            check('Auswahl „Repository“ ist sichtbar', pg.locator('.repo-s').is_visible())
            pg.select_option('.repo-s', 'x0')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 1 && document.querySelector('.repo-item').dataset.id === 'plugin.video.zusatz'", timeout=8000)
            check('Ein Repository gewählt: nur dessen Addons, ohne Überschrift', pg.locator('.repo-sh').count() == 0 and pg.locator('.repo-item').get_attribute('data-src') == 'x0')
            pg.locator('.repo-item').get_by_role('button', name='Installieren').click()
            pg.wait_for_selector('.cmp-head', timeout=20000)
            check('Prüfbericht nennt das Repository', '127.0.0.1:%d' % EXTRA_PORT in pg.inner_text('#layers'))
            pg.get_by_role('button', name='Abbrechen').click()
            pg.wait_for_selector('.cmp-head', state='detached', timeout=5000)
            ow = pg.evaluate('document.documentElement.scrollWidth')
            check('Kein seitliches Scrollen mit zwei Repositories', ow <= 421, ow)
            pg.locator('.repo-src[data-key=x0]').get_by_role('button', name='Entfernen').click()
            pg.get_by_role('button', name='Ja, entfernen').click()
            pg.wait_for_function("document.querySelectorAll('.repo-src').length === 1", timeout=10000)
            check('Entfernt: wieder nur das offizielle Repository, Auswahl verschwindet', not pg.locator('.repo-s').is_visible() and pg.locator('.repo-sh').count() == 0)
            pg.fill('.repo-q', '')

            print('Updates: alle auf einmal, Auswahl, Herkunft')
            check('Vorschläge: Scraper und Gadgets stehen zum Laden bereit', pg.locator('.repo-sugrow').count() == 2 and 'keine Kodi-Repositories' in pg.inner_text('.repo-sug'), pg.locator('.repo-sugrow').count())
            check('Ohne neuere Version gibt es keine Update-Leiste', not pg.locator('.repo-upd').is_visible())
            xs = addon_xml('script.game.schlicht', '1.1.0', SCRIPT, ['script.module.hilfsbau'], name='Schlichtes Spiel', summary='Einfaches Spiel')
            xm = addon_xml('script.module.hilfsbau', '3.2.0', MODULE, name='Hilfsbau', summary='Bibliothek')
            Repo.items['script.game.schlicht'] = (xs, zipped('script.game.schlicht', {'addon.xml': xs, 'default.py': 'import xbmcgui\nxbmcgui.Dialog().ok("a", "b")\n'}), '1.1.0')
            Repo.items['script.module.hilfsbau'] = (xm, zipped('script.module.hilfsbau', {'addon.xml': xm, 'lib/hilfsbau.py': 'X = 2\n'}), '3.2.0')
            if not pg.locator('.repo-box').evaluate('e => e.open'):
                pg.locator('summary:has-text("Repositories verwalten")').click()
            pg.get_by_role('button', name='Alle neu laden').click()
            pg.wait_for_function("document.querySelector('.repo-upd') && document.querySelector('.repo-upd').innerText.includes('2 Updates verfügbar')", timeout=60000)
            check('„Alle neu laden“: Leiste meldet 2 Updates', True)
            def ver(i):
                return next((a.get('version') for a in api('/api/admin/addons')['addons'] if a['id'] == i), None)
            pg.get_by_role('button', name='Auswählen …').click()
            pg.wait_for_selector('.repo-updlist .sw', timeout=20000)
            check('Auswahl: zwei Schalter, beide an, Knopf „Alle aktualisieren“', pg.locator('.repo-updlist .sw[aria-checked=true]').count() == 2 and pg.locator('.repo-updlist ~ .actions').get_by_role('button', name='Alle aktualisieren', exact=True).count() == 1)
            check('Zeile nennt alte und neue Version und das Repository', '1.0.0 → 1.1.0' in pg.inner_text('.repo-updlist') and 'Kodi (offiziell)' in pg.inner_text('.repo-updlist'), pg.inner_text('.repo-updlist'))
            pg.get_by_role('button', name='Alle abwählen').click()
            check('„Alle abwählen“: alle Schalter aus, Aktualisieren gesperrt, Knopf wird „Alle auswählen“',
                  pg.locator('.repo-updlist .sw[aria-checked=true]').count() == 0 and pg.get_by_role('button', name='Alle auswählen').count() == 1 and pg.locator('.repo-updlist ~ .actions .btn.pri').is_disabled())
            pg.locator('.repo-updlist .sw[data-id="script.game.schlicht"]').click()
            check('Ein Schalter an: „Auswahl aktualisieren (1)“', pg.get_by_role('button', name='Auswahl aktualisieren (1)').count() == 1)
            pg.get_by_role('button', name='Auswahl aktualisieren (1)').click()
            pg.wait_for_selector('.repo-updout:has-text("1 aktualisiert")', timeout=60000)
            check('Nur das gewählte Spiel wurde aktualisiert', ver('script.game.schlicht') == '1.1.0' and ver('script.module.hilfsbau') == '3.1.0', (ver('script.game.schlicht'), ver('script.module.hilfsbau')))
            pg.get_by_role('button', name='Fertig').click()
            pg.wait_for_function("document.querySelector('.repo-upd') && document.querySelector('.repo-upd').innerText.includes('1 Update verfügbar')", timeout=30000)
            check('Zurück im Browser: noch 1 Update verfügbar', True)
            pg.locator('.repo-upd').get_by_role('button', name='Alle aktualisieren').click()
            pg.wait_for_function("getComputedStyle(document.querySelector('.repo-upd')).display === 'none'", timeout=60000)
            check('„Alle aktualisieren“ in der Leiste: Bibliothek jetzt 3.2.0, Leiste verschwindet', ver('script.module.hilfsbau') == '3.2.0', ver('script.module.hilfsbau'))

            print('Prüf-Knopf in der Liste')
            pg.get_by_role('button', name='Schließen').last.click()
            pg.wait_for_timeout(500)
            pg.evaluate("openManager('sources')")
            pg.wait_for_selector('text=Kodi-Programme, Dienste & Bibliotheken', timeout=10000)
            btn = pg.locator('.cmp-btn').first
            btn.wait_for(timeout=8000)
            check('Prüf-Knopf zeigt das Urteil in Kurzform', 'Prüfung: läuft' in btn.inner_text(), btn.inner_text())
            btn.click()
            pg.wait_for_selector('.cmp-head[data-verdict=ok]', timeout=15000)
            check('Knopf öffnet den frisch gelesenen Bericht', 'Kompatibilität' in pg.inner_text('#layers'))
            check('Keine Skriptfehler', not errs, errs)
            b.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        srv.shutdown()
        srv2.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
