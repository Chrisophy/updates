# -*- coding: utf-8 -*-
"""Oberfläche: Kodi-Repository durchsuchen, Prüfbericht vor der Installation, Prüf-Knopf in der Quellenliste.

    python tests/repo_ui_test.py
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from http.server import HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from repo_test import Repo, build, wait  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
PORT, REPO_PORT = 8944, 8945
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def api(path):
    return json.loads(urllib.request.urlopen('http://127.0.0.1:%d%s' % (PORT, path), timeout=30).read())


def main():
    tmp = tempfile.mkdtemp(prefix='ms_repoui_')
    Repo.items = build()
    srv = HTTPServer(('127.0.0.1', REPO_PORT), Repo)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_KODI_REPO='http://127.0.0.1:%d/' % REPO_PORT)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close(); break
            except OSError:
                time.sleep(0.5)
        time.sleep(1.5)
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 420, 'height': 900})
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/' % PORT); pg.wait_for_timeout(1500)
            pg.evaluate("openManager('sources')")
            pg.wait_for_selector('text=Kodi-Repository durchsuchen', timeout=10000)
            check('Quellen-Seite hat den Knopf „Kodi-Repository durchsuchen …“', True)

            print('Repo-Browser')
            pg.get_by_role('button', name='Kodi-Repository durchsuchen').click()
            pg.wait_for_selector('.repo-item', timeout=15000)
            n = pg.locator('.repo-item').count()
            info = pg.inner_text('.repo-info')
            check('Erste Seite zeigt 40 Treffer und die Seitenzahl', n == 40 and '97 Treffer' in info and 'Seite 1 von 3' in info, (n, info))
            pg.get_by_role('button', name='Weiter').click()
            pg.wait_for_function("document.querySelector('.repo-info').innerText.includes('Seite 2 von 3')", timeout=8000)
            check('Weiter blättert', True)
            pg.fill('.repo-q', 'mond')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 2", timeout=8000)
            names = pg.eval_on_selector_all('.repo-item b', 'els => els.map(e => e.textContent)')
            check('Suche „mond“: Mondfilm vor Sonnenfilm', names == ['Mondfilm', 'Sonnenfilm'], names)
            check('Art und Beschreibung stehen am Eintrag', 'Videoquellen' in pg.inner_text('.repo-item') and 'Filme vom Mond' in pg.inner_text('.repo-item'))
            pg.fill('.repo-q', '')
            pg.select_option('.repo-g', 'service')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 1 && document.querySelector('.repo-item').dataset.id === 'service.uhr'", timeout=8000)
            check('Art „Dienste“ filtert', True)
            pg.select_option('.repo-g', '')
            ow = pg.evaluate('document.documentElement.scrollWidth')
            check('Kein seitliches Scrollen auf dem Handy', ow <= 421, ow)
            pg.fill('.repo-q', 'mond')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 2", timeout=8000)
            check('Ohne weitere Seiten steht kein Blätter-Rest („null“) unter der Liste', 'null' not in pg.inner_text('#layers'), pg.inner_text('#layers')[-300:])
            pg.fill('.repo-q', '')

            print('Prüfbericht vor der Installation')
            pg.fill('.repo-q', 'fensterspiel')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 1 && document.querySelector('.repo-item').dataset.id === 'script.game.fenster'", timeout=8000)
            pg.locator('.repo-item').get_by_role('button', name='Installieren').click()
            pg.wait_for_selector('.cmp-head', timeout=20000)
            head = pg.inner_text('.cmp-head')
            verdict = pg.get_attribute('.cmp-head', 'data-verdict')
            check('Fensterspiel: Urteil „läuft voraussichtlich nicht“ mit Befund zum Desktop-Fenster', verdict == 'no' and 'nicht' in head and 'Desktop-Fenster' in pg.inner_text('.cmp-f[data-level=error]'), (verdict, head))
            check('Bericht nennt, dass es eine Einschätzung aus dem Code ist', 'ohne es auszuführen' in pg.inner_text('#layers'))
            check('Es wurde noch nichts installiert', not [a for a in api('/api/admin/addons')['addons'] if a['id'] == 'script.game.fenster'])
            pg.get_by_role('button', name='Abbrechen').click()
            pg.wait_for_selector('.cmp-head', state='detached', timeout=5000)
            check('Abbrechen führt zurück in den Browser', pg.locator('.repo-q').count() == 1)

            print('Installieren')
            pg.fill('.repo-q', 'schlicht')
            pg.wait_for_function("document.querySelectorAll('.repo-item').length === 1 && document.querySelector('.repo-item').dataset.id === 'script.game.schlicht'", timeout=8000)
            pg.locator('.repo-item').get_by_role('button', name='Installieren').click()
            pg.wait_for_selector('.cmp-head[data-verdict=ok]', timeout=20000)
            check('Schlichtes Spiel: grünes Urteil', 'Läuft voraussichtlich' in pg.inner_text('.cmp-head'))
            check('Bericht nennt die nachzuladende Bibliothek', 'script.module.hilfsbau' in pg.inner_text('#layers'))
            pg.locator('.cmp-head').locator('xpath=ancestor::*[contains(@class,"panel")][1]').get_by_role('button', name='Installieren', exact=True).click()
            pg.wait_for_selector('.toast:has-text("installiert: Schlichtes Spiel")', timeout=30000)
            t = pg.inner_text('#toasts')
            check('Meldung nennt Typ, Namen und nachgeladene Bibliothek', 'Programm installiert: Schlichtes Spiel' in t and 'script.module.hilfsbau' in t, t)
            pg.wait_for_function("document.querySelector('.repo-item button') && document.querySelector('.repo-item button').textContent === 'Installiert'", timeout=10000)
            check('Browser zeigt den Eintrag danach als „Installiert“', True)
            check('Addon ist wirklich installiert', any(a['id'] == 'script.game.schlicht' for a in api('/api/admin/addons')['addons']))

            print('Weitere Repositories')
            pg.locator('summary:has-text("Weitere Repositories")').click()
            check('Eingabe für weitere Repositories ist da', pg.locator('.repo-extra').is_visible())

            print('Prüf-Knopf in der Liste')
            pg.get_by_role('button', name='Schließen').last.click()
            pg.wait_for_timeout(500)
            pg.evaluate("openManager('sources')")
            pg.wait_for_selector('text=Kodi-Programme, Dienste & Bibliotheken', timeout=10000)
            btn = pg.locator('.cmp-btn').first
            btn.wait_for(timeout=8000)
            check('Prüf-Knopf zeigt das Urteil in Kurzform', 'Prüfung: läuft' in btn.inner_text(), btn.inner_text())
            btn.click()
            pg.wait_for_selector('.cmp-head[data-verdict=ok]', timeout=15000)
            check('Knopf öffnet den frisch gelesenen Bericht', 'Kompatibilität' in pg.inner_text('#layers'))
            check('Keine Skriptfehler', not errs, errs)
            b.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
