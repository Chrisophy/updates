# -*- coding: utf-8 -*-
"""Offline-Test für resources/lib/evil.py (Hoster-Auflösung): Dropload-Formular, Kennung, Hinweis-Text, Verhalten von no_verify.

    python tests/evil_test.py
"""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault('MINIKODI_DATA', tempfile.mkdtemp())
os.environ.setdefault('MOVIESCOUT_DATA', os.environ['MINIKODI_DATA'])
from resources.lib import evil, multiquest  # noqa: E402

failed = 0


def check(name, cond, extra=''):
    global failed
    print('  ok   ' if cond else '  FEHLER', name, '' if cond else extra)
    failed += 0 if cond else 1


FID = 'abcd1234efgh'
PAGE = '<a href="/d/%s_n">Normal</a> <a href="/d/%s_h">Hoch</a>' % (FID, FID)
FORM = '<form><input type="hidden" name="op" value="download_orig"><input type="hidden" name="hash" value="H123"></form>'
DONE = '<a href="https://cdn.example/v/file.mp4?t=1&amp;e=2">Download</a>'

print('Kennung und Text')
check('Kennung aus embed-Adresse', evil._dropload_id('https://dropload.io/embed-%s.html' % FID) == FID)
check('Kennung aus /e/-Adresse mit Qualitätsendung', evil._dropload_id('https://dr0pstream.com/d/%s_n' % FID) == FID)
check('Ungültige Kennung wird abgelehnt', evil._dropload_id('https://dropload.io/e/kurz') == '')
check('Seitentext ohne Skripte und Tags', evil._page_text('<main><script>x()</script><p>Bitte  warten</p></main>') == 'Bitte warten')

print('Dropload-Download (simuliert)')
calls = {'get': [], 'post': []}
orig = (evil._get, multiquest.post, evil.time.sleep)


class R:
    def __init__(self, text):
        self.text = text

    def raise_for_status(self):
        pass


def fake_get(url, referer=None, ua=None):
    calls['get'].append(url)
    return PAGE if url.endswith('/d/' + FID) else (FORM if '_' in url.rsplit('/', 1)[-1] else '')


def fake_post(url, data=None, headers=None, timeout=None, **kw):
    calls['post'].append((url, dict(data or {}), kw))
    return R(DONE)


evil._get, multiquest.post, evil.time.sleep = fake_get, fake_post, lambda s: None
try:
    link = evil._dropload_download(FID)
    check('Link aus dem Formular, &amp; zurückgewandelt', link == 'https://cdn.example/v/file.mp4?t=1&e=2', link)
    check('Formularfelder (hash) werden mitgeschickt', calls['post'] and calls['post'][0][1].get('hash') == 'H123', calls['post'])
    check('erste Qualitätsstufe aus der Seite benutzt', calls['post'][0][0].endswith('/d/%s_n' % FID), calls['post'])
    res, ok = evil.resolve('https://dropload.io/embed-%s.html' % FID)
    check('resolve(): Dropload-Adresse ergibt Link mit Referer und User-Agent', ok and res.startswith('https://cdn.example/v/file.mp4?t=1&e=2|Referer=https://dr0pstream.com/&User-Agent='), (res, ok))
    check('Ohne Einstellung „verify.peer“ wird die Zertifikatsprüfung nicht abgeschaltet', 'verifypeer' not in res and calls['post'][-1][2].get('no_verify') is False, calls['post'][-1])
    # Formular fehlt -> kein Absturz, leeres Ergebnis
    evil._get = lambda url, referer=None, ua=None: ''
    check('Ohne Formular: leer statt Absturz', evil._dropload_download(FID) == '')
finally:
    evil._get, multiquest.post, evil.time.sleep = orig

print('Vorhandene Aufrufe der Engine')
try:
    resp = multiquest.get('http://127.0.0.1:9/', timeout=1, no_verify=True)
    check('no_verify: Verbindungsfehler wie sonst (kein TypeError)', False)
except TypeError as e:
    check('no_verify: Verbindungsfehler wie sonst (kein TypeError)', False, e)
except Exception:
    check('no_verify: Verbindungsfehler wie sonst (kein TypeError)', True)
print('FEHLER: %d' % failed if failed else 'Alles ok')
sys.exit(1 if failed else 0)
