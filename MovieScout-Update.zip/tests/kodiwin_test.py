# -*- coding: utf-8 -*-
"""Eigene Kodi-Fenster eines Addons (xbmcgui.WindowDialog + addControl, z. B. Spiele): Zustand, Tasten, Klicks, Dialoge im Fenster,
Spiel-Schleife in eigenem Thread, andere Addons laufen weiter.

    python tests/kodiwin_test.py
"""
import base64
import io
import json
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
PORT = 8925
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, raw=None, timeout=60):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    req = Request(BASE + path, data=data, method='POST' if data is not None else 'GET',
                  headers={'Content-Type': 'application/zip' if raw is not None else 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=timeout) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt


def zipped(aid, files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for n, c in files.items():
            z.writestr(aid + '/' + n, c)
    return b.getvalue()


def xml(aid, name):
    return ('<addon id="%s" name="%s" version="1.0.0"><requires><import addon="xbmc.python" version="3.0.0"/></requires>'
            '<extension point="xbmc.python.script" library="default.py"><provides>executable</provides></extension></addon>') % (aid, name)


GAME = r'''
import os, xbmc, xbmcgui, xbmcvfs
class Game(xbmcgui.WindowDialog):
    def __init__(self):
        super().__init__()
        p = xbmcvfs.translatePath('special://home/addons/script.game.fake')
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, os.path.join(p, 'background.png')))
        self.title = xbmcgui.ControlLabel(60, 40, 700, 50, "[B]FAKE[/B]", font='font14', textColor='0xFF000000')
        self.addControl(self.title)
        self.status = xbmcgui.ControlLabel(60, 90, 700, 50, "Spalte 3", font='font13', textColor='0xFF000000')
        self.addControl(self.status)
        self.btn_drop = xbmcgui.ControlButton(840, 330, 380, 60, "EINWERFEN", alignment=2)
        self.btn_reset = xbmcgui.ControlButton(840, 460, 380, 60, "Neu starten", alignment=2)
        self.btn_exit = xbmcgui.ControlButton(840, 540, 380, 60, "Beenden", alignment=2)
        for b in (self.btn_drop, self.btn_reset, self.btn_exit):
            self.addControl(b)
        self.btn_drop.controlDown(self.btn_reset); self.btn_reset.controlDown(self.btn_exit)
        self.btn_exit.controlUp(self.btn_reset); self.btn_reset.controlUp(self.btn_drop)
        self.setFocus(self.btn_drop)
        self.col, self.drops = 3, 0
        ret = xbmcgui.Dialog().select("Modus wählen", ["1 Spieler", "2 Spieler"])
        self.mode = ret
        self.btn_reset.setVisible(False)
        self.draw()
    def draw(self):
        self.status.setLabel("Modus %d · Spalte %d · Würfe %d" % (self.mode, self.col, self.drops))
    def onAction(self, action):
        a = action.getId()
        if a in (9, 10, 13, 92):
            self.close()
        elif a == 1:
            self.col = (self.col - 1) % 7; self.draw()
        elif a == 2:
            self.col = (self.col + 1) % 7; self.draw()
    def onControl(self, control):
        cid = control.getId()
        if cid == self.btn_exit.getId():
            self.close()
        elif cid == self.btn_drop.getId():
            self.drops += 1; self.draw()
            if self.drops == 2:
                kb = xbmc.Keyboard("", "Name:"); kb.doModal()
                if kb.isConfirmed():
                    self.title.setLabel("[COLOR red]Sieger: %s[/COLOR]" % kb.getText())
                self.btn_reset.setVisible(True)
g = Game(); g.doModal()
with open(os.environ['KW_OUT'], 'w') as f:
    f.write('ende %d %d' % (g.col, g.drops))
del g
'''

LOOP = r'''
import threading, xbmc, xbmcgui
class L(xbmcgui.WindowDialog):
    def __init__(self):
        super().__init__()
        self.lbl = xbmcgui.ControlLabel(10, 10, 600, 40, "0")
        self.addControl(self.lbl)
        self.n = 0; self.running = True
    def loop(self):
        while self.running:
            self.n += 1; self.lbl.setLabel(str(self.n)); xbmc.sleep(100)
    def onAction(self, a):
        if a.getId() in (10, 92): self.running = False; self.close()
w = L(); t = threading.Thread(target=w.loop); t.start(); w.doModal(); w.running = False; t.join()
'''


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_kwin_'))
    out = tmp / 'out.txt'
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1', KW_OUT=str(out),
               MOVIESCOUT_DIALOG_GONE='6')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=.3).close(); break
            except OSError:
                time.sleep(.25)
        time.sleep(1)
        c, r = http('/api/admin/addon/install', raw=zipped('script.game.fake', {'addon.xml': xml('script.game.fake', 'Fake-Spiel'), 'default.py': GAME, 'background.png': PNG}))
        check('Spiel installiert', c == 200, r)
        http('/api/admin/addon/install', raw=zipped('script.game.loop', {'addon.xml': xml('script.game.loop', 'Schleife'), 'default.py': LOOP}))
        http('/api/admin/addon/install', raw=zipped('plugin.video.other', {
            'addon.xml': '<addon id="plugin.video.other" name="Other" version="1"><extension point="xbmc.python.pluginsource" library="main.py"/></addon>',
            'main.py': 'import xbmcgui, xbmcplugin\nxbmcplugin.addDirectoryItem(int(sys.argv[1]), sys.argv[0] + "?a=1", xbmcgui.ListItem(label="Andere Quelle"), True)\n'}))

        print('Spiel starten (wie der Knopf „Starten“)')
        rid = secrets.token_hex(12)
        res = {}
        th = threading.Thread(target=lambda: res.update(r=http('/api/admin/addon/run', {'id': 'script.game.fake', 'rid': rid}, timeout=120)))
        th.start()

        def poll(wid='', wv=-1, wait=3):
            return http('/api/dialog?rid=%s&wait=%s&wid=%s&wv=%d' % (rid, wait, wid, wv))[1]
        d = poll()
        check('Erst kommt die Modus-Abfrage (Dialog im Fenster-Aufbau)', d.get('dialog') and d['dialog']['kind'] == 'select', d)
        http('/api/dialog', {'rid': rid, 'id': d['dialog']['id'], 'value': 1})
        d = poll()
        w = d.get('window')
        check('Dann das Fenster mit allen Steuerelementen', w and w['full'] and len(w['controls']) == 6, d)
        types = [x['t'] for x in w['controls']]
        check('Typen: Bild, 2 Beschriftungen, 3 Knöpfe', types == ['image', 'label', 'label', 'button', 'button', 'button'], types)
        img = w['controls'][0]
        check('Hintergrundbild als Engine-Adresse, liefert die Datei', img['img'].startswith('/api/dialog/file/') and http(img['img'].split('?')[0])[1] == PNG, img)
        lbl = w['controls'][2]
        check('Beschriftung mit Text, Farbe, Schrift, Lage', lbl['label'] == 'Modus 1 · Spalte 3 · Würfe 0' and lbl['color'] == 'FF000000' and lbl['font'] == 'font13'
              and (lbl['x'], lbl['y'], lbl['w'], lbl['h']) == (60, 90, 700, 50), lbl)
        ids = [x['id'] for x in w['controls']]
        check('Kodi-Kennungen ab 3001, Fokus auf „EINWERFEN“', ids == list(range(3001, 3007)) and w['focus'] == 3004, (ids, w['focus']))
        check('„Neu starten“ ist versteckt', w['controls'][4]['vis'] is False)
        wid, wv = w['id'], w['ver']
        d = poll(wid, wv, wait=0.5)
        check('Ohne Änderung: nichts Neues', d['window']['controls'] == [] and not d['window']['full'], d)

        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 2}})
        d = poll(wid, wv)
        ch = d['window']['controls']
        check('Pfeil rechts -> onAction -> nur die geänderte Beschriftung kommt', len(ch) == 1 and ch[0]['label'] == 'Modus 1 · Spalte 4 · Würfe 0', ch)
        wv = d['window']['ver']
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 7}})
        d = poll(wid, wv)
        check('OK auf dem markierten Knopf -> onControl (einmal, nicht doppelt)', 'Würfe 1' in json.dumps(d['window']['controls'], ensure_ascii=False), d)
        wv = d['window']['ver']
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'click', 'cid': 3004}})
        d = poll(wid, wv)
        check('Zweiter Wurf (Antippen) -> Namens-Abfrage über dem Fenster', d.get('dialog') and d['dialog']['kind'] == 'input' and d.get('window'), d)
        http('/api/dialog', {'rid': rid, 'id': d['dialog']['id'], 'value': 'Anna'})
        time.sleep(0.3)
        d = poll(wid, wv)
        allc = {x['id']: x for x in d['window']['controls']}
        check('Danach: Titel rot mit Namen, „Neu starten“ sichtbar', allc.get(3002, {}).get('label') == '[COLOR red]Sieger: Anna[/COLOR]' and allc.get(3005, {}).get('vis') is True, d)
        wv = d['window']['ver']
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 4}})
        d = poll(wid, wv)
        check('Pfeil runter folgt controlDown (Fokus wandert)', d['window']['focus'] == 3005, d['window'].get('focus'))

        print('Andere Addons laufen weiter, solange das Spiel offen ist')
        t0 = time.time()
        c, o = http('/api/open', {'provider_id': 'addon_plugin_video_other', 'item': {}}, timeout=20)
        check('Andere Quelle antwortet sofort (keine Sperre durch das Spiel)', c == 200 and o['items'] and time.time() - t0 < 8, (c, time.time() - t0))

        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 92}})
        th.join(15)
        c, r = res.get('r', (0, {}))
        check('Zurück -> Programm schließt das Fenster, Aufruf endet', c == 200 and r.get('ok'), res)
        check('Programm lief danach weiter bis zum Ende', out.exists() and out.read_text() == 'ende 4 2', out.read_text() if out.exists() else '')
        d = poll(wid, wv, wait=0.5)
        check('Fenster ist weg', d.get('window') is None, d)

        print('Spiel-Schleife in eigenem Thread')
        rid = secrets.token_hex(12)
        res = {}
        th = threading.Thread(target=lambda: res.update(r=http('/api/admin/addon/run', {'id': 'script.game.loop', 'rid': rid}, timeout=60)))
        th.start()
        d = poll()
        w = d.get('window')
        wid = w['id'] if w else ''
        vals = []
        wv = w['ver'] if w else -1
        for _ in range(6):
            d = poll(wid, wv, wait=2)
            if d.get('window'):
                wv = d['window']['ver']
                vals += [x['label'] for x in d['window']['controls']]
        nums = [int(v) for v in vals if str(v).isdigit()]
        check('Die Schleife aktualisiert die Anzeige laufend', len(nums) >= 4 and nums == sorted(nums) and nums[-1] > nums[0], vals)
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'close'}})
        th.join(10)
        check('Erzwungenes Schließen beendet das Programm', res.get('r', (0,))[0] == 200, res)

        print('Oberfläche weg -> Fenster schließt von selbst')
        rid = secrets.token_hex(12)
        res = {}
        th = threading.Thread(target=lambda: res.update(r=http('/api/admin/addon/run', {'id': 'script.game.loop', 'rid': rid}, timeout=60)))
        th.start()
        poll()
        t0 = time.time()
        th.join(20)
        check('Ohne Abfragen der Oberfläche endet es nach kurzer Zeit', not th.is_alive() and time.time() - t0 < 15, time.time() - t0)
        c, r = http('/api/admin/addon/run', {'id': 'script.game.loop'})
        check('Ohne Oberfläche (keine rid): kein Hängen', c == 200, (c, r))
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
