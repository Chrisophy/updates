# -*- coding: utf-8 -*-
"""requests-Ersatz (kodi_runtime/requests_compat.py): läuft, wenn `requests` fehlt (z. B. Pydroid). python tests/requests_compat_test.py"""
import sys, threading, json, gzip
from http.server import BaseHTTPRequestHandler, HTTPServer
class Block:
    def find_spec(self, name, path=None, target=None):
        if name.split('.')[0] in ('requests','urllib3'): raise ModuleNotFoundError("No module named '%s'" % name)
sys.meta_path.insert(0, Block())
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _send(self, code, body, ct='application/json', extra=()):
        self.send_response(code); self.send_header('Content-Type', ct)
        for k,v in extra: self.send_header(k,v)
        self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        if self.path.startswith('/redir'): return self._send(302, b'', extra=[('Location','/final?x=1')])
        if self.path.startswith('/final'): return self._send(200, b'hi \xc3\xa4', 'text/plain; charset=utf-8')
        if self.path.startswith('/gz'):
            b=gzip.compress(b'{"a":1}'); return self._send(200,b,extra=[('Content-Encoding','gzip')])
        if self.path.startswith('/404'): return self._send(404, b'nope', 'text/plain')
        if self.path.startswith('/cookie'): return self._send(200,b'{}',extra=[('Set-Cookie','sid=abc; Path=/')])
        if self.path.startswith('/echo'): return self._send(200, json.dumps({'path':self.path,'ua':self.headers.get('User-Agent'),'ck':self.headers.get('Cookie'),'x':self.headers.get('X-T')}).encode())
    def do_POST(self):
        n=int(self.headers.get('Content-Length',0)); b=self.rfile.read(n)
        self._send(200, json.dumps({'ct':self.headers.get('Content-Type'),'body':b.decode()}).encode())
srv=HTTPServer(('127.0.0.1',0),H); P=srv.server_port
threading.Thread(target=srv.serve_forever,daemon=True).start()
from engine import addonhost
import requests, urllib3
assert getattr(requests,'__is_movie_scout_compat__',False)
B='http://127.0.0.1:%d'%P
ok=0
def chk(n,c):
    global ok
    print('OK ' if c else 'FAIL', n); ok+= (not c)
r=requests.get(B+'/redir',headers={'User-Agent':'T'},timeout=5)
chk('redirect folgt', r.url==B+'/final?x=1' and r.text=='hi ä' and r.status_code==200 and len(r.history)==1)
r=requests.get(B+'/redir',allow_redirects=False); chk('kein Redirect', r.status_code==302 and r.headers['location']=='/final?x=1')
r=requests.get(B+'/gz'); chk('gzip+json', r.json()=={'a':1})
r=requests.get(B+'/404'); chk('404 ohne Ausnahme', r.status_code==404 and not r.ok)
try: r.raise_for_status(); chk('raise',False)
except requests.exceptions.HTTPError as e: chk('raise_for_status', e.response.status_code==404)
r=requests.get(B+'/echo',params={'a':'b c'},headers={'X-T':'1'}); j=r.json(); chk('params+header', j['path']=='/echo?a=b+c' and j['x']=='1')
r=requests.post(B+'/p',data={'k':'v w'}); chk('post form', r.json()['body']=='k=v+w' and 'urlencoded' in r.json()['ct'])
r=requests.post(B+'/p',json={'k':1}); chk('post json', json.loads(r.json()['body'])=={'k':1})
r=requests.post(B+'/p',data={'k':'v'},files={'f':('a.txt',b'zz')}); chk('multipart', 'zz' in r.json()['body'] and 'multipart' in r.json()['ct'])
s=requests.Session(); s.headers.update({'X-T':'s'}); s.get(B+'/cookie'); j=s.get(B+'/echo').json(); chk('Session Cookie+Header', j['ck']=='sid=abc' and j['x']=='s' and s.cookies.get('sid')=='abc')
try: requests.get('http://127.0.0.1:1/', timeout=2); chk('conn',False)
except requests.exceptions.ConnectionError: chk('ConnectionError', True)
try: requests.get('kein-schema'); chk('schema',False)
except requests.exceptions.MissingSchema: chk('MissingSchema', True)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning); requests.packages.urllib3.disable_warnings()
chk('verify=False ok', requests.get(B+'/echo',verify=False).status_code==200)
import time as _t
class Slow(H):
    def do_GET(self):
        _t.sleep(3); self._send(200, b'{}')
srv2=HTTPServer(('127.0.0.1',0),Slow); threading.Thread(target=srv2.serve_forever,daemon=True).start()
chk('Zeitlimit 2 s wird auf mindestens 8 s angehoben (langsame Antwort nach 3 s gelingt)', requests.get('http://127.0.0.1:%d/'%srv2.server_port, timeout=2).status_code==200)
print('FEHLER', ok); sys.exit(1 if ok else 0)
