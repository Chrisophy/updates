import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8962; ok = bad = 0
def check(n, c, x=''):
    global ok, bad
    if c: ok += 1; print('  ok   ', n)
    else: bad += 1; print('  FEHLER', n, x)
tmp = tempfile.mkdtemp()
env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT/'tests'/'fake_providers'), NO_PROXY='*')
srv = subprocess.Popen([sys.executable, str(ROOT/'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(100):
    try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
    except OSError: time.sleep(.25)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_context(viewport={'width':900,'height':900}).new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_function('typeof providers!=="undefined" && providers.length', timeout=20000)
        pg.evaluate("openSettings()"); pg.wait_for_selector('.setsearch')
        check('Suchfeld da, 5 Reiter', pg.locator('.ed-tabs .chip').count() == 5)
        pg.fill('.setsearch', 'proxy'); pg.wait_for_timeout(300)
        n = pg.locator('.setres-i').count(); check('Suche „proxy“ liefert Treffer', n >= 1, n)
        check('Reiter ausgeblendet während Suche', not pg.locator('.ed-tabs').is_visible())
        pg.locator('.setres-i').first.click(); pg.wait_for_timeout(500)
        check('Klick springt in den Bereich, Suche leer', pg.input_value('.setsearch') == '' and pg.locator('.ed-tabs').is_visible())
        check('Treffer ist sichtbar markiert', pg.locator('.setflash').count() >= 1 and pg.locator('.setflash').first.is_visible())
        pg.fill('.setsearch', 'adresse der engine'); pg.wait_for_timeout(300)
        print(pg.locator('.setres').inner_text().replace('\n',' | '))
        pg.locator('.setres-i').first.click(); pg.wait_for_timeout(500)
        check('Treffer im eingeklappten „Erweitert“ klappt auf', pg.locator('details.setadv label', has_text='Adresse der Engine').is_visible())
        pg.fill('.setsearch', 'zzzqqq'); pg.wait_for_timeout(200)
        check('Nichts gefunden: Hinweis', 'Nichts gefunden' in pg.locator('.setres').inner_text())
        pg.fill('.setsearch', '')
        pg.get_by_role('switch', name='Alle Einstellungen zeigen (Erweitert)').click(); pg.wait_for_timeout(200)
        tabs = pg.locator('.ed-tabs .chip').all_inner_texts()
        check('Einfach: nur 3 Reiter', tabs == ['Allgemein', 'Konten & Inhalte', 'System & Update'], tabs)
        check('Einfach merkt sich (store)', pg.evaluate("store.get('setadv')") is False)
        pg.fill('.setsearch', 'dns'); pg.wait_for_timeout(300)
        txt = pg.locator('.setres').inner_text(); check('Suche findet Netzwerk-Eintrag mit Vermerk (Erweitert)', 'Erweitert' in txt, txt[:200])
        pg.locator('.setres-i').first.click(); pg.wait_for_timeout(500)
        check('Klick schaltet auf Erweitert', pg.evaluate("store.get('setadv')") is True and pg.locator('.ed-tabs .chip').count() == 5)
        check('keine Skriptfehler', not errs, errs)
        b.close()
finally:
    srv.terminate()
print(ok, bad)
