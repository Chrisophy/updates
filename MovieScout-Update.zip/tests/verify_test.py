# -*- coding: utf-8 -*-
"""Test der Einstellung „SSL-Zertifikate nicht prüfen“ (verify.peer): lokaler HTTPS-Server mit selbstsigniertem Zertifikat.

    python tests/verify_test.py
"""
import os
import ssl
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
tmp = tempfile.mkdtemp(prefix='ms-vf-')
os.environ['MINIKODI_DATA'] = os.environ['MOVIESCOUT_DATA'] = tmp
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'resources' / 'lib'))

passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', tmp + '/k.pem', '-out', tmp + '/c.pem', '-days', '2',
                '-subj', '/CN=localhost'], check=True, capture_output=True)


class H(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'hallo')

    def log_message(self, *a):
        pass


srv = HTTPServer(('127.0.0.1', 8951), H)
ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ctx.load_cert_chain(tmp + '/c.pem', tmp + '/k.pem')
srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
threading.Thread(target=srv.serve_forever, daemon=True).start()

from kodi_runtime import xbmcaddon      # noqa: E402
import multiquest                       # noqa: E402

URL = 'https://127.0.0.1:8951/'


def get(**kw):
    try:
        return multiquest.get(URL, timeout=8, **kw).text
    except Exception as e:              # noqa: BLE001
        return 'FEHLER ' + type(e).__name__


check('Standard: Prüfung an, selbstsigniertes Zertifikat wird abgelehnt', get().startswith('FEHLER'))
check('Schalter aus: no_verify=True hilft nicht', get(no_verify=True).startswith('FEHLER'))
check('Schalter aus: verify=False hilft nicht', get(verify=False).startswith('FEHLER'))
xbmcaddon.save_settings({'verify.peer': 'true'})
check('Schalter an, aber Aufruf verlangt nichts: Prüfung bleibt', get().startswith('FEHLER'))
check('Schalter an + no_verify=True: Antwort kommt', get(no_verify=True) == 'hallo', get(no_verify=True))
check('Schalter an + verify=False: Antwort kommt', get(verify=False) == 'hallo')
xbmcaddon.save_settings({'verify.peer': 'false'})
check('Schalter wieder aus: wieder abgelehnt', get(no_verify=True).startswith('FEHLER'))

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
