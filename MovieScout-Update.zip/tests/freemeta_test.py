# -*- coding: utf-8 -*-
"""Kostenlose Filminfos (Wikipedia, IMDb, Rotten Tomatoes, Moviepilot, Filmstarts) und „Meine Bibliothek“ - mit Beispielseiten, ohne Netz.

    python tests/freemeta_test.py
"""
import json
import os
import sys
import tempfile
import urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault('MOVIESCOUT_DATA', tempfile.mkdtemp())
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


from kodi_runtime import paths                      # noqa: E402
paths.DATA_DIR = Path(tempfile.mkdtemp())
from engine import freemeta as FM, metadata as META, mylib as ML    # noqa: E402


def ld(obj):
    return '<html><script type="application/ld+json">%s</script></html>' % json.dumps(obj)


PAGES = {
    'de.wikipedia.org/w/api.php': json.dumps({'query': {'search': [{'title': 'Matrix (Film)'}]}}),
    'rest_v1/page/summary/Matrix_%28Film%29': json.dumps({'description': 'US-amerikanischer Science-Fiction-Film von 1999', 'extract': 'Ein Hacker entdeckt die Wahrheit.',
                                                       'thumbnail': {'source': 'https://upload/x.jpg'}, 'content_urls': {'desktop': {'page': 'https://de.wikipedia.org/wiki/Matrix_(Film)'}}}),
    'v3.sg.media-imdb.com/suggestion': json.dumps({'d': [{'id': 'tt0133093', 'l': 'Matrix', 'y': 1999, 'qid': 'movie', 'i': {'imageUrl': 'https://img/m.jpg'}, 's': 'Keanu Reeves, Laurence Fishburne'},
                                                          {'id': 'tt9999999', 'l': 'Matrix', 'y': 2003, 'qid': 'tvSeries'}]}),
    'imdb.com/title/tt0133093': ld({'@type': 'Movie', 'name': 'Matrix', 'duration': 'PT2H16M', 'contentRating': 'R', 'description': 'A hacker...', 'genre': ['Action'],
                                    'aggregateRating': {'ratingValue': 8.7, 'bestRating': 10, 'ratingCount': 2000000}}),
    'rottentomatoes.com/search': '<a href="https://www.rottentomatoes.com/m/the_matrix_reloaded">x</a><a href="https://www.rottentomatoes.com/m/matrix">y</a>',
    'rottentomatoes.com/m/matrix': ld({'@type': 'Movie', 'name': 'Matrix', 'aggregateRating': {'ratingValue': '83', 'bestRating': '100', 'ratingCount': 300}}),
    'moviepilot.de/suche': '<a href="/movies/matrix">Matrix</a>',
    'moviepilot.de/movies/matrix': ld({'@type': 'Movie', 'name': 'Matrix', 'aggregateRating': {'ratingValue': 7.9, 'bestRating': 10, 'ratingCount': 900}}),
    'filmstarts.de/suche': '<a href="/kritiken/20754.html">Matrix</a>',
    'filmstarts.de/kritiken/20754': '<html><title>Matrix - Film 1999 - FILMSTARTS.de</title><span class="stareval-note"> 4,5 </span><span class="stareval-note">4,3</span></html>',
}
CALLS = []


def fake_get(url, accept=''):
    CALLS.append(url)
    for k, v in PAGES.items():
        if k in url:
            if v is None:
                raise urllib.error.HTTPError(url, 503, 'x', {}, None)
            return v
    raise urllib.error.URLError('unbekannt ' + url)


FM._get = fake_get
FM._C.clear() if hasattr(FM._C, 'clear') else None

print('JSON-LD')
check('Movie gefunden', FM.jsonld(ld({'@graph': [{'@type': 'WebSite'}, {'@type': ['Movie'], 'name': 'X', 'aggregateRating': {'ratingValue': 5}}]})).get('name') == 'X')
check('leer ohne JSON-LD', FM.jsonld('<html></html>') == {})
check('Dauer', FM._minutes('PT2H16M') == 136 and FM._minutes('PT95M') == 95)

print('Zusammenfassung')
r = FM.lookup('Matrix', 1999, False)
srcs = {x['src']: x for x in r['ratings']}
check('vier Bewertungen', set(srcs) == {'imdb', 'rt', 'moviepilot', 'filmstarts'}, str(sorted(srcs)))
check('IMDb 8,7/10', srcs['imdb']['text'] == '8,7/10' and srcs['imdb']['score'] == 8.7, str(srcs.get('imdb')))
check('RT in Prozent', srcs['rt']['text'] == '83 %' and srcs['rt']['score'] == 8.3, str(srcs.get('rt')))
check('RT nimmt den passenden Link, nicht Reloaded', 'm/matrix' in srcs['rt']['url'] and 'reloaded' not in srcs['rt']['url'])
check('Moviepilot', srcs['moviepilot']['score'] == 7.9)
check('Filmstarts von 5 auf 10', srcs['filmstarts']['score'] == 9.0 and srcs['filmstarts']['text'].endswith('/5'), str(srcs.get('filmstarts')))
check('Beschreibung deutsch von Wikipedia', r['plot'].startswith('Ein Hacker'))
check('Poster, Länge, Besetzung von IMDb', r['poster'] == 'https://img/m.jpg' and r['runtime'] == 136 and r['cast'][0]['name'] == 'Keanu Reeves')
check('Serie (tvSeries) wird für Film nicht genommen', r['imdb'] == 'tt0133093')
n = len(CALLS)
FM.lookup('Matrix', 1999, False)
check('zweiter Aufruf kommt aus dem Zwischenspeicher', len(CALLS) == n)
a = FM.ratings_only('Matrix', 1999, False)
check('Durchschnitt', a['avg'] == round((8.7 + 8.3 + 7.9 + 9.0) / 4, 1), str(a['avg']))

print('Ausfälle')
PAGES['imdb.com/title/tt0133093'] = None
PAGES['rottentomatoes.com/search'] = None
FM._C.clear()
r = FM.lookup('Matrix', 1999, False)
check('IMDb-Seite 503: Suchdaten bleiben, Bewertung fehlt', r['cast'] and not any(x['src'] == 'imdb' for x in r['ratings']))
check('RT-Ausfall wird gemeldet, Rest läuft', r['errors'].get('rt') == 'HTTP 503' and any(x['src'] == 'moviepilot' for x in r['ratings']), str(r['errors']))
check('Unbekannter Titel: nichts erfunden', FM.lookup('Gibtsnicht Xyz', 0, False)['ratings'] == [])

print('Ohne TMDb-Schlüssel nutzt metadata die freien Quellen')
PAGES['imdb.com/title/tt0133093'] = ld({'@type': 'Movie', 'duration': 'PT2H16M', 'contentRating': 'FSK 16'})
FM._C.clear()
META._key = lambda: ''
m = META.lookup({'title': 'Matrix (1999)', 'year': 1999})
check('Quelle "frei", Beschreibung/Länge/Poster', m['source'] == 'frei' and m['plot'].startswith('Ein Hacker') and m['runtime'] == 136 and m['poster'], str(m))
check('FSK aus "FSK 16" gelesen', m['fsk'] == '16', repr(m.get('fsk')))
m2 = META.lookup({'title': 'Matrix', 'plot': 'Eigene Beschreibung'})
check('Beschreibung der Quelle hat Vorrang', m2['plot'] == 'Eigene Beschreibung')

print('Abschalten')
from kodi_runtime import xbmcaddon
xbmcaddon.save_settings({'meta.free': 'aus'})
n = len(CALLS)
check('Aus: keine Abfrage, keine Bewertungen', FM.lookup('Anderer', 2000, False) == {} and FM.ratings_only('Anderer', 2000, False).get('off') and len(CALLS) == n)
xbmcaddon.save_settings({'meta.free': 'an'})
check('An: wieder aktiv', FM.enabled())

print('Meine Bibliothek')
it = {'title': 'Matrix', 'year': 1999, 'tmdb': 603, 'poster': 'p.jpg'}
check('Schlüssel aus TMDB-Nummer', ML.key_of(it) == 'tmdb:603')
check('Schlüssel aus Titel+Jahr, ohne Zusätze', ML.key_of({'title': 'Der Pate (1972)', 'year': 1972}) == 'titel:der pate|1972')
check('kein Titel -> kein Schlüssel', ML.key_of({}) == '')
e = ML.set_(it, {'stars': 9, 'comment': 'Top, nochmal sehenswert', 'seen': True, 'rewatch': 'ja'})
check('speichern', e['stars'] == 9 and e['seen'] and e['seen_count'] == 1 and e['rewatch'] == 'ja' and e['seen_at'] > 0)
check('lesen', ML.get(it)['comment'].startswith('Top'))
e = ML.set_({'title': 'Matrix', 'tmdb': 603}, {'stars': 15})
check('Punkte auf 10 begrenzt', e['stars'] == 10 and e['comment'])
e = ML.set_(it, {'again': True})
check('nochmal gesehen zählt hoch', e['seen_count'] == 2)
ML.mark_seen({'title': 'Alien', 'year': 1979})
check('mark_seen legt Eintrag ohne Bewertung an', ML.get({'title': 'Alien', 'year': 1979})['seen'] and ML.get({'title': 'Alien', 'year': 1979})['stars'] == 0)
ML.set_({'title': 'Alien', 'year': 1979}, {'stars': 7})
ML.mark_seen({'title': 'Alien', 'year': 1979})
check('mark_seen lässt Bewertung unberührt', ML.get({'title': 'Alien', 'year': 1979})['stars'] == 7)
L = ML.listing()
check('Liste und Statistik', L['stats']['total'] == 2 and L['stats']['rated'] == 2 and L['stats']['avg'] == 8.5, str(L['stats']))
check('Sortierung nach Bewertung', [x['title'] for x in ML.listing(sort='bewertung')['items']] == ['Matrix', 'Alien'])
check('Filter nochmal', [x['title'] for x in ML.listing('nochmal')['items']] == ['Matrix'])
check('Suche im Kommentar', len(ML.listing(q='sehenswert')['items']) == 1)
e = ML.set_(it, {'seen': False, 'stars': 0, 'comment': '', 'rewatch': ''})
check('leerer Eintrag verschwindet', e is None and ML.get(it) is None)
ML.set_(it, {'stars': 6})
exp = ML.export_data()
ML.remove('tmdb:603')
check('Sicherung zurückspielen', ML.import_data(exp) == 1 and ML.get(it)['stars'] == 6)
check('Datei kaputt -> leer statt Absturz', (paths.DATA_DIR / 'mylib.json').write_text('{kaputt') or ML.listing()['stats']['total'] == 0)
try:
    ML.set_({}, {'stars': 3}); ok = False
except ValueError:
    ok = True
check('ohne Titel: Fehler', ok)

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
