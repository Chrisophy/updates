# -*- coding: utf-8 -*-
"""Weiterschauen: Position merken, beim nächsten Start „Weiter bei …“ oder „Von vorne beginnen“, Balken in „Zuletzt gesehen“.
Braucht ffmpeg (erzeugt ein 400-s-Testvideo, VP8/WebM).

    python tests/resume_ui_test.py
"""
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
API, VID = 8961, 8962
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def serve(path):
    data = Path(path).read_bytes()

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            rng = self.headers.get('Range')
            if rng and (m := re.match(r'bytes=(\d+)-(\d*)', rng)):
                a = int(m.group(1)); b = int(m.group(2)) if m.group(2) else len(data) - 1
                b = min(b, len(data) - 1)
                self.send_response(206)
                self.send_header('Content-Range', 'bytes %d-%d/%d' % (a, b, len(data)))
                body = data[a:b + 1]
            else:
                self.send_response(200); body = data
            self.send_header('Content-Type', 'video/webm'); self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Content-Length', str(len(body))); self.end_headers()
            try:
                self.wfile.write(body)
            except OSError:
                pass

        def log_message(self, *a):
            pass
    srv = ThreadingHTTPServer(('127.0.0.1', VID), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def main():
    tmp = tempfile.mkdtemp()
    video = tmp + '/t.webm'
    if not shutil.which('ffmpeg'):
        print('ffmpeg fehlt - Test übersprungen'); return 0
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc=size=160x90:rate=2', '-t', '400', '-c:v', 'libvpx', '-b:v', '20k',
                    '-deadline', 'realtime', '-cpu-used', '8', '-g', '20', '-an', video], check=True)
    vsrv = serve(video)
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError:
            time.sleep(.25)
    item = "{provider_id:'t', url:'x://film', title:'Testfilm', poster:''}"
    start = ("() => { const c = { item: %s, hosters: [{ name: 'Test', url: 'http://127.0.0.1:%d/t.webm', direct: true }], index: 0 };"
             " current = c; startPlayer(c, 0); }") % (item, VID)
    try:
        with sync_playwright() as p:
            b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
            pg = b.new_context(viewport={'width': 900, 'height': 600}).new_page()
            pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_selector('header.top'); pg.wait_for_timeout(600)

            pg.evaluate(start)
            pg.wait_for_function("() => { const v = document.querySelector('#player video'); return v && v.readyState >= 3 && v.currentTime > 0.5; }", timeout=30000)
            check('Erster Start: keine Rückfrage', pg.locator('.rsask').count() == 0)
            pg.evaluate("() => { const v = document.querySelector('#player video'); v.currentTime = 120; }")
            pg.wait_for_function("() => document.querySelector('#player video').currentTime >= 120.5", timeout=20000)
            pg.evaluate("() => document.querySelector('#player video').pause()")
            pg.wait_for_timeout(300)
            pos = pg.evaluate("() => posGet({provider_id:'t', url:'x://film', title:'Testfilm'})")
            check('Beim Pausieren gemerkt (~2:00 von 6:40)', pos and 119 <= pos['t'] <= 125 and 399 <= pos['d'] <= 401, pos)
            pg.evaluate("() => history.back()"); pg.wait_for_timeout(500)
            check('Player geschlossen', pg.locator('#player').count() == 0)

            # „Zuletzt gesehen“ zeigt den Balken
            pg.evaluate("() => { refreshView(); }"); pg.wait_for_timeout(500)
            bar = pg.evaluate("() => { const b = document.querySelector('[data-sec=hist] .rsbar b'); return b ? b.style.width : ''; }")
            check('Balken in „Zuletzt gesehen“ (~30 %)', bar and 28 <= float(bar.rstrip('%')) <= 32, bar)

            # Zweiter Start: Rückfrage, Weiter
            pg.evaluate(start)
            pg.wait_for_selector('.rsask', timeout=30000)
            txt = pg.locator('.rsask').inner_text()
            check('Rückfrage nennt die Stelle und bietet beide Wege', '2:0' in txt and 'Weiter bei' in txt and 'Von vorne beginnen' in txt, txt)
            check('Video steht, bis man wählt', pg.evaluate("() => document.querySelector('#player video').paused"))
            pg.get_by_role('button', name=re.compile('Weiter bei')).click()
            pg.wait_for_function("() => { const v = document.querySelector('#player video'); return !v.paused && v.currentTime > 118; }", timeout=20000)
            check('„Weiter bei“: Video läuft ab ~2:00', pg.evaluate("() => document.querySelector('#player video').currentTime") < 135)
            check('Rückfrage weg', pg.locator('.rsask').count() == 0)
            pg.evaluate("() => history.back()"); pg.wait_for_timeout(500)

            # Fernbedienung: die Rückfrage gehört den Tasten (OK/Pfeile dürfen das Video dahinter nicht steuern)
            pg.evaluate(start)
            pg.wait_for_selector('.rsask', timeout=30000)
            inask = "() => !!document.activeElement && !!document.activeElement.closest('.rsask')"
            check('Fernbedienung: erster Knopf ist markiert', pg.evaluate(inask))
            t0 = pg.evaluate("() => document.querySelector('#player video').currentTime")
            pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(150)
            check('Pfeil rechts: wandert zu „Von vorne beginnen“', 'Von vorne' in pg.evaluate("() => document.activeElement.textContent"))
            pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(150)
            check('Pfeil rechts am Ende: springt zurück zu „Weiter bei“', 'Weiter bei' in pg.evaluate("() => document.activeElement.textContent"))
            pg.keyboard.press('ArrowDown'); pg.keyboard.press('ArrowUp'); pg.wait_for_timeout(150)
            check('Pfeile bleiben in der Rückfrage (kein Sprung zur Leiste dahinter)', pg.evaluate(inask))
            check('Pfeile spulen das Video nicht und starten es nicht', pg.evaluate("() => { const v = document.querySelector('#player video'); return v.paused && Math.abs(v.currentTime - %s) < 1; }" % t0))
            pg.evaluate("() => document.activeElement.blur()")
            pg.keyboard.press('Enter'); pg.wait_for_timeout(200)
            check('OK ohne Markierung: holt den Fokus zurück, startet das Video nicht', pg.evaluate(inask) and pg.evaluate("() => document.querySelector('#player video').paused"))
            pg.keyboard.press('Enter')
            pg.wait_for_function("() => { const v = document.querySelector('#player video'); return !v.paused && v.currentTime > 118; }", timeout=20000)
            check('OK auf „Weiter bei“: Rückfrage weg, Video läuft ab ~2:00', pg.locator('.rsask').count() == 0 and pg.evaluate("() => document.querySelector('#player video').currentTime") < 140)
            pg.evaluate("() => history.back()"); pg.wait_for_timeout(500)

            # Dritter Start: von vorne
            pg.evaluate(start)
            pg.wait_for_selector('.rsask', timeout=30000)
            pg.get_by_role('button', name='Von vorne beginnen').click()
            pg.wait_for_function("() => { const v = document.querySelector('#player video'); return !v.paused && v.currentTime > 0.3; }", timeout=20000)
            check('„Von vorne“: Video startet bei 0', pg.evaluate("() => document.querySelector('#player video').currentTime") < 20)
            check('„Von vorne“: alte Stelle vergessen', pg.evaluate("() => { const e = posGet({provider_id:'t', url:'x://film', title:'Testfilm'}); return !e || e.t < 30; }"))
            pg.evaluate("() => history.back()"); pg.wait_for_timeout(500)

            # fast am Ende: gilt als gesehen
            pg.evaluate("() => posPut({provider_id:'t', url:'x://film', title:'Testfilm'}, 395, 400)")
            check('Fast zu Ende: Position gelöscht', pg.evaluate("() => posGet({provider_id:'t', url:'x://film', title:'Testfilm'})") is None)
            # Verlauf löschen räumt auf
            pg.evaluate("() => posPut({provider_id:'t', url:'x://film', title:'Testfilm'}, 100, 400)")
            pg.evaluate("() => histRemove(store.get('hist', [])[0].item)")
            check('Aus dem Verlauf entfernt: Position auch weg', pg.evaluate("() => posGet({provider_id:'t', url:'x://film', title:'Testfilm'})") is None)
            b.close()
    finally:
        srv.terminate(); vsrv.shutdown()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
