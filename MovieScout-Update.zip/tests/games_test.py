# -*- coding: utf-8 -*-
"""Test der Spiele-Gadgets (Tetris, Filmquiz, Pong im Netzwerk) mit echter Engine und Browser.

    python tests/games_test.py
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from datetime import date
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8896
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=30) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=8, step=0.1):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def setv(ext, **values):
    return http('/api/admin/ext/settings', {'ext': ext, 'values': values})[0]


def code_of(gid):
    from engine import examples as EXM
    return next(e for e in EXM.EXAMPLES if e['id'] == gid)['code']


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_games_'))
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)
        for gid in ('tetris', 'quiz', 'pong'):
            code, js = http('/api/admin/examples/install', {'id': gid})
            check('%s installiert' % gid, code == 200 and js.get('ok'), (code, js))
        lst = http('/api/admin/list?kind=extension')[1]
        rows = {r['file']: r for r in (lst if isinstance(lst, list) else lst.get('files') or lst.get('items') or [])}
        check('alle drei geladen, ohne Fehler', all(f + '.py' in rows and not (rows[f + '.py'].get('info') or {}).get('error') for f in ('tetris', 'quiz', 'pong')),
              {k: (v.get('info') or {}).get('error') for k, v in rows.items()})

        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            br = pw.chromium.launch()

            # ------------------------------------------------------------------ Tetris
            print('Tetris')
            pg = br.new_page(viewport={'width': 1000, 'height': 800})
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(BASE + '/api/x/tetris/index')
            pg.wait_for_function('window.TT && TT.state()')
            ev = pg.evaluate
            check('Spielfeld 10x20, Stein oben in der Mitte', ev('TT.state().b.length') == 20 and ev('TT.state().b[0].length') == 10 and ev('TT.state().p.y') <= 1)
            check('Vier Mal drehen = Ausgangsform', ev('(()=>{let m=TT.SHAPES[3];const s=JSON.stringify(m);for(let i=0;i<4;i++)m=TT.rotate(m);return JSON.stringify(m)===s})()') is True)
            check('Wände und Boden werden erkannt', ev('(()=>{const g=TT.newGame();const m=[[1]];return [TT.collide(g.b,m,-1,0),TT.collide(g.b,m,10,0),TT.collide(g.b,m,0,20),TT.collide(g.b,m,0,19)].join()})()') == 'true,true,true,false')
            check('Volle Reihe wird entfernt und gibt 100 Punkte (Stufe 1)', ev("""(()=>{const g=TT.newGame(()=>0.3);g.b[19]=Array(10).fill(1);for(let i=3;i<7;i++)g.b[19][i]=0;
                g.p={k:1,m:[[1,1,1,1]],x:3,y:10};TT.hardDrop(g);return JSON.stringify([g.lines,g.score>=100,g.b[19].filter(v=>v).length])})()""") == '[1,true,0]')
            check('Spiel endet, wenn der nächste Stein nicht mehr passt', ev('(()=>{const g=TT.newGame();for(let y=0;y<20;y++){g.b[y]=Array(10).fill(1);g.b[y][0]=0};TT.tick(g);g.p.y=0;return TT.collide(g.b,g.p.m,g.p.x,0)})()') is True)
            x0 = ev('TT.state().p.x')
            pg.keyboard.press('ArrowLeft')
            check('Pfeil links bewegt den Stein', ev('TT.state().p.x') == x0 - 1)
            m0 = ev('JSON.stringify(TT.state().p.m)')
            pg.keyboard.press('ArrowUp')
            k = ev('TT.state().p.k')
            check('Pfeil hoch dreht den Stein (außer beim Quadrat)', k == 2 or ev('JSON.stringify(TT.state().p.m)') != m0)
            pg.keyboard.press('Escape')
            check('Zurück = Pause, Anzeige sichtbar', ev('TT.state().paused') is True and pg.locator('#msg.on').count() == 1)
            y1 = ev('TT.state().p.y')
            time.sleep(1.0)
            check('In der Pause fällt nichts', ev('TT.state().p.y') == y1)
            pg.keyboard.press('Escape')
            check('Zweites Zurück setzt fort', ev('TT.state().paused') is False)
            y2 = ev('TT.state().p.y')
            pg.keyboard.press('Enter')
            check('OK lässt den Stein fallen (neuer Stein oben, Punkte > 0)', ev('TT.state().p.y') <= 1 and ev('TT.state().score') > 0)
            ev('(()=>{const g=TT.state();for(let y=2;y<20;y++){g.b[y]=Array(10).fill(1);g.b[y][0]=0}})()')
            for _ in range(6):
                pg.keyboard.press('Enter')
                if ev('TT.state().over'):
                    break
            check('Game Over wird angezeigt', ev('TT.state().over') is True and 'Game Over' in pg.inner_text('#msg'))
            check('Rekord wurde gespeichert', wait(lambda: 'tetris' in http('/api/x/tetris/punkte')[1]), http('/api/x/tetris/punkte')[1])
            pg.keyboard.press('Enter')
            check('OK startet neu', ev('TT.state().over') is False and ev('TT.state().score') == 0)
            check('Keine Skriptfehler (Tetris)', not errs, errs)
            tc = br.new_context(has_touch=True, viewport={'width': 400, 'height': 800})
            tp = tc.new_page()
            tp.goto(BASE + '/api/x/tetris/index')
            tp.wait_for_function('window.TT && TT.state()')
            check('Touch: Knöpfe sichtbar', tp.is_visible('#pad button[data-k="left"]'))
            x0 = tp.evaluate('TT.state().p.x')
            tp.tap('#pad button[data-k="right"]')
            check('Touch: Knopf ▶ bewegt', tp.evaluate('TT.state().p.x') == x0 + 1)
            sw = """([dx,dy])=>{const w=document.getElementById('wrap');const mk=(x,y)=>new Touch({identifier:1,target:w,clientX:x,clientY:y});
              const a=mk(100,200),b=mk(100+dx,200+dy);w.dispatchEvent(new TouchEvent('touchstart',{touches:[a],changedTouches:[a],bubbles:true}));
              if(dx){w.dispatchEvent(new TouchEvent('touchmove',{touches:[b],changedTouches:[b],bubbles:true,cancelable:true}))}
              w.dispatchEvent(new TouchEvent('touchend',{touches:[],changedTouches:[b],bubbles:true}))}"""
            x0 = tp.evaluate('TT.state().p.x')
            tp.evaluate(sw, [-120, 0])
            check('Touch: nach links ziehen bewegt', tp.evaluate('TT.state().p.x') < x0)
            s0 = tp.evaluate('TT.state().score')
            tp.evaluate(sw, [0, 160])
            check('Touch: nach unten wischen lässt fallen', tp.evaluate('TT.state().score') > s0)
            tc.close()
            pg.close()

            # ------------------------------------------------------------------ Quiz
            print('Filmquiz')
            ns = {}
            exec(code_of('quiz'), ns)
            F = ns['FRAGEN']
            check('Mindestens 40 Fragen, je 4 verschiedene Antworten, keine doppelten Fragen', len(F) >= 40 and all(len(q) == 5 and len(set(q[1:])) == 4 for q in F) and len({q[0] for q in F}) == len(F), len(F))
            r = ns['runde'](10)
            check('Runde: 10 Fragen, Index der richtigen Antwort stimmt', len(r) == 10 and all(len(q['a']) == 4 and 0 <= q['r'] < 4 for q in r))
            lookup = {q[0]: q[1] for q in F}
            check('... und zeigt wirklich auf die richtige Antwort', all(q['a'][q['r']] == lookup[q['f']] for q in r))
            e = ns['eigene']('Wie heißt Opas Hund; Waldi; Rex; Bello\nKaputt; nur eine\n;;;\nA; b; c; d; e; f')
            check('Eigene Fragen: gültige Zeilen übernommen (2 bis 5 Felder), Unsinn übersprungen', len(e) == 2 and e[0][0] == 'Wie heißt Opas Hund' and len(e[1]) == 5, e)
            check('Nur eigene Fragen', all(q['f'] in ('Wie heißt Opas Hund', 'A') for q in ns['runde'](10, e, True)) and len(ns['runde'](10, e, True)) == 2)
            code, js = http('/api/x/quiz/fragen')
            check('Route liefert 10 Fragen und die Zeit', code == 200 and len(js['fragen']) == 10 and js['zeit'] == 15, js if code != 200 else '')
            setv('quiz', anzahl=4, eigene='Wie heißt Opas Hund; Waldi; Rex; Bello', nur_eigene=True)
            js = http('/api/x/quiz/fragen')[1]
            check('Einstellungen wirken (4 Fragen angefordert, nur 1 eigene vorhanden)', len(js['fragen']) == 1 and js['fragen'][0]['f'] == 'Wie heißt Opas Hund', js)
            setv('quiz', anzahl=10, eigene='', nur_eigene=False)
            qp = br.new_page(viewport={'width': 1000, 'height': 800})
            qerr = []
            qp.on('pageerror', lambda e: qerr.append(str(e)))
            fake = {'zeit': 15, 'fragen': [{'f': 'Frage %d' % i, 'a': ['richtig', 'falsch A', 'falsch B', 'falsch C'], 'r': 0} for i in range(3)]}
            qp.route('**/api/x/quiz/fragen', lambda r_: r_.fulfill(status=200, content_type='application/json', body=json.dumps(fake)))
            qp.goto(BASE + '/api/x/quiz/index')
            qp.wait_for_selector('#ans button')
            qev = qp.evaluate
            check('Seite zeigt Frage 1/3 mit 4 Antworten', 'Frage 1/3' in qp.inner_text('#pr') and qp.locator('#ans button').count() == 4)
            qp.keyboard.press('ArrowDown')
            check('Pfeil runter wählt die dritte Antwort, rechts die zweite', qev('QZ.state().sel') == 2)
            qp.keyboard.press('ArrowRight')
            check('Pfeil rechts wechselt in die Nachbarspalte', qev('QZ.state().sel') == 3)
            qp.keyboard.press('1')
            check('Ziffer 1 antwortet sofort (richtig)', qev('QZ.state().locked') is True and qev('QZ.state().right') == 1 and qp.locator('#ans button.r').count() == 1)
            sc1 = qev('QZ.state().score')
            check('Punkte 100-150 (schnell = mehr)', 140 <= sc1 <= 150, sc1)
            qp.keyboard.press('Enter')
            check('OK geht zur nächsten Frage', qev('QZ.state().i') == 1 and qev('QZ.state().locked') is False)
            qp.keyboard.press('ArrowRight')
            qp.keyboard.press('Enter')
            check('Falsche Antwort: rot markiert, richtige grün, keine Punkte', qp.locator('#ans button.w').count() == 1 and qp.locator('#ans button.r').count() == 1 and qev('QZ.state().score') == sc1)
            qp.keyboard.press('Enter')
            qp.tap('#ans button:nth-child(1)') if False else qp.click('#ans button:nth-child(1)')
            check('Antippen/Anklicken funktioniert', qev('QZ.state().locked') is True and qev('QZ.state().right') == 2)
            qp.keyboard.press('Enter')
            qp.wait_for_selector('#end', state='visible')
            check('Ende: "2 von 3 richtig" und Punkte', '2 von 3' in qp.inner_text('#et') and qp.inner_text('#es').startswith(str(qev('QZ.state().score'))))
            check('Rekord gespeichert und angezeigt', wait(lambda: http('/api/x/quiz/punkte')[1].get('quiz', -1) >= 280) and ('Rekord' in qp.inner_text('#er') or 'Neuer' in qp.inner_text('#er')), (http('/api/x/quiz/punkte')[1], qp.inner_text('#er')))
            qp.keyboard.press('Enter')
            qp.wait_for_selector('#ans button')
            check('OK startet eine neue Runde', qev('QZ.state().i') == 0 and qev('QZ.state().score') == 0)
            check('Keine Skriptfehler (Quiz)', not qerr, qerr)
            qp.close()

            # ------------------------------------------------------------------ Pong
            print('Pong')
            ns = {}
            exec(code_of('pong'), ns)
            B, H, PX = ns['B'], ns['H'], ns['PX']
            st = ns['neu']()
            st['ball'], st['v'], st['pad'] = [PX + 40, 250.0], [-400.0, 0.0], [0.5, 0.5]
            r1 = None
            for _ in range(30):
                r1 = ns['schritt'](st, 1 / 60)
                if st['v'][0] > 0:
                    break
            check('Physik: Ball trifft den linken Schläger und fliegt zurück, schneller', st['v'][0] > 400 and r1 is None, st['v'])
            st = ns['neu']()
            st['ball'], st['v'], st['pad'] = [PX + 40, 250.0], [-400.0, 0.0], [0.05, 0.5]
            res = None
            for _ in range(60):
                res = ns['schritt'](st, 1 / 60)
                if res:
                    break
            check('Physik: Daneben = Punkt für rechts', res == 'punkt' and st['score'] == [0, 1] and st['serve'] == -1, (res, st['score']))
            st['score'] = [0, 6]
            st['ball'], st['v'] = [PX + 40, 250.0], [-400.0, 0.0]
            for _ in range(60):
                res = ns['schritt'](st, 1 / 60, 7)
                if res:
                    break
            check('Physik: siebter Punkt beendet das Spiel', res == 'ende' and st['score'][1] == 7)
            st = ns['neu']()
            st['ball'], st['v'] = [400.0, 12.0], [0.0, -300.0]
            ns['schritt'](st, 0.1)
            check('Physik: Oberer Rand wirft den Ball zurück', st['v'][1] > 0 and st['ball'][1] >= 10)
            s2 = ns['neu']()
            s2['seats'] = {'links': {'name': 'A', 'token': 't', 'last': 0, 'bot': False}, 'rechts': {'name': 'Computer', 'token': '', 'last': 0, 'bot': True}}
            s2['status'] = 'laeuft'
            ns['_aufraeumen'](s2, 1000.0)
            check('Schweigendes Gerät verliert nach 10 s den Platz; Computer allein spielt nicht weiter', s2['seats'] == {'links': None, 'rechts': None} and s2['status'] == 'wartet', s2['seats'])

            P = '/api/x/pong/'
            setv('pong', ziel=2, tempo=3)
            check('Anfangs sind beide Plätze frei', http(P + 'zustand')[1]['frei'] == ['links', 'rechts'] and http(P + 'zustand')[1]['status'] == 'wartet')
            check('Nur per POST', http(P + 'beitreten')[0] == 405)
            a = http(P + 'beitreten', {'name': 'Anna'})[1]
            check('Anna bekommt links', a.get('platz') == 'links' and a.get('token'), a)
            w = [x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'pong']
            check('Kachel: "Anna wartet"', w and 'Anna' in w[0]['text'], w)
            b = http(P + 'beitreten', {'name': 'Anna'})[1]
            check('Zweite Anna wird umbenannt und bekommt rechts', b.get('platz') == 'rechts' and b.get('name') != 'Anna', b)
            check('Dritter Beitritt: Plätze besetzt (409)', http(P + 'beitreten', {'name': 'Zoe'})[0] == 409)
            check('Falscher Token: abgewiesen', http(P + 'tick', {'platz': 'links', 'token': 'falsch', 'y': 0.2})[1] == {'error': 'weg'})
            stop = {'x': False}

            def ticks():
                http(P + 'tick', {'platz': 'links', 'token': a['token'], 'y': 0.0})
                return http(P + 'tick', {'platz': 'rechts', 'token': b['token'], 'y': 0.0})[1]
            s = ticks()
            check('Beide da: Countdown läuft ("start")', s['status'] in ('start', 'wartet') and wait(lambda: ticks()['status'] == 'start', 3, 0.05), s)
            check('Nach 3 s läuft das Spiel', wait(lambda: ticks()['status'] == 'laeuft', 6, 0.05))
            ball0 = ticks()['ball']
            time.sleep(0.15)
            ball1 = ticks()['ball']
            check('Ball bewegt sich', ball0 != ball1, (ball0, ball1))
            ok = wait(lambda: ticks()['status'] == 'ende', 40, 0.03)
            fin = ticks()
            check('Spiel endet bei 2 Punkten (Schläger beider Spieler ganz oben -> Ball geht vorbei)', ok and max(fin['score']) == 2, fin)
            check('Sieger steht fest und die Siegerliste zählt', fin['sieger'] in ('Anna', b['name']) and http(P + 'siege')[1].get(fin['sieger']) == 1, (fin, http(P + 'siege')[1]))
            http(P + 'nochmal', {'platz': 'links', 'token': a['token']})
            check('Revanche: Punkte zurück auf 0, es geht von vorn los', wait(lambda: ticks()['score'] == [0, 0] and ticks()['status'] in ('start', 'laeuft'), 5, 0.05))
            http(P + 'verlassen', {'platz': 'rechts', 'token': b['token']})
            check('Verlassen gibt den Platz frei und stoppt das Spiel', wait(lambda: 'rechts' in http(P + 'zustand')[1]['frei'] and http(P + 'zustand')[1]['status'] == 'wartet', 4))
            check('Computer-Gegner: Platz wird mit "Computer" besetzt', http(P + 'computer', {'platz': 'links', 'token': a['token']})[1].get('ok') and wait(lambda: http(P + 'zustand')[1]['namen'][1] == 'Computer', 3))
            ok = wait(lambda: http(P + 'tick', {'platz': 'links', 'token': a['token'], 'y': 0.0})[1]['status'] == 'laeuft', 8, 0.05)
            check('... und nach dem Countdown spielt der Computer mit', ok)
            pads = set()
            for _ in range(25):
                pads.add(round(http(P + 'tick', {'platz': 'links', 'token': a['token'], 'y': 0.0})[1]['pad'][1], 2))
                time.sleep(0.05)
            check('Der Computer bewegt seinen Schläger', len(pads) > 1, pads)
            http(P + 'verlassen', {'platz': 'links', 'token': a['token']})

            # Browser: zwei Geräte
            c1, c2 = br.new_context(viewport={'width': 900, 'height': 700}), br.new_context(viewport={'width': 900, 'height': 700}, has_touch=True)
            p1, p2 = c1.new_page(), c2.new_page()
            perr = []
            for x in (p1, p2):
                x.on('pageerror', lambda e: perr.append(str(e)))
                x.goto(BASE + '/api/x/pong/index')
            p1.fill('#nm', 'Papa')
            p1.click('#bj')
            p2.fill('#nm', 'Kind')
            p2.click('#bj')
            p1.wait_for_function('PG.state().me && PG.state().st && PG.state().st.namen[1] === "Kind"')
            check('Zwei Browser: links "Papa", rechts "Kind"', p1.evaluate('PG.state().me.platz') == 'links' and p2.evaluate('PG.state().me.platz') == 'rechts' and p1.inner_text('#n1') == 'Kind')
            p1.keyboard.down('ArrowUp')
            time.sleep(0.4)
            p1.keyboard.up('ArrowUp')
            check('Fernbedienung: Pfeil hoch bewegt den Schläger nach oben', p1.evaluate('PG.state().y') < 0.5)
            wait(lambda: http(P + 'zustand')[1]['pad'][0] < 0.45, 3)
            check('... und der Server hat es übernommen', http(P + 'zustand')[1]['pad'][0] < 0.45, http(P + 'zustand')[1]['pad'])
            p2.evaluate("""()=>{const w=document.getElementById('cvw');const r=w.getBoundingClientRect();const t=new Touch({identifier:1,target:w,clientX:r.left+50,clientY:r.top+r.height*0.9});
              w.dispatchEvent(new TouchEvent('touchstart',{touches:[t],changedTouches:[t],bubbles:true}))}""")
            wait(lambda: http(P + 'zustand')[1]['pad'][1] > 0.8, 3)
            check('Touch: Finger auf dem Feld setzt den Schläger dorthin', http(P + 'zustand')[1]['pad'][1] > 0.8, http(P + 'zustand')[1]['pad'])
            sp = br.new_page()
            sp.goto(BASE + '/api/x/pong/index')
            sp.wait_for_function('PG.state().st && PG.state().st.namen[0] === "Papa"')
            check('Zuschauer sieht beide Namen ohne mitzuspielen', sp.evaluate('PG.state().me') is None and sp.inner_text('#n1') == 'Kind')
            p1.keyboard.press('Escape')
            check('Zurück: Papa verlässt das Spiel, Platz wird frei', wait(lambda: 'links' in http(P + 'zustand')[1]['frei'], 4))
            check('Keine Skriptfehler (Pong)', not perr, perr)
            c1.close()
            c2.close()
            sp.close()
            br.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except subprocess.TimeoutExpired:
            p.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
