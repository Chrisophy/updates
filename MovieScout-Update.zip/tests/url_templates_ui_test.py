# -*- coding: utf-8 -*-
"""Vorlagen in den Adress-Feldern (System-Update, GitHub-Ordner Scraper/Erweiterungen): vorgegeben, änderbar, eigene Werte bleiben,
unberührte Vorlagen schalten nichts ungefragt ein; Erweiterungen lassen sich wie Scraper aus einem Ordner/Link laden.

    python tests/url_templates_ui_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT, SRV = 8928, 8929
API = 'http://127.0.0.1:%d' % PORT
passed = failed = 0
UPD = 'https://github.com/Chrisophy/updates/raw/main/MovieScout-Update.zip'
SCR = 'https://github.com/Chrisophy/scraper'
GAD = 'https://github.com/Chrisophy/gadgets'


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def call(path, body=None):
    req = urllib.request.Request(API + path, data=json.dumps(body).encode() if body is not None else None,
                                 headers={'Content-Type': 'application/json'} if body is not None else {})
    try:
        r = urllib.request.urlopen(req, timeout=60)
    except urllib.error.HTTPError as e:
        r = e
    return r.status, json.loads(r.read())


def main():
    tmp = tempfile.mkdtemp(prefix='ms_tpl_')
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, MINIKODI_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=.3).close(); break
            except OSError:
                time.sleep(.25)
        time.sleep(1)
        print('Engine')
        s, d = call('/api/settings')
        check('Vorlagen kommen mit den Einstellungen', d.get('templates') == {'update_source': UPD, 'github_repo': SCR, 'github_ext_repo': GAD}, d.get('templates'))
        check('Nichts davon ist gespeichert', not any(k in d['settings'] for k in ('update_source', 'github_repo', 'github_ext_repo')))
        s, d = call('/api/admin/update')
        check('Update-Quelle ohne eigene Angabe = Vorlage', d.get('source') == UPD, d.get('source'))
        sys.path.insert(0, str(ROOT))
        from engine import updater as U
        check('GitHub-Datei-Links werden zur Download-Adresse', U.parse_source(UPD) == ('zip', 'https://raw.githubusercontent.com/Chrisophy/updates/main/MovieScout-Update.zip') and U.parse_source('https://github.com/Chrisophy/updates/raw/refs/heads/main/MovieScout-Update.zip') == ('zip', 'https://raw.githubusercontent.com/Chrisophy/updates/refs/heads/main/MovieScout-Update.zip') and U.parse_source('https://github.com/Chrisophy/updates/MovieScout-Update.zip') == ('zip', 'https://raw.githubusercontent.com/Chrisophy/updates/HEAD/MovieScout-Update.zip'))

        tpl = call('/api/admin/templates')[1]['templates']['extension']

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                data = tpl.encode()
                self.send_response(200); self.send_header('Content-Type', 'text/plain'); self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)

            def log_message(self, *a):
                pass
        srv = HTTPServer(('127.0.0.1', SRV), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        s, d = call('/api/admin/github_sync', {'url': 'http://127.0.0.1:%d/gadget_test.py' % SRV, 'kind': 'extension'})
        check('Erweiterung über den Abgleich geladen (kind=extension)', s == 200 and d.get('kind') == 'extension' and d.get('changed') == 1, d)
        rows = call('/api/admin/list?kind=extension')[1]['items']
        check('… und liegt bei den Erweiterungen, nicht bei den Scrapern', any(r['file'] == 'gadget_test.py' for r in rows)
              and not any(r['file'] == 'gadget_test.py' for r in call('/api/admin/list?kind=provider')[1]['items']), rows)

        print('Oberfläche')
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 412, 'height': 890})
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(API + '/ui/?api=' + API); pg.wait_for_timeout(1500)

            def fields():
                return pg.evaluate("""() => { const v = (ph) => { const i = [...document.querySelectorAll('.panel input')].find((x) => x.placeholder === ph); return i ? i.value : null; };
                  return [v(%r), v(%r), v(%r)]; }""" % (UPD, SCR, GAD))
            pg.evaluate("openSettings()"); pg.wait_for_selector('.panel h2', timeout=8000); pg.wait_for_timeout(500)
            check('Alle drei Felder sind mit der Vorlage gefüllt', fields() == [UPD, SCR, GAD], fields())
            pg.get_by_role('button', name='Speichern', exact=True).click(); pg.wait_for_timeout(800)
            st = call('/api/settings')[1]['settings']
            check('Speichern ohne Änderung schaltet nichts ein (Vorlagen nicht gespeichert)', not any(k in st for k in ('update_source', 'github_repo', 'github_ext_repo')), {k: st.get(k) for k in ('update_source', 'github_repo', 'github_ext_repo')})
            pg.evaluate("openSettings()"); pg.wait_for_selector('.panel h2', timeout=8000); pg.wait_for_timeout(500)
            pg.evaluate("""() => { const i = [...document.querySelectorAll('.panel input')].find((x) => x.placeholder === %r); i.value = 'https://github.com/ich/meine-scraper'; i.dispatchEvent(new Event('input')); }""" % SCR)
            pg.evaluate("""() => { const i = [...document.querySelectorAll('.panel input')].find((x) => x.placeholder === %r); i.value = ''; i.dispatchEvent(new Event('input')); }""" % GAD)
            pg.evaluate("window.ghSyncNow = async () => {}")                       # kein echter Netzabruf im Test
            pg.get_by_role('button', name='Speichern', exact=True).click(); pg.wait_for_timeout(800)
            st = call('/api/settings')[1]['settings']
            check('Eigene Adresse wird gespeichert', st.get('github_repo') == 'https://github.com/ich/meine-scraper', st.get('github_repo'))
            check('Geleertes Feld wird als „aus“ gespeichert', st.get('github_ext_repo') == '', st.get('github_ext_repo'))
            check('Unberührte Update-Vorlage bleibt ungespeichert', 'update_source' not in st)
            pg.evaluate("openSettings()"); pg.wait_for_selector('.panel h2', timeout=8000); pg.wait_for_timeout(500)
            check('Beim nächsten Öffnen: eigene Werte statt Vorlage', fields() == [UPD, 'https://github.com/ich/meine-scraper', ''], fields())
            n = pg.evaluate("""() => { const i = [...document.querySelectorAll('.panel input')].find((x) => x.placeholder === %r);
              const btn = [...i.closest('.field').querySelectorAll('button')].find((x) => x.textContent === 'Vorlage'); btn.click(); return i.value; }""" % GAD)
            check('Knopf „Vorlage“ setzt die Vorlage wieder ein', n == GAD, n)
            check('Keine Skriptfehler', not errs, errs)
            b.close()
        srv.shutdown()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
