# -*- coding: utf-8 -*-
"""Live-TV-Sender als Liste mit EPG-Zeile (Einstellung Liste/Raster).
    python tests/imgfit_test.py"""
import os, socket, subprocess, sys, tempfile, time, base64
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8979
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAQAAAACCAYAAAB/qH1jAAAAEklEQVR4nGP4z8Dwn4GBgQEAFAAD/7s0TQAAAABJRU5ErkJggg==')
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_page(viewport={'width': 900, 'height': 700})
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (API, API)); pg.wait_for_selector('header.top'); pg.wait_for_function('typeof providers !== "undefined" && providers.length', timeout=20000)
            items = "[{title:'Das Erste', poster:'LOGO', kind:'play', live:true, now:'Tagesschau', plot:'Jetzt: Tagesschau (bis 20:15) · Danach: Wetter\\n\\nGermany'}, {title:'ZDF', poster:'LOGO', kind:'play', live:true, now:'', plot:'Germany'}, {title:'Film', poster:'LOGO', kind:'play'}]".replace('LOGO', 'data:image/png;base64,' + base64.b64encode(PNG).decode())
            pg.evaluate("(src) => { const g = document.createElement('div'); g.id = 'tg'; document.body.append(g); g.append(...itemsView(eval(src))); }", items)
            pg.wait_for_timeout(300)
            r = pg.evaluate("() => ({ rows: document.querySelectorAll('#tg .row').length, grid: document.querySelectorAll('#tg .grid').length, live: document.querySelectorAll('#tg .row.live').length, epg: [...document.querySelectorAll('#tg .epg')].map(e => e.textContent) })")
            check('Live-Sender werden als Liste gezeigt (nicht als Poster)', r['rows'] == 3 and r['grid'] == 0 and r['live'] == 2, r)
            check('Programm (Jetzt/Danach) steht direkt in der Zeile, nur die EPG-Zeile', r['epg'] == ['Jetzt: Tagesschau (bis 20:15) · Danach: Wetter'], r)
            pg.evaluate("() => { document.querySelector('#tg').remove(); applySkin(normalizeSkin({poster:{live:'grid'}})); }")
            pg.evaluate("(src) => { const g = document.createElement('div'); g.id = 'tg'; document.body.append(g); g.append(...itemsView(eval(src))); }", items)
            check('Einstellung „Poster-Raster“ bringt die Karten zurück', pg.evaluate("document.querySelectorAll('#tg .grid .card').length") == 3)
            pg.evaluate("() => applySkin(normalizeSkin({poster:{live:'bogus'}}))")
            check('Ungültiger Wert fällt auf Liste zurück', pg.evaluate("skin.cur.poster.live") == 'list')
            b.close()
    finally:
        srv.terminate()
    check('keine JS-Fehler', not errs, errs)
    print('\n%d ok, %d Fehler' % (passed, failed)); sys.exit(1 if failed else 0)
main()
