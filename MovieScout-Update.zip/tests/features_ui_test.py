# -*- coding: utf-8 -*-
"""Oberflächen-Tests (Playwright/Chromium) für: Hauptmenü beim Abspielen ausblenden, Einstellungen in Reitern, Teilen im WLAN,
System-Update, Netzwerk (DNS/Schutz), Baukasten-Knopf, Suche mit Frist.

    python tests/features_ui_test.py
"""
import io
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
UP, API, API2 = 8871, 8872, 8873
BASE = 'http://127.0.0.1:%d/ui/?api=%s' % (API, 'http://127.0.0.1:%d' % API)
passed = failed = 0

BRIDGE = """
window.__calls = [];
window.MovieScoutApp = {
  version() { return 'test'; }, keepScreenOn() {}, nativeAvailable() { return false; },
  takeIntent() { return ''; },
  backgroundEnabled() { return true; }, setBackground(v) {}, notificationsEnabled() { return true; }, setNotifications(v) {},
  notificationsAllowed() { return true; }, openNotificationSettings() {}, setNotifyPrefs(j) {},
  openExternal(u) { __calls.push(['ext', u]); return true; },
  restartApp() { __calls.push(['restart']); },
};
try { localStorage.setItem('mk.chatName', JSON.stringify('Test')); } catch (e) {}
"""

SLOW = '''# -*- coding: utf-8 -*-
import time
SITE_ID = 'slow'
SITE_NAME = 'Langsam'
SITE_DOMAIN = 'slow.test'


def load(url='', params=None):
    return [{'title': 'Nur Suche', 'url': 'x', 'next_func': 'load', 'is_playable': False}]


def search(query='', params=None):
    time.sleep(6)
    return [{'title': 'Spätes Ergebnis ' + query, 'url': 's1', 'next_func': 'get_hosters', 'is_playable': True}]


def get_hosters(title='', year='', season=0, episode=0, imdb='', tmdb='', url='', params=None):
    return []
'''


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def wait_port(port, tries=120):
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def jget(port, path, body=None):
    req = Request('http://127.0.0.1:%d%s' % (port, path), data=json.dumps(body).encode() if body is not None else None,
                  headers={'Content-Type': 'application/json'} if body is not None else {})
    with urlopen(req, timeout=30) as r:
        return json.loads(r.read())


def calls(pg):
    return pg.evaluate('window.__calls')


def tab(pg, name):
    pg.get_by_role('tab', name=name, exact=True).click()
    pg.wait_for_timeout(120)


def make_zip(version):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('VERSION', version + '\n')
        z.write(ROOT / 'main.py', 'main.py')
        for d in ('engine', 'kodi_runtime', 'providers', 'extensions', 'resources', 'static', 'system'):
            for f in sorted((ROOT / d).rglob('*')):
                if f.is_dir() or '__pycache__' in f.parts or f.suffix == '.pyc' or 'vendor' in f.relative_to(ROOT).parts:
                    continue
                z.write(f, f.relative_to(ROOT).as_posix())
    return buf.getvalue()


def run(pg, tmp):
    print('Start')
    pg.goto(BASE)
    pg.wait_for_selector('.tile')

    print('Einstellungen in Reitern')
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    tabs = pg.get_by_role('tab').all_inner_texts()
    check('Fünf Bereiche', tabs == ['Allgemein', 'Konten & Inhalte', 'Quellen & Listen', 'Netzwerk', 'System & Update'], tabs)
    check('Startet immer bei "Allgemein"', pg.get_by_role('tab', name='Allgemein').get_attribute('aria-pressed') == 'true')
    check('Allgemein: Adresse der Engine sichtbar, DNS noch nicht', pg.get_by_text('Adresse der Engine').is_visible() and not pg.get_by_text('DNS-Dienst der Engine').is_visible())
    check('Eine Seite ist deutlich kürzer als die alte Gesamtliste', pg.evaluate("document.querySelector('.panel').scrollHeight") < 2600)
    tab(pg, 'Konten & Inhalte')
    check('Konten: TMDB sichtbar, Adresse der Engine verborgen', pg.get_by_text('TMDB-API-Schlüssel').is_visible() and not pg.get_by_text('Adresse der Engine').is_visible())
    tab(pg, 'Quellen & Listen')
    check('Quellen: M3U + Stalker sichtbar', pg.get_by_text('M3U-Playlisten (IPTV)').is_visible() and pg.get_by_text('Stalker-Portale (MAG/Stalker-IPTV)').is_visible())
    tab(pg, 'Netzwerk')
    check('Netzwerk: DNS, Schutz, Quoten, Proxy', all(pg.get_by_text(t, exact=True).first.is_visible() for t in ('DNS-Dienst der Engine', 'Schutz vor Sperren', 'Quoten je Seite', 'Eigener Proxy (optional)')))
    check('Netzwerk: Stand der Hosts wird geladen', pg.locator('.panel').inner_text().find('Noch keine Anfragen') >= 0 or 'DNS:' in pg.locator('.panel').inner_text())
    check('Eigene DoH-Adresse erst bei "Eigene …"', not pg.get_by_text('Eigene DoH-Adresse', exact=True).is_visible())
    pg.locator('xpath=//div[contains(@class,"field")][.//label[text()="DNS-Dienst der Engine"]]//select').select_option('custom')
    check('... dann erscheint das Feld', pg.get_by_text('Eigene DoH-Adresse', exact=True).is_visible())
    pg.locator('xpath=//div[contains(@class,"field")][.//label[text()="DNS-Dienst der Engine"]]//select').select_option('system')
    pg.locator('.panel .field:has(label:text-is("DNS-Dienst der Engine")) .btn', has_text='Testen').click()
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('example.com')", timeout=40000)
    check('DNS-Test zeigt Ergebnis je Adresse', 'example.com' in pg.locator('.panel').inner_text())

    # Speichern: Einstellungen landen in der Engine, Freigabe-Felder bleiben unangetastet
    pg.locator('xpath=//div[contains(@class,"field")][.//label[text()="Schutz vor Sperren"]]//select').select_option('strict')
    pg.locator('.panel textarea[placeholder^="voe.sx"]').fill('voe.sx = 30/min')
    tab(pg, 'System & Update')
    pg.locator('.panel input[placeholder$="MovieScout-Update.zip"]').fill('https://github.com/x/y')
    pg.get_by_role('button', name='Speichern', exact=True).click()
    pg.wait_for_selector('.panel', state='detached')
    s = jget(API, '/api/settings')['settings']
    check('Speichern: Schutz, Quote und Update-Quelle gespeichert', s.get('net_protect') == 'strict' and s.get('net_quota') == 'voe.sx = 30/min' and s.get('update_source') == 'https://github.com/x/y', {k: s.get(k) for k in ('net_protect', 'net_quota', 'update_source')})
    # zurück auf Standard
    jget(API, '/api/settings', {'settings': {'net_protect': 'normal', 'net_quota': '', 'update_source': ''}})

    print('System & Update')
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    tab(pg, 'System & Update')
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('Läuft: Version')")
    ver = (ROOT / 'VERSION').read_text().split()[0]
    check('Update-Status zeigt die laufende Version', 'Läuft: Version ' + ver in pg.locator('.panel').inner_text(), pg.locator('.panel').inner_text()[:400])
    pg.get_by_role('button', name='Jetzt prüfen').click()
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('Keine Update-Quelle')")
    check('Prüfen ohne Quelle: klare Meldung', True)
    check('Zwischenspeicher-Übersicht ist da', 'Filminfos (TMDB)' in pg.locator('.panel').inner_text() and 'Trefferquote' in pg.locator('.panel').inner_text())
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('MovieScout belegt')", timeout=30000)
    ptxt = pg.locator('.panel').inner_text()
    check('Speicher aufräumen: Übersicht mit Gruppen und Geschütztem', 'Speicher aufräumen' in ptxt and 'Poster-Speicher' in ptxt and 'Addon-Zwischenspeicher' in ptxt and 'Wird nie automatisch gelöscht' in ptxt and 'Downloads' in ptxt, ptxt[-900:])
    pg.get_by_role('button', name='Nur Altes aufräumen').click()
    pg.wait_for_selector('text=frei gemacht')
    check('Speicher aufräumen: "Nur Altes aufräumen" läuft und meldet', True)
    pg.get_by_role('button', name='Auswahl aufräumen').click()
    pg.wait_for_selector('text=Jetzt aufräumen?')
    pg.get_by_role('button', name='Nein').click()
    pg.wait_for_timeout(250)
    check('Speicher aufräumen: Nein bricht ab', pg.get_by_role('button', name='Auswahl aufräumen').count() == 1)
    pg.get_by_role('button', name='Auswahl aufräumen').click()
    pg.get_by_role('button', name='Ja, aufräumen').click()
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('MovieScout belegt')", timeout=30000)
    check('Speicher aufräumen: Auswahl wird bereinigt', True)
    with pg.expect_file_chooser() as fc:
        pg.get_by_role('button', name='Update-ZIP wählen …').click()
    zp = Path(tmp) / 'upd.zip'
    zp.write_bytes(make_zip('98.0.1'))
    fc.value.set_files(str(zp))
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('Version 98.0.1 aus Datei installiert')", timeout=60000)
    txt = pg.locator('.panel').inner_text()
    check('Update-ZIP wird eingespielt und gemeldet', 'Wirkt nach dem Neustart' in txt, txt[:500])
    check('Hinweis "Update wartet", Knopf "Jetzt neu starten" (in der App)', 'wartet auf den Neustart' in txt and pg.get_by_role('button', name='Jetzt neu starten').count() == 1)
    pg.get_by_role('button', name='Jetzt neu starten').click()
    check('Neustart-Knopf ruft die App', ['restart'] in calls(pg), calls(pg))
    check('Rückgängig-/Zurücksetzen-Knopf erscheint', pg.get_by_role('button', name='Auf Stand der App zurücksetzen').count() == 1)
    pg.get_by_role('button', name='Auf Stand der App zurücksetzen').click()
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('Zurück auf den Stand der App')")
    check('Zurücksetzen meldet Ergebnis', True)
    pg.get_by_role('button', name='Scraper-Baukasten öffnen').click()
    ext = [c[1] for c in calls(pg) if c[0] == 'ext']
    check('Baukasten-Knopf öffnet die Seite der Engine im Browser des Geräts', ext and ext[-1].startswith('http://127.0.0.1:%d/api/x/baukasten/index' % API), ext)
    pg.go_back()
    pg.wait_for_timeout(200)

    print('Teilen im WLAN')
    check('Teilen-Knopf in der Kopfzeile', pg.locator('#btnShare').count() == 1)
    pg.click('#btnShare')
    pg.wait_for_selector('.panel')
    check('Panel: Freigabe zunächst aus', pg.get_by_role('switch', name='Freigabe im WLAN').get_attribute('aria-checked') == 'false')
    pg.get_by_role('switch', name='Freigabe im WLAN').click()
    pg.wait_for_selector('input[data-pw]')
    pw = pg.input_value('input[data-pw]')
    check('Einschalten vergibt ein Passwort', len(pw) >= 6, pw)
    st = jget(API, '/api/share/status')
    check('Engine hat Freigabe an und dasselbe Passwort', st['enabled'] and st['password'] == pw and st['role'] == 'host', st)
    check('Adresse(n) für die anderen werden gezeigt', pg.locator('.panel .field:has(label:text-is("Adresse für die anderen")) button').count() >= 1)
    pg.fill('input[data-pw]', 'MeinPasswort7')
    pg.get_by_role('button', name='Passwort übernehmen').click()
    pg.wait_for_timeout(500)
    check('Eigenes Passwort übernommen', jget(API, '/api/share/status')['password'] == 'MeinPasswort7')
    pg.fill('input[data-pw]', 'kurz')
    pg.get_by_role('button', name='Passwort übernehmen').click()
    pg.wait_for_selector('.toast.bad')
    check('Zu kurzes Passwort: Fehlermeldung', 'mindestens' in pg.locator('.toast.bad').first.inner_text())
    pg.get_by_role('switch', name='Freigabe im WLAN').click()
    pg.wait_for_timeout(500)
    check('Ausschalten', jget(API, '/api/share/status')['enabled'] is False)
    # Einstellungen speichern darf die Freigabe nicht zurücksetzen
    pg.get_by_role('switch', name='Freigabe im WLAN').click()
    pg.wait_for_timeout(400)
    pg.go_back()
    pg.wait_for_timeout(200)
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    pg.get_by_role('button', name='Speichern', exact=True).click()
    pg.wait_for_selector('.panel', state='detached')
    check('"Speichern" in den Einstellungen lässt die Freigabe unverändert', jget(API, '/api/share/status')['enabled'] is True)

    print('Mit einem anderen Gerät verbinden')
    jget(API2, '/api/admin/share', {'enabled': True, 'password': 'GastPasswort1'})
    pg.click('#btnShare')
    pg.wait_for_selector('.panel')
    form = pg.locator('.panel .field:has(label:text-is("Mit einem anderen Gerät verbinden"))')
    form.get_by_role('button', name='Verbinden').click()
    pg.wait_for_selector('.toast.bad')
    check('Ohne Adresse: Hinweis', 'Adresse' in pg.locator('.toast.bad').last.inner_text())
    form.locator('input').first.fill('127.0.0.1')
    form.locator('input').nth(1).fill('x')
    form.get_by_role('button', name='Verbinden').click()
    pg.wait_for_timeout(300)
    check('Ohne Port: Hinweis mit Beispiel', any('Port' in t for t in pg.locator('.toast.bad').all_inner_texts()), pg.locator('.toast.bad').all_inner_texts())
    form.locator('input').first.fill('127.0.0.1:%d' % API2)
    form.locator('input').nth(1).fill('falsch')
    form.get_by_role('button', name='Verbinden').click()
    pg.wait_for_timeout(700)
    check('Falsches Passwort: abgelehnt, nicht verbunden', any('falsch' in t.lower() for t in pg.locator('.toast.bad').all_inner_texts()) and pg.evaluate("JSON.parse(localStorage.getItem('mk.share_remote'))") is None)
    form.locator('input').nth(1).fill('GastPasswort1')
    form.get_by_role('button', name='Verbinden').click()
    pg.wait_for_function("localStorage.getItem('mk.share_remote') && localStorage.getItem('mk.share_remote') !== 'null'", timeout=15000)
    api_now = pg.evaluate("JSON.parse(localStorage.getItem('mk.api'))")
    check('Verbunden: die App benutzt jetzt die Engine des anderen Geräts', api_now == 'http://127.0.0.1:%d' % API2, api_now)
    check('Eigene Verbindung wurde für "Trennen" gemerkt', pg.evaluate("JSON.parse(localStorage.getItem('mk.share_home')).api") == 'http://127.0.0.1:%d' % API)
    check('Zugangszeichen statt Passwort gespeichert', pg.evaluate("JSON.parse(localStorage.getItem('mk.token'))") not in ('', 'GastPasswort1'))
    pg.wait_for_selector('.tile')
    pg.click('#btnShare')
    pg.wait_for_selector('.panel')
    check('Panel zeigt "Verbunden mit …" und "Trennen"', 'Verbunden mit' in pg.locator('.panel').inner_text() and pg.get_by_role('button', name='Trennen und zurück zum eigenen Gerät').count() == 1)
    pg.get_by_role('button', name='Trennen und zurück zum eigenen Gerät').click()
    pg.wait_for_timeout(500)
    check('Trennen: wieder die eigene Engine', pg.evaluate("JSON.parse(localStorage.getItem('mk.api'))") == 'http://127.0.0.1:%d' % API and pg.evaluate("JSON.parse(localStorage.getItem('mk.share_remote'))") is None)
    pg.wait_for_selector('.tile')

    print('Gast-Ansicht (Rolle "guest")')
    pg.route('**/api/share/status', lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps({'role': 'guest', 'enabled': True, 'name': 'Wohnzimmer'})))
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    pg.wait_for_timeout(300)
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    txt = pg.locator('.panel').inner_text()
    check('Gast: "Einstellungen" öffnet nur die Teilen-Ansicht (keine Verwaltung)', 'Teilen im WLAN' in txt and 'Adresse der Engine' not in txt and 'System-Update' not in txt and 'Zugriffstoken' not in txt, txt[:300])
    check('Gast: Abmelden-Knopf', pg.get_by_role('button', name='Abmelden').count() == 1)
    pg.unroute('**/api/share/status')
    pg.go_back()

    print('Hauptmenü beim Abspielen ausblenden')
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    check('Vorher: Kopfzeile sichtbar', pg.locator('header.top').is_visible())
    pg.evaluate("startPlayer && 0")
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    pg.evaluate("window.MovieScoutApp.takeIntent = () => JSON.stringify({kind: 'play', url: 'http://127.0.0.1:%d/nichts.m3u8', title: 'Testsender'}); window.msIntent();" % UP)
    pg.wait_for_selector('#player')
    pg.wait_for_timeout(300)
    check('Beim Abspielen: Seite hat die Markierung "playing"', pg.evaluate("document.body.classList.contains('playing')"))
    check('Kopfzeile ist ausgeblendet', not pg.locator('header.top').is_visible())
    check('Ansicht dahinter ist ausgeblendet', not pg.locator('#view').is_visible())
    check('Player ist sichtbar', pg.locator('#player').is_visible())
    pg.mouse.move(300, 300)
    pg.wait_for_timeout(200)
    pg.keyboard.press('ArrowRight')
    pg.wait_for_timeout(200)
    check('Tasten im Player (Vorspulen) stören nicht, Menü bleibt weg', not pg.locator('header.top').is_visible() and pg.locator('#player').count() == 1)
    pg.go_back()
    pg.wait_for_timeout(400)
    check('Zurück: Player weg, Markierung weg', pg.locator('#player').count() == 0 and not pg.evaluate("document.body.classList.contains('playing')"))
    check('Kopfzeile ist wieder da', pg.locator('header.top').is_visible() and pg.locator('#view').is_visible())

    print('Nächste Folge')
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    r = pg.evaluate("""() => {
      const E = (n, t) => ({ kind: 'play', provider_id: 'x', url: 'u' + n, title: t || ('Folge ' + n), season: 1, episode: n, parent_title: 'Serie' });
      nav[nav.length - 1].items = [E(3), E(1), E(2)];           // bewusst unsortiert
      const out = {};
      setPlayCtx(nav[nav.length - 1].items[1]);
      out.n1 = nextEpisode().episode;
      setPlayCtx(nav[nav.length - 1].items[0]);
      out.last = nextEpisode();
      nav[nav.length - 1].items = [{ kind: 'play', provider_id: 'x', url: 'm1', title: 'Film 1' }, { kind: 'play', provider_id: 'x', url: 'm2', title: 'Film 2' }];
      setPlayCtx(nav[nav.length - 1].items[0]);
      out.movie = playCtx;
      nav[nav.length - 1].items = [E(1), E(2)];
      setPlayCtx(nav[nav.length - 1].items[0]);
      const opened = []; window.openSources = (i) => opened.push(i.episode);
      startPlayer({ item: nav[nav.length - 1].items[0], hosters: [{ name: 'h', url: 'http://127.0.0.1:1/x.mp4' }], index: 0 }, 0);
      out.btn = !document.querySelector('#nxBtn').hidden;
      out.cfg = cfg.nextep;
      document.querySelector('video') && document.querySelector('video').dispatchEvent(new Event('ended'));
      out.opened = opened;
      return out;
    }""")
    check('Folgen werden nach Nummer sortiert: nach Folge 1 kommt 2', r['n1'] == 2, r)
    check('Nach der letzten Folge kommt keine weitere', r['last'] is None, r)
    check('Filmlisten zählen nicht als Serie', r['movie'] is None, r)
    check('Player zeigt „Nächste Folge“-Knopf', r['btn'], r)
    check('Einstellung "Nächste Folge" ist standardmäßig an', r['cfg'] is True, r)
    pg.evaluate("document.querySelector('#nxBtn').click()")
    pg.wait_for_timeout(300)
    check('Knopf startet die nächste Folge (Quellen der Folge 2 werden geöffnet)', pg.evaluate("window.__opened || 1") and pg.evaluate("playCtx.item.episode") == 2)
    pg.goto(BASE)
    pg.wait_for_selector('.tile')

    print('Verlauf und Zwischenspeicher: Rückfrage, einzeln entfernen')
    items = [{'ts': 3, 'item': {'title': 'Film %d' % i, 'provider_id': 'fake', 'provider': 'Fake', 'url': 'u%d' % i, 'kind': 'play', 'next_func': 'get_hosters'}} for i in (1, 2, 3)]
    pg.evaluate("v => localStorage.setItem('mk.hist', JSON.stringify(v))", items)
    pg.goto(BASE)
    pg.wait_for_selector('[data-sec=hist] .card')
    check('Verlauf zeigt 3 Einträge, jeder mit Entfernen-Knopf', pg.locator('[data-sec=hist] .card').count() == 3 and pg.locator('[data-sec=hist] .card .xb').count() == 3)
    pg.locator('[data-sec=hist] .card', has_text='Film 2').locator('.xb').click()
    pg.wait_for_function("document.querySelectorAll('[data-sec=hist] .card').length === 2")
    left = pg.evaluate("JSON.parse(localStorage.getItem('mk.hist')).map(x => x.item.title)")
    check('Einzelner Eintrag entfernt, die anderen bleiben', left == ['Film 1', 'Film 3'], left)
    pg.locator('[data-sec=hist] .card', has_text='Film 1').focus()
    pg.keyboard.press('Delete')
    pg.wait_for_function("document.querySelectorAll('[data-sec=hist] .card').length === 1")
    check('Entf-Taste entfernt den Eintrag unter dem Fokus', pg.evaluate("JSON.parse(localStorage.getItem('mk.hist')).length") == 1)
    pg.evaluate("v => localStorage.setItem('mk.hist', JSON.stringify(v))", items)
    pg.goto(BASE)
    pg.wait_for_selector('[data-sec=hist] .card')
    pg.get_by_role('button', name='Verlauf leeren').click()
    pg.wait_for_selector('text=Verlauf löschen?')
    check('Rückfrage vor dem Löschen, vorgewählt ist "Nein"', pg.evaluate("document.activeElement.textContent") == 'Nein')
    pg.get_by_role('button', name='Nein').click()
    pg.wait_for_timeout(250)
    check('Nein: nichts gelöscht', pg.evaluate("JSON.parse(localStorage.getItem('mk.hist')).length") == 3 and pg.locator('.panel').count() == 0)
    pg.get_by_role('button', name='Verlauf leeren').click()
    pg.wait_for_selector('text=Verlauf löschen?')
    pg.go_back()
    pg.wait_for_timeout(250)
    check('Zurück/Schließen zählt als Nein', pg.evaluate("JSON.parse(localStorage.getItem('mk.hist')).length") == 3)
    pg.get_by_role('button', name='Verlauf leeren').click()
    pg.get_by_role('button', name='Ja, löschen').click()
    pg.wait_for_function("localStorage.getItem('mk.hist') === '[]'")
    pg.wait_for_function("document.querySelectorAll('[data-sec=hist]').length === 0", timeout=5000)
    check('Ja: Verlauf gelöscht, Bereich verschwindet', pg.locator('[data-sec=hist]').count() == 0)
    pg.evaluate("v => localStorage.setItem('mk.hist', JSON.stringify(v))", items)
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    pg.get_by_role('button', name='Verlauf löschen').click()
    pg.wait_for_selector('text=Verlauf löschen?')
    pg.get_by_role('button', name='Nein').click()
    pg.wait_for_timeout(250)
    check('Einstellungen: "Verlauf löschen" fragt nach (Nein behält alles)', pg.evaluate("JSON.parse(localStorage.getItem('mk.hist')).length") == 3 and pg.get_by_role('tab', name='Allgemein').count() == 1)
    tab(pg, 'System & Update')
    pg.get_by_role('button', name='Alles leeren').click()
    pg.wait_for_selector('text=Zwischenspeicher leeren?')
    pg.get_by_role('button', name='Nein').click()
    pg.wait_for_timeout(300)
    check('Zwischenspeicher: Nein löscht nichts und meldet nichts', 'Zwischenspeicher geleert' not in ' '.join(pg.locator('.toast').all_inner_texts()))
    pg.get_by_role('button', name='Alles leeren').click()
    pg.get_by_role('button', name='Ja, leeren').click()
    pg.wait_for_selector('text=Zwischenspeicher geleert')
    check('Zwischenspeicher: Ja leert', True)
    pg.go_back()
    pg.wait_for_timeout(200)

    print('Suche mit Frist')
    pg.evaluate("localStorage.setItem('mk.searchwait', '2')")
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    pg.fill('#q', 'Matrix')
    pg.press('#q', 'Enter')
    pg.wait_for_selector('text=Treffer für Matrix', timeout=10000)
    t0 = time.time()
    pg.wait_for_function("document.body.innerText.includes('noch nicht fertig')", timeout=10000)
    dt = time.time() - t0
    check('Schnelle Quelle zeigt Treffer, langsame ("Langsam") hält nicht auf', 'Langsam' in pg.locator('#view').inner_text() and 'Treffer für Matrix' in pg.locator('#view').inner_text())
    check('Meldung nach der Frist (ca. 2 s), nicht erst nach 6 s', dt < 4.5, dt)
    pg.wait_for_selector('text=Spätes Ergebnis Matrix', timeout=15000)
    check('Spätes Ergebnis erscheint von selbst nachträglich', True)
    check('... und die Meldung "noch nicht fertig" verschwindet', 'noch nicht fertig' not in pg.locator('#view').inner_text())

    print('Windows-Programm: Neustart-Knopf (ohne App-Brücke)')
    c2 = pg.context.browser.new_context(viewport={'width': 1280, 'height': 800})
    w = c2.new_page()
    hits = []

    def upd_route(r):
        resp = r.fetch()
        d = resp.json()
        d['can_restart'] = True
        d['restart_needed'] = True
        d['pending'] = d.get('pending') or '99.0.0'
        r.fulfill(status=200, content_type='application/json', body=json.dumps(d))

    w.route('**/api/admin/update', upd_route)
    w.route('**/api/admin/restart', lambda r: (hits.append(1), r.fulfill(status=200, content_type='application/json', body='{"ok":true}')))
    w.goto(BASE)
    w.wait_for_selector('.tile')
    w.click('#btnSettings')
    w.wait_for_selector('.panel')
    tab(w, 'System & Update')
    w.wait_for_function("document.querySelector('.panel').innerText.includes('Läuft: Version')")
    check('Mit Windows-Programm: Knopf "Jetzt neu starten" erscheint auch ohne App', w.get_by_role('button', name='Jetzt neu starten').count() == 1)
    w.get_by_role('button', name='Jetzt neu starten').click()
    w.wait_for_selector('text=Starte neu')
    check('Knopf ruft /api/admin/restart und meldet "Starte neu"', len(hits) == 1)
    c2.close()


def main():
    tmp = tempfile.mkdtemp(prefix='ms_fui_')
    provs = Path(tmp) / 'providers'
    provs.mkdir()
    shutil.copy2(ROOT / 'tests' / 'fake_providers' / 'fake.py', provs / 'fake.py')
    (provs / 'slow.py').write_text(SLOW, 'utf-8')
    base_env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(provs), FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE'):
        base_env.pop(k, None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    procs = [up]
    for port, name in ((API, 'a'), (API2, 'b')):
        d = Path(tmp) / ('data_' + name)
        d.mkdir()
        procs.append(subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(port)],
                                      env=dict(base_env, MINIKODI_DATA=str(d), MOVIESCOUT_DATA=str(d)), cwd=str(ROOT),
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
    try:
        assert wait_port(UP) and wait_port(API) and wait_port(API2), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 1280, 'height': 800}, user_agent='Mozilla/5.0 (Linux; Android 12) MovieScoutApp/test')
            ctx.add_init_script(BRIDGE)
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            try:
                run(pg, tmp)
                check('Keine Skriptfehler in der Oberfläche', not errs, errs)
            except Exception:                                   # noqa: BLE001
                import traceback
                traceback.print_exc()
                global failed
                failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png'))
                print('Screenshot:', Path(tmp) / 'fail.png', errs)
            b.close()
    finally:
        for pr in procs:
            pr.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
