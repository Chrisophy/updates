# -*- coding: utf-8 -*-
"""Test des mitgelieferten Gadgets „Gerät“ (Hardware-Info) mit echter Engine.

    python tests/geraet_test.py
"""
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8896
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def get(path):
    try:
        with urlopen('http://127.0.0.1:%d%s' % (PORT, path), timeout=30) as r:
            txt, code = r.read().decode('utf-8', 'replace'), r.status
    except HTTPError as e:
        txt, code = e.read().decode('utf-8', 'replace'), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt


def main():
    from engine import hwinfo
    print('hwinfo')
    d = hwinfo.collect('1.2.3', ROOT)
    check('collect liefert alle Abschnitte', all(k in d for k in ('device', 'cpu', 'ram', 'storage', 'os', 'app')), list(d))
    check('RAM und Kerne gelesen', d['ram']['total'] > 0 and d['cpu']['cores'] >= 1, d['ram'])
    check('Speicher der App gelesen', d['storage'].get('app', {}).get('total', 0) > 0)
    check('Version durchgereicht', d['app']['version'] == '1.2.3')
    check('Prop ohne Android leer, kein Fehler', hwinfo.prop('ro.gibt.es.nicht') == '')
    json.dumps(d)

    tmp = Path(tempfile.mkdtemp(prefix='ms_hw_'))
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        end = time.time() + 40
        while time.time() < end:
            try:
                get('/api/info')
                if get('/api/info')[0] == 200:
                    break
            except Exception:                              # noqa: BLE001
                time.sleep(0.4)
        print('Engine')
        code, page = get('/api/x/geraet/index')
        check('Seite „Mein Gerät“ wird ausgeliefert (Erweiterung wurde angelegt)', code == 200 and 'Mein Gerät' in page, str(page)[:200])
        check('Seite enthält Chipset/RAM/Speicher', all(x in page for x in ('Prozessor', 'Arbeitsspeicher', 'Speicher')))
        check('Seite zeigt Codec-Bereich und Kopierknopf', 'sec-codec' in page and 'id="cp"' in page)
        code, dat = get('/api/x/geraet/daten')
        check('Daten als JSON', code == 200 and dat['ram']['total'] > 0 and dat['app']['version'], str(dat)[:200])
        check('Versionsnummer der App steht drin', dat['app']['version'] == (ROOT / 'VERSION').read_text().strip(), dat['app'])
        code, ws = get('/api/ext/widgets?fresh=1')
        txt = json.dumps(ws)
        check('Kachel „Gerät“ liefert Daten', code == 200 and any(w.get('ext') == 'geraet' and 'RAM' in w.get('text', '') for w in ws.get('widgets', [])), txt[:300])
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
