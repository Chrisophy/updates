# -*- coding: utf-8 -*-
"""Fernbedienung: OK = sofort öffnen, OK halten = Titel-Menü.   python tests/tv_ok_test.py"""
import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8972
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_context(viewport={'width': 900, 'height': 900}, user_agent='Mozilla/5.0 MovieScoutApp').new_page()
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_selector('header.top'); pg.wait_for_timeout(600)
            pg.evaluate("""() => { const m=document.querySelector('main')||document.body; const c=document.createElement('button'); c.className='card'; c.id='tc'; c.textContent='Testfilm';
              c._fav={provider_id:'t',url:'x://a',title:'Testfilm',kind:'play'}; window.__clicks=0; c.addEventListener('click',()=>{window.__clicks++}); m.prepend(c); c.focus(); }""")
            pg.keyboard.down('Enter'); pg.wait_for_timeout(80); pg.keyboard.up('Enter'); pg.wait_for_timeout(150)
            check('Kurz OK: sofort geöffnet, kein Menü', pg.evaluate('window.__clicks') == 1 and pg.locator('.cardmenu').count() == 0, pg.evaluate('window.__clicks'))
            pg.evaluate("document.getElementById('tc').focus()")
            pg.keyboard.down('Enter'); pg.wait_for_timeout(900)
            check('OK halten: Menü geht auf', pg.locator('.cardmenu').count() == 1)
            pg.keyboard.up('Enter'); pg.wait_for_timeout(200)
            check('Beim Loslassen nichts zusätzlich geöffnet', pg.evaluate('window.__clicks') == 1 and pg.locator('.cardmenu').count() == 1)
            check('Menü hat Abspielen, Info, Schließen', all(pg.locator('.cardmenu').get_by_role('button', name=n).count() for n in ('Abspielen', 'Info', 'Schließen')))
            b.close()
    finally:
        srv.terminate()
    check('Keine Skriptfehler', not errs, errs)
    print('\n%d ok, %d Fehler' % (passed, failed)); return 1 if failed else 0
if __name__ == '__main__': sys.exit(main())
