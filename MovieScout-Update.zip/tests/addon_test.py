# -*- coding: utf-8 -*-
"""Test der Kodi-Addon-Installation (plugin.video.*): Installieren, Menüs, Suche, Abspielen, Einstellungen, Entfernen mit echter Engine und Browser.

    python tests/addon_test.py
"""
import json
import io
import threading
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import quote
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from datetime import date
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8908
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=30) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=8, step=0.1):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def setv(ext, **values):
    return http('/api/admin/ext/settings', {'ext': ext, 'values': values})[0]


def code_of(gid):
    from engine import examples as EXM
    return next(e for e in EXM.EXAMPLES if e['id'] == gid)['code']


ADDON_XML = """<?xml version="1.0" encoding="UTF-8"?>
<addon id="plugin.video.fixture" name="Fixture" version="%s" provider-name="Test">
  <requires><import addon="xbmc.python" version="3.0.0"/></requires>
  <extension point="xbmc.python.pluginsource" library="main.py"><provides>video</provides></extension>
  <extension point="xbmc.service" library="service.py" start="startup"/>
  <extension point="xbmc.addon.metadata"><summary lang="de">Testaddon</summary><assets><icon>icon.png</icon></assets></extension>
</addon>"""
MAIN = """
import json
from urllib.parse import parse_qsl, urlencode
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
from resources.lib import util

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
ADDON = xbmcaddon.Addon()


def add(title, params, folder=True, play=False):
    li = xbmcgui.ListItem(label=title)
    if play:
        li.setProperty('IsPlayable', 'true')
    li.setInfo('video', {'title': title, 'plot': 'Plot ' + title})
    xbmcplugin.addDirectoryItem(HANDLE, BASE + '?' + urlencode(params), li, isFolder=folder)


params = dict(parse_qsl(sys.argv[2][1:]))
action = params.get('action', 'root')
if action == 'root':
    add(ADDON.getLocalizedString(30001), {'action': 'search'})
    add('Ordner', {'action': 'folder'})
    add('Offene Einstellungen', {'action': 'open_settings'}, folder=False, play=True)
    add('Sender suchen', {'action': 'search_prompt'}, folder=False, play=True)
elif action == 'folder':
    add('Film Eins', {'action': 'play', 'id': '1'}, folder=False, play=True)
    add('Film Zwei', {'action': 'play', 'id': '2'}, folder=False, play=True)
elif action == 'search':
    q = params.get('query') or xbmcgui.Dialog().input('Suche')
    for n in util.results(q):
        add(n, {'action': 'play', 'id': '9'}, folder=False, play=True)
elif action == 'play':
    li = xbmcgui.ListItem(path=ADDON.getSetting('base') + '/clip%s.webm' % params.get('id'))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
elif action == 'notify':
    xbmcgui.Dialog().notification('[B]Fixture[/B]', '[COLOR red]Backup[/COLOR] erstellt[CR]', xbmcgui.NOTIFICATION_INFO, 3000)
elif action == 'ask':
    d = xbmcgui.Dialog()
    ok = d.yesno('Frage', 'Wirklich?')
    idx = d.select('Wahl', ['A', 'B', 'C'])
    kb = xbmc.Keyboard('', 'Name'); kb.doModal()
    txt = kb.getText() if kb.isConfirmed() else 'abgebrochen'
    d.notification('Fixture', 'ja=%s idx=%s name=%s' % (ok, idx, txt))
elif action == 'marsh':
    import marshal
    try:
        marshal.loads(marshal.dumps(compile('1', 'x', 'eval')))
        xbmcgui.Dialog().notification('Fixture', 'marshal-code erlaubt')
    except RuntimeError:
        xbmcgui.Dialog().notification('Fixture', 'marshal-code blockiert')
    xbmcgui.Dialog().notification('Fixture', 'marshal-daten=%s' % marshal.loads(marshal.dumps([1, 2])))
elif action == 'imp':
    import importlib
    for m in ('colorsys', 'sched', 'mailcap', 'wave', 'netrc'):
        try:
            importlib.import_module(m)
        except ImportError:
            pass
    import difflib, fractions, statistics
    xbmcgui.Dialog().notification('Fixture', 'imports ok')
elif action == 'playfile':
    import os, xbmcvfs
    tmp = xbmcvfs.translatePath('special://temp')
    os.makedirs(tmp, exist_ok=True)
    fp = os.path.join(tmp, 'deezer_1.mp3')
    with open(fp, 'wb') as f:
        f.write(b'0123456789abcdefghij')
    li = xbmcgui.ListItem('Artist - Titel', path=fp)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
elif action == 'jsontest':
    json.loads = lambda *a, **k: 'PATCHED'
    add('addon sieht: ' + json.loads('1'), {'action': 'x'})
    add('[B][COLOR red][ Klammer ][/COLOR][/B]', {'action': 'folder'})
elif action == 'modstate':
    import fixlocal
    fixlocal.n += 1
    xbmcgui.Dialog().notification('Fixture', 'n=%s' % fixlocal.n)
elif action == 'queue':
    pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    pl.clear()
    for i in (1, 2):
        li = xbmcgui.ListItem('Titel %d' % i)
        li.setProperty('IsPlayable', 'true')
        pl.add(BASE + '?action=play&id=%d' % i, li)
    xbmc.Player().play(pl, startpos=1)
elif action == 'pic':
    import os, xbmcvfs
    fp = os.path.join(xbmcvfs.translatePath('special://temp'), 'img_1.jpg')
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    open(fp, 'wb').write(bytes([255, 216, 255, 224]) + b'JPEGDATA')
    xbmc.executebuiltin('ShowPicture(%s)' % fp)
elif action == 'keepalive':
    # Muster von xStream/xShip: setResolvedUrl, dann auf den Player warten (bis „Bild da“ bzw. bis zum Ende der Wiedergabe)
    import os, glob, sqlite3, xbmcvfs, time
    os.chdir(xbmcvfs.translatePath('special://database/'))
    db = sorted(glob.glob('MyVideos*.db'), reverse=True)[0]
    con = sqlite3.connect(db); n = len(con.execute('SELECT * FROM files').fetchall()); con.close()

    class P(xbmc.Player):
        av = False
        def onAVStarted(self):
            self.av = True

    pl = P()
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path='http://127.0.0.1:9/v.mp4'))
    t0 = time.time()
    mon = xbmc.Monitor()
    while not mon.abortRequested() and not pl.av:
        mon.waitForAbort(0.25)
    for i in range(240):
        if pl.isPlayingVideo():
            break
        xbmc.sleep(1000)
    xbmcgui.Dialog().notification('Fixture', 'av=%s files=%s dt=%.1f' % (pl.av, n, time.time() - t0))
elif action == 'svcplay2':
    port = xbmcgui.Window(10000).getProperty('fixture.port')
    li = xbmcgui.ListItem('Telegram Video', path='http://127.0.0.1:%s/stream?chat=x&msg=1&t=abc' % port)
    xbmc.Player().play(li.getPath(), li)
elif action == 'svcchild':
    xbmcgui.Dialog().notification('Fixture', 'child=' + xbmcgui.Window(10000).getProperty('fixture.child'))
elif action == 'svcplay':
    port = xbmcgui.Window(10000).getProperty('fixture.port')
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path='http://127.0.0.1:%s/v.webm' % port)) if port else xbmcgui.Dialog().notification('Fixture', 'Dienst fehlt')
elif action == 'refresh':
    xbmcgui.Dialog().notification('Fixture', 'gesendet')
    xbmc.executebuiltin('Container.Refresh')
elif action == 'update':
    xbmc.executebuiltin('Container.Update(%s?action=folder&x=a%%2Cb,replace)' % BASE)
elif action == 'info':
    add('v=' + ADDON.getAddonInfo('version') + ' n=' + ADDON.getAddonInfo('name') + ' p=' + ('yes' if ADDON.getAddonInfo('path').endswith('plugin.video.fixture') else 'no'), {'action': 'x'})
"""
SERVICE = "\nimport threading\nfrom http.server import BaseHTTPRequestHandler, HTTPServer\nimport xbmc, xbmcgui\n\n\nclass H(BaseHTTPRequestHandler):\n    def do_GET(self):\n        d = b'SVCDATA' * 10\n        self.send_response(200); self.send_header('Content-Type', 'video/webm'); self.send_header('Content-Length', str(len(d))); self.end_headers(); self.wfile.write(d)\n\n    def log_message(self, *a):\n        pass\n\n\nsrv = HTTPServer(('127.0.0.1', 0), H)\nthreading.Thread(target=srv.serve_forever, daemon=True).start()\nxbmcgui.Window(10000).setProperty('fixture.port', str(srv.server_address[1]))\n\n\ndef _child():                                      # Thread des Dienstes: kennt sein Addon?\n    import xbmcaddon\n    xbmcgui.Window(10000).setProperty(\'fixture.child\', xbmcaddon.Addon().getAddonInfo(\'id\'))\n    xbmc.log(\'Kind-Thread bereit\')\n\n\nthreading.Thread(target=_child).start()\nmon = xbmc.Monitor()\nwhile not mon.abortRequested():\n    if mon.waitForAbort(1):\n        break\nsrv.shutdown()\nxbmcgui.Window(10000).clearProperty('fixture.port')\n"
UTIL = "def results(q):\n    return ['Treffer %s A' % q, 'Treffer %s B' % q]\n"
SETTINGS = ('<settings><category label="Konto"><setting id="base" type="text" default="http://127.0.0.1:8911" label="Adresse"/>'
            '<setting id="pw" type="text" option="hidden" default="" label="Passwort"/>'
            '<setting id="qual" type="enum" values="Niedrig|Hoch" default="1" label="Qualität"/>'
            '<setting id="flag" type="bool" default="false" label="Schalter"/>'
            '<setting type="action" label="Anmelden" action="RunPlugin(plugin://plugin.video.fixture/?action=notify)"/>'
            '</category></settings>')
PO = 'msgid ""\nmsgstr ""\n\nmsgctxt "#30001"\nmsgid "Search"\nmsgstr "Suchen"\n'


def make_zip(version='1.0.0', evil=False, nomain=False, noxml=False, kind='plugin.video.fixture'):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        d = 'plugin.video.fixture/'
        if not noxml:
            z.writestr(d + 'addon.xml', (ADDON_XML % version).replace('plugin.video.fixture', kind))
        if not nomain:
            z.writestr(d + 'main.py', MAIN)
        z.writestr(d + 'fixlocal.py', 'n = 0\n')
        z.writestr(d + 'service.py', SERVICE)
        z.writestr(d + 'resources/__init__.py', '')
        z.writestr(d + 'resources/lib/__init__.py', '')
        z.writestr(d + 'resources/lib/util.py', UTIL)
        z.writestr(d + 'resources/settings.xml', SETTINGS)
        z.writestr(d + 'resources/language/resource.language.de_de/strings.po', PO)
        z.writestr(d + 'icon.png', b'x')
        if evil:
            z.writestr(d + '../../evil.txt', 'x')
    return b.getvalue()


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_addon_'))

    class Mini(BaseHTTPRequestHandler):                    # Mini-Server wie ihn NewPipe auf 127.0.0.1 startet
        def do_GET(self):
            data = b'WEBMDATA' * 10
            self.send_response(200); self.send_header('Content-Type', 'video/webm'); self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)

        def log_message(self, *a):
            pass
    mini = HTTPServer(('127.0.0.1', 8911), Mini)
    other = HTTPServer(('127.0.0.1', 8912), Mini)
    for srv in (mini, other):
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    env['MOVIESCOUT_DIALOG_GONE'] = '3'
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)

        def post_zip(data):
            req = Request(BASE + '/api/admin/addon/install', data=data, method='POST', headers={'Content-Type': 'application/zip'})
            try:
                with urlopen(req, timeout=30) as r:
                    return r.status, json.loads(r.read())
            except HTTPError as e:
                return e.code, json.loads(e.read())

        print('Installieren')
        c, r = post_zip(make_zip())
        check('Addon wird installiert', c == 200 and r['addon']['id'] == 'plugin.video.fixture' and r['addon']['version'] == '1.0.0', r)
        provs = http('/api/providers')[1]['providers']
        pv = [x for x in provs if x['id'] == 'addon_plugin_video_fixture']
        check('Erscheint als Quelle „Fixture“, nicht in der Gesamtsuche', pv and pv[0]['name'] == 'Fixture' and pv[0]['global_search'] is False, pv)
        check('Ungültige ZIPs werden abgelehnt (kein ZIP / ohne addon.xml / ohne main.py / unsicherer Pfad)',
              post_zip(b'kein zip')[0] == 400 and post_zip(make_zip(noxml=True))[0] == 400 and post_zip(make_zip(nomain=True))[0] == 400
              and post_zip(make_zip(evil=True))[0] == 400)  # script.*/Dienste sind seit 2.22 erlaubt (tests/script_test.py)
        check('Keine Datei außerhalb des Addon-Ordners entstanden', not (tmp / 'evil.txt').exists() and not (tmp / 'd' / 'evil.txt').exists())

        print('Menüs')
        PID = 'addon_plugin_video_fixture'
        c, root = http('/api/open', {'provider_id': PID, 'item': {}})
        titles = [i['title'] for i in root['items']]
        check('Startmenü: übersetzter Titel aus strings.po, Ordner; Einstellungen am Ende', titles == ['Suchen', 'Ordner', 'Sender suchen', 'Einstellungen'], titles)
        kinds = {i['title']: i['kind'] for i in root['items']}
        check('Suche wird als Suche erkannt, Ordner als Ordner', kinds == {'Suchen': 'search', 'Ordner': 'folder', 'Sender suchen': 'search', 'Einstellungen': 'folder'}, kinds)
        folder = [i for i in root['items'] if i['title'] == 'Ordner'][0]
        check('Volle plugin://-Adresse bleibt erhalten', folder['url'].startswith('plugin://plugin.video.fixture/?action=folder'), folder['url'])
        c, sub = http('/api/open', {'provider_id': PID, 'item': folder})
        check('Ordner zeigt zwei spielbare Filme', [(i['title'], i['kind']) for i in sub['items']] == [('Film Eins', 'play'), ('Film Zwei', 'play')], sub)
        srch = [i for i in root['items'] if i['kind'] == 'search'][0]
        c, sr = http('/api/open', {'provider_id': PID, 'item': srch, 'q': 'Matrix'})
        check('Suche übergibt den Suchbegriff an das Addon', [i['title'] for i in sr['items']] == ['Treffer Matrix A', 'Treffer Matrix B'], sr)
        c, g = http('/api/search?provider_id=%s&q=Alien' % PID)
        check('Direkte Suche in der Quelle funktioniert ebenfalls', c == 200 and len(g['items']) == 2, g)

        print('Abspielen und Einstellungen')
        film = sub['items'][1]
        c, res = http('/api/resolve', {'provider_id': PID, 'item': film})
        check('„Film Zwei“ liefert die vom Addon gelöste Adresse (Einstellung „base“ aus settings.xml)', c == 200 and res['hosters'] and res['hosters'][0]['url'] == 'http://127.0.0.1:8911/clip2.webm', res)
        c, info = http('/api/open', {'provider_id': PID, 'item': {'title': 'i', 'url': 'plugin://plugin.video.fixture/?action=info', 'next_func': 'load'}})
        check('Addon-Infos (Version, Name, Pfad) stimmen', info['items'][0]['title'] == 'v=1.0.0 n=Fixture p=yes', info)

        c, nr = http('/api/resolve', {'provider_id': PID, 'item': {'title': 'Backup', 'url': 'plugin://plugin.video.fixture/?action=notify', 'next_func': 'get_hosters'}})
        check('Addon-Aktion ohne Stream: deren Meldung statt „Keine Streams“', nr.get('error') == 'Backup erstellt' and nr.get('info') is True and not nr['hosters'], nr)

        print('Lokaler Mini-Server des Addons über den Proxy')
        def proxied(u):
            try:
                with urlopen(BASE + '/api/proxy?u=' + quote(u, safe=''), timeout=15) as r:
                    return r.status, r.read()
            except HTTPError as e:
                return e.code, e.read()
        c, b = proxied('http://127.0.0.1:8911/clip2.webm')
        check('Adresse, die das Addon genannt hat (127.0.0.1:8911), wird vom Proxy geholt', c == 200 and b.startswith(b'WEBMDATA'), (c, b[:80]))
        c, b = proxied('http://127.0.0.1:8912/clip2.webm')
        check('Andere lokale Ports bleiben gesperrt (Schutz vor Missbrauch)', c in (400, 403), (c, b[:80]))
        c, b = proxied('http://127.0.0.1:%d/api/providers' % PORT)
        check('Die Engine selbst ist über den Proxy nicht erreichbar', c in (400, 403), (c, b[:80]))

        print('Addon verändert json.loads global')
        c, jr = http('/api/open', {'provider_id': PID, 'item': {'title': 'j', 'url': 'plugin://plugin.video.fixture/?action=jsontest', 'next_func': 'load'}})
        check('Das Addon sieht seine eigene Änderung, Titel mit Klammern bleiben aber heil',
              [i['title'] for i in jr['items']] == ['addon sieht: PATCHED', '[ Klammer ]'], jr)
        c, again = http('/api/open', {'provider_id': PID, 'item': {'title': 'j', 'url': 'plugin://plugin.video.fixture/?action=jsontest', 'next_func': 'load'}, 'fresh': True})
        check('Auch beim zweiten Aufruf und für die übrige Engine (Antworten sind gültiges JSON)', c == 200 and http('/api/providers')[0] == 200 and again['items'][1]['title'] == '[ Klammer ]', again)



        print('Container.Refresh / Update, sys ohne import, frische Module')
        U = lambda a, nf: {'provider_id': PID, 'item': {'title': a, 'url': 'plugin://plugin.video.fixture/?action=' + a, 'next_func': nf}, 'fresh': True}
        c, r = http('/api/resolve', U('refresh', 'get_hosters'))
        check('Container.Refresh: Antwort verlangt „neu laden“', c == 200 and r.get('ui') == {'refresh': True} and r.get('info') is True, r)
        c, r = http('/api/resolve', U('queue', 'get_hosters'))
        check('Player().play(Wiedergabeliste): der gewählte Eintrag wird aufgelöst (Titel 2 = clip2)', c == 200 and r['hosters'] and r['hosters'][0]['url'].endswith('/clip2.webm'), r)
        time.sleep(1.5)
        c, r = http('/api/resolve', U('svcplay', 'get_hosters'))
        sv = r['hosters'][0]['url'] if r.get('hosters') else ''
        check('Addon-Dienst (xbmc.service) läuft im Hintergrund und setzt Window-Eigenschaft', sv.startswith('http://127.0.0.1:') and sv.endswith('/v.webm'), r)
        if sv:
            c, b = proxied(sv)
            check('Stream-Server des Dienstes ist über den Proxy erreichbar', c == 200 and b.startswith(b'SVCDATA'), (c, b[:60]))
        _cwd = os.getcwd()
        _t = time.time()
        c, r = http('/api/resolve', U('keepalive', 'get_hosters'))
        msg = ' '.join(n.get('message', '') for n in r.get('notes', []))
        check('Addon wartet nach setResolvedUrl auf den Player (xStream/xShip): kein Hängen, „Bild da“ wird gemeldet', c == 200 and time.time() - _t < 8 and 'av=True' in msg and r.get('hosters'), (c, msg, r))
        check('Kodi-Datenbanken (special://database/) sind lesbar', 'files=0' in msg, msg)
        c, r = http('/api/resolve', U('svcplay2', 'get_hosters'))
        h2 = (r.get('hosters') or [{}])[0]
        check('Lokaler Stream ohne Dateiendung gilt als direkter Stream (kein „Seite einbetten“)', h2.get('direct') is True and h2.get('format') != 'embed', h2)
        c, pl = http('/api/play', {'hoster': h2}) if h2 else (0, {})
        check('Wiedergabeplan: Medium über die Engine (Proxy), nicht als eingebettete Seite', pl.get('mode') == 'media' and pl.get('needs_proxy') is True and '/api/proxy?u=' in pl.get('proxy_path', ''), pl)
        c, r = http('/api/resolve', U('svcchild', 'get_hosters'))
        check('Threads des Dienstes kennen ihr Addon (xbmcaddon.Addon() ohne Kennung)', 'child=plugin.video.fixture' in (r.get('error') or ''), r)
        c, st = http('/api/admin/addon/settings?id=plugin.video.fixture')
        check('Einstellungen zeigen den Zustand des Dienstes samt Protokoll', st.get('service', {}).get('running') is True and any('Kind-Thread' in l for l in st['service'].get('log', [])), st.get('service'))
        c, r = http('/api/resolve', U('pic', 'get_hosters'))
        img = (r.get('ui') or {}).get('image', '')
        check('ShowPicture: Antwort enthält die Adresse des Bildes (Engine liefert die Datei)', img.startswith('/api/localfile/'), r)
        if img:
            with urlopen(BASE + img, timeout=10) as rr:
                check('… und das Bild lässt sich abrufen', rr.read().endswith(b'JPEGDATA'))
        c, r = http('/api/open', U('update', 'load'))
        check('Container.Update: Antwort nennt die neue Adresse (Komma bleibt heil), keine Liste', c == 200 and r.get('ui', {}).get('goto', '').endswith('?action=folder&x=a%2Cb') and not r['items'], r)
        c, r = http('/api/resolve', U('modstate', 'get_hosters'))
        c, r2 = http('/api/resolve', U('modstate', 'get_hosters'))
        check('Module im Addon-Ordner starten bei jedem Aufruf frisch (n=1 beide Male)', 'n=1' in (r.get('error') or '') and 'n=1' in (r2.get('error') or ''), (r, r2))

        print('Rückfragen des Addons (Dialoge)')
        import threading as _th
        ASK = {'provider_id': PID, 'item': {'title': 'ask', 'url': 'plugin://plugin.video.fixture/?action=ask', 'next_func': 'get_hosters'}}
        c, r = http('/api/resolve', dict(ASK, fresh=True))
        check('Ohne Oberfläche gelten Standardantworten (nichts blockiert)', c == 200 and 'ja=False idx=0 name=abgebrochen' in (r.get('error') or ''), r)
        rid = 'abcdef123456abcd'
        seen = []

        def responder():
            for ans in ({'value': True}, {'value': 2}, {'value': 'Zoe'}):
                for _ in range(40):
                    c2, pr = http('/api/dialog?rid=' + rid)
                    if pr.get('dialog'):
                        seen.append(pr['dialog']['kind'])
                        http('/api/dialog', dict(ans, rid=rid, id=pr['dialog']['id']))
                        break
        th = _th.Thread(target=responder); th.start()
        c, r = http('/api/resolve', dict(ASK, rid=rid, fresh=True))
        th.join()
        check('Fragen kommen an (Ja/Nein, Auswahl, Eingabe) und die Antworten erreichen das Addon', seen == ['yesno', 'select', 'input']
              and 'ja=True idx=2 name=Zoe' in (r.get('error') or ''), (seen, r))
        rid2 = 'zzzzzz123456zzzz'

        def canceller():
            for _n in range(3):
                for _ in range(40):
                    c2, pr = http('/api/dialog?rid=' + rid2)
                    if pr.get('dialog'):
                        http('/api/dialog', {'rid': rid2, 'id': pr['dialog']['id'], 'cancel': True})
                        break
        th = _th.Thread(target=canceller); th.start()
        c, r = http('/api/resolve', dict(ASK, rid=rid2, fresh=True))
        th.join()
        check('Abbrechen einer Frage ergibt die Standardantwort', c == 200 and 'ja=False idx=0 name=abgebrochen' in (r.get('error') or ''), r)
        check('Ungültige Abfrage-ID wird abgelehnt', http('/api/dialog?rid=x')[0] == 400)

        rid3 = 'hbhbhb123456hbhb'

        def slow():
            for ans in ({'value': True}, {'value': 1}, {'value': 'Lang'}):
                for _ in range(40):
                    c2, pr = http('/api/dialog?rid=' + rid3)
                    if pr.get('dialog'):
                        for _k in range(5):                      # 5 s „lesen“ (länger als die 3 s Toleranz), mit Lebenszeichen
                            time.sleep(1); http('/api/dialog?rid=' + rid3 + '&wait=0')
                        http('/api/dialog', dict(ans, rid=rid3, id=pr['dialog']['id']))
                        break
        th = _th.Thread(target=slow); th.start()
        c, r = http('/api/resolve', dict(ASK, rid=rid3, fresh=True))
        th.join()
        check('Frage bleibt offen, solange die Oberfläche Lebenszeichen schickt (Nutzer liest lange)', 'ja=True idx=1 name=Lang' in (r.get('error') or ''), r)
        c, r = http('/api/resolve', dict(ASK, rid='gonegonegone1234', fresh=True))
        check('Ohne Lebenszeichen verfällt die Frage (Standardantwort, nichts hängt)', c == 200 and 'ja=False' in (r.get('error') or ''), r)



        print('Datei als Wiedergabe (z. B. Deezer entschlüsselt in special://temp)')
        c, r = http('/api/resolve', {'provider_id': PID, 'item': {'title': 'f', 'url': 'plugin://plugin.video.fixture/?action=playfile', 'next_func': 'get_hosters'}, 'fresh': True})
        hs = r.get('hosters') or []
        check('Addon-Datei wird zu einem Hoster (msfile://)', c == 200 and len(hs) == 1 and hs[0]['url'].startswith('msfile://') and hs[0]['url'].endswith('.mp3') and hs[0]['format'] == 'audio', r)
        c, plan = http('/api/play', {'hoster': hs[0]}) if hs else (0, {})
        check('Wiedergabeplan zeigt auf die Engine (proxy_path /api/localfile/…)', c == 200 and plan.get('mode') == 'media' and '/api/localfile/' in plan.get('proxy_path', ''), plan)
        if plan.get('proxy_path'):
            rq = Request(BASE + plan['proxy_path'], headers={'Range': 'bytes=2-5'})
            with urlopen(rq, timeout=15) as rr:
                body, st, cr = rr.read(), rr.status, rr.headers.get('Content-Range')
            check('Datei wird mit Bereichsanfrage ausgeliefert (Spulen geht)', st == 206 and body == b'2345' and cr == 'bytes 2-5/20', (st, body, cr))
            with urlopen(Request(BASE + plan['proxy_path']), timeout=15) as rr:
                check('Ganze Datei wird ausgeliefert', rr.read() == b'0123456789abcdefghij')
        try:
            urlopen(Request(BASE + '/api/localfile/nichtda/x.mp3'), timeout=10)
            check('Unbekanntes Token: 404', False)
        except HTTPError as e:
            check('Unbekanntes Token: 404', e.code == 404)

        print('Verschleierte Addons')
        c, r = http('/api/resolve', {'provider_id': PID, 'item': {'title': 'm', 'url': 'plugin://plugin.video.fixture/?action=marsh', 'next_func': 'get_hosters'}, 'fresh': True})
        check('Bytecode-Laden aus Addons wird blockiert, normale marshal-Daten gehen', c == 200 and 'blockiert' in (r.get('error') or '') and 'marshal-daten=[1, 2]' in (r.get('error') or ''), r)
        c, r = http('/api/resolve', {'provider_id': PID, 'item': {'title': 'i', 'url': 'plugin://plugin.video.fixture/?action=imp', 'next_func': 'get_hosters'}, 'fresh': True})
        check('Normale Importe im Addon (frische Standardbibliotheks-Module) funktionieren trotz Bytecode-Sperre', 'imports ok' in (r.get('error') or ''), r)
        bz = io.BytesIO()
        with zipfile.ZipFile(bz, 'w') as z:
            z.writestr('plugin.video.fixture/addon.xml', (ADDON_XML % '9.9').replace('plugin.video.fixture', 'plugin.video.packed'))
            z.writestr('plugin.video.fixture/main.py', 'import base64\nx = "' + 'A' * 150000 + '"\nexec(base64.b64decode(x))\n' + '#' * 20000)
        c, r = post_zip(bz.getvalue())
        check('Verschleiertes Addon wird beim Installieren abgelehnt (mit klarer Meldung)', c == 400 and 'verschleiert' in str(r.get('error')), (c, r))

        print('Einstellungen und Kodi-Markup')
        c, sc = http('/api/admin/addon/settings?id=plugin.video.fixture')
        fl = {f['id']: f for f in sc['fields'] if f.get('id')}
        check('Schema: Text, versteckt, Auswahl, Schalter, Aktion', c == 200 and fl['base']['type'] == 'text' and fl['pw']['hidden'] and fl['qual']['type'] == 'select'
              and [o['label'] for o in fl['qual']['options']] == ['Niedrig', 'Hoch'] and fl['flag']['type'] == 'bool' and any(f['type'] == 'action' for f in sc['fields']), sc)
        c, r = http('/api/admin/addon/settings?id=plugin.video.fixture', {'values': {'pw': 'geheim', 'flag': True, 'qual': '0', 'unbekannt': 'x'}})
        c, sc = http('/api/admin/addon/settings?id=plugin.video.fixture')
        fl = {f['id']: f for f in sc['fields'] if f.get('id')}
        check('Speichern: Werte kommen zurück, Unbekanntes wird ignoriert', fl['pw']['value'] == 'geheim' and fl['flag']['value'] is True and str(fl['qual']['value']) == '0'
              and 'unbekannt' not in fl, fl)
        act = [f for f in sc['fields'] if f['type'] == 'action'][0]
        c, r = http('/api/admin/addon/settings?id=plugin.video.fixture', {'action': act['action']})
        msgs = [n['message'] for n in r.get('notes', [])]
        check('Aktion läuft, Meldung ohne [COLOR]/[B]/[CR]', c == 200 and msgs and '[' not in ''.join(msgs) and 'Backup erstellt' in msgs[0], r)
        c, r = http('/api/admin/addon/settings?id=plugin.video.fixture', {'action': 'plugin://anderes.addon/?x=1'})
        check('Fremde plugin://-Adresse wird abgelehnt', c >= 400, (c, r))
        check('Oberfläche hat Einstellungs-Formular', 'openAddonSettings' in (ROOT / 'static' / 'index.html').read_text('utf-8'))

        print('Aktualisieren und Entfernen')
        c, r = post_zip(make_zip('2.0.0'))
        c, info = http('/api/open', {'provider_id': PID, 'item': {'title': 'i', 'url': 'plugin://plugin.video.fixture/?action=info', 'next_func': 'load'}, 'fresh': True})
        check('Neu installieren ersetzt die Version', c == 200 and 'v=2.0.0' in info['items'][0]['title'], info)
        lst = http('/api/admin/addons')[1]['addons']
        check('Liste der installierten Addons', [a['id'] for a in lst] == ['plugin.video.fixture'] and lst[0]['version'] == '2.0.0', lst)
        c, r = http('/api/admin/addon/remove', {'id': 'plugin.video.fixture'})
        check('Entfernen löscht Quelle und Ordner', c == 200 and not (tmp / 'd' / 'addons' / 'plugin.video.fixture').exists()
              and not [x for x in http('/api/providers')[1]['providers'] if x['id'] == PID])
        check('Erneutes Entfernen: 404', http('/api/admin/addon/remove', {'id': 'plugin.video.fixture'})[0] == 404)
        check('Oberfläche hat den Installieren-Knopf', 'Kodi-Addon / Script (ZIP) installieren' in (ROOT / 'static' / 'index.html').read_text('utf-8'))
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        mini.shutdown(); other.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    from kodi_runtime import xbmc as _kx, xbmcgui as _kg
    _li = _kg.ListItem(label='x'); _li.getVideoInfoTag().setCast([_kx.Actor(name='A', role='R')])
    check('xbmc.Actor vorhanden (Multistream: Besetzung in Filmlisten)', _kx.Actor(name='A').getName() == 'A')
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
