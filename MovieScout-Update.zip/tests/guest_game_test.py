# -*- coding: utf-8 -*-
"""Mehrspieler-Spiele für Gäste (Teilen im WLAN): nur Erweiterungen mit EXT_GUEST = True, nur mit Passwort.

    python tests/guest_game_test.py
"""
import asyncio
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = tempfile.mkdtemp(prefix='ms_guest_')
os.environ.update(MINIKODI_DATA=DATA, MOVIESCOUT_DATA=DATA, MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_LAN_GATE='1',
                  MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'))
os.environ.pop('MOVIESCOUT_TOKEN', None)
os.environ.pop('MINIKODI_TOKEN', None)
sys.path.insert(0, str(ROOT))
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ' + name)
    else:
        failed += 1
        print('  FAIL ' + name + ('  ' + str(extra) if extra else ''))


GAME = '''EXT_ID = 'spielx'
EXT_NAME = 'Spiel X'
EXT_GUEST = True
def register(api):
    api.route('index', lambda req: '<html>spiel</html>')
    api.route('tick', lambda req: {'ok': True})
'''
OTHER = '''EXT_ID = 'andere'
EXT_NAME = 'Andere'
def register(api):
    api.route('index', lambda req: '<html>andere</html>')
'''
FAKE_TRUE = '''EXT_ID = 'falsch'
EXT_NAME = 'Falsch'
EXT_GUEST = "ja"
def register(api):
    api.route('index', lambda req: 'x')
'''


def main():
    from engine import app as A, extensions as X, share as SH, system as S
    from kodi_runtime import xbmcaddon
    S.EXT_DIR.mkdir(parents=True, exist_ok=True)
    for n, code in (('spielx.py', GAME), ('andere.py', OTHER), ('falsch.py', FAKE_TRUE)):
        (S.EXT_DIR / n).write_text(code, 'utf-8')
    X.load_all()
    check('Erweiterungen geladen', {'spielx', 'andere', 'falsch'} <= set(X.EXTS), list(X.EXTS))
    check('EXT_GUEST = True wird erkannt', X.guest_ext('spielx'))
    check('ohne EXT_GUEST: kein Gastzugang', not X.guest_ext('andere'))
    check('EXT_GUEST muss genau True sein (nicht "ja")', not X.guest_ext('falsch'))
    check('unbekannte Erweiterung: kein Gastzugang', not X.guest_ext('gibtsnicht') and not X.guest_ext(''))
    app = A.create_app()

    async def call(method, path, client='192.168.77.5', headers=None, query=''):
        hdr = {'host': 'moviescout.test', **(headers or {})}
        scope = {'type': 'http', 'asgi': {'version': '3.0'}, 'http_version': '1.1', 'method': method, 'path': path, 'raw_path': path.encode(),
                 'query_string': query.encode(), 'headers': [(k.lower().encode(), v.encode()) for k, v in hdr.items()],
                 'client': (client, 5000), 'server': ('127.0.0.1', 8000), 'scheme': 'http', 'root_path': ''}
        sent = []

        async def receive():
            return {'type': 'http.request', 'body': b'{}', 'more_body': False}

        async def send(m):
            sent.append(m)
        await app(scope, receive, send)
        st = next(m['status'] for m in sent if m['type'] == 'http.response.start')
        return st, b''.join(m.get('body', b'') for m in sent if m['type'] == 'http.response.body')

    def run(*a, **k):
        return asyncio.run(call(*a, **k))

    SH.forget()
    xbmcaddon.save_settings({'share_enabled': 'false', 'share_password': ''})
    SH.invalidate()
    st, _ = run('GET', '/api/x/spielx/index')
    check('Freigabe aus: fremdes Gerät kommt nicht ans Spiel', st in (401, 403), st)
    SH.set_config(True, 'Testpass1')
    st, _ = run('GET', '/api/x/spielx/index')
    check('Freigabe an, ohne Anmeldung: kein Zugriff', st in (401, 403), st)
    st, _ = run('GET', '/api/x/spielx/index', headers={'X-Token': 'falsch'})
    check('falsches Passwort: kein Zugriff', st in (401, 403), st)
    tok = SH.token_for('Testpass1')
    h = {'Cookie': 'ms_share=' + tok}
    st, body = run('GET', '/api/x/spielx/index', headers=h)
    check('angemeldeter Gast öffnet die Spielseite', st == 200 and b'spiel' in body, (st, body[:80]))
    st, body = run('POST', '/api/x/spielx/tick', headers=h)
    check('angemeldeter Gast darf POST an die Spielroute', st == 200, (st, body[:80]))
    st, body = run('GET', '/api/x/spielx/index', query='share=Testpass1')
    check('Link mit ?share=Passwort genügt (ohne Cookie)', st == 200 and b'spiel' in body, st)
    st, _ = run('POST', '/api/x/spielx/tick', headers={'X-Share': 'Testpass1', 'Origin': 'http://moviescout.test'})
    check('Seite schickt das Passwort als Header X-Share mit', st == 200, st)
    st, _ = run('GET', '/api/x/spielx/index', query='share=falsch')
    check('falsches ?share=: kein Zugriff', st in (401, 403), st)
    st, _ = run('GET', '/api/x/andere/index', headers=h)
    check('Gast bekommt andere Erweiterungen NICHT', st == 403, st)
    st, _ = run('GET', '/api/x/falsch/index', headers=h)
    check('Erweiterung mit EXT_GUEST = "ja" bleibt gesperrt', st == 403, st)
    st, _ = run('POST', '/api/admin/ext/run', headers=h)
    check('Verwaltung bleibt gesperrt', st == 403, st)
    st, _ = run('GET', '/api/x/spielx/index', client='127.0.0.1')
    check('Das Gerät selbst darf wie immer', st == 200, st)
    SH.set_config(False, '')
    st, _ = run('GET', '/api/x/spielx/index', headers=h)
    check('Freigabe aus: Gast sofort draußen', st in (401, 403), st)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return failed == 0


if __name__ == '__main__':
    ok = main()
    shutil.rmtree(DATA, ignore_errors=True)
    sys.exit(0 if ok else 1)
