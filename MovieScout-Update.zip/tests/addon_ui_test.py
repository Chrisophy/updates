"""Oberfläche: Container.Refresh / Container.Update eines Kodi-Addons laden die Liste neu (Browser-Test mit Playwright)."""
import io, os, shutil, socket, subprocess, sys, tempfile, time, urllib.request, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 8923
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1; print('  ok    ' + name)
    else:
        failed += 1; print('  FEHLER ' + name, extra)


XML = '<addon id="plugin.video.counter" name="Zaehler" version="1.0.0" provider-name="t"><requires><import addon="xbmc.python" version="3.0.0"/></requires><extension point="xbmc.python.pluginsource" library="main.py"><provides>video</provides></extension></addon>\n'
MAIN = "import os, xbmc, xbmcgui, xbmcplugin, xbmcvfs\nfrom urllib.parse import parse_qsl\nH = int(sys.argv[1]); B = sys.argv[0]\nP = dict(parse_qsl(sys.argv[2][1:])); a = P.get('action', 'root')\nf = xbmcvfs.translatePath('special://temp/counter.txt')\ndef n():\n    try: return int(open(f).read())\n    except Exception: return 0\ndef add(t, q, folder=False):\n    li = xbmcgui.ListItem(label=t); xbmcplugin.addDirectoryItem(H, B + '?' + q, li, isFolder=folder)\nif a == 'root':\n    add('Zaehler: %d' % n(), 'action=none'); add('Erhoehen', 'action=inc'); add('Gehe zu B', 'action=goto'); add('Login', 'action=login', True)\nelif a == 'inc':\n    v = n() + 1; open(f, 'w').write(str(v)); xbmc.executebuiltin('Container.Refresh')\nelif a == 'goto':\n    xbmc.executebuiltin('Container.Update(%s?action=b,replace)' % B)\nelif a == 'login':\n    open(f, 'w').write('100'); xbmc.executebuiltin('Container.Update(%s,replace)' % B)\nelif a == 'b':\n    add('Seite B', 'action=none')\nxbmcplugin.endOfDirectory(H)\n"


def main():
    z = io.BytesIO()
    with zipfile.ZipFile(z, 'w') as zf:
        zf.writestr('plugin.video.counter/addon.xml', XML)
        zf.writestr('plugin.video.counter/main.py', MAIN)
    tmp = tempfile.mkdtemp(prefix='ms_cnt_')
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close(); break
            except OSError:
                time.sleep(0.5)
        time.sleep(1.5)
        urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/api/admin/addon/install' % PORT, data=z.getvalue(), method='POST', headers={'Content-Type': 'application/zip'})).read()
        urllib.request.urlopen('http://127.0.0.1:%d/api/health?run=1' % PORT, timeout=90).read()     # „Alle prüfen“ lief schon: Addon trägt jetzt einen Hinweistext
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 420, 'height': 900})
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/' % PORT); pg.wait_for_timeout(1500)
            pg.evaluate("openProvider(providers.find(p=>p.addon==='plugin.video.counter'))")
            pg.wait_for_selector('text=Zaehler: 0', timeout=10000)

            def click(label, expect):
                pg.wait_for_timeout(1200); pg.get_by_text(label).first.click()
                try:
                    pg.wait_for_selector('text=' + expect, timeout=10000); return True
                except Exception:
                    return False
            check('Container.Refresh: Liste zeigt nach der Aktion den neuen Stand', click('Erhoehen', 'Zaehler: 1'))
            check('… und beim zweiten Mal wieder', click('Erhoehen', 'Zaehler: 2'))
            check('Container.Update auf das Startmenü (Anmelden): Liste neu, keine leere Ebene', click('Login', 'Zaehler: 100'))
            check('Titel kehrt zum Namen der Quelle zurück', 'Zaehler' in pg.locator('main h1').first.inner_text())
            check('Container.Update auf eine andere Seite ersetzt die Liste', click('Gehe zu B', 'Seite B'))
            pg.evaluate("openDiagnose()"); pg.wait_for_selector('table.diag', timeout=8000)
            row = pg.locator('table.diag tr', has_text='Zaehler').first
            check('Diagnose: Addon steht auf „ungeprüft“, nicht auf „Fehler“ (nur Hinweis „wird nur auf Wunsch gestartet“)',
                  'Fehler' not in row.inner_text() and row.locator('i.dot.unknown').count() == 1, row.inner_text())
            check('Keine JavaScript-Fehler', not errs, errs)
            b.close()
    finally:
        p.terminate(); shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
