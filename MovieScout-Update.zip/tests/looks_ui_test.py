# -*- coding: utf-8 -*-
"""Oberflächen-Tests (Playwright): Looks (Netflix, Disney, Sky, Joyn, Arte, ARD, ZDF) und Menüleiste mit eigenen Buttons.

    python tests/looks_ui_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
UP, API = 8863, 8864
BASE = 'http://127.0.0.1:%d/ui/' % API
passed = failed = 0
LOOKS = {'look-netflix': ('Netflix-Look', '#e50914', 'tab'), 'look-disney': ('Disney-Look', '#0063e5', 'pill'), 'look-sky': ('Sky-Look', '#00a0e9', 'tile'),
         'look-joyn': ('Joyn-Look', '#ff2d78', 'pill'), 'look-arte': ('Arte-Look', '#fa5a1e', 'tab'), 'look-ard': ('ARD-Look', '#3d8bff', 'tab'),
         'look-zdf': ('ZDF-Look', '#fa7d19', 'pill')}


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def wait_port(port, tries=100):
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close(); return True
        except OSError:
            time.sleep(0.25)
    return False


def css(pg, name):
    return pg.evaluate("n => getComputedStyle(document.documentElement).getPropertyValue(n).trim()", name)


def run(pg, errs):
    print('Start (Standard-Skin)')
    pg.goto(BASE); pg.wait_for_selector('.tile'); pg.wait_for_timeout(300)
    check('Standard-Skin: keine Menüleiste, solange keine Buttons da sind', pg.locator('.navbar').count() == 0)
    check('Neuer Bereich „Entdecken“ mit 4 Kacheln', pg.locator('[data-sec=disc] .tile').count() == 4, pg.locator('[data-sec=disc]').count())

    print('Looks')
    pg.evaluate("openSkinEditor()"); pg.wait_for_selector('.looks')
    check('Sieben Looks in der Galerie', pg.locator('.looks .look').count() == 7, pg.locator('.looks .look').count())
    for lid, (name, acc, style) in LOOKS.items():
        pg.locator('.looks .look', has_text=name).click(); pg.wait_for_timeout(350)
        got = (css(pg, '--acc'), pg.locator('.navbar').get_attribute('data-nav') if pg.locator('.navbar').count() else None, pg.locator('.navbar .nb').count())
        check('%s: Akzent %s, Leiste „%s“, 5 Buttons' % (name, acc, style), got == (acc, style, 5), got)
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)

    print('Menüleiste benutzen (Netflix-Look)')
    pg.evaluate("(() => { SK.active = 'look-netflix'; applySkin(activeSkin()); refreshView(); })()"); pg.wait_for_timeout(400)
    names = pg.locator('.navbar .nb .nt').all_inner_texts()
    check('Beschriftungen', names == ['Startseite', 'Weiterschauen', 'Meine Liste', 'Meine Videos', 'Quellen'], names)
    check('Alle Buttons sind per Fernbedienung erreichbar (data-f)', pg.locator('.navbar .nb[data-f]').count() == 5)
    pg.focus('.navbar .nb >> nth=0'); pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(120)
    check('Pfeil rechts springt zum nächsten Button', pg.evaluate("document.activeElement.textContent.trim()") == 'Weiterschauen', pg.evaluate("document.activeElement.textContent"))
    pg.locator('.navbar .nb', has_text='Meine Videos').click(); pg.wait_for_timeout(500)
    check('„Meine Videos“ öffnet den Mediaplayer', pg.locator('#layers .layer').count() == 1 and 'Videos' in pg.locator('#layers .layer').inner_text(), pg.locator('#layers').inner_text()[:80])
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)
    pg.locator('.navbar .nb', has_text='Quellen').click(); pg.wait_for_timeout(500)
    check('„Quellen“ springt zum Bereich (Seite scrollt)', pg.evaluate("window.scrollY") > 50, pg.evaluate("window.scrollY"))
    pg.locator('.navbar .nb', has_text='Startseite').click(); pg.wait_for_timeout(700)
    check('„Startseite“ scrollt nach oben', pg.evaluate("window.scrollY") < 20, pg.evaluate("window.scrollY"))

    print('Eigene Buttons bearbeiten')
    pg.evaluate("openSkinEditor()"); pg.wait_for_selector('.looks')
    pg.get_by_role('tab', name='Buttons').click(); pg.wait_for_selector('.navrow')
    check('Fünf Zeilen im Editor', pg.locator('.navrow').count() == 5)
    pg.locator('.navrow').nth(0).locator('input').nth(1).fill('Daheim'); pg.wait_for_timeout(300)
    check('Beschriftung ändert die Leiste sofort', pg.locator('.navbar .nb .nt').first.inner_text() == 'Daheim')
    check('Look wird dabei kopiert (Vorlage bleibt unberührt)', pg.evaluate("activeSkin().builtin === false && allSkins().find(x => x.id === 'look-netflix').nav.items[0].label === 'Startseite'"))
    pg.get_by_role('button', name='＋ Button hinzufügen').click(); pg.wait_for_timeout(300)
    check('Button hinzugefügt (6 Zeilen)', pg.locator('.navrow').count() == 6 and pg.locator('.navbar .nb').count() == 6)
    row = pg.locator('.navrow').nth(5)
    row.locator('select').first.select_option('search'); pg.wait_for_timeout(250)
    row = pg.locator('.navrow').nth(5)
    row.locator('input').nth(1).fill('Krimi'); row.locator('input').nth(2).fill('Krimi-Abend'); pg.wait_for_timeout(200)
    # Eingabefelder: Symbol, Beschriftung, Ziel  (Ziel = letztes)
    row = pg.locator('.navrow').nth(5)
    ins = row.locator('input')
    ins.nth(0).fill('🔍'); ins.nth(1).fill('Krimi-Abend'); ins.nth(2).fill('Krimi'); pg.wait_for_timeout(300)
    last = pg.evaluate("skin.cur.nav.items[skin.cur.nav.items.length - 1]")
    check('Aktion „Suche“ mit Begriff gespeichert', last['act'] == 'search' and last['arg'] == 'Krimi' and last['label'] == 'Krimi-Abend' and last['icon'] == '🔍', last)
    pg.get_by_role('button', name='Button 6 nach oben').click(); pg.wait_for_timeout(300)
    check('Nach oben verschieben', pg.evaluate("skin.cur.nav.items.map(x => x.label)")[4] == 'Krimi-Abend', pg.evaluate("skin.cur.nav.items.map(x => x.label)"))
    pg.get_by_role('button', name='Button 5 nach unten').click(); pg.wait_for_timeout(300)
    pg.locator('.ordrow, .src').first  # Editor bleibt offen
    sel = pg.locator('.field select').first
    sel.select_option('tile'); pg.wait_for_timeout(300)
    check('Aussehen der Leiste umstellbar (Kacheln)', pg.locator('.navbar').get_attribute('data-nav') == 'tile')
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)
    pg.locator('.navbar .nb', has_text='Krimi-Abend').click(); pg.wait_for_timeout(600)
    check('Button „Krimi-Abend“ startet die Suche nach „Krimi“', pg.evaluate("(() => { const f = nav[nav.length - 1]; return f.type === 'search' && f.q === 'Krimi'; })()"))
    pg.evaluate("history.back()"); pg.wait_for_timeout(400)

    print('Entfernen, Speichern, Neuladen')
    pg.evaluate("openSkinEditor()"); pg.wait_for_selector('.looks')
    pg.get_by_role('tab', name='Buttons').click(); pg.wait_for_selector('.navrow')
    pg.get_by_role('button', name='Button 6 entfernen').click(); pg.wait_for_timeout(300)
    check('Button entfernt', pg.locator('.navrow').count() == 5 and 'Krimi-Abend' not in pg.locator('.navbar').inner_text())
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)
    pg.reload(); pg.wait_for_selector('.tile'); pg.wait_for_timeout(400)
    check('Nach dem Neuladen noch da', pg.locator('.navbar .nb').count() == 5 and pg.locator('.navbar .nb .nt').first.inner_text() == 'Daheim' and pg.locator('.navbar').get_attribute('data-nav') == 'tile')

    print('Sicherheit und Übernahme')
    r = pg.evaluate("normalizeNav({style:'x', items:[{act:'link',label:'<b>x</b>',arg:'javascript:alert(1)'},{act:'evil',label:'böse'},{act:'link',arg:'https://a.b/c',label:'ok'},{act:'sec',arg:'nix'}]})")
    check('Unbekannte Aktionen fliegen raus, Stil fällt auf Kapseln zurück', r['style'] == 'pill' and len(r['items']) == 3, r)
    check('Markup im Namen entschärft, javascript:-Link verworfen', '<' not in r['items'][0]['label'] and r['items'][0]['arg'] == '' and r['items'][1]['arg'] == 'https://a.b/c', r)
    check('Ungültiger Bereich wird zu Favoriten', r['items'][2]['arg'] == 'favs', r)
    check('Höchstens 16 Buttons', pg.evaluate("normalizeNav({items: Array.from({length: 40}, () => ({act:'home',label:'x'}))}).items.length") == 16)
    pg.evaluate("localStorage.setItem('mk.skins', JSON.stringify({active:'alt', list:[{id:'alt', name:'Alt', layout:{home:['quick','hist','favs','media','status','tiles'], header:[], homeHidden:[], headerHidden:[]}}]}))")
    pg.reload(); pg.wait_for_selector('.tile'); pg.wait_for_timeout(300)
    order = pg.evaluate("skin.cur.layout.home")
    check('Alter Skin ohne die neuen Bereiche: „nav“ oben, „disc“ hinter Favoriten', order[0] == 'nav' and order.index('disc') == order.index('favs') + 1, order)
    n = pg.evaluate("importSkins(JSON.stringify({movieScoutSkin: 1, skin: {name: 'Fremd', nav: {style: 'tile', items: [{act: 'home', label: 'Los', icon: '🚀'}]}}}))")
    got = pg.evaluate("(() => { const x = SK.list[SK.list.length - 1]; return [x.name, x.nav.style, x.nav.items.length, x.nav.items[0].icon]; })()")
    check('Skin-Import bringt die Buttons mit', n == 1 and got == ['Fremd', 'tile', 1, '🚀'], got)
    pg.evaluate("openSkinEditor()"); pg.wait_for_selector('.looks')
    pg.get_by_role('tab', name='Anordnung').click(); pg.wait_for_timeout(200)
    txt = pg.locator('.ordrow').all_inner_texts()
    check('Anordnung kennt Menüleiste und Entdecken', any('Menüleiste' in t for t in txt) and any('Entdecken' in t for t in txt), txt)
    pg.evaluate("history.back()")
    check('Keine Fehler in der Konsole', not errs, errs)


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'),
               MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1')
    env.pop('MINIKODI_TOKEN', None); env.pop('MOVIESCOUT_TOKEN', None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    global failed
    try:
        assert wait_port(UP) and wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_context(viewport={'width': 1280, 'height': 900}).new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
            try:
                run(pg, errs)
            except Exception:      # noqa: BLE001
                import traceback
                traceback.print_exc(); failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png')); print('Screenshot:', Path(tmp) / 'fail.png')
            b.close()
    finally:
        srv.terminate(); up.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
