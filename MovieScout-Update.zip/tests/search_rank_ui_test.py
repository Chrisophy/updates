# -*- coding: utf-8 -*-
"""Oberflächen-Test (Playwright): Suche zeigt Genaues zuerst, dann Passendes, dann Ähnliches; ohne Treffer wird vereinfacht nachgesucht.

    python tests/search_rank_ui_test.py
"""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import discover_test as DT                                            # noqa: E402

UP, API = 8875, 8876
BASE = 'http://127.0.0.1:%d/ui/' % API
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


CASES = [
    ['Matrix', 'Matrix', 0], ['The Matrix (1999)', 'the matrix', 0], ['Matrix [HD] German', 'matrix', 0], ['Matrix - Stream Deutsch', 'matrix', 0],
    ['Matrix Reloaded', 'Matrix', 1], ['Die Matrix Revolutions', 'Matrix', 2], ['Revolutions Matrix', 'Matrix Revolutions', 3],
    ['Mörder gesucht', 'Moerder gesucht', 0], ['Muller', 'Müller', 4], ['Resident Evil (2026)', 'Resident Evil 2026', 0], ['Resident Evil: Apocalypse', 'Resident Evil', 1],
    ['Dark Knight', 'The Dark Knight', 4], ['The Dark Knight Rises', 'The Dark Knight', 1], ['Interstelar', 'Interstellar', 4], ['Ganz anderes', 'Matrix', 5],
    ['1917', '1917', 0], ['Blade Runner 2049', 'Blade Runner 2049', 0], ['Blade Runner', 'Blade Runner 2049', 4], ['Bläde Runner', 'Blade Runner', 4]]


def item(title, pid='p1', prov='Quelle A'):
    return {'title': title, 'kind': 'play', 'provider': prov, 'provider_id': pid, 'url': 'u-' + title, 'next_func': 'get_hosters'}


def run(pg, errs, calls):
    pg.goto(BASE); pg.wait_for_selector('[data-sec]'); pg.wait_for_timeout(300)

    print('Bewertung')
    bad = pg.evaluate("(cases) => cases.filter(([t, q, w]) => mtScore({ title: t }, q).tier !== w).map((c) => c.join(' | '))", CASES)
    check('%d Titel/Such-Paare werden richtig eingestuft' % len(CASES), not bad, bad)
    r = pg.evaluate("(() => { const r = mtRank([{ title: 'Matrix Reloaded' }, { title: 'Anderes' }, { title: 'Matrix (2003)' }, { title: 'Matrix (1999)' }, { title: 'Die Matrix' }], 'Matrix 1999');"
                    " return [r.exact, r.good, r.similar].map((l) => l.map((x) => x.title)); })()")
    check('Rangfolge: gesuchtes Jahr zuerst, Rest nach Nähe', r == [['Matrix (1999)', 'Matrix (2003)'], ['Matrix Reloaded', 'Die Matrix'], ['Anderes']], r)
    v = pg.evaluate("[mtVariants('Resident Evil: Apocalypse (2004)'), mtVariants('Matrix'), mtVariants('1917'), mtVariants('Der Müller & Sohn')]")
    check('Vereinfachte Suchbegriffe (ohne Jahr/Untertitel, Umlaut-Schreibweise), höchstens zwei', v == [['Resident Evil Apocalypse', 'Resident Evil'], [], [], ['Der Müller Sohn', 'Der Mueller & Sohn']], v)

    print('Genaues erscheint zuerst')
    SCRIPT = {'Film': [item('Film Teil 2', 'p1'), item('Der Film Alt', 'p2', 'Quelle B'), item('Ganz anderes', 'p2', 'Quelle B'), item('Film', 'p2', 'Quelle B'), item('Film (2020)', 'p1')]}
    calls.clear()
    pg.route('**/api/search?**', lambda route: route.fulfill(status=200, content_type='application/json', body=json.dumps(
        {'items': SCRIPT.get(parse_qs(urlparse(route.request.url).query).get('q', [''])[0], []), 'results': []})))
    pg.evaluate("pushView({ type: 'search', q: 'Film' })"); pg.wait_for_selector('[data-grp]', timeout=15000); pg.wait_for_timeout(600)
    grp = pg.locator('[data-grp]').all_inner_texts()
    check('Drei Gruppen mit Überschrift und Zahl', [g.replace('\n', ' ') for g in grp] == ['Genaue Treffer 2', 'Passende Treffer 2', 'Ähnliche Treffer 1'] or len(grp) == 3, grp)
    order = pg.evaluate("[...document.querySelectorAll('#view .card .t, #view .row .t')].map((e) => e.textContent)")
    nq = len([c for c in calls if 'q=Film' in c])
    check('Genaue Treffer stehen ganz oben (auch wenn sie später ankommen), dann Passende, dann Ähnliches', order[:2] == ['Film', 'Film (2020)'] and order[2:4] == ['Film Teil 2', 'Der Film Alt'] and order[-1] == 'Ganz anderes', order)
    check('Es gibt einen genauen Treffer: keine Nachsuche', all('q=Film' in c for c in calls) and nq > 0, calls[:6])
    check('Kopf nennt Treffer und Quellen', 'Treffer aus' in pg.locator('.crumbs .sub').inner_text(), pg.locator('.crumbs .sub').inner_text())
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)

    print('Nichts Genaues: vereinfacht nachsuchen')
    SCRIPT2 = {'Film Nummer 5 (2024)': [item('Irgendwas Film', 'p1')], 'Film Nummer 5': [item('Film Nummer 5', 'p2', 'Quelle B')]}
    pg.unroute('**/api/search?**'); calls.clear()
    pg.route('**/api/search?**', lambda route: route.fulfill(status=200, content_type='application/json', body=json.dumps(
        {'items': SCRIPT2.get(parse_qs(urlparse(route.request.url).query).get('q', [''])[0], []), 'results': []})))
    pg.evaluate("pushView({ type: 'search', q: 'Film Nummer 5 (2024)' })"); pg.wait_for_selector('[data-grp="Genaue Treffer"]', timeout=20000); pg.wait_for_timeout(500)
    st = pg.evaluate("nav[nav.length - 1].state.tried")
    check('Zweiter Versuch ohne Jahr und Klammern', st == ['Film Nummer 5 (2024)', 'Film Nummer 5'], st)
    check('Der Treffer der Variante steht als „Genaue Treffer“ oben', pg.evaluate("document.querySelector('#view .card .t, #view .row .t').textContent") == 'Film Nummer 5')
    check('Hinweis nennt die zusätzliche Suche', 'zusätzlich gesucht nach: „Film Nummer 5“' in pg.locator('#view').inner_text(), pg.locator('#view').inner_text()[:300])
    check('Nach dem Fund keine dritte Runde', len({c for c in calls}) == 2, sorted({c for c in calls}))
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)

    print('Gar nichts gefunden')
    pg.unroute('**/api/search?**'); calls.clear()
    pg.route('**/api/search?**', lambda route: route.fulfill(status=200, content_type='application/json', body=json.dumps({'items': [], 'results': []})))
    pg.evaluate("pushView({ type: 'search', q: 'Der Müller: Teil 3 (2001)' })"); pg.wait_for_function("document.querySelector('#view .empty')", timeout=40000); pg.wait_for_timeout(300)
    qs = sorted({parse_qs(c)['q'][0] for c in calls})
    check('Höchstens zwei zusätzliche Suchbegriffe', len(qs) == 3, qs)
    check('„Keine Treffer“ erst nach allen Versuchen', 'Keine Treffer' in pg.locator('#view .empty').inner_text())
    check('Keine Fehler in der Konsole', not errs, errs)


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp,
               FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    global failed
    try:
        assert DT.wait_port(UP) and DT.wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_context(viewport={'width': 1280, 'height': 900}).new_page()
            errs, calls = [], []
            pg.on('request', lambda r: calls.append(r.url.split('/api/search?')[1]) if '/api/search?' in r.url else None)
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
            try:
                run(pg, errs, calls)
            except Exception:      # noqa: BLE001
                import traceback
                traceback.print_exc(); failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png')); print('Screenshot:', Path(tmp) / 'fail.png')
            b.close()
    finally:
        srv.terminate(); up.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
