# -*- coding: utf-8 -*-
"""Handy-Fernbedienung (static/remote.html, gleiche Seite wie im Kodi-Addon): Kopplung per Code, Tasten, Befehle, Sprache.
   python tests/remote_ms_test.py"""
import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8966; ok = bad = 0
def check(n, c, x=''):
    global ok, bad
    if c: ok += 1; print('  ok   ', n)
    else: bad += 1; print('  FEHLER', n, x)
tmp = tempfile.mkdtemp()
env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT/'tests'/'fake_providers'), NO_PROXY='*')
srv = subprocess.Popen([sys.executable, str(ROOT/'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(100):
    try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
    except OSError: time.sleep(.25)
BASE = 'http://127.0.0.1:%d' % API
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        tv = b.new_context(viewport={'width': 1280, 'height': 720}).new_page(); errs = []
        tv.on('pageerror', lambda e: errs.append('TV ' + str(e)))
        tv.goto(BASE + '/ui/'); tv.wait_for_selector('header.top'); tv.wait_for_timeout(1200)
        tv.evaluate("openRemote()"); tv.wait_for_function("remoteCode && remoteCode.length === 6", timeout=8000)
        code = tv.evaluate("remoteCode")
        ph = b.new_context(**p.devices['Pixel 7']).new_page()
        ph.on('pageerror', lambda e: errs.append('Handy ' + str(e)))
        ph.goto(BASE + '/remote?code=' + code); ph.wait_for_timeout(1200)
        check('Seite ist die MovieScout-Fernbedienung', ph.evaluate("document.body.classList.contains('ms')") and 'MovieScout' in ph.locator('#appName').inner_text())
        check('Kodi-Bereiche ausgeblendet', not ph.locator('.sec-zip').is_visible() and not ph.locator('.sec-cast.kodi-only').is_visible())
        check('MovieScout-Bereiche sichtbar', ph.locator('.sec-tools.ms-only').is_visible() and ph.locator('.sec-cast.ms-only').is_visible())
        check('Handy: verbunden', 'verbunden' in ph.locator('#ipInfo').inner_text().lower() and ph.locator('#ipInfo').inner_text().startswith('✓'), ph.locator('#ipInfo').inner_text())
        check('TV: Handy erkannt', tv.evaluate("remotePeer") is True)
        # Tasten
        tv.evaluate("layers.length && history.back()"); tv.wait_for_timeout(300)
        tv.evaluate("document.activeElement && document.activeElement.blur()")
        ph.get_by_role('button', name='⬇️ Unten').dispatch_event('pointerdown'); ph.get_by_role('button', name='⬇️ Unten').dispatch_event('pointerup'); tv.wait_for_timeout(300)
        check('Pfeil unten bewegt den Fokus', tv.evaluate("!!document.activeElement && document.activeElement !== document.body"))
        # Bereiche
        ph.get_by_role('button', name='⚙️', exact=True).first.click(); tv.wait_for_timeout(800)
        check('Einstellungen öffnen sich', tv.evaluate("layers.length") >= 1 and tv.locator('text=Einstellungen').count() > 0)
        ph.get_by_role('button', name='↩️ Zurück').click(); tv.wait_for_timeout(500)
        check('Zurück schließt', tv.evaluate("layers.length") == 0)
        ph.locator('button[title="Downloads"]').click(); tv.wait_for_timeout(800)
        check('Downloads öffnen sich', tv.evaluate("layers.length") == 1)
        ph.get_by_role('button', name='🏠 Home').click(); tv.wait_for_timeout(800)
        check('Home schließt alles', tv.evaluate("layers.length") == 0)
        # Sprache und Text
        ph.evaluate("msVoice('Öffne Einstellungen')"); tv.wait_for_timeout(800)
        check('Sprache: „Öffne Einstellungen“', tv.evaluate("layers.length") == 1)
        ph.evaluate("msSend({type:'key',key:'back'})"); tv.wait_for_timeout(500)
        ph.evaluate("msVoice('Suche Film Testfilm')"); tv.wait_for_timeout(1500)
        check('Sprache: Suche startet (Schreibweise bleibt)', tv.evaluate("nav[nav.length-1].type") == 'search' and tv.evaluate("nav[nav.length-1].q") == 'Testfilm', tv.evaluate("JSON.stringify(nav[nav.length-1])"))
        tv.evaluate("goHome()"); tv.wait_for_timeout(800)
        ph.fill('#keyboardInput', 'Matrix'); ph.get_by_role('button', name='Senden').click(); tv.wait_for_timeout(1500)
        check('Tippen + Senden sucht', tv.evaluate("nav[nav.length-1].q") == 'Matrix', tv.evaluate("JSON.stringify(nav[nav.length-1])"))
        # Player-Befehle (Attrappe)
        tv.evaluate("document.body.insertAdjacentHTML('beforeend','<div id=\"player\"><video></video></div>')")
        ph.locator('button[title="Stumm"]').click(); tv.wait_for_timeout(300)
        check('Stumm schaltet den Player', tv.evaluate("document.querySelector('#player video').muted") is True)
        ph.get_by_role('button', name='🔉').click(); tv.wait_for_timeout(300)
        check('Leiser ändert die Lautstärke', tv.evaluate("document.querySelector('#player video').volume") < 1)
        tv.evaluate("document.querySelector('#player').remove()")
        # Favoriten-Buttons
        names = ph.locator('#favoritesGrid button').all_inner_texts()
        check('4 MovieScout-Schnellbuttons', len(names) == 4 and 'Suche' in names[0] and 'Verlauf' in ' '.join(names), names)
        ph.get_by_role('button', name='⚙️ Anpassen').click(); ph.wait_for_timeout(300)
        opts = ph.locator('#favCmd_0 option').all_inner_texts()
        check('Anpassen zeigt MovieScout-Befehle (kein Kodi)', any('Downloads' in o for o in opts) and not any('Kodi' in o for o in opts), opts[:4])
        # Kopplung per Eingabe / falscher Code
        ph2 = b.new_context(**p.devices['Pixel 7']).new_page()
        ph2.goto(BASE + '/remote'); ph2.wait_for_timeout(800)
        check('Ohne Code: Eingabefeld', ph2.locator('#msPair').is_visible())
        ph2.fill('#msCodeIn', code); ph2.get_by_role('button', name='Verbinden').click(); ph2.wait_for_timeout(1500)
        check('Richtiger Code verbindet', ph2.locator('#ipInfo').inner_text().startswith('✓'), ph2.locator('#ipInfo').inner_text())
        # gleiche Datei im Kodi-Betrieb (Pfad ohne /remote, kein Code)
        kd = b.new_context(**p.devices['Pixel 7']).new_page(); kd.on('pageerror', lambda e: errs.append('Kodi ' + str(e)))
        kd.route('**/get_ip', lambda r: r.fulfill(status=200, content_type='application/json', body='{"ip":"192.168.1.5","port":50808}'))
        kd.goto(BASE + '/ui/remote.html'); kd.wait_for_timeout(800)
        check('Kodi-Betrieb: Kodi-Menü, keine MovieScout-Bereiche', not kd.evaluate("document.body.classList.contains('ms')") and kd.locator('.sec-zip').is_visible() and not kd.locator('.sec-tools.ms-only').is_visible() and 'Kodi' in kd.locator('#appName').inner_text())
        check('Kodi-Betrieb: Adresse angezeigt', '192.168.1.5' in kd.locator('#ipInfo').inner_text(), kd.locator('#ipInfo').inner_text())
        b.close()
finally:
    srv.terminate()
check('Keine Skriptfehler', not errs, errs[:3])
print('\n%d ok, %d Fehler' % (ok, bad)); sys.exit(1 if bad else 0)
