# -*- coding: utf-8 -*-
"""Launcher-Funktionen der Oberfläche mit nachgebauter App-Schnittstelle (window.MovieScoutApp):
Apps im Startmenü, App auf den Desktop legen und starten, Home-Taste, „Als Startbildschirm festlegen“.
    python tests/launcher_ui_test.py"""
import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8976
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
FAKE = """
window.__calls = []; window.__home = false; window.__res = {};
window.__st = {launcher: false, notifications: false, storage: 'media', camera: true, mic: false, battery: false};
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
window.MovieScoutApp = {
  version: () => '9.9', setBackground: () => {}, backgroundEnabled: () => true, notificationsAllowed: () => true, notificationsEnabled: () => true, takeIntent: () => (window.__intent || ''), keepScreenOn: () => {},
  listApps: () => JSON.stringify([{pkg: 'com.fake.kamera', label: 'Kamera'}, {pkg: 'com.fake.rechner', label: 'Rechner'}, {pkg: 'com.fake.zeit', label: 'Zeitung'}]),
  appIcon: (p) => { window.__calls.push('icon:' + p); return PNG; },
  launchApp: (p) => { window.__calls.push('launch:' + p); return p !== 'com.fake.weg'; },
  isLauncher: () => window.__home,
  permStatus: () => JSON.stringify(window.__st),
  permRequest: (k) => { window.__calls.push('perm:' + k); return window.__res[k] || 'dialog'; },
  openHomeSettings: () => { window.__calls.push('homesettings'); return true; },
  homeApp: () => JSON.stringify(window.__homeApp || { pkg: 'com.google.android.apps.tv.launcherx', label: 'Google TV', self: false }),
  adbHelp: () => '# 1) x\\nadb shell cmd package set-home-activity --user 0 de.itspossible.moviescout/X\\n# 3) y\\nadb shell appops set --uid de.itspossible.moviescout MANAGE_EXTERNAL_STORAGE allow',
  launcherAdbCommand: () => 'adb shell cmd package set-home-activity de.itspossible.moviescout/de.itspossible.moviescout.MainActivity',
};
"""
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 1100, 'height': 760}, user_agent='Mozilla/5.0 MovieScoutApp')
            ctx.add_init_script(FAKE)
            pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (API, API)); pg.wait_for_function('typeof providers !== "undefined" && providers.length', timeout=20000); pg.wait_for_timeout(600)
            pg.evaluate("async () => { SK.active = 'look-desk-android'; skinsSave(); applySkin(activeSkin()); await renderView(); }"); pg.wait_for_timeout(500)

            pg.locator('.dstart').click(); pg.wait_for_selector('.startm .sme'); pg.wait_for_timeout(500)
            names = pg.evaluate("[...document.querySelectorAll('.sme b')].map(e => e.textContent)")
            check('Startmenü listet die Android-Apps', all(n in names for n in ('Kamera', 'Rechner', 'Zeitung')), names)
            check('Filter „Apps“ vorhanden', pg.locator('.smchips .chip', has_text='Apps').count() == 1)
            check('Funktion „Einrichtung“ im Startmenü', any(n.startswith('Einrichtung') for n in names), names)
            pg.locator('.smchips .chip', has_text='Apps').click(); pg.wait_for_timeout(500)
            check('Filter zeigt nur die Apps', pg.locator('.sme').count() == 3)
            check('App-Symbole werden als Bild geholt', pg.locator('.sme .di img').count() == 3 and pg.evaluate("__calls.filter(c => c.startsWith('icon:')).length") >= 3, pg.evaluate("__calls"))

            # per Menü (OK halten) auf den Desktop
            pg.evaluate("document.querySelector('.sme').focus()")
            pg.keyboard.down('Enter'); pg.wait_for_timeout(900); pg.keyboard.up('Enter'); pg.wait_for_timeout(850)
            pg.locator('.cardmenu').get_by_role('button', name='Auf Desktop legen').click(); pg.wait_for_timeout(600)
            check('App liegt auf dem Desktop mit echtem Symbol', pg.locator('.dicon .di.app img').count() == 1)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            if pg.locator('.startm').count(): pg.evaluate("history.back()"); pg.wait_for_timeout(300)
            pg.locator('.dicon').first.click(); pg.wait_for_timeout(300)
            check('Klick startet die App', 'launch:com.fake.kamera' in pg.evaluate("__calls"), pg.evaluate("__calls"))
            # Sicherung/Neustart: Symbol wieder da
            pg.reload(); pg.wait_for_selector('#deskbar'); pg.wait_for_timeout(900)
            check('Nach Neustart: App-Symbol noch da', pg.locator('.dicon .di.app img').count() == 1)
            # deinstallierte App
            pg.evaluate("() => { const d = deskGet(); d.items.push({ id: 'weg', k: 'app', ref: 'com.fake.weg', label: 'Weg', icon: '📱', c: 4, r: 1 }); deskSet(d); deskLayout(); }"); pg.wait_for_timeout(300)
            pg.locator('.dicon[data-id="weg"]').click(); pg.wait_for_timeout(300)
            check('Fehlende App: Hinweis statt Absturz', pg.locator('.toast', has_text='nicht mehr installiert').count() >= 1)

            # Home-Taste: aus Unterseite/Fenster zurück auf den Desktop
            pg.evaluate("pushView({type:'list', title:'X', pid: providers[0].id, item: null, search: false})"); pg.wait_for_timeout(600)
            pg.evaluate("window.__intent = JSON.stringify({kind:'home'}); window.msIntent()"); pg.wait_for_timeout(700)
            check('Home-Taste (Intent „home“): zurück auf dem Desktop', pg.evaluate("nav.length") == 1 and pg.locator('.dkarea').count() == 1)
            pg.evaluate("window.__intent = ''")
            pg.evaluate("openSettings()"); pg.wait_for_timeout(500)
            pg.evaluate("window.__intent = JSON.stringify({kind:'home'}); window.msIntent()"); pg.wait_for_timeout(700)
            check('Home-Taste schließt auch Fenster', pg.evaluate("layers.length") == 0)
            pg.evaluate("window.__intent = ''")

            # Einrichtungs-Assistent
            pg.locator('.dstart').click(); pg.wait_for_selector('.startm .sme'); pg.wait_for_timeout(300)
            pg.fill('.smq', 'Einrichtung'); pg.wait_for_timeout(200)
            pg.locator('.sme').first.click(); pg.wait_for_selector('.setup'); pg.wait_for_timeout(500)
            rows = pg.evaluate("[...document.querySelectorAll('.setrow')].map(r => [r.dataset.state, r.querySelector('b').textContent.trim()])")
            check('Assistent zeigt 6 Punkte mit Stand', len(rows) == 6 and rows[0] == ['no', 'Startbildschirm'] and rows[1] == ['no', 'Home-Taste übernehmen'] and rows[3][0] == 'part' and rows[4][0] == 'part', rows)
            pg.get_by_role('button', name='Alles erlauben').first.click(); pg.wait_for_timeout(300)
            check('„Alles erlauben“ ist ein einziger Aufruf (perm:all)', pg.evaluate("__calls.filter(c => c === 'perm:all').length") == 1, pg.evaluate("__calls"))
            check('… mit Hinweis zur Reihenfolge', 'nacheinander' in pg.locator('.setup .setmsg').first.inner_text(), pg.locator('.setup .setmsg').first.inner_text())
            pg.evaluate("window.msPermChanged('all', 'done')"); pg.wait_for_timeout(200)
            check('… und Abschlussmeldung ohne Änderung am Startbildschirm', 'Startbildschirm bleibt' in pg.locator('.setup .setmsg').first.inner_text())
            pg.locator('.setrow').first.get_by_role('button', name='Festlegen').click(); pg.wait_for_timeout(300)
            check('„Festlegen“ fragt die App (perm:launcher)', 'perm:launcher' in pg.evaluate("__calls"))
            check('Hinweis zum Systemfenster', 'Android fragt jetzt' in pg.locator('.setrow').first.inner_text())
            pg.evaluate("window.__st.launcher = true; window.__home = true; window.msPermChanged('launcher', 'done')"); pg.wait_for_timeout(300)
            check('Nach „done“: Punkt erledigt, Knopf weg', pg.locator('.setrow').first.get_attribute('data-state') == 'ok' and not pg.locator('.setrow').first.get_by_role('button', name='Festlegen').is_visible())
            pg.locator('.setrow').nth(3).get_by_role('button').click(); pg.wait_for_timeout(200)
            check('Dateizugriff wird angefragt', 'perm:storage' in pg.evaluate("__calls"))
            pg.evaluate("__res.homekey = 'settings'"); pg.locator('.setrow').nth(1).get_by_role('button', name='Einschalten').click(); pg.wait_for_timeout(200)
            check('„Home-Taste übernehmen“ fragt die App (perm:homekey)', 'perm:homekey' in pg.evaluate("__calls"))
            check('… mit Anleitung zu Bedienungshilfen', 'Bedienungshilfen' in pg.locator('.setrow').nth(1).inner_text(), pg.locator('.setrow').nth(1).inner_text())
            pg.evaluate("window.__st.homekey = true; window.msPermChanged('homekey', 'done')"); pg.wait_for_timeout(300)
            check('Nach „done“: erledigt, Knopf weg', pg.locator('.setrow').nth(1).get_attribute('data-state') == 'ok' and not pg.locator('.setrow').nth(1).get_by_role('button', name='Einschalten').is_visible())
            pg.evaluate("__res.battery = 'settings'")
            pg.locator('.setrow').nth(5).get_by_role('button').click(); pg.wait_for_timeout(200)
            check('Akku: Hinweis zur Einstellungsseite', 'Einstellungen sind offen' in pg.locator('.setrow').nth(5).inner_text())
            check('Stand-Zeile zeigt Version der Oberfläche', 'Oberfläche' in pg.locator('.setver').inner_text() and 'unterstützt' in pg.locator('.setver').inner_text(), pg.locator('.setver').inner_text())
            pg.evaluate("__res.launcher = 'adb'; window.__st.launcher = false; window.msPermChanged('launcher', 'adb')"); pg.wait_for_timeout(200)
            check('Ohne Auswahl im System: ADB-Befehl wird geöffnet', 'set-home-activity' in pg.locator('.setadb pre').inner_text() and pg.evaluate("document.querySelector('.setadb').open"))
            pg.get_by_role('button', name='Android: Standard-Apps / Startbildschirm direkt öffnen').click(); pg.wait_for_timeout(200)
            check('Direkter Weg zur Android-Seite', 'homesettings' in pg.evaluate("__calls"))
            pg.evaluate("history.back()"); pg.wait_for_timeout(400)
            pg.evaluate("window.__st.tv = true; window.__st.launcher = false; window.__home = false")
            pg.evaluate("openLauncherSetup()"); pg.wait_for_selector('.setup'); pg.wait_for_timeout(500)
            check('Fernseher: Hinweis und ADB-Befehl sofort sichtbar', 'Fernseher' in pg.locator('.setrow').first.inner_text() and pg.evaluate("document.querySelector('.setadb').open"))
            check('Fernseher: Hinweis zum fehlenden „Alle Dateien“-Schalter', 'Befehl 3' in pg.locator('.setrow').nth(3).inner_text(), pg.locator('.setrow').nth(3).inner_text())
            check('Anzeige, welche App die Home-Taste öffnet', 'Google TV' in pg.locator('.sethome').inner_text(), pg.locator('.sethome').inner_text())
            check('Befehle für Prüfen und Dateizugriff stehen im ADB-Feld', 'appops set' in pg.locator('.setadb pre').inner_text())
            pg.evaluate("window.msPermChanged('storage', 'adb')"); pg.wait_for_timeout(200)
            check('Dateizugriff ohne Schalter: klare Meldung statt „teilweise“-Sackgasse', 'keinen Schalter' in pg.locator('.setrow').nth(3).inner_text())
            pg.evaluate("window.__homeApp = { pkg: 'de.itspossible.moviescout', label: 'MovieScout', self: true }; window.msPermChanged('launcher', 'open')"); pg.wait_for_timeout(200)
            check('Ist MovieScout Home: „✔ öffnet gerade MovieScout“', 'öffnet gerade MovieScout' in pg.locator('.sethome').inner_text())
            pg.evaluate("history.back()"); pg.wait_for_timeout(400)
            # Einstellungen enthalten den Knopf
            pg.evaluate("goHome()"); pg.wait_for_timeout(500)
            pg.evaluate("openSettings()"); pg.wait_for_timeout(800)
            check('Einstellungen: Knopf „Einrichtung“', pg.get_by_role('button', name='Einrichtung: Startbildschirm & Berechtigungen').count() >= 1)
            b.close()
    finally:
        srv.terminate()
    check('Keine Skriptfehler', not errs, errs)
    print('\n%d ok, %d Fehler' % (passed, failed)); return 1 if failed else 0
if __name__ == '__main__': sys.exit(main())
