# -*- coding: utf-8 -*-
"""Test des Glas-Modus im Skin und der Tonspuren-Auswahl im Player mit echter Engine und Browser.

    python tests/glass_audio_test.py
"""
import json
import threading
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from datetime import date
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8904
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=30) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=8, step=0.1):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def setv(ext, **values):
    return http('/api/admin/ext/settings', {'ext': ext, 'values': values})[0]


def code_of(gid):
    from engine import examples as EXM
    return next(e for e in EXM.EXAMPLES if e['id'] == gid)['code']


HLS_CMD = ['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=160x90:rate=10:duration=12', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=12',
           '-f', 'lavfi', '-i', 'sine=frequency=660:duration=12', '-map', '0:v', '-map', '1:a', '-map', '2:a', '-c:v', 'libvpx-vp9', '-b:v', '100k', '-g', '20',
           '-c:a', 'libopus', '-ac', '2', '-strict', '-2', '-f', 'hls', '-hls_time', '4', '-hls_playlist_type', 'vod', '-hls_segment_type', 'fmp4',
           '-master_pl_name', 'master.m3u8', '-var_stream_map', 'v:0,agroup:aud a:0,agroup:aud,language:de,name:Deutsch,default:yes a:1,agroup:aud,language:en,name:English', 'v%v.m3u8']


class CorsHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def log_message(self, *a):
        pass


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_ga_'))
    hd = tmp / 'hls'
    hd.mkdir()
    subprocess.run(HLS_CMD, cwd=str(hd), check=True)
    fport = 8905
    fake = ThreadingHTTPServer(('127.0.0.1', fport), partial(CorsHandler, directory=str(hd)))
    threading.Thread(target=fake.serve_forever, daemon=True).start()
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), MINIKODI_ALLOW_PRIVATE='1', PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            br = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
            ctx = br.new_context(viewport={'width': 1000, 'height': 700})
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(BASE + '/ui/?api=' + BASE)
            pg.wait_for_function('typeof startPlayer === "function" && typeof applySkin === "function" || typeof normalizeSkin === "function"', timeout=20000)

            print('Glas-Modus')
            d = pg.evaluate("normalizeSkin({}).glass")
            check('Standard: Glas ist AUS (Leistung)', d['on'] is False and d['alpha'] == 55 and d['blur'] == 14, d)
            n = pg.evaluate("normalizeSkin({ glass: { on: true, alpha: 5, blur: 99 } }).glass")
            check('Werte werden begrenzt (alpha 15–90, Unschärfe 0–30)', n == {'on': True, 'alpha': 15, 'blur': 30}, n)
            check('Alte Skins ohne Glas-Feld laden ohne Fehler', pg.evaluate("normalizeSkin({ name: 'alt', colors: {} }).glass.on") is False)
            pg.evaluate("localStorage.clear()")
            has = pg.evaluate("typeof applySkin")
            fn = 'applySkin' if has == 'function' else None
            check('applySkin vorhanden', fn is not None, has)
            pg.evaluate("applySkin(Object.assign(normalizeSkin(skin.cur), { glass: { on: true, alpha: 40, blur: 20 } }))")
            check('Klasse sk-gl gesetzt, Unschärfe-Variable 20px', pg.evaluate("document.body.classList.contains('sk-gl')") and pg.evaluate("document.documentElement.style.getPropertyValue('--gl-blur')") == '20px')
            pg.evaluate("openPanel((p) => p.append(document.createTextNode('x')))")
            pg.wait_for_selector('.panel')
            bf = pg.evaluate("getComputedStyle(document.querySelector('.panel')).backdropFilter")
            bg = pg.evaluate("getComputedStyle(document.querySelector('.panel')).backgroundColor")
            check('Fenster hat Unschärfe und durchsichtigen Hintergrund', 'blur(20px)' in bf and bg.startswith('rgba'), (bf, bg))
            pg.evaluate("history.back()"); pg.wait_for_timeout(500)
            pg.evaluate("applySkin(Object.assign(normalizeSkin(skin.cur), { glass: { on: false, alpha: 40, blur: 20 } }))")
            pg.evaluate("openPanel((p) => p.append(document.createTextNode('x')))")
            pg.wait_for_selector('.panel')
            check('Aus: kein Filter, volle Farbe', pg.evaluate("getComputedStyle(document.querySelector('.panel')).backdropFilter") == 'none' and not pg.evaluate("document.body.classList.contains('sk-gl')"))
            pg.evaluate("history.back()"); pg.wait_for_timeout(500)

            print('Tonauswahl (hls.js ist offline nicht ladbar: Attrappe mit Tonspuren statt echtem hls.js)')
            MOCK = """window.Hls = class { static isSupported() { return true; }
              constructor() { this.h = {}; this._a = 0; this.levels = [{ audioCodec: 'ec-3' }]; this.currentLevel = 0;
                this.audioTracks = [{ name: 'Deutsch', lang: 'de', audioCodec: 'ac-3', attrs: { CHANNELS: '6' } }, { name: 'English', lang: 'en', audioCodec: 'ec-3', attrs: { CHANNELS: '16/JOC' } }, { name: 'English Stereo', lang: 'en', audioCodec: 'mp4a.40.2', attrs: { CHANNELS: '2' } }]; window.__hls = this; }
              on(e, f) { (this.h[e] = this.h[e] || []).push(f); } loadSource() { setTimeout(() => (this.h.atu || []).forEach((f) => f()), 50); } attachMedia() {} destroy() {}
              get audioTrack() { return this._a; } set audioTrack(i) { this._a = i; } };
              Hls.Events = { ERROR: 'err', MANIFEST_PARSED: 'mp', AUDIO_TRACKS_UPDATED: 'atu' };"""
            pg.route('**/vendor/hls.min.js', lambda r: r.fulfill(status=200, content_type='application/javascript', body=MOCK))
            hos = {'id': 0, 'name': 'H', 'url': 'http://127.0.0.1:%d/master.m3u8' % fport, 'format': 'hls', 'direct': True, 'headers': {}, 'drm': None}
            pg.evaluate("store.set('audlang', ''); store.set('audch', 'auto')")
            pg.evaluate("([h]) => startPlayer({ item: { title: 'Ton' }, hosters: [h], index: 0 }, 0)", [hos])
            pg.wait_for_function("window.__hls", timeout=15000)
            pg.wait_for_timeout(300)
            pg.click('#audBtn')
            pg.wait_for_selector('.panel button:has-text("English Stereo")', timeout=8000)
            txt = pg.inner_text('.panel')
            check('Drei Spuren mit Sprache, Dolby Digital / Plus / Atmos und Kanälen', 'Dolby Digital · Surround 5.1' in txt and 'Dolby Digital Plus · Dolby Atmos' in txt and 'AAC · Stereo' in txt and '(de)' in txt, txt)
            check('Erste Spur ist als aktiv markiert', '✓ Deutsch' in txt, txt)
            check('Dolby-Hinweis steht im Menü', 'Dolby (Digital / Plus) kann dieses Gerät' in txt)
            pg.click('.panel button:has-text("English Stereo")')
            pg.wait_for_timeout(300)
            check('Wechsel: Spur 3 gesetzt und Sprache (en) gemerkt', pg.evaluate("window.__hls.audioTrack") == 2 and pg.evaluate("store.get('audlang','')") == 'en')
            pg.click('#audBtn'); pg.wait_for_selector('.panel button:has-text("English Stereo")')
            check('Menü zeigt Spur 3 aktiv', '✓ English Stereo' in pg.inner_text('.panel'))
            pg.click('.panel button:has-text("Surround") >> nth=-1')
            pg.wait_for_timeout(300)
            check('Surround bevorzugt: gespeichert und englische Surround-Spur gewählt', pg.evaluate("store.get('audch','')") == 'surround' and pg.evaluate("window.__hls.audioTrack") == 1, pg.evaluate("window.__hls.audioTrack"))
            pg.evaluate("history.back()"); pg.wait_for_timeout(600)
            pg.evaluate("store.set('audch', 'stereo')")
            pg.evaluate("([h]) => startPlayer({ item: { title: 'Nochmal' }, hosters: [h], index: 0 }, 0)", [hos])
            pg.wait_for_function("window.__hls && window.__hls.audioTrack === 2", timeout=8000)
            check('Nächster Film: Englisch + Stereo wird automatisch gewählt', True)
            pg.evaluate("history.back()"); pg.wait_for_timeout(600)
            pg.evaluate("store.set('audlang', ''); store.set('audch', 'auto')")
            pg.evaluate("([h]) => startPlayer({ item: { title: 'Neutral' }, hosters: [h], index: 0 }, 0)", [hos])
            pg.wait_for_function("window.__hls", timeout=8000); pg.wait_for_timeout(500)
            check('Ohne Vorlieben bleibt die Standardspur (nichts wird verstellt)', pg.evaluate("window.__hls.audioTrack") == 0)
            pg.click('#audBtn'); pg.wait_for_selector('.panel')
            pg.evaluate("history.back()"); pg.wait_for_timeout(500)
            check('Keine Skriptfehler', not errs, errs)
            ctx.close(); br.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        fake.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
