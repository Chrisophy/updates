# -*- coding: utf-8 -*-
"""Spiele passen in jedes Fenster (Hoch- und Querformat, Handy) und verschieben sich nie: python tests/games_fit_test.py"""
import os
import socket
import subprocess
import sys
import tempfile
import time
import json
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
PORT = 8897
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def post(path, body):
    r = Request(BASE + path, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
    return json.loads(urlopen(r, timeout=30).read())


def upgrade_test():
    d = tempfile.mkdtemp(prefix='ms_up_')
    os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = d
    sys.path.insert(0, str(ROOT))
    from engine import system as SYS
    from engine import examples as EXM
    code = next(e for e in EXM.EXAMPLES if e['id'] == 'tetris')['code']
    old = code.replace('<meta name="ms-game">', '')
    (SYS.EXT_DIR).mkdir(parents=True, exist_ok=True)
    f = SYS.EXT_DIR / 'tetris.py'
    f.write_text(old, 'utf-8')
    check('Alte Fassung (ohne Marke) wird auf die neue gehoben', SYS.upgrade_games() == ['tetris'] and 'ms-game' in f.read_text('utf-8'))
    check('Zweiter Lauf lässt sie in Ruhe', SYS.upgrade_games() == [])
    check('Alte Fassung liegt im Papierkorb', any(SYS.TRASH_DIR.glob('tetris.py.*.bak')))


def main():
    upgrade_test()
    tmp = Path(tempfile.mkdtemp(prefix='ms_fit_'))
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(120):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close(); break
            except OSError:
                time.sleep(0.25)
        time.sleep(1)
        for gid in ('tetris', 'minispiele', 'pong', 'solitaire'):
            check('%s installiert' % gid, post('/api/admin/examples/install', {'id': gid}).get('ok'))
        from playwright.sync_api import sync_playwright
        sizes = [('Handy hoch', 412, 760), ('Handy quer', 800, 340), ('Handy quer klein', 700, 300), ('Tablet quer', 1280, 720)]
        with sync_playwright() as pw:
            br = pw.chromium.launch()
            for gid, setup in (('tetris', None), ('minispiele', 'snake'), ('minispiele', '2048'), ('minispiele', 'memory'), ('pong', None), ('solitaire', None)):
                for label, w, h in sizes:
                    ctx = br.new_context(viewport={'width': w, 'height': h}, has_touch=True, is_mobile=True)
                    pg = ctx.new_page()
                    errs = []
                    pg.on('pageerror', lambda e: errs.append(str(e)))
                    pg.goto(BASE + '/api/x/%s/index' % gid)
                    pg.wait_for_timeout(500)
                    if setup:
                        pg.click('button[data-g="%s"]' % setup)
                        pg.wait_for_timeout(300)
                    # Fokus/Tastatur/Pfeile dürfen nichts verschieben
                    for sel in ('input', 'button'):
                        if pg.locator(sel).count():
                            try: pg.locator(sel).first.focus()
                            except Exception: pass
                    pg.keyboard.press('ArrowDown'); pg.keyboard.press('ArrowUp'); pg.keyboard.press('Space')
                    pg.evaluate('window.scrollTo(0,500)')
                    pg.wait_for_timeout(150)
                    r = pg.evaluate("""()=>{const out={sy:scrollY+(document.scrollingElement||{}).scrollTop,iw:innerWidth,ih:innerHeight,bad:[]};
                      for(const e of document.querySelectorAll('canvas,#side,#pad,#lobby,#stage,header,#top,#cvw,#bar,#menu button')){const b=e.getBoundingClientRect();
                        if(b.width===0||b.height===0||getComputedStyle(e).display==='none')continue;
                        if(b.bottom>innerHeight+1||b.right>innerWidth+1||b.left<-1||b.top<-1)out.bad.push((e.id||e.tagName)+':'+Math.round(b.top)+'-'+Math.round(b.bottom)+'/'+Math.round(b.left)+'-'+Math.round(b.right))}
                      return out}""")
                    name = '%s%s @ %s %dx%d' % (gid, ('/' + setup) if setup else '', label, w, h)
                    check(name + ': nichts verschoben, alles im Bild', r['sy'] == 0 and not r['bad'], r)
                    check(name + ': keine Skriptfehler', not errs, errs)
                    ctx.close()
            br.close()
    finally:
        p.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


main()
