"""Atari unter Android-/TV-Kennung: keine Javatari-Touch-Oberfläche, Bild füllt den Schirm, alles per Fernbedienung."""
import os, sys, socket, subprocess, tempfile, time, shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent; API = 8983; ok = bad = 0
def check(n, c, d=''):
    global ok, bad
    if c: ok += 1; print('  ok   ', n)
    else: bad += 1; print('  FEHLER', n, d)
tmp = tempfile.mkdtemp(); (Path(tmp) / 'retro' / 'atari2600').mkdir(parents=True); shutil.copy(ROOT / 'tests' / 'test_game.a26', Path(tmp) / 'retro' / 'atari2600' / 't.a26')
env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), NO_PROXY='127.0.0.1')
srv = subprocess.Popen([sys.executable, 'main.py', '--port', str(API)], cwd=ROOT, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(100):
    try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
    except OSError: time.sleep(.25)
UAS = {'TV': 'Mozilla/5.0 (Linux; Android 12; TCL TV) AppleWebKit/537.36 Chrome/120 Safari/537.36',
       'Handy': 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'}
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        for name, ua in UAS.items():
            ctx = b.new_context(viewport={'width': 1280, 'height': 720}, user_agent=ua, has_touch=(name == 'Handy'), is_mobile=(name == 'Handy'))
            pg = ctx.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/retro/play.html?rom=/api/retro/rom/atari2600/t.a26' % API); pg.wait_for_timeout(4000)
            t = pg.evaluate("document.body.innerText")
            check(name + ': kein „go full-screen“-Dialog', 'GO!' not in t and 'full-screen' not in t, t[:80])
            vis = lambda sel: pg.evaluate("(s)=>{const e=document.querySelector(s);if(!e)return false;const r=e.getBoundingClientRect();return getComputedStyle(e).display!='none'&&r.width>0}", sel)
            check(name + ': keine Konsolenleiste / Wisch- / Ton-Hinweis', not (vis('#jt-bar') or vis('#jt-screen-scroll-message') or vis('#jt-unmute-message') or vis('.jt-console-panel')))
            r = pg.evaluate("(()=>{const r=document.querySelector('#jt-screen-canvas').getBoundingClientRect();return [r.width,r.height]})()")
            check(name + ': Bild nutzt den Schirm (Breite ≥ 90 % oder Höhe ≥ 90 %)', r[0] >= 1280 * .9 or r[1] >= 720 * .9, r)
            if name == 'TV': check('TV: ≡-Knopf (nur Touch) nicht sichtbar', not vis('#mbtn'))
            pg.keyboard.press('ContextMenu'); pg.wait_for_timeout(300)
            check(name + ': Menütaste öffnet das Spielmenü', pg.evaluate('window.__retro.isOpen()'))
            pg.keyboard.press('Escape'); pg.wait_for_timeout(200); pg.evaluate('window.__retro.setMenu(false)')
            pg.keyboard.down('Enter'); pg.wait_for_timeout(1700); pg.keyboard.up('Enter'); pg.wait_for_timeout(200)
            check(name + ': OK lange halten öffnet das Spielmenü', pg.evaluate('window.__retro.isOpen()'))
            pg.evaluate('window.__retro.setMenu(false)')
            pg.evaluate("window.__calls=[];const k=Javatari.room.consoleControls,o=k.processControlState.bind(k);k.processControlState=(c,v)=>{window.__calls.push([c,v]);return o(c,v)}")
            for key in ('ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'): pg.keyboard.down(key); pg.wait_for_timeout(80); pg.keyboard.up(key)
            n = pg.evaluate("new Set(window.__calls.filter(c=>c[1]).map(c=>c[0])).size")
            check(name + ': Pfeiltasten gehen als Joystick an den Emulator (4 Richtungen gedrückt)', n >= 4, n)
            check(name + ': keine Skriptfehler', not errs, errs)
            ctx.close()
finally:
    srv.terminate()
print('\n%d ok, %d Fehler' % (ok, bad)); sys.exit(1 if bad else 0)
