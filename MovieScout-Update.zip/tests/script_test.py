# -*- coding: utf-8 -*-
"""Test der script.*-Kompatibilität: Bibliotheken (script.module.*), Programme, Dienste, RunScript, Abhängigkeiten aus einem Fake-Kodi-Repository.

    python tests/script_test.py
"""
import gzip
import io
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
PORT, REPO_PORT = 8921, 8922
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, raw=None):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    req = Request(BASE + path, data=data, method='POST' if data is not None else 'GET',
                  headers={'Content-Type': 'application/zip' if raw is not None else 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=60) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=10, step=0.2):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def addon_xml(aid, ver, points, requires=(), name=None):
    req = ''.join('<import addon="%s" version="1.0.0"%s/>' % (r.rstrip('?'), ' optional="true"' if r.endswith('?') else '') for r in requires)
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<addon id="%s" name="%s" version="%s" provider-name="Test">\n'
            '  <requires><import addon="xbmc.python" version="3.0.0"/>%s</requires>\n%s\n'
            '  <extension point="xbmc.addon.metadata"><summary lang="de">Test %s</summary></extension>\n</addon>') % (aid, name or aid, ver, req, points, aid)


def zipped(aid, files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for n, c in files.items():
            z.writestr(aid + '/' + n, c)
    return b.getvalue()


PROG = """
import json, os, sys
import xbmc, xbmcgui
import fixlib
import inner
from resources.lib import helper
rec = {'argv': [os.path.basename(sys.argv[0])] + sys.argv[1:], 'lib': fixlib.hello(), 'inner': inner.VALUE, 'helper': helper.who()}
with open(os.environ['FIXPROG_OUT'], 'a') as f:
    f.write(json.dumps(rec) + '\\n')
xbmcgui.Dialog().notification('Fixprog', 'lib=%s args=%s' % (fixlib.hello(), ','.join(sys.argv[1:])))
"""
RUNNER = """
import xbmc, xbmcgui, xbmcplugin
from urllib.parse import parse_qsl
HANDLE = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
if params.get('action') == 'go':
    xbmc.executebuiltin('RunScript(script.fixprog, a, b)')
li = xbmcgui.ListItem(label='Fertig')
xbmcplugin.addDirectoryItem(HANDLE, sys.argv[0] + '?action=done', li, isFolder=True)
xbmcplugin.endOfDirectory(HANDLE)
"""
SVC = """
import os, xbmc
mon = xbmc.Monitor()
import fixlib
n = 0
while not mon.abortRequested():
    with open(os.environ['FIXSVC_OUT'], 'w') as f:
        f.write('%s:%d' % (fixlib.hello(), n))
    n += 1
    if mon.waitForAbort(0.3):
        break
"""


def build_repo():
    z = {}
    meta = {}
    z['script.module.inner'] = (zipped('script.module.inner', {
        'addon.xml': addon_xml('script.module.inner', '1.0.0', '<extension point="xbmc.python.module" library="lib"/>'),
        'lib/inner.py': 'VALUE = 42\n'}), '1.0.0')
    z['script.module.fixlib'] = (zipped('script.module.fixlib', {
        'addon.xml': addon_xml('script.module.fixlib', '2.0.0', '<extension point="xbmc.python.module" library="lib"/>', ['script.module.inner', 'script.module.requests', 'script.module.opt?']),
        'lib/fixlib.py': 'def hello():\n    return "lib-ok"\n'}), '2.0.0')
    return z


class Repo(BaseHTTPRequestHandler):
    zips = {}
    hits = []

    def do_GET(self):
        Repo.hits.append(self.path)
        if self.path == '/addons.xml.gz':
            root = '<addons>' + ''.join('<addon id="%s" version="%s"/>' % (k, v[1]) for k, v in Repo.zips.items()) + '</addons>'
            data = gzip.compress(root.encode())
        else:
            parts = self.path.strip('/').split('/')
            ent = Repo.zips.get(parts[0]) if len(parts) == 2 else None
            data = ent[0] if ent and parts[1] == '%s-%s.zip' % (parts[0], ent[1]) else None
        if data is None:
            self.send_response(404); self.end_headers(); return
        self.send_response(200); self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)

    def log_message(self, *a):
        pass


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_script_'))
    Repo.zips = build_repo()
    srv = HTTPServer(('127.0.0.1', REPO_PORT), Repo)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    out_prog, out_svc = tmp / 'prog.jsonl', tmp / 'svc.txt'
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1', MINIKODI_ALLOW_PRIVATE='1',
               MOVIESCOUT_KODI_REPO='http://127.0.0.1:%d/' % REPO_PORT, FIXPROG_OUT=str(out_prog), FIXSVC_OUT=str(out_svc))
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait(lambda: http('/api/providers')[0] == 200, 30):
            print('Engine startet nicht'); return 1

        print('Programm mit Abhängigkeiten installieren')
        prog = zipped('script.fixprog', {
            'addon.xml': addon_xml('script.fixprog', '1.0.0', '<extension point="xbmc.python.script" library="default.py"/>',
                                   ['script.module.fixlib', 'script.module.requests']),
            'default.py': PROG, 'resources/__init__.py': '', 'resources/lib/__init__.py': '',
            'resources/lib/helper.py': 'def who():\n    return "helper-ok"\n'})
        c, r = http('/api/admin/addon/install', raw=prog)
        check('Programm wird installiert (kind=script)', c == 200 and r['addon']['kind'] == 'script' and r['addon']['id'] == 'script.fixprog', r)
        dp = r.get('deps', {})
        check('Fehlende Bibliotheken kommen aus dem Repo (fixlib + inner), requests nicht', sorted(dp.get('installed', [])) == ['script.module.fixlib', 'script.module.inner'] and not dp.get('failed'), dp)
        check('Optionale/mitgelieferte Abhängigkeiten werden nicht geholt', not any('opt' in h or 'requests' in h for h in Repo.hits), Repo.hits)
        lst = http('/api/admin/addons')[1]['addons']
        kinds = {a['id']: a['kind'] for a in lst}
        check('Liste zeigt Typen', kinds.get('script.module.fixlib') == 'module' and kinds.get('script.fixprog') == 'script', kinds)
        check('Nichts fehlt mehr', all(not a['missing'] for a in lst), lst)
        provs = [x['id'] for x in http('/api/providers')[1]['providers']]
        check('Programm erscheint als Quelle, Bibliotheken nicht', 'addon_script_fixprog' in provs and not any('module' in x for x in provs), provs)

        print('Programm starten')
        PID = 'addon_script_fixprog'
        c, root = http('/api/open', {'provider_id': PID, 'item': {}})
        titles = [i['title'] for i in root.get('items', [])]
        check('Startmenü: „Starten“-Eintrag', c == 200 and titles and titles[0].startswith('Starten'), root)
        c, res = http('/api/open', {'provider_id': PID, 'item': root['items'][0]})
        rec = [json.loads(l) for l in out_prog.read_text().splitlines()] if out_prog.exists() else []
        check('Programm lief mit Bibliotheken (Datei-, Paket- und Unterbibliothek)', rec and rec[0]['lib'] == 'lib-ok' and rec[0]['inner'] == 42 and rec[0]['helper'] == 'helper-ok', rec)
        check('sys.argv[0] ist der Programmpfad, keine Argumente', rec and rec[0]['argv'] == ['default.py'], rec)
        check('Meldung des Programms kommt in der Antwort an', 'lib=lib-ok' in json.dumps(res, ensure_ascii=False), res)
        c, r = http('/api/admin/addon/run', {'id': 'script.fixprog', 'args': ['x', 'y z']})
        rec = [json.loads(l) for l in out_prog.read_text().splitlines()]
        check('Direktstart mit Argumenten', c == 200 and rec[-1]['argv'] == ['default.py', 'x', 'y z'], (r, rec))

        print('RunScript aus einem Plugin')
        plug = zipped('plugin.video.runner', {
            'addon.xml': addon_xml('plugin.video.runner', '1.0.0', '<extension point="xbmc.python.pluginsource" library="main.py"><provides>video</provides></extension>'),
            'main.py': RUNNER})
        c, r = http('/api/admin/addon/install', raw=plug)
        check('Plugin installiert', c == 200 and r['addon']['kind'] == 'plugin', r)
        n0 = len(out_prog.read_text().splitlines())
        c, res = http('/api/open', {'provider_id': 'addon_plugin_video_runner', 'item': {'url': 'plugin://plugin.video.runner/?action=go', 'next_func': 'load', 'title': 'Los'}})
        rec = [json.loads(l) for l in out_prog.read_text().splitlines()]
        check('RunScript(script.fixprog, a, b) startet das Programm mit a, b', c == 200 and len(rec) == n0 + 1 and rec[-1]['argv'] == ['default.py', 'a', 'b'], (res, rec[-2:]))
        check('Programmeinträge landen nicht in der Liste des Plugins', [i['title'] for i in res.get('items', [])] == ['Fertig'], res)

        print('Dienst')
        svc = zipped('script.fixsvc', {
            'addon.xml': addon_xml('script.fixsvc', '1.0.0', '<extension point="xbmc.service" library="service.py" start="startup"/>', ['script.module.fixlib']),
            'service.py': SVC})
        c, r = http('/api/admin/addon/install', raw=svc)
        check('Dienst-Addon wird installiert und startet', c == 200 and r['addon']['kind'] == 'service' and wait(lambda: out_svc.exists() and out_svc.read_text().startswith('lib-ok:'), 10), r)
        check('Dienst ist keine Quelle', 'addon_script_fixsvc' not in [x['id'] for x in http('/api/providers')[1]['providers']])

        print('Fehlerfälle')
        bad = zipped('skin.fixture', {'addon.xml': addon_xml('skin.fixture', '1.0.0', '<extension point="xbmc.gui.skin" effectslowdown="1"/>')})
        c, r = http('/api/admin/addon/install', raw=bad)
        check('Skins werden verständlich abgelehnt', c == 400 and 'nicht unterstützt' in json.dumps(r, ensure_ascii=False), r)
        gone = zipped('script.needs', {
            'addon.xml': addon_xml('script.needs', '1.0.0', '<extension point="xbmc.python.script" library="default.py"/>', ['script.module.gibtsnicht']),
            'default.py': 'pass\n'})
        c, r = http('/api/admin/addon/install', raw=gone)
        check('Fehlende, nicht auffindbare Bibliothek wird gemeldet (Installation bleibt)', c == 200 and r['deps']['failed'] and r['deps']['failed'][0]['id'] == 'script.module.gibtsnicht', r)
        lst = {a['id']: a for a in http('/api/admin/addons')[1]['addons']}
        check('Liste führt die fehlende Bibliothek auf', lst['script.needs']['missing'] == ['script.module.gibtsnicht'], lst['script.needs'])
        c, r = http('/api/admin/addon/deps', {'id': 'script.needs', 'fetch': False})
        check('Abhängigkeiten ohne Download prüfen', c == 200 and r['deps']['missing'] == ['script.module.gibtsnicht'], r)
        c, r = http('/api/admin/addon/run', {'id': 'plugin.video.runner'})
        check('Quelle ist kein Programm', c == 400, r)
        c, r = http('/api/admin/addon/run', {'id': 'script.nope'})
        check('Unbekanntes Programm', c == 400, r)
        zbomb = io.BytesIO()
        with zipfile.ZipFile(zbomb, 'w') as z:
            z.writestr('script.evil/addon.xml', addon_xml('script.evil', '1.0.0', '<extension point="xbmc.python.script" library="default.py"/>'))
            z.writestr('script.evil/../../x.txt', 'x')
        check('Unsichere Pfade bleiben abgelehnt', http('/api/admin/addon/install', raw=zbomb.getvalue())[0] == 400)

        print('Verständliche Fehler')
        def prog(aid, code, req=()):
            return zipped(aid, {'addon.xml': addon_xml(aid, '1.0.0', '<extension point="xbmc.python.script" library="default.py"/>', list(req)), 'default.py': code})
        http('/api/admin/addon/install', raw=prog('script.badimp', 'import gibtsnicht_modul\n', ['script.module.gibtsnicht']))
        c, r = http('/api/admin/addon/run', {'id': 'script.badimp'})
        check('Fehlende Bibliothek: Klartext mit Kennung und Nachladen-Hinweis', c == 400 and 'script.module.gibtsnicht' in r['error'] and 'Nachladen' in r['error'], r)
        http('/api/admin/addon/install', raw=prog('script.badimp2', 'import gibtsnicht_modul2\n'))
        c, r = http('/api/admin/addon/run', {'id': 'script.badimp2'})
        check('Fehlendes Python-Modul ohne bekannte Abhängigkeit: Modulname im Klartext', c == 400 and 'gibtsnicht_modul2' in r['error'] and 'Traceback' not in r['error'], r)
        http('/api/admin/addon/install', raw=prog('script.crash', 'x = 1\nraise ValueError("kaputt")\n'))
        c, r = http('/api/admin/addon/run', {'id': 'script.crash'})
        check('Absturz: Fehlertext mit Datei und Zeile', c == 400 and 'ValueError: kaputt' in r['error'] and 'default.py, Zeile 2' in r['error'], r)
        c, res = http('/api/open', {'provider_id': 'addon_script_crash', 'item': {'url': 'script://script.crash/run', 'next_func': 'load', 'title': 'x'}})
        check('Auch über die Oberfläche (/api/open) kommt der Klartext an', c == 502 and 'default.py, Zeile 2' in res.get('error', ''), (c, res))
        http('/api/admin/addon/install', raw=prog('script.win', 'import xbmcgui\nclass W(xbmcgui.WindowXMLDialog):\n    pass\nW("x.xml", "/tmp").doModal()\n'))
        c, r = http('/api/admin/addon/run', {'id': 'script.win'})
        check('Kodi-Fenster (WindowXML): ehrlicher Hinweis statt stillem Nichts', c == 200 and any('WindowXML' in n.get('message', '') for n in r['notes']), r)

        print('Entfernen')
        c, r = http('/api/admin/addon/remove', {'id': 'script.fixprog'})
        check('Programm entfernen', c == 200 and 'addon_script_fixprog' not in [x['id'] for x in http('/api/providers')[1]['providers']], r)
        c, r = http('/api/admin/addon/remove', {'id': 'script.module.inner'})
        check('Bibliothek entfernen (ohne Quelle)', c == 200 and not (tmp / 'd' / 'addons' / 'script.module.inner').exists(), r)
        c, r = http('/api/admin/addon/deps', {'id': 'script.module.fixlib'})
        check('Nachladen holt die entfernte Bibliothek wieder', c == 200 and r['deps']['installed'] == ['script.module.inner'], r)
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
