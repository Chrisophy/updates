# -*- coding: utf-8 -*-
"""GitHub-Sync: Datei im falschen Ordner wird richtig einsortiert, Hilfsdateien sind kein Fehler.

    python tests/sync_kind_test.py
"""
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
tmp = tempfile.mkdtemp(prefix='ms_sync_')
os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = tmp
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


SCRAPER = "SITE_ID = 'fp'\nSITE_NAME = 'Film Palast'\n\n\ndef load(url='', params=None):\n    return []\n\n\ndef get_hosters(**kw):\n    return []\n"
EXT = "EXT_ID = 'gad'\nEXT_NAME = 'Gad'\n\n\ndef register(api):\n    pass\n"
HELPER = "def helper(x):\n    return x\n"
BROKEN = "def load(:\n"
FILES = {'filmpalast.py': SCRAPER, 'mini_player.py': HELPER, 'gad.py': EXT, 'kaputt.py': BROKEN}


class R:
    def __init__(self, text, code=200):
        self.text, self.status_code = text, code


def main():
    import kodi_runtime  # noqa: F401
    from engine import app
    from resources.lib import multiquest

    def fake_get(url, **kw):
        if 'api.github.com' in url:
            return R(json.dumps([{'type': 'file', 'name': n, 'download_url': 'http://raw/' + n} for n in FILES]))
        return R(FILES[url.rsplit('/', 1)[1]])
    multiquest.get = fake_get
    app.R.reload_all = lambda *a, **k: None

    for kind, repo in (('extension', 'https://github.com/x/gadgets'), ('provider', 'https://github.com/x/scraper')):
        r = app.sync_github_providers(repo, kind)
        print(kind, {k: r[k] for k in ('changed', 'unchanged', 'skipped', 'failed')})
        check('%s: Hilfsdatei übersprungen, nur die kaputte Datei zählt als Fehler' % kind, r['skipped'] == 1 and r['failed'] == 1 and any('kaputt.py' in w for w in r['warnings']), r)
    from engine import system as SYS
    check('Scraper aus dem Gadget-Ordner liegt bei den Scrapern', (SYS.kind_dir('provider') / 'filmpalast.py').is_file())
    check('Erweiterung aus dem Scraper-Ordner liegt bei den Erweiterungen', (SYS.kind_dir('extension') / 'gad.py').is_file())
    check('Hilfsdatei wurde nicht abgelegt', not (SYS.kind_dir('provider') / 'mini_player.py').exists() and not (SYS.kind_dir('extension') / 'mini_player.py').exists())
    check('Scraper liegt nicht doppelt bei den Erweiterungen', not (SYS.kind_dir('extension') / 'filmpalast.py').exists())
    r = app.sync_github_providers('https://github.com/x/scraper', 'provider')
    check('Zweiter Lauf: alles unverändert', r['changed'] == 0 and r['unchanged'] == 2, r)
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
