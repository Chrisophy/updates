# -*- coding: utf-8 -*-
"""Mediaplayer-Mediathek, Dateibrowser und "Sicherung aus Ordner/Chat-Datei einspielen":

    python tests/medialib_test.py
"""
import io
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 8841
API = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def call(path, data=None, raw=False, headers=None, method=None):
    body = None
    h = dict(headers or {})
    if data is not None:
        body = json.dumps(data).encode() if not isinstance(data, bytes) else data
        h.setdefault('Content-Type', 'application/json')
    req = urllib.request.Request(API + path, data=body, headers=h, method=method)
    try:
        r = urllib.request.urlopen(req, timeout=40)
    except urllib.error.HTTPError as e:
        r = e
    b = r.read()
    if raw:
        return r.status, {k.title(): v for k, v in dict(r.headers).items()}, b
    try:
        return r.status, json.loads(b)
    except Exception:
        return r.status, b


def wait_port(port, tries=100):
    import socket
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def main():
    tmp = Path(tempfile.mkdtemp())
    media = tmp / 'media'
    (media / 'Alben' / 'Eins').mkdir(parents=True)
    (media / 'Filme').mkdir()
    (media / 'Fotos').mkdir()
    (media / 'Alben' / 'Eins' / 'a.mp3').write_bytes(b'ID3' + bytes(range(256)) * 40)
    (media / 'Alben' / 'Eins' / 'b.flac').write_bytes(b'fLaC' + b'\0' * 500)
    (media / 'Alben' / 'cover.txt').write_text('kein Medium')
    (media / 'Filme' / 'f.mp4').write_bytes(b'\0\0\0\x18ftypmp42' + b'\1' * 5000)
    (media / 'Filme' / 'g.mkv').write_bytes(b'\x1a\x45\xdf\xa3' + b'\2' * 100)
    (media / 'Fotos' / 'p.jpg').write_bytes(b'\xff\xd8\xff' + b'\3' * 100)
    (media / '.versteckt.mp3').write_bytes(b'x')
    data = tmp / 'data'
    env = dict(os.environ, MOVIESCOUT_DATA=str(data), PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MINIKODI_DATA'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(PORT)], env=env, cwd=str(ROOT),
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        assert wait_port(PORT), 'Engine startet nicht'

        print('Dateibrowser')
        s, d = call('/api/fs/roots')
        check('Startpunkte vorhanden', s == 200 and any(r['path'] for r in d['roots']), d)
        s, d = call('/api/fs/list?path=' + urllib.request.quote(str(media)) + '&only=media')
        names = [e['name'] for e in d['entries']]
        check('Ordner zuerst, sortiert', names[:3] == ['Alben', 'Filme', 'Fotos'], names)
        s, d = call('/api/fs/list?path=' + urllib.request.quote(str(media / 'Alben')) + '&only=media')
        check('Nur Medien: cover.txt ausgeblendet', [e['name'] for e in d['entries']] == ['Eins'], d)
        check('Elternordner gemeldet', d['parent'] == str(media), d)
        s, d = call('/api/fs/list?path=' + urllib.request.quote(str(media)))
        check('Versteckte Dateien ausgeblendet', not any(e['name'].startswith('.') for e in d['entries']), d)
        s, d = call('/api/fs/list?path=' + urllib.request.quote(str(media / 'nix')))
        check('Fehlender Ordner: Fehlermeldung', s == 400 and 'error' in d, (s, d))

        print('Mediathek hinzufügen')
        s, d = call('/api/media/add', {'paths': [str(media / 'Alben'), str(media / 'Filme' / 'f.mp4')]})
        check('Ordner rekursiv + Datei hinzugefügt (3 Musik/Video)', s == 200 and d['added'] == 3, d)
        s, d = call('/api/media/lib')
        L = d['lists']
        check('Musik einsortiert', [e['name'] for e in L['music']] == ['a.mp3', 'b.flac'], L)
        check('Video einsortiert', [e['name'] for e in L['video']] == ['f.mp4'], L)
        s, d = call('/api/media/add', {'paths': [str(media / 'Alben' / 'Eins' / 'a.mp3')]})
        check('Doppelte werden übersprungen', d['added'] == 0 and d['skipped'] == 1, d)
        s, d = call('/api/media/add', {'paths': [str(media / 'Filme' / 'g.mkv'), str(media / 'Fotos' / 'p.jpg'), str(media / 'Alben' / 'cover.txt')]})
        check('Mehrfachwahl: 2 neu, Textdatei übersprungen', d['added'] == 2 and d['skipped'] == 1, d)
        L = d['lists_all']
        check('Bilder-Liste', [e['name'] for e in L['image']] == ['p.jpg'], L)

        print('Wiedergabe (Bereichsanfragen)')
        eid = L['music'][0]['id']
        s, h, b = call('/api/media/file/' + eid, raw=True)
        check('Datei wird ausgeliefert', s == 200 and b.startswith(b'ID3') and h.get('Content-Type', '').startswith('audio/mpeg'), (s, h))
        s, h, b = call('/api/media/file/' + eid, raw=True, headers={'Range': 'bytes=3-9'})
        check('Spulen: 206 mit Teilstück', s == 206 and b == bytes(range(0, 7)) and h.get('Content-Range', '').startswith('bytes 3-9/'), (s, h, b))
        s, h, b = call('/api/media/file/' + L['video'][1]['id'], raw=True)
        check('MKV bekommt passenden Typ', h.get('Content-Type') == 'video/x-matroska', h)
        s, d = call('/api/media/file/0123456789ab')
        check('Unbekannte ID: 404', s == 404, (s, d))
        check('Pfad statt ID wird nicht ausgeliefert', call('/api/media/file/' + urllib.request.quote(str(media / 'Fotos' / 'p.jpg'), safe=''))[0] == 404)

        print('Verschieben und Löschen')
        a, b_ = L['music'][0]['id'], L['music'][1]['id']
        s, d = call('/api/media/move', {'id': a, 'delta': 1})
        s, d = call('/api/media/lib')
        check('Eine Position nach unten', [e['name'] for e in d['lists']['music']] == ['b.flac', 'a.mp3'], d)
        s, d = call('/api/media/move', {'id': a, 'delta': -5})
        s, d = call('/api/media/lib')
        check('Oben bleibt oben (begrenzt)', d['lists']['music'][0]['name'] == 'a.mp3', d)
        s, d = call('/api/media/move', {'id': b_, 'to': 'video'})
        s, d = call('/api/media/lib')
        check('In andere Liste verschoben', [e['name'] for e in d['lists']['video']][-1] == 'b.flac' and len(d['lists']['music']) == 1, d)
        s, d = call('/api/media/move', {'list': 'video', 'order': [e['id'] for e in reversed(d['lists']['video'])]})
        s, d = call('/api/media/lib')
        check('Reihenfolge per Liste gesetzt', d['lists']['video'][0]['name'] == 'b.flac', d)
        s, d = call('/api/media/remove', {'ids': [a]})
        check('Eintrag gelöscht', d['removed'] == 1, d)
        check('Datei selbst bleibt bestehen', (media / 'Alben' / 'Eins' / 'a.mp3').exists())
        s, d = call('/api/media/file/' + a)
        check('Gelöschter Eintrag wird nicht mehr ausgeliefert', s == 404)

        print('Gespeichert (Neustart) und Sicherung')
        srv.terminate(); srv.wait(10)
        srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(PORT)], env=env, cwd=str(ROOT),
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        assert wait_port(PORT), 'Engine startet nicht (2)'
        s, d = call('/api/media/lib')
        check('Nach Neustart noch da', len(d['lists']['video']) == 3 and len(d['lists']['image']) == 1, d)
        s, h, zdata = call('/api/admin/export', {'ui': {}, 'full': False}, raw=True)
        z = zipfile.ZipFile(io.BytesIO(zdata))
        check('Sicherung enthält die Mediathek', 'medialib.json' in z.namelist(), z.namelist())
        call('/api/media/remove', {'clear': 'video'})
        call('/api/media/remove', {'clear': 'image'})
        s, d = call('/api/media/lib')
        check('Listen geleert', not d['lists']['video'] and not d['lists']['image'])
        zp = tmp / 'sicherung.zip'
        zp.write_bytes(zdata)

        print('Sicherung aus Ordner einspielen (ohne Dateiauswahl des Systems)')
        s, d = call('/api/admin/import_path', {'path': str(zp)})
        check('Aus Pfad eingespielt', s == 200 and d.get('ok') and any('Mediathek' in r for r in d['report']), (s, d))
        s, d = call('/api/media/lib')
        check('Mediathek wiederhergestellt', len(d['lists']['video']) == 3 and len(d['lists']['image']) == 1, d)
        s, d = call('/api/admin/import_path', {'path': str(media / 'Alben' / 'cover.txt')})
        check('Keine ZIP: klare Meldung', s == 400, (s, d))
        s, d = call('/api/admin/import_path', {'path': str(tmp / 'gibtsnicht.zip')})
        check('Fehlende Datei: klare Meldung', s == 400, (s, d))
        bad = tmp / 'kaputt.zip'
        bad.write_bytes(b'kein zip')
        s, d = call('/api/admin/import_path', {'path': str(bad)})
        check('Kaputte ZIP: Fehlermeldung statt Absturz', s == 400 and 'error' in d, (s, d))

        print('Sicherung aus Familienchat-Datei')
        s, d = call('/api/admin/chatzips')
        check('Noch keine ZIP im Chat', s == 200 and d['files'] == [], d)
        key = call('/api/chat')[1].get('key') if isinstance(call('/api/chat')[1], dict) else ''
        s, d = call('/api/files?name=sicherung.zip&mime=application%2Fzip&author=Handy', zdata,
                    headers={'Content-Type': 'application/zip', 'X-Chat-Key': key or ''}, method='POST')
        check('ZIP über den Chat gesendet', s == 200 and d.get('message'), (s, str(d)[:200]))
        s, d = call('/api/admin/chatzips')
        check('ZIP wird angeboten', s == 200 and len(d['files']) == 1 and d['files'][0]['name'] == 'sicherung.zip', d)
        if d.get('files'):
            call('/api/media/remove', {'clear': 'video'})
            s, r = call('/api/admin/import_chatfile', {'id': d['files'][0]['id']})
            check('Aus Chat-Datei eingespielt', s == 200 and r.get('ok'), (s, r))
        s, r = call('/api/admin/import_chatfile', {'id': '../../etc/passwd'})
        check('Ungültige ID abgelehnt', s == 404, (s, r))
    finally:
        srv.terminate()
        try:
            srv.wait(10)
        except Exception:
            srv.kill()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
