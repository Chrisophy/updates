# -*- coding: utf-8 -*-
"""Kodi-Addon-Kompatibilität im Kleinen (xStream / xShip / Multistream): python tests/addon_compat_test.py"""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault('MOVIESCOUT_DATA', tempfile.mkdtemp())
os.environ.setdefault('MINIKODI_DATA', os.environ['MOVIESCOUT_DATA'])
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('OK  ', name)
    else:
        failed += 1; print('FAIL', name, extra)


from engine import addonhost as A                                     # noqa: E402
import engine.resolvers                                               # noqa: E402,F401  (legt vendor/ in den Suchpfad)

print('Importe werden auf das Addon-Paket umgeleitet')
cases = [
    ('from resources.lib import x', 'from ao_t.lib import x'),
    ('    import resources.lib.y as z', '    import ao_t.lib.y as z'),
    ('if k >= 20: from resources.lib.listitem import L', 'if k >= 20: from ao_t.lib.listitem import L'),
    ('try: from resources.lib import q', 'try: from ao_t.lib import q'),
    ('else: import resources.lib.w as w', 'else: import ao_t.lib.w as w'),
    ('a = 1; from resources.lib import e', 'a = 1; from ao_t.lib import e'),
    ('x = "resourcesfoo"', 'x = "resourcesfoo"'),
    ('d = {"a": 1}', 'd = {"a": 1}'),
]
for src, want in cases:
    got = A._rewrite(src, 'ao_t')
    check('Umschreiben: %s' % src[:46], got == want, got)
check('Zweiter Durchlauf ändert nichts mehr', A._rewrite(A._rewrite(cases[2][0], 'ao_t'), 'ao_t') == cases[2][1])

print('Fehlende Module')
import pyaes                                                          # noqa: E402
k, iv = os.urandom(32), os.urandom(16)
e = pyaes.Encrypter(pyaes.AESModeOfOperationCBC(k, iv)); ct = e.feed(b'Hallo Welt') + e.feed()
d = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(k, iv))
check('pyaes (script.module.pyaes) verschlüsselt/entschlüsselt', d.feed(ct) + d.feed() == b'Hallo Welt')

print('Kodi-Schnittstelle')
from kodi_runtime import xbmc, xbmcgui, xbmcplugin                    # noqa: E402
check('xbmc.VideoStreamDetail/AudioStreamDetail/SubtitleStreamDetail', all(hasattr(xbmc, n) for n in ('VideoStreamDetail', 'AudioStreamDetail', 'SubtitleStreamDetail')))
check('xbmc.LOGNOTICE', hasattr(xbmc, 'LOGNOTICE'))
check('xbmcplugin.SORT_METHOD_GENRE / PROGRAM_COUNT', hasattr(xbmcplugin, 'SORT_METHOD_GENRE') and hasattr(xbmcplugin, 'SORT_METHOD_PROGRAM_COUNT'))
tag = xbmcgui.ListItem(label='x').getVideoInfoTag()
tag.addVideoStream(xbmc.VideoStreamDetail(width=1920, height=1080)); tag.addAudioStream(xbmc.AudioStreamDetail(channels=2))
check('InfoTag.add…Stream wirft nicht', True)

print('Schalter-Standardwerte')
from kodi_runtime import xbmcaddon, paths                             # noqa: E402
ad = paths.DATA_DIR / 'addons' / 'plugin.video.boolt' / 'resources'
ad.mkdir(parents=True, exist_ok=True)
(ad / 'settings.xml').write_text('<settings version="1"><section id="x"><category id="c"><group id="g">'
                                 '<setting id="plugin_a" type="boolean"><default>True</default></setting>'
                                 '<setting id="plugin_b" type="boolean"><default>False</default></setting>'
                                 '<setting id="name" type="string"><default>Ab</default></setting></group></category></section></settings>', 'utf-8')
(ad.parent / 'moviescout-addon.json').write_text('{"id": "plugin.video.boolt"}', 'utf-8')
dflt = xbmcaddon._addon_defaults('plugin.video.boolt')
check('Boolesche Standardwerte kommen klein geschrieben („True“ → "true")', dflt.get('plugin_a') == 'true' and dflt.get('plugin_b') == 'false' and dflt.get('name') == 'Ab', dflt)

print('Gleichnamige Module von Engine-Scraper und Addon')
import types                                                          # noqa: E402
fake = types.ModuleType('netzkino'); fake.__file__ = str(A.SYS.BUNDLED_DIR / 'netzkino.py'); sys.modules['netzkino'] = fake
hid = A._hide_engine_modules()
check('Engine-Scraper wird für den Addon-Lauf beiseite gelegt', 'netzkino' not in sys.modules and hid.get('netzkino') is fake)
for k2, v in hid.items():
    sys.modules[k2] = v
check('… und danach wieder eingesetzt', sys.modules.get('netzkino') is fake)
sys.modules.pop('netzkino', None)

print('Ältere Installationen werden beim ersten Start nachgezogen')
md = A.addon_path('plugin.video.migt'); md.mkdir(parents=True, exist_ok=True)
(md / 'a.py').write_text('if k >= 20: from resources.lib.listitem import L\n', 'utf-8')
(md / 'moviescout-addon.json').write_text('{"id": "plugin.video.migt", "pkg": "ao_migt"}', 'utf-8')
m2 = A._migrate('plugin.video.migt', A.meta('plugin.video.migt'))
check('Einzeiler-Import in alter Installation umgeleitet, Stand vermerkt', 'from ao_migt.lib.listitem' in (md / 'a.py').read_text('utf-8') and m2.get('rw') == A.REWRITE_VERSION and A.meta('plugin.video.migt').get('rw') == A.REWRITE_VERSION)

print('Dienst eines Addons beim Engine-Start (Vodkool: `import service`)')
import time, zipfile, io                                              # noqa: E402
buf = io.BytesIO()
with zipfile.ZipFile(buf, 'w') as z:
    z.writestr('plugin.video.svct/addon.xml', '<addon id="plugin.video.svct" name="S" version="1" provider-name="x"><requires/>'
               '<extension point="xbmc.python.pluginsource" library="main.py"><provides>video</provides></extension>'
               '<extension point="xbmc.service" library="service_run.py" start="startup"/></addon>')
    z.writestr('plugin.video.svct/main.py', 'pass\n')
    z.writestr('plugin.video.svct/service_run.py', 'import service\n')
    z.writestr('plugin.video.svct/service.py', "import xbmcgui\nxbmcgui.Window(10000).setProperty('svct.ok', 'ja')\n")
A.install_zip(buf.getvalue())
A.start_service('plugin.video.svct')
for _ in range(30):
    if not A._SERVICES['plugin.video.svct']['thread'].is_alive():
        break
    time.sleep(0.1)
from kodi_runtime import skin as _skin                                # noqa: E402
check('Dienst findet seine eigenen Module ohne vorherigen Aufruf', _skin.win_get(10000, 'svct.ok') == 'ja', list(A._SERVICES['plugin.video.svct']['ctx'].svc_log))
A.stop_service('plugin.video.svct')

print('Scraper der Engine liegen nicht unter ihrem bloßen Dateinamen in sys.modules')
from engine import registry as _reg                                   # noqa: E402
_reg.reload_all()
_stems = [p.file[:-3] for p in _reg.REGISTRY.values() if getattr(p, 'file', '').endswith('.py')] or ['m3u_iptv', 'stalker_portal']     # was die Engine wirklich mitbringt (früher netzkino, internetarchive …)
check('Scraper-Dateinamen sind für Addons frei (netzkino, internetarchive …), Scraper trotzdem geladen: %s' % ', '.join(_stems),
      bool(_stems) and all(st not in sys.modules and 'ms_scraper_' + st in sys.modules for st in _stems), [(st, st in sys.modules, 'ms_scraper_' + st in sys.modules) for st in _stems])

print('xShip: Domain-Status "dead"/"cf_blocked" sperrt keinen Scraper mehr')
from kodi_runtime import xbmcaddon as _xa                            # noqa: E402
_buf = io.BytesIO()
with zipfile.ZipFile(_buf, 'w') as z:
    z.writestr('plugin.video.hlth/addon.xml', '<addon id="plugin.video.hlth" name="H" version="1" provider-name="x"><requires/>'
               '<extension point="xbmc.python.pluginsource" library="main.py"><provides>video</provides></extension></addon>')
    z.writestr('plugin.video.hlth/main.py', 'pass\n')
A.install_zip(_buf.getvalue())
_xa.save_settings({'provider.a.health': 'dead', 'provider.b.health': 'cf_blocked', 'provider.c.domain': 'x.de'}, 'plugin.video.hlth')
_ad = _xa.Addon('plugin.video.hlth')
check('health dead -> ok', _ad.getSetting('provider.a.health') == 'ok')
check('health cf_blocked -> ok', _ad.getSetting('provider.b.health') == 'ok')
check('health ohne Eintrag (z. B. filmo) -> ok', _ad.getSetting('provider.filmo.health') == 'ok')
check('andere Einstellungen bleiben unberührt', _ad.getSetting('provider.c.domain') == 'x.de')

_buf2 = io.BytesIO()
with zipfile.ZipFile(_buf2, 'w') as z:
    z.writestr('plugin.video.xship/addon.xml', '<addon id="plugin.video.xship" name="X" version="1" provider-name="x"><requires/>'
               '<extension point="xbmc.python.pluginsource" library="main.py"><provides>video</provides></extension></addon>')
    z.writestr('plugin.video.xship/main.py', 'pass\n')
A.install_zip(_buf2.getvalue())
_xa.save_settings({'provider.a.domain': 'boese.example', 'lastDomainCheck': '5', 'scrapers.timeout': '35'}, 'plugin.video.xship')
_xs = _xa.Addon('plugin.video.xship')
check('xShip: Domain-Check läuft nie', int(_xs.getSetting('lastDomainCheck')) > 4000000000)
check('xShip: gespeicherte Fremd-Domain wird ignoriert', _xs.getSetting('provider.a.domain') == '')
check('xShip: Scraper-Zeitlimit mindestens 60 s', _xs.getSetting('scrapers.timeout') == '60')

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
