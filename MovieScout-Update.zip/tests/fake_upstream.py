# -*- coding: utf-8 -*-
"""Lokaler Fake-Streamserver für die Tests (Referer-/Origin-Pflicht, Range, Lizenz, Embed-Seite)."""
import base64
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8811
MP4 = b'\x00\x00\x00\x18ftypmp42\x00\x00\x00\x00mp42isom' + bytes(range(256)) * 8


def _vavoo_items():
    def it(name, group, cid):
        return {'type': 'iptv', 'ids': {'id': cid}, 'name': name, 'group': group,
                'url': 'https://vavoo.to/vavoo-iptv/play/' + cid, 'logo': 'https://img.test/%s.png' % cid}
    out = [it('Das Erste HD', 'Germany', 'de1'), it('Das Erste HD .b', 'Germany', 'de1b'),
           it('RTL+ FHD', 'Germany', 'de2'), it('ZDF HEVC', 'Germany', 'de3'), it('Kaputt', 'Germany', 'failde'),
           it('ORF 1 HD', 'Austria', 'at1')]
    out += [it('Rai %03d' % i, 'Italy', 'it%d' % i) for i in range(130)]
    return out


def _vavoo_page(cursor):
    items = _vavoo_items()
    half = len(items) // 2
    if not cursor:
        return {'items': items[:half], 'nextCursor': 'p2'}
    return {'items': items[half:]}


class H(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    def _send(self, code, body=b'', ctype='application/octet-stream', extra=None):
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def _need(self, header, value):
        if self.headers.get(header) != value:
            self._send(403, ('need %s: %s got %r' % (header, value, self.headers.get(header))).encode(), 'text/plain')
            return False
        return True

    def _tmdb(self, p):
        """Minimaler TMDB-Nachbau (v3): Suche, Details mit Besetzung/Freigaben, Folgen."""
        from urllib.parse import parse_qs, urlparse
        q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
        if q.get('api_key') != 'testkey' and self.headers.get('Authorization') != 'Bearer eyJtest':
            return self._send(401, b'{"status_message":"Invalid API key"}', 'application/json')
        cast = [{'name': 'Anna Beispiel', 'character': 'Hauptrolle'}, {'name': 'Bernd Muster', 'character': 'Gegenspieler'}]
        out = {}
        if p == '/search/movie':
            out = {'results': [{'id': 101, 'title': 'Film Eins', 'original_title': 'Film One', 'release_date': '2020-05-01', 'popularity': 9}]
                   if q.get('query') == 'Film Eins' else []}
        elif p == '/search/tv':
            out = {'results': [{'id': 202, 'name': 'Serie Zwei', 'original_name': 'Series Two', 'first_air_date': '2019-03-02', 'popularity': 5}]
                   if q.get('query') == 'Serie Zwei' else []}
        elif p == '/movie/101':
            out = {'title': 'Film Eins', 'release_date': '2020-05-01', 'runtime': 112, 'overview': 'Ein Testfilm über Tests.' if q.get('language') == 'de-DE' else 'A test film.',
                   'tagline': 'Alles wird getestet', 'vote_average': 7.34, 'genres': [{'name': 'Drama'}, {'name': 'Komödie'}],
                   'poster_path': '/p101.jpg', 'credits': {'cast': cast},
                   'release_dates': {'results': [{'iso_3166_1': 'US', 'release_dates': [{'certification': 'PG-13', 'type': 3}]},
                                                 {'iso_3166_1': 'DE', 'release_dates': [{'certification': '', 'type': 1}, {'certification': '12', 'type': 3}]}]}}
        elif p == '/tv/202':
            out = {'name': 'Serie Zwei', 'first_air_date': '2019-03-02', 'episode_run_time': [45], 'overview': '' if q.get('language') == 'de-DE' else 'An English series text.',
                   'genres': [{'name': 'Krimi'}], 'number_of_seasons': 2, 'credits': {'cast': cast},
                   'content_ratings': {'results': [{'iso_3166_1': 'DE', 'rating': '16'}]}}
        elif p == '/tv/202/season/1/episode/2':
            out = {'name': 'Die zweite Folge', 'overview': 'Folge zwei beschreibt viel.', 'runtime': 43}
        else:
            return self._send(404, b'{}', 'application/json')
        self._send(200, json.dumps(out).encode(), 'application/json')

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        p = self.path.split('?')[0]
        host = 'http://127.0.0.1:%d' % PORT
        if p == '/master.m3u8':
            if not self._need('Referer', 'https://site.test/'):
                return
            self._send(200, b'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=800000\nv/index.m3u8\n', 'application/vnd.apple.mpegurl')
        elif p == '/v/index.m3u8':
            if not self._need('Referer', 'https://site.test/'):
                return
            body = ('#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXTINF:4,\nseg0.ts\n#EXTINF:4,\n%s/v/seg1.ts?t=9\n#EXT-X-ENDLIST\n' % host).encode()
            self._send(200, body, 'application/vnd.apple.mpegurl')
        elif p in ('/v/seg0.ts', '/v/seg1.ts'):
            if not self._need('Referer', 'https://site.test/'):
                return
            self._send(200, (b'\x47' + b'\x00' * 187) * 3, 'video/mp2t')
        elif p == '/dash/manifest.mpd':
            if not self._need('Origin', 'https://site.test'):
                return
            body = (b'<?xml version="1.0"?><MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" mediaPresentationDuration="PT8S">'
                    b'<Period><AdaptationSet mimeType="video/mp4"><SegmentTemplate media="seg-$Number$.m4s" initialization="init.mp4" startNumber="1" duration="4" timescale="1"/>'
                    b'<Representation id="1" bandwidth="1000" codecs="avc1.42c01e"/></AdaptationSet></Period></MPD>')
            self._send(200, body, 'application/dash+xml')
        elif p == '/rtl/out/x.ism/manifest.mpd':
            # wie RTL+: BaseURL auf Period-Ebene, vom Host-Wurzelverzeichnis aus
            body = (b'<?xml version="1.0"?><MPD xmlns="urn:mpeg:dash:schema:mpd:2011" type="static" mediaPresentationDuration="PT8S">'
                    b'<Period><BaseURL>/rtlseg/out/x.ism/</BaseURL><AdaptationSet mimeType="video/mp4">'
                    b'<SegmentTemplate media="dash/ess-$RepresentationID$-$Time$.dash" initialization="dash/ess-$RepresentationID$.dash" timescale="1"/>'
                    b'<Representation id="video=1" bandwidth="1000" codecs="avc1.42c01e"/></AdaptationSet></Period></MPD>')
            self._send(200, body, 'application/dash+xml')
        elif p == '/rtlseg/out/x.ism/dash/ess-video=1.dash':
            self._send(200, b'INITSEG', 'video/mp4')
        elif p.startswith('/dash/') and p.endswith(('.m4s', '.mp4')):
            if not self._need('Origin', 'https://site.test'):
                return
            self._send(200, b'SEG' + p.encode(), 'video/mp4')
        elif p == '/scraper.py':
            code = ("SITE_ID='urlscraper'\nSITE_NAME='Von URL'\ndef load(url='', params=None):\n"
                    "    return [{'title':'A','url':'a','next_func':'get_hosters','is_playable':True}]\n"
                    "def get_hosters(url='', params=None):\n    return []\n")
            self._send(200, code.encode(), 'text/plain')
        elif p == '/movie.mp4':
            rng = self.headers.get('Range')
            if rng and rng.startswith('bytes='):
                a, _, b = rng[6:].partition('-')
                a = int(a or 0)
                b = int(b) if b else len(MP4) - 1
                chunk = MP4[a:b + 1]
                self._send(206, chunk, 'video/mp4', {'Content-Range': 'bytes %d-%d/%d' % (a, a + len(chunk) - 1, len(MP4)),
                                                       'Accept-Ranges': 'bytes'})
            else:
                self._send(200, MP4, 'video/mp4', {'Accept-Ranges': 'bytes'})
        elif p == '/noext/stream':
            self._send(200, b'#EXTM3U\n#EXTINF:4,\nx.ts\n', 'text/plain')
        elif p == '/noext/movie':
            self._send(200, MP4, 'application/octet-stream')
        elif p == '/embed/abc':
            html = ('<html><body><script>var player = jwplayer("x").setup({sources:[{file:"%s/master.m3u8"}]});</script></body></html>' % host)
            self._send(200, html.encode(), 'text/html; charset=utf-8')
        elif p == '/embed/broken':
            self._send(200, b'<html><body>nix</body></html>', 'text/html')
        elif p == '/site/list':
            self._send(200, json.dumps({'items': [{'t': 'Film Eins', 'id': 'f1'}, {'t': 'Serie Zwei', 'id': 's2'}]}).encode(), 'application/json')
        elif p == '/latin1':
            self._send(200, 'Käse & Brötchen'.encode('latin-1'), 'text/html; charset=iso-8859-1')
        elif p.startswith('/tmdb/'):
            self._tmdb(p[len('/tmdb'):])
        elif p == '/redir':
            self.send_response(302)
            self.send_header('Location', '/site/list')
            self.send_header('Content-Length', '0')
            self.end_headers()
        elif p == '/headers':
            self._send(200, json.dumps({k.lower(): v for k, v in self.headers.items()}).encode(), 'application/json')
        elif p == '/cookie':
            if 'sid=abc' in (self.headers.get('Cookie') or ''):
                self._send(200, b'cookie-ok', 'text/plain')
            else:
                self._send(200, b'cookie-set', 'text/plain', {'Set-Cookie': 'sid=abc; Path=/'})
        else:
            self._send(404, b'nope', 'text/plain')

    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0)
        body = self.rfile.read(n)
        p = self.path.split('?')[0]
        if p == '/license':
            if self.headers.get('x-dt-auth-token') != 'TOK':
                self._send(403, b'no token', 'text/plain')
                return
            out = json.dumps({'license': base64.b64encode(b'LICENSE:' + body).decode()}).encode()
            self._send(200, out, 'application/json')
        elif p == '/echo':
            self._send(200, body, 'application/octet-stream')
        elif p == '/mediahubmx.json':
            self._send(200, b'{"catalogs":[]}', 'application/json')
        elif p == '/mediahubmx-catalog.json':
            req = json.loads(body or b'{}')
            self._send(200, json.dumps(_vavoo_page(req.get('cursor'))).encode(), 'application/json')
        elif p == '/mediahubmx-resolve.json':
            req = json.loads(body or b'{}')
            cid = (req.get('url') or '').rsplit('/', 1)[-1]
            out = [] if cid.startswith('fail') else [{'url': 'http://127.0.0.1:%d/v/index.m3u8?id=%s' % (PORT, cid)}]
            self._send(200, json.dumps(out).encode(), 'application/json')
        else:
            self._send(404, b'nope', 'text/plain')


if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
