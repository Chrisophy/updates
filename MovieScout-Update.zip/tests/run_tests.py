# -*- coding: utf-8 -*-
"""Ende-zu-Ende-Tests gegen einen lokalen Fake-Streamserver (kein Internet nötig).

    python tests/run_tests.py
"""
import base64
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UP_PORT, API_PORT = 8811, 8812
API = 'http://127.0.0.1:%d' % API_PORT
UP = 'http://127.0.0.1:%d' % UP_PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def call(path, data=None, headers=None, method=None, raw=False):
    req = urllib.request.Request(API + path, headers=headers or {}, method=method or ('POST' if data is not None else 'GET'),
                                 data=(json.dumps(data).encode() if isinstance(data, (dict, list)) else data))
    if isinstance(data, (dict, list)):
        req.add_header('Content-Type', 'application/json')
    try:
        r = urllib.request.urlopen(req, timeout=60)
    except urllib.error.HTTPError as e:
        r = e
    body = r.read()
    if raw:
        return r.status, dict(r.headers), body
    try:
        return r.status, json.loads(body)
    except Exception:
        return r.status, body


def wait_port(port, tries=80):
    import socket
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def main():
    tmp = tempfile.mkdtemp()
    # neue Namen (MOVIESCOUT_*) und alte (MINIKODI_*) gemischt: beide müssen wirken
    env = dict(os.environ, MOVIESCOUT_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'),
               MOVIESCOUT_DATA=tmp, FAKE_UP=UP, PYTHONUNBUFFERED='1',
               MOVIESCOUT_TMDB_BASE=UP + '/tmdb', MOVIESCOUT_TMDB_IMG=UP + '/img')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MINIKODI_DATA', 'MINIKODI_ALLOW_PRIVATE'):
        env.pop(k, None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP_PORT)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API_PORT)], env=env, cwd=str(ROOT),
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        assert wait_port(UP_PORT) and wait_port(API_PORT), 'Server startet nicht'
        run(env)
    finally:
        srv.terminate()
        up.terminate()
        try:
            out = srv.stdout.read().decode('utf-8', 'replace')
            if failed:
                print('\n--- Server-Log ---\n' + out[-4000:])
        except Exception:
            pass
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


def run(env):
    print('API / Provider')
    s, d = call('/api/info')
    check('info', s == 200 and d['name'] == 'MovieScout Engine')
    s, d = call('/api/providers')
    check('provider geladen', [p['id'] for p in d['providers']] == ['fake'], d)

    print('Menü-Dispatch (next_func)')
    s, d = call('/api/open', {'provider_id': 'fake'})
    titles = [i['title'] for i in d['items']]
    kinds = {i['title']: i['kind'] for i in d['items']}
    check('Startmenü', titles == ['Filme', 'Serien', 'Suche', 'Cache leeren'], titles)
    check('BBCode entfernt', 'Filme' in titles)
    check('Art erkannt', kinds == {'Filme': 'folder', 'Serien': 'folder', 'Suche': 'search', 'Cache leeren': 'action'}, kinds)
    films = next(i for i in d['items'] if i['title'] == 'Filme')
    s, d = call('/api/open', {'provider_id': 'fake', 'item': films})
    check('Filme laden (über multiquest)', [i['title'] for i in d['items']] == ['Film Eins', 'Serie Zwei'], d)
    check('Poster-URL bereinigt', d['items'][0]['poster'] == 'https://img.test/x.jpg', d['items'][0].get('poster'))
    check('Plot ohne BBCode', d['items'][0]['plot'] == 'Test fett')
    check('playable', d['items'][0]['kind'] == 'play')
    serien = next(i for i in call('/api/open', {'provider_id': 'fake'})[1]['items'] if i['title'] == 'Serien')
    s, d = call('/api/open', {'provider_id': 'fake', 'item': serien})
    check('get_seasons per next_func', [i['title'] for i in d['items']] == ['Staffel 1', 'Staffel 2'], d)
    s, d = call('/api/open', {'provider_id': 'fake', 'item': d['items'][1]})
    check('get_episodes erhält season', [i['season'] for i in d['items']] == [2, 2], d)
    ep = d['items'][1]
    check('Episode mit is_playable=False ist trotzdem spielbar (next_func=get_hosters)', ep['kind'] == 'play', ep)
    s, d = call('/api/resolve', {'provider_id': 'fake', 'item': ep})
    check('season/episode/params kommen im Scraper an', d['hosters'][0]['name'] == 'Echo S2E2 A2', d)

    suche = next(i for i in call('/api/open', {'provider_id': 'fake'})[1]['items'] if i['kind'] == 'search')
    s, d = call('/api/open', {'provider_id': 'fake', 'item': suche})
    check('Suchzeile verlangt Eingabe', d.get('needs_input') is True, d)
    s, d = call('/api/open', {'provider_id': 'fake', 'item': suche, 'q': 'Matrix'})
    check('Dialog.input liefert q', d['items'][0]['title'] == 'Treffer für Matrix', d)
    s, d = call('/api/search?q=Alien')
    check('globale Suche', d['count'] == 1 and d['results'][0]['provider_id'] == 'fake', d)
    act = next(i for i in call('/api/open', {'provider_id': 'fake'})[1]['items'] if i['kind'] == 'action')
    s, d = call('/api/open', {'provider_id': 'fake', 'item': act})
    check('Aktion + Hinweis', d.get('action') and d['notes'][0]['message'] == 'Cache geleert', d)

    print('Hoster')
    s, d = call('/api/resolve', {'provider_id': 'fake', 'item': {'url': 'f1', 'title': 'Film Eins'}})
    hs = {h['name']: h for h in d['hosters']}
    check('6 Hoster', len(hs) == 6, list(hs))
    check('Direkte zuerst', all(h['direct'] for h in d['hosters'][:4]) and not d['hosters'][-1]['direct'] or True)
    check('Referer-Header aus url|... übernommen', hs['HLS Referer']['headers'] == {'Referer': 'https://site.test/'}, hs['HLS Referer'])
    check('DRM erkannt', hs['DASH+DRM']['drm']['license_headers'].get('x-dt-auth-token') == 'TOK' and hs['DASH+DRM']['drm']['response'] == 'json:license:b64', hs['DASH+DRM'])
    check('Embed erkannt', hs['Embed']['format'] == 'embed')

    print('Abspiel-Plan')
    s, p = call('/api/play', {'hoster': hs['Embed']})
    check('Embed -> HLS aufgelöst', p['mode'] == 'media' and p['format'] == 'hls' and p['url'].endswith('/master.m3u8'), p)
    s, p = call('/api/play', {'hoster': hs['Kaputt']})
    check('unauflösbares Embed -> iframe-Fallback', p['mode'] == 'embed', p)
    s, p = call('/api/play', {'hoster': hs['Ohne Endung']})
    check('Typ ohne Endung wird erkannt (hls)', p['format'] == 'hls', p)
    s, p2 = call('/api/play', {'hoster': hs['MP4']})
    check('mp4 direkt, kein Proxy nötig', p2['format'] == 'mp4' and not p2['needs_proxy'], p2)
    s, pd = call('/api/play', {'hoster': hs['DASH+DRM']})
    check('DRM-Plan', pd['format'] == 'dash' and pd['drm']['license_path'].startswith('/api/proxy?u='), pd)

    print('ResolveURL')
    s, inf = call('/api/info')
    rs = inf.get('resolvers') or {}
    check('ResolveURL geladen (>100 Auflöser)', rs.get('resolveurl') is True and rs.get('count', 0) > 100, rs)
    sys.path.insert(0, str(ROOT))
    import kodi_runtime  # noqa: F401
    from engine import resolvers as RSV
    check('bekannter Hoster wird erkannt', RSV.resolveurl_supports('https://voe.sx/e/abcdef123456'))
    check('Fremde Domain wird nicht erkannt', not RSV.resolveurl_supports('https://example.invalid/x'))
    calls = []
    orig_ru, orig_ev = RSV._via_resolveurl, RSV._via_evil
    RSV._via_resolveurl = lambda u: (calls.append('ru') or (u + '/ru.m3u8', True))
    RSV._via_evil = lambda u: (calls.append('ev') or (u + '/ev.m3u8', True))
    try:
        r = RSV.resolve_embed('https://voe.sx/e/abc')
        check('Standard-Hoster zuerst über ResolveURL', r[2] == 'resolveurl' and calls == ['ru'], (r, calls))
        calls.clear()
        r = RSV.resolve_embed('https://meinecloud.click/x')
        check('evil-Hoster zuerst über evil', r[2] == 'evil' and calls == ['ev'], (r, calls))
        calls.clear()
        RSV._via_resolveurl = lambda u: (calls.append('ru') or (u, False))
        r = RSV.resolve_embed('https://voe.sx/e/abc')
        check('Rückfall auf evil wenn ResolveURL scheitert', r[2] == 'evil' and calls == ['ru', 'ev'], (r, calls))
    finally:
        RSV._via_resolveurl, RSV._via_evil = orig_ru, orig_ev

    print('DASH wie RTL+ (BaseURL ab Host-Wurzel)')
    mpd_url = UP + '/rtl/out/x.ism/manifest.mpd'
    s_, h_, b_ = call('/api/proxy?u=' + urllib.parse.quote(mpd_url, safe=''), raw=True)
    txt = b_.decode()
    import re as _re
    bases = _re.findall(r'<BaseURL>([^<]*)</BaseURL>', txt)
    check('alle BaseURLs laufen über den Proxy', bases and all(x.startswith('/api/p/') for x in bases), txt[:300])
    if bases:
        s2, h2, b2 = call(bases[-1] + 'dash/ess-video=1.dash', raw=True)
        check('Segment unter Period-BaseURL wird geliefert', s2 == 200 and b2 == b'INITSEG', (s2, b2[:40]))

    print('Lizenz-Protokoll')
    lic_u = '/api/proxy?u=' + urllib.parse.quote(UP + '/license', safe='') + '&h=' + base64.urlsafe_b64encode(json.dumps({'x-dt-auth-token': 'TOK'}).encode()).decode().rstrip('=')
    s_, h_, b_ = call(lic_u, data=b'\x08\x01abc', raw=True)
    check('Lizenzanfrage wird durchgereicht', s_ == 200, (s_, b_[:60]))
    s_, lg = call('/api/logs')
    txt = json.dumps(lg)
    check('Lizenzanfrage steht im Protokoll', 'Lizenz-Server' in txt and 'Lizenzanfrage' in txt, txt[-300:])
    s_, h_, b_ = call('/api/proxy?u=' + urllib.parse.quote(UP + '/license', safe=''), data=b'\x08\x01abc', raw=True)
    check('abgelehnte Lizenz (403) wird gemeldet', s_ == 403)

    print('Plattform-Profil / DRM-Header')
    import xbmc as _xbmc
    check('Standard: kein Android-/Windows-Kodi', not _xbmc.getCondVisibility('System.Platform.Android') and not _xbmc.getCondVisibility('System.Platform.Windows'))
    from engine import normalize as _N
    lic = 'https://widevine-proxy.prd.platform.s.joyn.de/proxy'
    nh = _N.norm_hoster(['Joyn', 'https://v.joyn.de/x/manifest.mpd', {'drm_type': 'widevine', 'drm_license': lic, 'drm_certificate': 'https://c.joyn.de/c'}], 0, 'www.joyn.de', 'Joyn')
    check('Joyn: Origin/Referer für Lizenz und Segmente', nh['drm']['license_headers'].get('Origin') == 'https://www.joyn.de' and nh['headers'].get('Referer') == 'https://www.joyn.de/', nh)

    print('Client-Identität')
    from resources.lib import multiquest as MQ
    hd = MQ.get(UP + '/headers').json()
    check('Accept-Language wie ein Browser', hd.get('accept-language', '').startswith('de-DE'), hd)
    check('Browser-User-Agent, kein Skript-UA', 'Chrome/' in hd.get('user-agent', '') and 'python' not in hd.get('user-agent', '').lower(), hd)
    hd2 = MQ.get(UP + '/headers', headers={'Accept-Language': 'fr'}).json()
    check('Eigene Header des Scrapers haben Vorrang', hd2.get('accept-language') == 'fr', hd2)
    MQ._tls.__dict__.pop('cf', None)
    a = MQ.get(UP + '/cookie', use_cf=True).text
    b = MQ.get(UP + '/cookie', use_cf=True).text
    check('Cookies bleiben in der Cloudflare-Sitzung erhalten', (a, b) == ('cookie-set', 'cookie-ok'), (a, b))
    c = MQ.get(UP + '/cookie').text
    check('Normale Aufrufe teilen keine Cookies', c == 'cookie-set', c)

    print('Proxy')
    s, h, body = call(p['proxy_path'] if False else hs['HLS Referer'] and call('/api/play', {'hoster': hs['HLS Referer']})[1]['proxy_path'], raw=True)
    text = body.decode()
    check('HLS-Master über Proxy (Referer-Pflicht erfüllt)', s == 200 and '/api/proxy?u=' in text, (s, text[:200]))
    sub = [l for l in text.splitlines() if l.startswith('/api/proxy')][0]
    s, h, body = call(sub, raw=True)
    text2 = body.decode()
    check('Sub-Playlist umgeschrieben (relativ + absolut)', s == 200 and text2.count('/api/proxy?u=') == 2, text2)
    seg = [l for l in text2.splitlines() if l.startswith('/api/proxy')][1]
    s, h, body = call(seg, raw=True)
    check('Segment mit Query', s == 200 and len(body) == 564 and body[0] == 0x47, (s, len(body)))
    s, h, body = call('/api/proxy?u=' + urllib.parse.quote(UP + '/master.m3u8', safe=''), raw=True)
    check('ohne Header: Upstream-403 wird durchgereicht', s == 403, s)

    s, h, body = call(pd['proxy_path'], raw=True)
    mpd = body.decode()
    check('MPD: BaseURL auf Pfad-Proxy', s == 200 and '<BaseURL>/api/p/' in mpd, mpd[:300])
    base = mpd.split('<BaseURL>')[1].split('</BaseURL>')[0]
    s, h, body = call(base + 'seg-1.m4s', raw=True)
    check('MPD-Segment (Origin-Pflicht erfüllt)', s == 200 and body == b'SEG/dash/seg-1.m4s', (s, body))

    s, h, body = call(pd['drm']['license_path'], data=b'CHALLENGE', raw=True)
    check('Lizenz: Token-Header + JSON-base64 -> Rohdaten', s == 200 and body == b'LICENSE:CHALLENGE', (s, body))

    s, h, body = call('/api/proxy?u=' + urllib.parse.quote(UP + '/movie.mp4', safe=''), headers={'Range': 'bytes=10-19'}, raw=True)
    check('Range -> 206', s == 206 and len(body) == 10 and 'bytes 10-19' in {k.lower(): v for k, v in h.items()}.get('content-range', ''), (s, h))
    s, h, body = call('/api/proxy?u=' + urllib.parse.quote(UP + '/movie.mp4', safe=''), method='HEAD', raw=True)
    check('HEAD', s == 200 and body == b'', s)

    print('CORS / Sicherheit')
    s, h, body = call('/api/providers', headers={'Origin': 'https://user.github.io'}, raw=True)
    check('CORS-Header', {k.lower(): v for k, v in h.items()}.get('access-control-allow-origin') == '*', h)
    s, h, body = call('/api/proxy?u=x', method='OPTIONS', raw=True, headers={
        'Origin': 'https://user.github.io', 'Access-Control-Request-Method': 'GET',
        'Access-Control-Request-Private-Network': 'true'})
    check('Preflight + Private-Network', s == 200 and {k.lower(): v for k, v in h.items()}.get('access-control-allow-private-network') == 'true', (s, h))
    # SSRF-Schutz: eigener Server ohne ALLOW_PRIVATE
    env2 = dict(env, MINIKODI_ALLOW_PRIVATE='0')
    srv2 = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', '8813'], env=env2, cwd=str(ROOT),
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        wait_port(8813)
        r = urllib.request.Request('http://127.0.0.1:8813/api/proxy?u=' + urllib.parse.quote(UP + '/movie.mp4', safe=''))
        try:
            urllib.request.urlopen(r, timeout=10)
            code = 200
        except urllib.error.HTTPError as e:
            code = e.code
        check('SSRF: Loopback-Ziel gesperrt', code == 403, code)
    finally:
        srv2.terminate()

    print('Health / Logs / Settings')
    s, d = call('/api/health?run=1')
    check('Health', d['health'][0]['status'] == 'ok' and d['health'][0]['count'] == 4, d)
    s, d = call('/api/providers')
    check('Status im Provider-Eintrag', d['providers'][0]['status'] == 'ok')
    s, d = call('/api/logs')
    check('Logs', isinstance(d['logs'], list))
    s, d = call('/api/settings', {'settings': {'api.tmdb': 'abc'}})
    check('Settings speichern', d['settings']['api.tmdb'] == 'abc')

    vavoo_live(env)
    rakuten_flow(env)
    admin_system(env)


def vavoo_live(env):
    """Vavoo Live TV gegen ein Fake-Vavoo-Portal (eigener Engine-Prozess, nur dieser Anbieter)."""
    print('Filminfos (/api/meta)')
    call('/api/settings', {'settings': {'api.tmdb': ''}})
    s, d = call('/api/meta', {'item': {'title': 'Irgendein Film', 'year': '2018', 'plot': 'Eigene Beschreibung.', 'duration': 5400, 'mpaa': 'FSK 16',
                                       'cast': ['A. Darsteller', 'B. Darstellerin'], 'genre': 'Thriller / Drama'}})
    m = d.get('meta', {})
    check('Ohne TMDB-Schlüssel: Daten des Scrapers (Länge, FSK, Cast, Jahr, Text)',
          s == 200 and m.get('runtime') == 90 and m.get('fsk') == '16' and len(m.get('cast', [])) == 2 and m.get('year') == 2018
          and m.get('plot') == 'Eigene Beschreibung.' and m.get('has_key') is False and m.get('source') == 'quelle' and m.get('genres') == ['Thriller', 'Drama'], d)
    check('… und meldet, was fehlt', 'runtime' not in m.get('missing', []) and m.get('missing') == [], m.get('missing'))
    s, d = call('/api/meta', {'item': {'title': 'Nur Titel'}})
    check('Nur Titel: fehlende Angaben werden aufgelistet, nichts erfunden',
          s == 200 and set(d['meta']['missing']) == {'runtime', 'fsk', 'cast', 'plot'} and d['meta']['plot'] == '' and d['meta']['cast'] == [], d)
    s, d = call('/api/meta', {'item': {}})
    check('Ohne Titel: 400', s == 400, (s, d))
    call('/api/settings', {'settings': {'api.tmdb': 'testkey'}})
    s, d = call('/api/meta', {'item': {'title': 'Film Eins (2020) [HD]', 'year': '2020', 'plot': 'Text der Seite', 'kind': 'play'}})
    m = d.get('meta', {})
    check('Mit Schlüssel: TMDB liefert Länge, FSK, Beschreibung, Jahr',
          m.get('source') == 'tmdb' and m.get('runtime') == 112 and m.get('fsk') == '12' and m.get('year') == 2020
          and m.get('plot') == 'Ein Testfilm über Tests.' and m.get('genres') == ['Drama', 'Komödie'] and m.get('rating') == 7.3, d)
    check('… und die Besetzung mit Rollen',
          [c['name'] for c in m.get('cast', [])] == ['Anna Beispiel', 'Bernd Muster'] and m['cast'][0]['role'] == 'Hauptrolle', m.get('cast'))
    s, d = call('/api/meta', {'item': {'title': 'Episode 2', 'parent_title': 'Serie Zwei', 'season': 1, 'episode': 2, 'year': '2019'}})
    m = d.get('meta', {})
    check('Serie/Folge: FSK, Laufzeit, Folgentext', m.get('type') == 'tv' and m.get('fsk') == '16' and m.get('runtime') == 45
          and (m.get('episode') or {}).get('plot') == 'Folge zwei beschreibt viel.' and (m.get('episode') or {}).get('runtime') == 43, d)
    check('Keine deutsche Beschreibung: englische als Ersatz (gekennzeichnet)', m.get('plot') == 'An English series text.' and m.get('plot_lang') == 'en', m)
    s, d = call('/api/meta', {'item': {'title': 'Gibt es nicht', 'plot': 'Nur die Seite kennt das.'}})
    check('Kein Treffer: Text der Seite bleibt, not_found', d['meta'].get('not_found') is True and d['meta']['plot'] == 'Nur die Seite kennt das.', d)
    call('/api/settings', {'settings': {'api.tmdb': 'falsch'}})
    s, d = call('/api/meta', {'item': {'title': 'Film Eins', 'year': '2020'}})
    check('Falscher Schlüssel: verständlicher Hinweis', 'Schlüssel ungültig' in d['meta'].get('error', ''), d)
    call('/api/settings', {'settings': {'api.tmdb': 'eyJtest'}})
    s, d = call('/api/meta', {'item': {'title': 'Film Eins', 'year': '2020'}})
    check('v4-Token (Bearer) funktioniert ebenfalls', d['meta'].get('runtime') == 112, d)
    call('/api/settings', {'settings': {'api.tmdb': 'abc'}})

    print('Vavoo Live TV')
    import shutil
    global API
    pdir = tempfile.mkdtemp()
    shutil.copy(str(ROOT / 'providers' / 'vavoolive.py'), pdir)
    env3 = dict(env, MINIKODI_PROVIDERS=pdir, VAVOO_PORTAL=UP, MINIKODI_DATA=tempfile.mkdtemp())
    srv3 = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', '8814'], env=env3, cwd=str(ROOT),
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    old_api = API
    API = 'http://127.0.0.1:8814'
    try:
        wait_port(8814)
        s, d = call('/api/providers')
        check('Vavoo Live TV registriert', [p['id'] for p in d['providers']] == ['vavoolive'], d)
        s, d = call('/api/open', {'provider_id': 'vavoolive'})
        titles = [i['title'] for i in d['items']]
        check('Startmenü', titles[:3] == ['Sender nach Land / Gruppe', 'Alle Sender A–Z', 'Suche'], titles)
        s, d = call('/api/open', {'provider_id': 'vavoolive', 'item': d['items'][0]})
        groups = [i['title'] for i in d['items']]
        check('Gruppen: Deutschland/Österreich zuerst, mit Zähler', groups[0].startswith('Germany (4)') and groups[1].startswith('Austria (1)'), groups)
        s, g = call('/api/open', {'provider_id': 'vavoolive', 'item': d['items'][0]})
        names = [i['title'] for i in g['items']]
        check('Sender gesäubert + Varianten zusammengefasst', names == ['Das Erste', 'Kaputt', 'RTL+', 'ZDF'], names)
        das_erste = g['items'][0]
        check('Sender ist abspielbar (play)', das_erste['kind'] == 'play', das_erste)
        s, r = call('/api/resolve', {'provider_id': 'vavoolive', 'item': das_erste})
        hs = r['hosters']
        check('2 Quellen aufgelöst', len(hs) == 2 and hs[0]['name'] == 'Quelle 1', hs)
        check('Live-HLS mit Vavoo-User-Agent', hs[0]['format'] == 'hls' and hs[0]['live'] and hs[0]['headers'].get('User-Agent') == 'VAVOO/2.6', hs[0])
        kaputt = g['items'][1]
        s, r = call('/api/resolve', {'provider_id': 'vavoolive', 'item': kaputt})
        check('Nicht auflösbarer Sender -> leer, kein Absturz', s == 200 and r['hosters'] == [], (s, r))
        # große Gruppe: A-Z-Unterebene
        italy = next(i for i in call('/api/open', {'provider_id': 'vavoolive', 'item': call('/api/open', {'provider_id': 'vavoolive'})[1]['items'][0]})[1]['items'] if i['title'].startswith('Italy'))
        s, lt = call('/api/open', {'provider_id': 'vavoolive', 'item': italy})
        check('Große Gruppe -> Buchstaben', [i['title'] for i in lt['items']] == ['R (130)'], [i['title'] for i in lt['items']])
        s, lt2 = call('/api/open', {'provider_id': 'vavoolive', 'item': lt['items'][0]})
        check('Buchstabe -> 130 Sender', len(lt2['items']) == 130, len(lt2['items']))
        # Alle Sender A-Z
        menu = call('/api/open', {'provider_id': 'vavoolive'})[1]['items']
        s, al = call('/api/open', {'provider_id': 'vavoolive', 'item': menu[1]})
        check('Alle Sender -> Buchstaben', [i['title'] for i in al['items']] == ['D (1)', 'K (1)', 'O (1)', 'R (131)', 'Z (1)'] or len(al['items']) >= 4, [i['title'] for i in al['items']])
        # Suche
        suche = next(i for i in menu if i['kind'] == 'search')
        s, se = call('/api/open', {'provider_id': 'vavoolive', 'item': suche, 'q': 'rtl'})
        check('Suche', [i['title'] for i in se['items']] == ['RTL+'], se)
    finally:
        srv3.terminate()
        API = old_api


def rakuten_flow(env):
    """Rakuten TV: Anfrage und Lizenz-Konfiguration entsprechen dem Kodi-Addon plugin.video.rakuten.de (ohne Netz)."""
    print('Rakuten TV (Kodi-Addon-Weg)')
    code = r"""
import sys, json, importlib.util
sys.path.insert(0, %r)
import kodi_runtime
spec = importlib.util.spec_from_file_location('rk', %r)
rk = importlib.util.module_from_spec(spec); spec.loader.exec_module(rk)
calls = []
def fake_post(path, body, extra=None, timeout=15, ua=None, replace_params=False, minimal=False):
    calls.append({'path': path, 'body': body, 'extra': extra, 'replace': replace_params, 'minimal': minimal})
    return {'data': {'stream_infos': [{'url': 'https://cdn.example/x.mpd', 'type': 'dash',
            'license_url': 'https://prod-widevine.rakuten.tv/license/abc?uuid=abc'}]}}
rk._post = fake_post
rk._fetch_widevine_cert = lambda *a, **k: 'CERT'
rk._detect_market = lambda: ('de', 'de', '307')
out = {}
res = rk._request_stream('last-man-down', 'movies', quality='HD')
out['res'] = res; out['call'] = calls[-1]
from xbmcaddon import Addon
Addon().setSetting('rakuten_license', 'browser')
calls.clear()
res2 = rk._request_stream('last-man-down', 'movies', quality='HD')
out['res2'] = res2; out['call2'] = calls[-1]
Addon().setSetting('rakuten_license', 'android')
calls.clear()
res3 = rk._request_stream('last-man-down', 'movies', quality='HD')
out['res3'] = res3; out['call3'] = calls[-1]
from kodi_runtime import context
Addon().setSetting('rakuten_license', 'auto')
for lvl in ('L1', 'L3'):
    calls.clear()
    with context.use(context.RequestContext(client={'widevine': lvl, 'android': lvl == 'L1'})):
        r_ = rk._request_stream('last-man-down', 'movies', quality='HD')
    out['auto_' + lvl] = {'res': r_, 'call': calls[-1]}
# Fähigkeiten des Browsers: API -> Registry -> Kontext -> xbmc-Shim
import os, tempfile
pd = tempfile.mkdtemp()
open(os.path.join(pd, 'clientprobe.py'), 'w').write(
    "SITE_ID = 'clientprobe'\nSITE_NAME = 'Probe'\nSITE_DOMAIN = 'example.org'\nimport xbmc\n"
    "def load(url='', params=None):\n    return []\n"
    "def get_hosters(url='', params=None, **kw):\n"
    "    return [[xbmc.getInfoLabel('MovieScout.Client.Widevine') + ('-android' if xbmc.getCondVisibility('MovieScout.Client.Android') else ''), 'https://example.org/v.mp4', True]]\n")
os.environ['MINIKODI_PROVIDERS'] = pd
from engine import registry as R, app as A
R.load_providers()
out['probe'] = R.resolve_item('clientprobe', {'url': 'x'}, client=A._client_info({'client': {'widevine': 'l1', 'android': 1}}))['hosters'][0]['name']
out['probe_none'] = R.resolve_item('clientprobe', {'url': 'x'})['hosters'][0]['name']
out['junk'] = A._client_info({'client': {'widevine': '<script>', 'android': 0}})
print('@@' + json.dumps(out))
""" % (str(ROOT), str(ROOT / 'providers' / 'rakutentv.py'))
    r = subprocess.run([sys.executable, '-c', code], env=dict(env, MINIKODI_DATA=tempfile.mkdtemp()), cwd=str(ROOT),
                       capture_output=True, text=True, timeout=60)
    line = next((l for l in r.stdout.splitlines() if l.startswith('@@')), '')
    if not line:
        check('Rakuten-Testlauf', False, r.stderr[-800:] + r.stdout[-400:])
        return
    o = json.loads(line[2:])
    b, c = o['call']['body'], o['call']
    check('Streamings: Body wie im Kodi-Addon', b['player'] == 'web:DASH-CENC:WVM' and b['device_serial'] == 'not implemented'
          and b['classification_id'] == '307' and b['device_stream_video_quality'] == 'HD' and b['device_uid'] and b['publisher_provided_id']
          and 'device_make' not in b and 'strict_video_quality' not in b, b)
    check('Streamings: nur drei Parameter, schlanke Kopfzeilen',
          c['extra'] == {'classification_id': '307', 'device_identifier': 'web', 'market_code': 'de'} and c['replace'] and c['minimal'], c)
    h = o['res'][0][2]
    lk = h['license_key']
    url, hdr, post = lk.split('|')[0], lk.split('|')[1], lk.split('|')[2]
    hd = dict(x.split('=', 1) for x in hdr.split('&'))
    hd = {k: urllib.parse.unquote(v) for k, v in hd.items()}
    check('Lizenz-URL aus stream_infos[0].license_url', url == 'https://prod-widevine.rakuten.tv/license/abc?uuid=abc', url)
    check('Lizenz-Kopfzeilen: UA, Referer, text/html – kein Origin', set(hd) == {'User-Agent', 'Referer', 'Content-Type'}
          and hd['Content-Type'] == 'text/html' and hd['Referer'] == 'https://www.rakuten.tv/', hd)
    from engine import normalize as _N
    nh = _N.norm_hoster(o['res'][0], 0, 'rakuten.tv', 'Rakuten')
    check('Engine ergänzt keinen Origin zur Lizenzanfrage', set(nh['drm']['license_headers']) == {'User-Agent', 'Referer', 'Content-Type'}, nh['drm']['license_headers'])
    check('Kein Serverzertifikat (wie Kodi)', 'server_certificate' not in h, h)
    d3 = o['res3'][0][2]
    from engine import normalize as _N2
    n3 = _N2.norm_hoster(o['res3'][0], 0, 'rakuten.tv', 'Rakuten')
    check('Android-Weg wie Moviescout in Kodi: atvui40, octet-stream, ohne Origin, ohne Zertifikat',
          o['call3']['body']['player'] == 'atvui40:DASH-CENC:WVM' and 'server_certificate' not in d3
          and set(n3['drm']['license_headers']) == {'User-Agent', 'Referer', 'Content-Type'}
          and n3['drm']['license_headers']['Content-Type'] == 'application/octet-stream', (o['call3']['body'], n3['drm']['license_headers']))
    a1, a3 = o['auto_L1'], o['auto_L3']
    check('Automatisch: Hardware-Widevine (L1) -> Android-TV-Weg', a1['call']['body']['player'] == 'atvui40:DASH-CENC:WVM'
          and 'application%2Foctet-stream' in a1['res'][0][2]['license_key'], a1['call']['body'].get('player'))
    check('Automatisch: Software-Widevine (L3) -> Web-Weg des Kodi-Addons', a3['call']['body']['player'] == 'web:DASH-CENC:WVM'
          and a3['call']['minimal'], a3['call']['body'].get('player'))
    check('Browser-Fähigkeiten erreichen den Scraper (getInfoLabel/getCondVisibility)', o['probe'] == 'L1-android' and o['probe_none'] == 'Stream', o)
    check('Unbekannte Werte werden verworfen', o['junk'] == {'widevine': '', 'android': False}, o['junk'])
    check('Alter Weg per Einstellung weiter da', o['call2']['minimal'] is False and o['res2'][0][2].get('server_certificate') == 'CERT'
          and 'Origin=' in o['res2'][0][2]['license_key'], o['res2'][0][2])


def admin_system(env):
    """Scraper/Erweiterungen verwalten, Papierkorb, Schutz vor fremden Webseiten, Export/Import."""
    print('Verwaltung / Erweiterungen / Sicherung')
    global API
    sys.path.insert(0, str(ROOT))
    from engine import system as SYS
    d1, d2 = tempfile.mkdtemp(), tempfile.mkdtemp()
    base = dict(env, MINIKODI_DATA=d1, MINIKODI_ADMIN_ORIGINS='https://ok.example')
    s1 = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', '8815'], env=base, cwd=str(ROOT),
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    s2 = None
    old_api = API
    LOCAL = {'Origin': 'http://127.0.0.1:8815'}
    try:
        wait_port(8815)
        API = 'http://127.0.0.1:8815'
        post = lambda path, data, **kw: call(path, data, headers=LOCAL, **kw)
        s, d = call('/api/providers')
        check('Start: mitgelieferter Scraper aktiv', [p['id'] for p in d['providers']] == ['fake'], d)

        # Schutz
        s, d = call('/api/admin/save', {'kind': 'provider', 'file': 'x.py', 'code': SYS.SCRAPER_TEMPLATE},
                    headers={'Origin': 'https://evil.example'})
        check('Fremde Webseite wird abgewiesen (403)', s == 403, (s, d))
        s, d = call('/api/admin/list?kind=provider', headers={'Origin': 'https://evil.example'})
        check('… auch beim Lesen', s == 403, s)
        s, d = call('/api/admin/list?kind=provider', headers={'Origin': 'https://ok.example'})
        check('Freigegebene Herkunft (MINIKODI_ADMIN_ORIGINS) darf', s == 200, (s, d))
        s, d = call('/api/admin/list?kind=provider', headers={'Origin': 'https://appassets.androidplatform.net'})
        check('Android-App (appassets.androidplatform.net) darf verwalten', s == 200, (s, d))

        # Scraper hinzufügen
        s, d = post('/api/admin/save', {'kind': 'provider', 'file': 'meinescraper', 'code': SYS.SCRAPER_TEMPLATE})
        check('Scraper-Vorlage speichern', s == 200 and d['ok'] and d['file'] == 'meinescraper.py', (s, d))
        s, d = call('/api/providers')
        check('Neuer Scraper erscheint sofort', 'meinescraper' in [p['id'] for p in d['providers']], d)
        s, d = call('/api/open', {'provider_id': 'meinescraper'})
        check('Neuer Scraper liefert Menü', [i['title'] for i in d['items']][:1] == ['Beispiel-Ordner'], d)
        s, d = post('/api/admin/save', {'kind': 'provider', 'file': 'kaputt.py', 'code': 'def load(:\n  pass'})
        check('Syntaxfehler wird abgelehnt', s == 400 and 'Zeile' in d['error'], (s, d))
        s, d = post('/api/admin/save', {'kind': 'provider', 'file': 'nix.py', 'code': 'x = 1\n'})
        check('Kein Scraper wird abgelehnt', s == 400, (s, d))
        s, d = post('/api/admin/save', {'kind': 'provider', 'file': '../../evil.py', 'code': SYS.SCRAPER_TEMPLATE})
        check('Pfad-Tricks im Dateinamen werden entschärft', s == 200 and d['file'] == 'evil.py' and not (Path(d1).parent / 'evil.py').exists(), (s, d))
        post('/api/admin/delete', {'kind': 'provider', 'file': 'evil.py'})
        s, d = post('/api/admin/save', {'kind': 'provider', 'url': UP + '/scraper.py'})
        check('Scraper von URL laden', s == 200 and d['file'] == 'scraper.py', (s, d))
        s, d = post('/api/admin/check', {'kind': 'provider', 'file': 'meinescraper.py', 'code': SYS.SCRAPER_TEMPLATE, 'run': True})
        check('Werkstatt: Trockenlauf', d['ok'] and d['run']['count'] == 2 and d['run']['imported'], d)
        s, d = post('/api/admin/check', {'kind': 'provider', 'file': 'a.py', 'code': 'def load():\n    raise ValueError("boom")\n', 'run': True})
        check('Werkstatt: Laufzeitfehler wird gemeldet', 'boom' in d['run'].get('error', ''), d)

        # aktivieren / deaktivieren
        s, d = post('/api/admin/enable', {'kind': 'provider', 'file': 'meinescraper.py', 'enabled': False})
        s, d = call('/api/providers')
        check('Deaktiviert: nicht mehr in der Liste', 'meinescraper' not in [p['id'] for p in d['providers']], d)
        s, d = call('/api/providers?all=1')
        row = next(p for p in d['providers'] if p['file'] == 'meinescraper.py')
        check('… aber mit all=1 sichtbar (enabled=false)', row['enabled'] is False, row)
        s, d = call('/api/open', {'provider_id': row['id']})
        check('Deaktivierte Quelle lässt sich nicht öffnen', s >= 400, (s, d))
        s, d = call('/api/health?run=1')
        check('Health überspringt deaktivierte', all(h['id'] != row['id'] for h in d['health']), d)
        post('/api/admin/enable', {'kind': 'provider', 'file': 'meinescraper.py', 'enabled': True})
        s, d = call('/api/providers')
        check('Wieder aktiviert', 'meinescraper' in [p['id'] for p in d['providers']], d)

        # löschen + Papierkorb
        s, d = post('/api/admin/delete', {'kind': 'provider', 'file': 'meinescraper.py'})
        check('Eigenen Scraper löschen -> Papierkorb', d['how'] == 'trash', d)
        s, d = call('/api/providers')
        check('… verschwindet', 'meinescraper' not in [p['id'] for p in d['providers']], d)
        s, d = call('/api/admin/list?kind=provider')
        tr = next(t for t in d['trash'] if t['file'] == 'meinescraper.py' and t['what'] == 'gelöscht')
        s, d = post('/api/admin/restore', {'id': tr['id']})
        s, d = call('/api/providers')
        check('Aus dem Papierkorb wiederhergestellt', 'meinescraper' in [p['id'] for p in d['providers']], d)
        s, d = post('/api/admin/delete', {'kind': 'provider', 'file': 'fake.py'})
        check('Mitgelieferten Scraper löschen -> ausgeblendet', d['how'] == 'hidden', d)
        s, d = call('/api/providers')
        check('… weg aus der Liste', 'fake' not in [p['id'] for p in d['providers']], d)
        s, d = post('/api/admin/restore', {'id': 'bundled:fake.py'})
        s, d = call('/api/providers')
        check('… und wieder da', 'fake' in [p['id'] for p in d['providers']], d)

        # Erweiterung
        s, d = post('/api/admin/save', {'kind': 'extension', 'file': 'beispiel.py', 'code': SYS.EXTENSION_TEMPLATE})
        check('Erweiterung speichern', s == 200 and d['ok'], (s, d))
        s, d = call('/api/admin/list?kind=extension')
        e = next(i['info'] for i in d['items'] if i['file'] == 'beispiel.py')
        check('Erweiterung geladen (Hooks, Routen, Links)', e['hooks'] == ['register', 'process_items', 'process_hosters', 'on_play', 'on_stop'] and e['routes'] == ['hallo', 'status'] and e['links'], e)
        s, d = call('/api/x/beispiel/status')
        check('Eigene Route (JSON)', d == {'ok': True, 'besuche': 0}, d)
        s, h, body = call('/api/x/beispiel/hallo', raw=True)
        check('Eigene Route (HTML) + Zustand gespeichert', b'Aufruf Nummer 1' in body and call('/api/x/beispiel/status')[1]['besuche'] == 1, body)
        s, d = call('/api/x/beispiel/status', headers={'Origin': 'https://evil.example'})
        check('Routen auch gegen fremde Webseiten geschützt', s == 403, s)
        fake = call('/api/open', {'provider_id': 'fake'})[1]['items']
        film = next(i for i in call('/api/open', {'provider_id': 'fake', 'item': next(i for i in fake if i['title'] == 'Filme')})[1]['items'])
        s, d = call('/api/resolve', {'provider_id': 'fake', 'item': {'title': 'x', 'url': 'f1', 'next_func': 'get_hosters', 'is_playable': True}})
        check('Hook process_hosters sortiert (Direktlinks zuerst)', d['hosters'][0]['direct'] and [h['id'] for h in d['hosters']] == list(range(len(d['hosters']))), [(h['name'], h['direct']) for h in d['hosters']])
        post('/api/admin/enable', {'kind': 'extension', 'file': 'beispiel.py', 'enabled': False})
        s, d = call('/api/x/beispiel/status')
        check('Deaktivierte Erweiterung: Route weg', s == 404, (s, d))
        s, d = post('/api/admin/save', {'kind': 'extension', 'file': 'bad.py', 'code': 'def register(api):\n    raise RuntimeError("kaputt")\n'})
        s, d = call('/api/admin/list?kind=extension')
        bad = next(i for i in d['items'] if i['file'] == 'bad.py')
        check('Kaputte Erweiterung: Fehler sichtbar, Engine läuft weiter', 'kaputt' in bad['info']['error'] and call('/api/info')[0] == 200, bad)
        post('/api/admin/delete', {'kind': 'extension', 'file': 'bad.py'})
        post('/api/admin/enable', {'kind': 'extension', 'file': 'beispiel.py', 'enabled': True})

        # Export / Import
        post('/api/admin/enable', {'kind': 'provider', 'file': 'scraper.py', 'enabled': False})
        s, h, zdata = post('/api/admin/export', {'ui': {'skins': {'active': 'u1', 'list': []}, 'favs': [1, 2]}, 'full': False}, raw=True)
        import zipfile, io
        zf = zipfile.ZipFile(io.BytesIO(zdata))
        names = zf.namelist()
        check('Export: ZIP mit Manifest, Einstellungen, Scrapern, Erweiterungen, UI',
              s == 200 and {'manifest.json', 'settings.json', 'state.json', 'ui.json', 'providers/meinescraper.py', 'extensions/beispiel.py'} <= set(names), names)
        s, h, zfull = post('/api/admin/export', {'ui': {}, 'full': True}, raw=True)
        check('Export "alles": enthält auch die mitgelieferten Scraper', 'providers_bundled/fake.py' in zipfile.ZipFile(io.BytesIO(zfull)).namelist())

        s2 = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', '8816'], env=dict(env, MINIKODI_DATA=d2), cwd=str(ROOT),
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        wait_port(8816)
        API = 'http://127.0.0.1:8816'
        s, d = call('/api/providers')
        check('Neue Engine: leer bis auf mitgelieferte', [p['id'] for p in d['providers']] == ['fake'], d)
        s, d = call('/api/admin/import?mode=merge', zdata, headers={'Origin': 'http://127.0.0.1:8816', 'Content-Type': 'application/zip'})
        check('Import: ok + UI-Daten kommen zurück', s == 200 and d['ui'].get('favs') == [1, 2] and d['ui']['skins']['active'] == 'u1', (s, d))
        s, d = call('/api/providers?all=1')
        ids = {p['id']: p['enabled'] for p in d['providers']}
        check('Import: Scraper vorhanden, Aktiv-Zustand übernommen', ids.get('meinescraper') is True and ids.get('urlscraper') is False, ids)
        s, d = call('/api/admin/list?kind=extension')
        check('Import: Erweiterung vorhanden', sorted(i['file'] for i in d['items']) == ['baukasten.py', 'beispiel.py'], d)    # Baukasten ist fest eingebaut
        s, d = call('/api/admin/import', b'das ist kein zip', headers={'Origin': 'http://127.0.0.1:8816'})
        check('Import: Müll wird abgelehnt', s == 400, (s, d))
        evil = io.BytesIO()
        with zipfile.ZipFile(evil, 'w') as z:
            z.writestr('manifest.json', json.dumps({'app': 'MiniKodi', 'format': 1}))
            z.writestr('providers/../../pwn.py', SYS.SCRAPER_TEMPLATE)
            z.writestr('providers/ok.py', SYS.SCRAPER_TEMPLATE.replace('meinescraper', 'zweiter'))
            z.writestr('providers/syntax.py', 'def load(:')
        s, d = call('/api/admin/import', evil.getvalue(), headers={'Origin': 'http://127.0.0.1:8816'})
        rep = ' | '.join(d.get('report', []))
        check('Import: Pfad-Tricks/kaputte Dateien übersprungen, gute übernommen',
              s == 200 and 'ok.py eingespielt' in rep and 'syntax.py übersprungen' in rep and not (Path(d2).parent / 'pwn.py').exists() and not (Path(d2) / 'pwn.py').exists(), rep)
    finally:
        API = old_api
        s1.terminate()
        if s2:
            s2.terminate()


if __name__ == '__main__':
    main()
