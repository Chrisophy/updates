# -*- coding: utf-8 -*-
"""Alle Menüs mit der Fernbedienung (Pfeiltasten + OK) erreichbar: jedes sichtbare Bedienelement ist fokussierbar und mit
Pfeil runter/rechts erreichbar; zugeklappte Bereiche (<details>) blockieren die Navigation nicht.   python tests/tv_menus_test.py"""
import json, os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8974
ok = fail = 0
def check(n, c, x=''):
    global ok, fail
    if c: ok += 1; print('  ok   ', n)
    else: fail += 1; print('  FEHLER', n, x)
AUDIT = """() => {
  const sc = scope(); const fo = focusables(sc);
  const vis = (e) => { const r = e.getClientRects(); if (!r.length || e.offsetParent === null) return false; const d = e.closest('details:not([open])'); return !d || (e.tagName==='SUMMARY' && e.parentElement===d); };
  const all = [...sc.querySelectorAll('button,a[href],input:not([type=hidden]),select,textarea,summary,[role=button],[role=switch],[role=tab],[onclick]')].filter(vis)
    .filter((e) => !e.disabled && !e.closest('[aria-hidden=true]') && !e.hasAttribute('hidden'));
  const missing = all.filter((e) => !fo.includes(e) && !fo.some((f) => f.contains(e) || e.contains(f))).map((e) => e.tagName + ':' + (e.className||'') + ':' + (e.textContent||e.placeholder||e.getAttribute('aria-label')||'').trim().slice(0, 30));
  return { n: fo.length, missing };
}"""
WALK = """() => {
  const sc = scope(); const fo = focusables(sc); const set = new Set(fo);
  const cur = () => vf || document.activeElement;
  const put = (el) => { try { vfClear(); navAnchor = null; if (isTextField(el)) vfSet(el); else el.focus(); } catch (e) {} };
  const seen = new Set(); const q = [];
  const first = fo[0]; if (!first) return { total: 0, lost: [] };
  put(first); const start = cur(); if (set.has(start)) { seen.add(start); q.push(start); }
  while (q.length) {
    const el = q.shift();
    for (const d of ['down', 'up', 'right', 'left']) {
      put(el); move(d); const c = cur();
      if (c && set.has(c) && !seen.has(c)) { seen.add(c); q.push(c); }
    }
  }
  return { total: fo.length, lost: fo.filter((e) => !seen.has(e)).map((e) => { const r = e.getBoundingClientRect(); return e.tagName + ':' + (e.textContent || e.placeholder || '').trim().slice(0, 25) + '@' + Math.round(r.left) + ',' + Math.round(r.top) + ' w' + Math.round(r.width) + ' h' + Math.round(r.height); }) };
}"""
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    items = [{'id': 'a%d' % i, 'name': 'Addon %d' % i, 'group': 'video', 'version': '1.0', 'summary': 'x', 'src': 's', 'src_label': 'Repo', 'installed': False, 'update': False} for i in range(12)]
    ITEM = "{provider_id:'t', url:'x://a', title:'Testfilm', year:2001, tmdb:4711, poster:''}"
    CALLS = [('Startseite', 'void 0'), ('Einstellungen', 'openSettings()'), ('Quellen & System', 'openManager()'), ('Kodi-Repositories', 'openRepoBrowser()'), ('Titel-Info', 'openInfo(%s)' % ITEM),
             ('Favoriten wählen', 'openFavPicker(%s)' % ITEM), ('Titel-Menü', 'openCardMenu(%s, null)' % ITEM), ('Downloads', 'openDownloads()'), ('Chat', 'openChat()'),
             ('Meine Bibliothek', 'openMyLib()'), ('Themen', 'openTopicManager()'), ('Teilen', 'openShare()'), ('Handy koppeln', 'openCastPair()'), ('Fernbedienung', 'openRemote()'),
             ('Support-Bericht', 'openSupportReport()'), ('Diagnose', 'openDiagnose()'), ('Skin-Editor', 'openSkinEditor()'), ('Mediaplayer', 'openMediaPlayer()'),
             ('Kacheln', 'openTileManager()'), ('Sammlungen', 'openBundleManager()'), ('Entdecken', "openDiscover('movie')"), ('Trakt', 'openTrakt()'), ('Adresse abspielen', 'openPlayUrl()'),
             ('Feed hinzufügen', 'openAddFeed()'), ('Nachrichten verwalten', 'openNewsManager()'), ('Haus', 'openHaus()'), ('Sprachhilfe', 'voiceHelp()')]
    try:
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_context(viewport={'width': 1920, 'height': 1080}).new_page()
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.route('**/api/admin/repo/search*', lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps({'items': items, 'total': 459, 'page': 0, 'pages': 12, 'sources': [{'key': 's', 'label': 'Repo', 'count': 459}], 'errors': [], 'updates': 0})))
            pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_selector('header.top'); pg.wait_for_timeout(900)
            for name, call in CALLS:
                
                for _ in range(6):
                    if not pg.evaluate('layers.length'): break
                    pg.evaluate('history.back()'); pg.wait_for_timeout(350)
                try: pg.evaluate("() => { try { const r = %s; if (r && r.catch) r.catch(()=>{}); } catch (e) {} }" % call)
                except Exception as e: print('  (übersprungen)', name, str(e)[:60]); continue
                pg.wait_for_timeout(900)
                if not pg.evaluate('layers.length') and call != 'void 0': print('  (kein Fenster)', name); continue
                # Reiter durchgehen (Einstellungen, Verwaltung): jeden Reiter prüfen
                tabs = pg.evaluate("() => [...scope().querySelectorAll('[role=tab],.tabs .chip,.chips .chip')].map((e,i)=>i)") or []
                variants = [None] + tabs[:8]
                for v in variants:
                    if v is not None:
                        pg.evaluate("(i) => { const e = [...scope().querySelectorAll('[role=tab],.tabs .chip,.chips .chip')][i]; if (e) e.click(); }", v); pg.wait_for_timeout(500)
                    a = pg.evaluate(AUDIT)
                    label = name + ('' if v is None else ' [Reiter %d]' % (v + 1))
                    check(label + ': alles fokussierbar (%d)' % a['n'], not a['missing'], a['missing'][:6])
                    if a['n']:
                        w = pg.evaluate(WALK)
                        check(label + ': mit Pfeiltasten erreichbar', not w['lost'], w['lost'][:6])
            b.close()
    finally:
        srv.terminate()
    check('Keine Skriptfehler', not errs, errs[:3])
    print('\n%d ok, %d Fehler' % (ok, fail)); return 1 if fail else 0
if __name__ == '__main__': sys.exit(main())
