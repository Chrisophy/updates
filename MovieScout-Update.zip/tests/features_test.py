# -*- coding: utf-8 -*-
"""Tests für die Neuerungen 2.1: System-Update ohne APK, Teilen im WLAN, parallele Suche, Zwischenspeicher,
Schutz vor Sperren, DNS, Kodi-Schnittstellen.

    python tests/features_test.py

Teil A läuft im Prozess (Einheiten + Anfragen direkt an die ASGI-App, damit "fremde" Geräte geprüft werden können),
Teil B startet echte Engine-Prozesse (Update einspielen, Neustart, Rückfall bei kaputtem Update).
"""
import asyncio
import io
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import types
import zipfile
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parent.parent
DATA = tempfile.mkdtemp(prefix='ms_feat_')
os.environ['MINIKODI_DATA'] = DATA
os.environ['MOVIESCOUT_DATA'] = DATA
os.environ['MINIKODI_ALLOW_PRIVATE'] = '1'
os.environ['MINIKODI_PROVIDERS'] = str(ROOT / 'tests' / 'fake_providers')
os.environ.pop('MOVIESCOUT_TOKEN', None)
os.environ.pop('MINIKODI_TOKEN', None)
sys.path.insert(0, str(ROOT))

passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


# =============================================================================== Teil A: im Prozess
from kodi_runtime import context, xbmcaddon, xbmcgui, inputstreamhelper  # noqa: E402
from kodi_runtime import skin as K  # noqa: E402
from engine import cache as CACHE, ratelimit as RL, dns as DNS, share as SH, normalize as N  # noqa: E402
from engine import registry as R  # noqa: E402


def part_cache():
    print('Zwischenspeicher')
    c = CACHE.Cache('t_ttl', ttl=0.4, persist=True)
    c.put('a', {'x': 1})
    check('Wert kommt zurück', c.get('a') == {'x': 1})
    c._mem.clear()
    check('... auch nach Verlust des Arbeitsspeichers (SQLite)', c.get('a') == {'x': 1})
    time.sleep(0.5)
    check('Nach Ablauf (TTL): nichts mehr', c.get('a') is None)
    v, stale = c.get_stale('a', max_stale=30)
    check('Abgelaufen, aber noch brauchbar (veraltet) zum schnellen Anzeigen', v == {'x': 1} and stale is True, (v, stale))
    v, stale = c.get_stale('a', max_stale=0)
    check('Nach Ende der Schonfrist: weg', v is None)
    c.put('b', [1, 2], ttl=60)
    check('Eigene TTL je Eintrag', c.get('b') == [1, 2])
    c.delete('b')
    check('Löschen', c.get('b') is None)
    st = c.stats()
    check('Statistik zählt Treffer und Fehlgriffe', st['hits'] >= 2 and st['misses'] >= 1 and st['persist'], st)
    small = CACHE.Cache('t_small', ttl=60, max_mem=8)
    for i in range(30):
        small.put(i, i)
    check('Arbeitsspeicher bleibt begrenzt', len(small._mem) <= 8, len(small._mem))
    check('Alle Zwischenspeicher in der Übersicht', any(s['name'] == 't_ttl' for s in CACHE.all_stats()))


class Resp:
    def __init__(self, status=200, headers=None):
        self.status_code = status
        self.headers = headers or {}


def part_ratelimit():
    print('Schutz vor Sperren')
    xbmcaddon.save_settings({'net_protect': 'normal', 'net_quota': 'quota.test = 2/min', 'net_proxy': 'http://u:p@proxy.test:3128',
                             'net_proxy_hosts': 'proxied.test'})
    RL.invalidate()
    RL.reset()
    n = {'c': 0}

    def ok():
        n['c'] += 1
        return Resp(200)
    RL.call('http://quota.test/a', 'GET', ok)
    RL.call('http://quota.test/b', 'GET', ok)
    t0 = time.time()
    try:
        RL.call('http://quota.test/c', 'GET', ok)
        raised = False
    except RL.RateLimited as e:
        raised = 'Quote' in str(e)
    check('Quote: die dritte Anfrage in der Minute wird klar abgelehnt (nicht endlos gewartet)', raised and time.time() - t0 < 3 and n['c'] == 2, (raised, n))

    seq = [Resp(429, {'Retry-After': '1'}), Resp(200)]
    calls = []

    def flaky():
        calls.append(1)
        return seq[len(calls) - 1] if len(calls) <= 2 else Resp(200)
    t0 = time.time()
    r = RL.call('http://flaky.test/x', 'GET', flaky)
    check('429 mit Retry-After: einmal höflich wiederholt, dann klappt es', r.status_code == 200 and len(calls) == 2 and time.time() - t0 >= 1, (r.status_code, calls))

    def blocked():
        return Resp(429, {'Retry-After': '90'})
    RL.call('http://hard.test/x', 'POST', blocked)
    t0 = time.time()
    try:
        RL.call('http://hard.test/y', 'GET', ok)
        raised = False
    except RL.RateLimited as e:
        raised = 'Sekunden' in str(e)
    check('Lange Sperre: Folgeanfragen warten nicht ewig, sondern melden "später wieder"', raised and time.time() - t0 < 3)
    snap = {r['host']: r for r in RL.snapshot()}
    check('Übersicht zeigt gebremste Hosts', snap.get('hard.test', {}).get('cooling_s', 0) > 30 and snap.get('hard.test', {}).get('throttled') == 1, snap.get('hard.test'))

    before = n['c']
    RL.call('http://127.0.0.1/x', 'GET', ok)
    RL.call('http://192.168.1.5/x', 'GET', ok)
    check('Geräte im eigenen Netz werden nicht gebremst', n['c'] == before + 2)
    check('Proxy nur für die genannten Seiten', RL.proxy_for('http://proxied.test/a') == 'http://u:p@proxy.test:3128' and RL.proxy_for('http://other.test/') == '' and RL.proxy_for('http://192.168.1.2/') == '')
    check('Quoten-Text wird gelesen', RL._parse_quota('a.de = 5/sek\nb.de: 100/std\nkaputt') == {'a.de': (5, 1.0), 'b.de': (100, 3600.0)})
    xbmcaddon.save_settings({'net_protect': 'off', 'net_quota': '', 'net_proxy': '', 'net_proxy_hosts': ''})
    RL.invalidate()
    RL.reset()
    k = n['c']
    for _ in range(5):
        RL.call('http://off.test/', 'GET', ok)
    check('Schutz "aus": alles direkt', n['c'] == k + 5)
    xbmcaddon.save_settings({'net_protect': 'normal'})
    RL.invalidate()


def part_dns():
    print('DNS-Wechsler')
    st = DNS.status()
    check('Status nennt Auswahl und Anbieter', st['mode'] == 'system' and {'cloudflare', 'google', 'quad9', 'adguard', 'custom'} <= set(st['presets']), st)
    out = DNS.test('custom', '')
    check('Test ohne gültige eigene Adresse: klar "nicht ok"', out['ok'] is False and out['rows'] and not out['rows'][0].get('doh'))
    out = DNS.test('custom', 'http://unsicher.test/dns')
    check('Eigene Adresse muss https sein', out['ok'] is False)
    xbmcaddon.save_settings({'dns_mode': 'google'})
    DNS.invalidate()
    try:
        ai = socket.getaddrinfo('localhost', 80)
        ip = socket.getaddrinfo('127.0.0.1', 80)
        check('Mit DNS-Wechsel: localhost und IP-Adressen gehen unverändert durch', bool(ai) and ip[0][4][0] == '127.0.0.1')
    finally:
        xbmcaddon.save_settings({'dns_mode': 'system'})
        DNS.invalidate()
    check('Zurück auf System-DNS', DNS.status()['mode'] == 'system')


def part_search():
    print('Parallele Suche mit Fristen')
    saved = dict(R.REGISTRY)
    orig_job = R._search_job
    R.REGISTRY.clear()
    for pid in ('fast1', 'fast2', 'slow', 'dead'):
        R.REGISTRY[pid] = types.SimpleNamespace(enabled=True, module=object(), global_search=True, name=pid)

    def fake_job(pid, query, timeout, fresh):
        if pid == 'slow':
            time.sleep(4)
        if pid == 'dead':
            R._record_search(pid, False, 10)
            raise RuntimeError('kaputt')
        time.sleep(0.1)
        R._record_search(pid, True, 100)
        return {'items': [{'title': pid + ' ' + query}], 'notes': []}
    R._search_job = fake_job
    R._SSTAT.clear()
    try:
        info = {}
        t0 = time.time()
        res, errs = R.search_all('x', hard=1.5, soft=0.5, info=info)
        dt = time.time() - t0
        titles = sorted(r['title'] for r in res)
        check('Schnelle Quellen liefern, die langsame hält nicht auf (Antwort nach %.1f s statt 4 s)' % dt, dt < 2.5 and titles == ['fast1 x', 'fast2 x'], (dt, titles))
        check('Langsame Quelle wird als "noch nicht fertig" gemeldet', 'slow' in info.get('pending', []) and 'dead' in errs, (info, errs))
        for _ in range(3):
            R._record_search('dead', False, 10)
        info = {}
        res, errs = R.search_all('y', hard=1.5, soft=0.5, info=info)
        check('Quelle mit Dauerfehlern wird eine Weile übersprungen (Sicherung)', 'dead' in info.get('skipped', {}) and 'dead' not in errs, info)
        check('Reihenfolge nach gemessener Antwortzeit (schnelle zuerst) ist erreichbar', R.search_stats()['fast1']['ema'] > 0)
    finally:
        R._search_job = orig_job
        R.REGISTRY.clear()
        R.REGISTRY.update(saved)
        R._SSTAT.clear()
        time.sleep(0)


def part_kodi():
    print('Kodi-Schnittstellen')
    ctx = context.RequestContext(query='', params={'title': 'Titel X', 'year': '1999'}, client={'widevine': 'L3', 'android': True})
    with context.use(ctx):
        dp = xbmcgui.DialogProgress()
        dp.create('Lade', 'Zeile 1', 'Zeile 2')
        check('DialogProgress.create (Kodi 18, mehrere Zeilen)', ctx.progress['open'] and ctx.progress['message'] == 'Zeile 1\nZeile 2' and ctx.progress['heading'] == 'Lade', ctx.progress)
        dp.update(40, 'Halbzeit')
        check('DialogProgress.update setzt Prozent und Text', ctx.progress['percent'] == 40 and ctx.progress['message'] == 'Halbzeit', ctx.progress)
        dp.update(500)
        check('Prozent bleibt zwischen 0 und 100', ctx.progress['percent'] == 100)
        check('iscanceled() ist zunächst False', dp.iscanceled() is False)
        ctx.cancelled.set()
        check('iscanceled() wird True, wenn die Engine abbricht (Schleifen enden)', dp.iscanceled() is True)
        dp.close()
        check('close() beendet', ctx.progress['open'] is False and dp.isFinished())
        bg = xbmcgui.DialogProgressBG()
        bg.create('Hintergrund', 'msg')
        check('DialogProgressBG', ctx.progress['heading'] == 'Hintergrund' and not bg.isFinished())
        bg.close()
        check('DialogProgressBG beendet', bg.isFinished())

        K.builtin('Skin.SetString(mein,Wert)')
        check('Skin.SetString + Skin.String', K.info_label('Skin.String(mein)') == 'Wert')
        K.builtin('Skin.SetBool(an)')
        check('Skin.SetBool + Skin.HasSetting', K.cond_visible('Skin.HasSetting(an)'))
        K.builtin('Skin.ToggleSetting(an)')
        check('Skin.ToggleSetting schaltet um', not K.cond_visible('Skin.HasSetting(an)'))
        K.builtin('Skin.Reset(mein)')
        check('Skin.Reset', K.info_label('Skin.String(mein)') == '')
        K.builtin('SetProperty(farbe,rot,home)')
        check('Window-Properties über SetProperty / Window(home).Property(..)', K.info_label('Window(home).Property(farbe)') == 'rot')
        K.builtin('ClearProperty(farbe,home)')
        check('ClearProperty', K.info_label('Window(home).Property(farbe)') == '')

        check('Bedingung: und / oder / nicht / Klammern', K.cond_visible('true + !false') and K.cond_visible('false | (true + true)') and not K.cond_visible('true + !true'))
        check('Bedingung: String.IsEqual mit Infolabel', K.cond_visible('String.IsEqual(ListItem.Title,Titel X)') and not K.cond_visible('String.IsEqual(ListItem.Title,anders)'))
        check('Bedingung: String.Contains / StartsWith / IsEmpty', K.cond_visible('String.Contains(ListItem.Title,tel)') and K.cond_visible('String.StartsWith(ListItem.Title,Titel)') and K.cond_visible('String.IsEmpty(Skin.String(leer))'))
        check('Bedingung: Integer.IsGreater mit Infolabel', K.cond_visible('Integer.IsGreater(ListItem.Year,1990)') and not K.cond_visible('Integer.IsGreater(ListItem.Year,2000)'))
        xbmcaddon.save_settings({'platform_profile': 'android'})
        check('Bedingung: Plattform folgt der Einstellung "Gerätetyp"', K.cond_visible('System.Platform.Android') and not K.cond_visible('System.Platform.Windows'))
        xbmcaddon.save_settings({'platform_profile': 'web'})
        check('Bedingung: installierte Hilfs-Addons', K.cond_visible('System.HasAddon(inputstream.adaptive)') and not K.cond_visible('System.HasAddon(plugin.unbekannt)') and K.cond_visible('System.Platform.Linux'))
        check('Infolabel: Client-Widevine, Datum/Uhrzeit nicht leer', K.info_label('MovieScout.Client.Widevine') == 'L3' and len(K.info_label('System.Time(hh:mm)')) == 5)

        r = json.loads(K.jsonrpc(json.dumps({'jsonrpc': '2.0', 'method': 'XBMC.GetInfoLabels', 'params': {'labels': ['ListItem.Title']}, 'id': 7})))
        check('JSON-RPC XBMC.GetInfoLabels', r['result'] == {'ListItem.Title': 'Titel X'} and r['id'] == 7, r)
        r = json.loads(K.jsonrpc(json.dumps({'jsonrpc': '2.0', 'method': 'Addons.GetAddonDetails', 'params': {'addonid': 'inputstream.adaptive'}, 'id': 1})))
        check('JSON-RPC Addons.GetAddonDetails (Hilfs-Addon vorhanden)', r['result']['addon']['enabled'] is True, r)
        r = json.loads(K.jsonrpc(json.dumps({'jsonrpc': '2.0', 'method': 'Addons.GetAddonDetails', 'params': {'addonid': 'x.y'}, 'id': 1})))
        check('JSON-RPC unbekanntes Addon: Fehlerantwort', 'error' in r)
        r = json.loads(K.jsonrpc(json.dumps([{'jsonrpc': '2.0', 'method': 'JSONRPC.Ping', 'id': 1}, {'jsonrpc': '2.0', 'method': 'JSONRPC.Version', 'id': 2}])))
        check('JSON-RPC Stapel', isinstance(r, list) and r[0]['result'] == 'pong' and r[1]['result']['version']['major'] >= 12)
        check('JSON-RPC kaputter Text', 'error' in json.loads(K.jsonrpc('{kein json')))

        h = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
        check('inputstreamhelper: Widevine L3 ist ok (Browser entscheidet)', h.check_inputstream() and h.inputstream_addon == 'inputstream.adaptive')
        ctx.client['widevine'] = 'NONE'
        check('inputstreamhelper: kein Widevine -> False', not inputstreamhelper.Helper('mpd', drm='widevine').check_inputstream())
        check('inputstreamhelper: unbekannte Zusatzfunktionen stören nicht', inputstreamhelper.Helper('hls').some_unknown_call(1, 2) is None)
        check('inputstreamhelper: rtmp -> inputstream.rtmp', inputstreamhelper.Helper('rtmp').inputstream_addon == 'inputstream.rtmp')

        li = xbmcgui.ListItem('Film')
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        li.setProperty('inputstream.adaptive.license_key', 'https://lic.example/get||R{SSM}|')
        li.setProperty('inputstream.adaptive.stream_headers', 'Referer=https%3A%2F%2Fex.de%2F&User-Agent=T')
        hs = N.hoster_from_resolved('https://cdn.example/stream.mpd', li, 'ex.de', 'Ex')
        blob = json.dumps(hs, ensure_ascii=False)
        check('Hoster aus ListItem: DRM-Daten, Format und Header übernommen', hs and 'lic.example' in blob and 'mpd' in blob and 'Referer' in blob, blob[:300])


def part_share_asgi():
    print('Teilen im WLAN (Anfragen von fremden Geräten)')
    os.environ['MOVIESCOUT_LAN_GATE'] = '1'
    from engine import app as A
    app = A.create_app()

    async def call(method, path, client='192.168.77.5', headers=None, body=None, query=''):
        raw = json.dumps(body).encode() if body is not None else b''
        hdr = {'host': 'moviescout.test', **(headers or {})}
        if body is not None:
            hdr['content-type'] = 'application/json'
        scope = {'type': 'http', 'asgi': {'version': '3.0'}, 'http_version': '1.1', 'method': method, 'path': path, 'raw_path': path.encode(),
                 'query_string': query.encode(), 'headers': [(k.lower().encode(), v.encode()) for k, v in hdr.items()],
                 'client': (client, 5000), 'server': ('127.0.0.1', 8000), 'scheme': 'http', 'root_path': ''}
        sent = []

        async def receive():
            return {'type': 'http.request', 'body': raw, 'more_body': False}

        async def send(m):
            sent.append(m)
        await app(scope, receive, send)
        st = next(m['status'] for m in sent if m['type'] == 'http.response.start')
        hd = {k.decode().lower(): v.decode() for m in sent if m['type'] == 'http.response.start' for k, v in m.get('headers', [])}
        data = b''.join(m.get('body', b'') for m in sent if m['type'] == 'http.response.body')
        try:
            js = json.loads(data)
        except Exception:                                   # noqa: BLE001
            js = None
        return st, js, hd, data

    def run(*a, **k):
        return asyncio.run(call(*a, **k))

    SH.forget()
    xbmcaddon.save_settings({'share_enabled': 'false', 'share_password': ''})
    SH.invalidate()
    st, js, _h, _d = run('GET', '/api/info')
    check('Freigabe aus (App-Modus): fremdes Gerät kommt nicht in die API', st in (401, 403), st)
    st, _j, _h, _d = run('GET', '/api/info', client='127.0.0.1')
    check('Das Gerät selbst darf immer', st == 200, st)

    conf = SH.set_config(True, 'Testpass1')
    check('Freigabe einschalten mit eigenem Passwort', conf['enabled'] and conf['password'] == 'Testpass1')
    try:
        SH.set_config(True, 'kurz')
        short = False
    except ValueError:
        short = True
    check('Zu kurzes Passwort wird abgelehnt', short)
    gen = SH.new_password()
    check('Erzeugtes Passwort: 8 Zeichen, ohne verwechselbare', len(gen) == 8 and not set(gen) & set('0O1IL'))

    st, js, _h, _d = run('GET', '/api/info')
    check('Ohne Anmeldung: 401 mit Hinweis "share"', st == 401 and js and js.get('share') is True, (st, js))
    st, _j, hd, _d = run('GET', '/')
    check('Ohne Anmeldung im Browser: Weiterleitung auf die Anmeldeseite', st == 303 and hd.get('location') == '/share', (st, hd))
    st, _j, _h, data = run('GET', '/share')
    check('Anmeldeseite ist erreichbar', st == 200 and b'Passwort' in data)
    st, js, _h, _d = run('POST', '/api/share/login', body={'password': 'falsch'})
    check('Falsches Passwort: 401', st == 401 and 'falsch' in (js or {}).get('error', ''), (st, js))
    st, js, hd, _d = run('POST', '/api/share/login', body={'password': 'Testpass1'})
    tok = (js or {}).get('token')
    check('Richtiges Passwort: Zugangszeichen + Cookie (nicht das Passwort selbst)', st == 200 and tok and tok != 'Testpass1' and 'ms_share=' in hd.get('set-cookie', ''), (st, js, hd))
    H = {'X-Token': tok}
    st, js, _h, _d = run('GET', '/api/info', headers=H)
    check('Mit Zugangszeichen: Info lesbar', st == 200, st)
    st, js, _h, _d = run('GET', '/api/info', headers={'Cookie': 'ms_share=' + tok})
    check('Auch per Cookie (Browser)', st == 200, st)
    st, js, _h, _d = run('GET', '/api/providers', headers=H)
    check('Quellenliste für Gäste', st == 200, st)
    st, js, _h, _d = run('GET', '/api/search', headers=H, query='q=Matrix')
    check('Suche für Gäste', st == 200, st)
    st, js, _h, _d = run('GET', '/api/share/status', headers=H)
    check('Status für Gast: Rolle "guest", ohne Passwort und Adressen', st == 200 and js['role'] == 'guest' and 'password' not in js and 'urls' not in js and 'seen' not in js, js)
    for method, path in (('GET', '/api/settings'), ('POST', '/api/settings'), ('POST', '/api/admin/reload'), ('GET', '/api/admin/list'),
                         ('POST', '/api/admin/update/upload'), ('POST', '/api/admin/share'), ('POST', '/api/cache/clear'), ('GET', '/api/admin/net')):
        st, js, _h, _d = run(method, path, headers=H, body={} if method == 'POST' else None)
        check('Gast darf nicht: %s %s' % (method, path), st == 403, (st, js))
    st, js, _h, _d = run('GET', '/api/share/status', client='127.0.0.1')
    check('Host sieht Passwort, Adressen und Geräte', js['role'] == 'host' and js['password'] == 'Testpass1' and isinstance(js['urls'], list) and 'seen' in js, js)
    check('Gerät des Gastes steht in der Liste', any(s['ip'] == '192.168.77.5' for s in js['seen']), js['seen'])
    st, js, _h, _d = run('POST', '/api/admin/share', client='127.0.0.1', body={'enabled': True, 'password': 'Neu12345'})
    check('Host ändert das Passwort', st == 200 and js['password'] == 'Neu12345', (st, js))
    st, js, _h, _d = run('GET', '/api/info', headers=H)
    check('Passwortwechsel meldet alle Gäste sofort ab', st == 401, st)
    st, js, _h, _d = run('POST', '/api/share/login', body={'password': 'Neu12345'})
    tok2 = js['token']
    st, js, _h, _d = run('GET', '/api/info', headers={'X-Token': tok2})
    check('Neues Passwort funktioniert', st == 200)

    for i in range(8):
        run('POST', '/api/share/login', client='192.168.77.99', body={'password': 'x%d' % i})
    st, js, _h, _d = run('POST', '/api/share/login', client='192.168.77.99', body={'password': 'Neu12345'})
    check('Durchprobieren wird gebremst: nach 8 Fehlversuchen 429 (auch mit richtigem Passwort)', st == 429, st)
    st, js, _h, _d = run('POST', '/api/share/login', client='192.168.77.5', body={'password': 'Neu12345'})
    check('Andere Geräte sind davon nicht betroffen', st == 200, st)

    st, js, _h, _d = run('GET', '/api/info', query='token=' + tok2)
    check('Zugangszeichen auch als ?token= (für Stream-Adressen)', st == 200, st)
    st, js, _h, _d = run('GET', '/api/info', headers={'X-Token': 'x' * 40})
    check('Falsches Zugangszeichen: 401', st == 401)
    st, js, _h, _d = run('POST', '/api/admin/share', client='127.0.0.1', body={'enabled': False})
    st, js, _h, _d = run('GET', '/api/info', headers={'X-Token': tok2})
    check('Freigabe aus: Gäste sofort draußen', st in (401, 403), st)


def part_a():
    part_cache()
    part_ratelimit()
    part_dns()
    part_search()
    part_kodi()
    part_share_asgi()


# =============================================================================== Teil B: echte Prozesse
def wait_port(port, tries=120):
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def http(port, path, body=None, method=None, raw=None, headers=None):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    hd = dict(headers or {})
    if body is not None:
        hd['Content-Type'] = 'application/json'
    req = Request('http://127.0.0.1:%d%s' % (port, path), data=data, method=method or ('POST' if data is not None else 'GET'), headers=hd)
    try:
        with urlopen(req, timeout=60) as r:
            txt = r.read()
            code = r.status
    except HTTPError as e:
        txt = e.read()
        code = e.code
    try:
        return code, json.loads(txt)
    except Exception:                                       # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def start(port, data):
    env = dict(os.environ, MINIKODI_DATA=data, MOVIESCOUT_DATA=data, PYTHONUNBUFFERED='1')
    env.pop('MOVIESCOUT_LAN_GATE', None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(port)], env=env, cwd=str(ROOT),
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    ok = wait_port(port)
    return p, ok


def stop(p):
    p.terminate()
    try:
        p.wait(10)
    except subprocess.TimeoutExpired:
        p.kill()


def make_zip(version, mutate=None, drop=()):
    """Aus dem Projektordner ein Update-ZIP bauen (ohne vendor/android/tests)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('VERSION', version + '\n')
        z.write(ROOT / 'main.py', 'main.py')
        for d in ('engine', 'kodi_runtime', 'providers', 'extensions', 'resources', 'static', 'system'):
            for f in sorted((ROOT / d).rglob('*')):
                if f.is_dir() or '__pycache__' in f.parts or f.suffix == '.pyc' or 'vendor' in f.relative_to(ROOT).parts:
                    continue
                rel = f.relative_to(ROOT).as_posix()
                if rel in drop:
                    continue
                raw = f.read_bytes()
                if mutate:
                    raw = mutate(rel, raw)
                z.writestr(rel, raw)
    return buf.getvalue()


def part_b():
    print('System-Update (echte Engine)')
    port = 8861
    data = tempfile.mkdtemp(prefix='ms_upd_')
    base_ver = (ROOT / 'VERSION').read_text().strip().splitlines()[0]
    p, ok = start(port, data)
    try:
        check('Engine startet', ok)
        if not ok:
            return
        code, st = http(port, '/api/admin/update')
        check('Status: läuft mit dem mitgelieferten Stand', code == 200 and st['running'] == base_ver and not st['using_update'] and not st['restart_needed'], st)
        check('Ohne Windows-Programm/App: Neustart per Knopf nicht angeboten', st.get('can_restart') is False, st)
        code, ext = http(port, '/api/admin/list?kind=extension')
        ids = json.dumps(ext)
        check('Scraper-Baukasten ist fest eingebaut (beim ersten Start angelegt)', code == 200 and 'baukasten' in ids, ids[:200])
        code, page = http(port, '/api/x/baukasten/index')
        check('Baukasten-Seite wird von der Engine ausgeliefert', code == 200 and isinstance(page, str) and '<html' in page.lower(), str(page)[:120])

        code, js = http(port, '/api/admin/update/upload', raw=b'das ist kein zip', headers={'Content-Type': 'application/zip'})
        check('Kaputte Datei wird abgelehnt', code == 400 and 'ZIP' in js['error'], js)
        bad = make_zip('9.9.9', lambda rel, raw: raw + b'\ndef kaputt(:\n' if rel == 'engine/registry.py' else raw)
        code, js = http(port, '/api/admin/update/upload', raw=bad, headers={'Content-Type': 'application/zip'})
        check('Quelltext mit Syntaxfehler wird abgelehnt (nichts wird eingespielt)', code == 400 and 'registry.py' in js['error'], js)
        code, js = http(port, '/api/admin/update/upload', raw=make_zip('0.0.1'), headers={'Content-Type': 'application/zip'})
        check('Zu altes Paket wird abgelehnt', code == 400, js)
        code, js = http(port, '/api/admin/update/upload', raw=make_zip('9.9.9', drop=('engine/app.py',)), headers={'Content-Type': 'application/zip'})
        check('Unvollständiges Paket wird abgelehnt', code == 400 and 'app.py' in js['error'], js)
        evil = io.BytesIO()
        with zipfile.ZipFile(evil, 'w') as z:
            z.writestr('VERSION', '9.9.9\n')
            z.writestr('engine/../../evil.py', 'x=1')
        code, js = http(port, '/api/admin/update/upload', raw=evil.getvalue(), headers={'Content-Type': 'application/zip'})
        check('Pfad aus dem Ordner heraus ("..") wird abgelehnt', code == 400 and 'Pfad' in js['error'], js)
        check('Nichts davon hat etwas verändert', http(port, '/api/admin/update')[1]['overlay'] == '' and not (Path(data) / 'update' / 'current').exists())

        v1 = '99.1.0'
        code, js = http(port, '/api/admin/update/upload', raw=make_zip(v1, lambda rel, raw: raw.replace(b'</body>', b'<!--UPD-MARK-1--></body>') if rel == 'static/index.html' else raw),
                        headers={'Content-Type': 'application/zip'})
        check('Gültiges Update wird angenommen', code == 200 and js['ok'] and js['version'] == v1 and js['restart_needed'], js)
        st = http(port, '/api/admin/update')[1]
        check('Status: Neustart nötig', st['restart_needed'] and st['overlay'] == v1 and st['running'] == base_ver, st)
        code, _j = http(port, '/api/admin/update/rollback', body={})
        check('Rückgängig ohne früheren Stand: klare Meldung', code == 400)
    finally:
        stop(p)

    p, ok = start(port, data)
    try:
        check('Nach Neustart läuft das Update', ok)
        st = http(port, '/api/admin/update')[1]
        check('Läuft mit dem neuen Stand, Neustart nicht mehr nötig', st['running'] == '99.1.0' and st['using_update'] and not st['restart_needed'] and not st['failed'], st)
        code, ui = http(port, '/ui/')
        check('Oberfläche kommt aus dem Update', code == 200 and 'UPD-MARK-1' in ui)
        check('Start-Marker ist nach sauberem Start gelöscht', not (Path(data) / 'update' / 'booting').exists())
        code, ext = http(port, '/api/admin/list?kind=extension')
        check('Eingebaute Erweiterung funktioniert auch im Update', 'baukasten' in json.dumps(ext))
        code, js = http(port, '/api/admin/update/upload', raw=make_zip('99.2.0'), headers={'Content-Type': 'application/zip'})
        check('Zweites Update', code == 200 and js['version'] == '99.2.0', js)
        code, js = http(port, '/api/admin/update/upload', raw=make_zip('99.2.0'), headers={'Content-Type': 'application/zip'})
        check('Dieselbe Version nochmal: abgelehnt', code == 400 and 'schon' in js['error'], js)
        code, js = http(port, '/api/admin/update/rollback', body={})
        st = http(port, '/api/admin/update')[1]
        check('Rückgängig: vorheriger Stand ist wieder der aktuelle', code == 200 and st['overlay'] == '99.1.0' and st['previous'] == '99.2.0', (js, st))
        code, js = http(port, '/api/admin/update/reset', body={})
        st = http(port, '/api/admin/update')[1]
        check('Zurücksetzen auf den mitgelieferten Stand', code == 200 and st['overlay'] == '', st)
    finally:
        stop(p)

    p, ok = start(port, data)
    try:
        st = http(port, '/api/admin/update')[1]
        check('Nach dem Zurücksetzen und Neustart läuft wieder der Grundstand', ok and st['running'] == base_ver and not st['using_update'], st)
    finally:
        stop(p)

    print('Rückfall bei kaputtem Update')
    data2 = tempfile.mkdtemp(prefix='ms_bad_')
    cur = Path(data2) / 'update' / 'current'
    for d in ('engine', 'kodi_runtime', 'static'):
        shutil.copytree(ROOT / d, cur / d, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    shutil.copy2(ROOT / 'main.py', cur / 'main.py')
    (cur / 'VERSION').write_text('99.9.9\n')
    (cur / 'engine' / 'app.py').write_text('def kaputt(:\n')
    p, ok = start(port, data2)
    try:
        check('Engine startet trotz kaputtem Update (Rückfall auf den Grundstand)', ok)
        if ok:
            st = http(port, '/api/admin/update')[1]
            check('Läuft mit dem Grundstand, Update als fehlerhaft gemerkt, Meldung vorhanden', st['running'] == base_ver and st['failed'] and not st['using_update'], st)
            check('Kaputter Stand wurde zur Seite gelegt', (Path(data2) / 'update' / 'bad').exists() and not (Path(data2) / 'update' / 'current').exists())
    finally:
        stop(p)
    # Hängt der Start (Marker bleibt liegen), fällt der nächste Start zurück
    data3 = tempfile.mkdtemp(prefix='ms_hang_')
    cur = Path(data3) / 'update' / 'current'
    for d in ('engine', 'kodi_runtime', 'static'):
        shutil.copytree(ROOT / d, cur / d, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    shutil.copy2(ROOT / 'main.py', cur / 'main.py')
    (cur / 'VERSION').write_text('99.8.0\n')
    (Path(data3) / 'update' / 'booting').write_text('99.8.0')
    p, ok = start(port, data3)
    try:
        st = http(port, '/api/admin/update')[1] if ok else {}
        check('Alter Start-Marker (letzter Start nie fertig geworden): Update wird nicht benutzt', ok and not st.get('using_update') and st.get('failed'), st)
    finally:
        stop(p)


def main():
    try:
        part_a()
    except Exception:                                       # noqa: BLE001
        import traceback
        traceback.print_exc()
        global failed
        failed += 1
    try:
        part_b()
    except Exception:                                       # noqa: BLE001
        import traceback
        traceback.print_exc()
        failed += 1
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
