# -*- coding: utf-8 -*-
"""Kodi-Addons, die an Kleinigkeiten scheiterten (DMAX, Deluxe Music, ARDundZDF):
UTF-8-BOM im Startskript, „<“ in einem Attributwert der settings.xml, special://userdata ohne Schrägstrich,
Router mit importlib.import_module('resources.…') und getattr(sys.modules[__name__], …), eingebautes kodi_six.
    python tests/addon_quirks_test.py"""
import io, os, sys, tempfile, zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
tmp = tempfile.mkdtemp(prefix='ms_quirk_')
os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = tmp
passed = failed = 0
def check(n, ok, x=''):
    global passed, failed
    if ok: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)

XML = ('<addon id="plugin.video.quirk" name="Quirk" version="1.0" provider-name="x"><requires><import addon="xbmc.python" version="3.0.0"/>'
       '<import addon="script.module.kodi-six"/></requires><extension point="xbmc.python.pluginsource" library="main.py"><provides>video</provides></extension></addon>')
SET = ('<?xml version="1.0" encoding="utf-8"?>\n<settings>\n<category label="A">\n'
       '<setting label="Intervall" type="select" values="12 Std.|1 Tag" default="12 Std." id="pref_iv"/>\n'
       '<setting label="Musik" type="select" id="pref_m" default="Keine"\n values="Keine|Kodi <Bild>|Addon <Player & Info>"/>\n'
       '</category>\n</settings>\n')
MAIN = '''﻿# -*- coding: utf-8 -*-
import sys, importlib, os
from kodi_six import xbmc, xbmcplugin, xbmcgui
from kodi_six.utils import py2_encode
import xbmcaddon
A = xbmcaddon.Addon()
iv = A.getSetting('pref_iv')
ud = xbmc.translatePath("special://userdata")
os.makedirs(os.path.join(ud, "addon_data", "plugin.video.quirk"), exist_ok=True)
def Sub(): 
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), 'plugin://plugin.video.quirk/?x=1', xbmcgui.ListItem('SubOK'), True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
if 'wait=1' in sys.argv[2]:
    pl = xbmc.Player(); pl.play('https://x/y.m3u8', xbmcgui.ListItem('V'))
    while 1:                                    # wie ARDundZDF: auf den Player warten
        if pl.isPlaying():
            break
        xbmc.sleep(200)
    while pl.isPlaying():                       # und auf das Ende warten
        xbmc.sleep(100)
elif 'dirID=' in sys.argv[2]:
    fn = sys.argv[2].split('dirID=')[1]
    if '.' in fn:
        mod = importlib.import_module('.'.join(fn.split('.')[:-1]))
        getattr(mod, fn.split('.')[-1])()
    else:
        getattr(sys.modules[__name__], fn)()
else:
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), 'plugin://plugin.video.quirk/?dirID=Sub', xbmcgui.ListItem('Menu ' + iv), True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
'''
LIB = '''import sys, xbmcplugin, xbmcgui
def Deep():
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), 'plugin://plugin.video.quirk/?x=2', xbmcgui.ListItem('DeepOK'), True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
'''
def main():
    import kodi_runtime  # noqa: F401
    from engine import addonhost as A, addonrepo as R, compat as CP
    from kodi_runtime import context, xmlfix, xbmcvfs
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        z.writestr('plugin.video.quirk/addon.xml', '﻿' + XML)
        z.writestr('plugin.video.quirk/main.py', MAIN.encode('utf-8'))
        z.writestr('plugin.video.quirk/resources/settings.xml', SET)
        z.writestr('plugin.video.quirk/resources/__init__.py', '')
        z.writestr('plugin.video.quirk/resources/lib/__init__.py', '')
        z.writestr('plugin.video.quirk/resources/lib/deep.py', LIB)
    data = buf.getvalue()
    check('Prüfung: BOM ist kein Syntaxfehler', CP.scan_zip(data)[1]['verdict'] != 'no', CP.scan_zip(data)[1]['findings'][:2])
    A.install_zip(data)
    check('kodi-six gilt als geliefert', R.provided('script.module.kodi-six') and not R.missing(A.meta('plugin.video.quirk')))
    ctx = context.RequestContext()
    with context.use(ctx):
        A.run('plugin.video.quirk', '')
    check('Start mit BOM + Standardwert aus kaputter settings.xml', [i['title'] for i in ctx.items][:1] == ['Menu 12 Std.'], [i['title'] for i in ctx.items])
    r = xmlfix.fromstring(SET)
    check('xmlfix: „<“ und „&“ in Attributwert', [e.get('values') for e in r.iter('setting') if e.get('id') == 'pref_m'] == ['Keine|Kodi <Bild>|Addon <Player & Info>'])
    check('special://userdata ohne Schrägstrich', xbmcvfs.translatePath('special://userdata').endswith(os.sep) and Path(xbmcvfs.translatePath('special://userdata'), 'addon_data').is_dir())
    for q, want in (('dirID=Sub', 'SubOK'), ('dirID=resources.lib.deep.Deep', 'DeepOK')):
        ctx = context.RequestContext()
        with context.use(ctx):
            A.run('plugin.video.quirk', '?' + q)
        check('Router: ' + q, [i['title'] for i in ctx.items] == [want], [i['title'] for i in ctx.items] + [str(ctx.notes)[:120]])
    import threading
    res = {}
    def go():
        c = context.RequestContext()
        with context.use(c):
            A.run('plugin.video.quirk', '?wait=1')
        res['r'] = c.resolved
    th = threading.Thread(target=go, daemon=True); th.start(); th.join(15)
    check('Warten auf Player.isPlaying() hängt nicht', not th.is_alive() and res.get('r') and res['r'][0]['path'] == 'https://x/y.m3u8', res)
    c = context.RequestContext()
    with context.use(c):
        A.run('plugin.video.quirk', 'https://radio.example/stream.aac', play=True)
    check('Direkte Medien-Adresse im Listeneintrag wird ohne Addon abgespielt', [r['path'] for r in c.resolved] == ['https://radio.example/stream.aac'], c.resolved)
    import types, shutil
    d = Path(tmp) / 'deps'; (d / 'urllib3').mkdir(parents=True); (d / 'urllib3' / '__init__.py').write_text('')
    fake = types.ModuleType('urllib3'); sys.modules['urllib3'] = fake
    saved = A._hide_shims([str(d)])
    gone = 'urllib3' not in sys.modules
    sys.modules['urllib3'] = types.ModuleType('urllib3_real'); A._restore_shims(saved)
    check('Ersatz-urllib3 weicht dem echten aus der Bibliothek und kommt zurück', saved and gone and sys.modules['urllib3'] is fake)
    fb = ROOT / 'vendor' / '_fallback'
    check('Reserve: urllib3, certifi, idna liegen unter vendor/_fallback', all((fb / n / '__init__.py').is_file() for n in ('urllib3', 'certifi', 'idna')))
    check('nach dem Lauf: Alias-Module entfernt, __main__ unverändert', 'resources.lib.deep' not in sys.modules and not hasattr(sys.modules['__main__'], 'Sub'))
try:
    main()
except Exception:
    import traceback; traceback.print_exc(); failed += 1
print('%d ok, %d Fehler' % (passed, failed))
sys.exit(1 if failed else 0)
