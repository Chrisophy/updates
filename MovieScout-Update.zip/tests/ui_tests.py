# -*- coding: utf-8 -*-
"""Oberflächen-Tests (Playwright/Chromium) gegen die echte Engine mit Fake-Quellen.

    python tests/ui_tests.py        (benötigt: pip install playwright && playwright install chromium)
"""
import json
import os
import subprocess
import sys
import tempfile
import time
import socket
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
UP, API = 8821, 8822
BASE = 'http://127.0.0.1:%d/ui/' % API
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def wait_port(port, tries=80):
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def css(pg, var):
    return pg.evaluate("v => getComputedStyle(document.documentElement).getPropertyValue(v).trim()", var)


def open_skin_editor(pg):
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    pg.get_by_text('Aussehen / Skin-Editor').click()
    pg.wait_for_selector('.ed-tabs')


def tab(pg, name):
    pg.get_by_role('tab', name=name, exact=True).click()
    pg.wait_for_timeout(150)


def run(pg, errs):
    print('Start')
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    check('Startseite zeigt Quelle "Fake"', pg.locator('[data-sec=tiles] .tile .n').first.inner_text() == 'Fake')
    check('Abschnitte sind als Bereiche markiert (Favoriten, Entdecken, Nachrichten, Mediaplayer, Quellen)', pg.locator('#view > .hsec').count() == 6)

    print('Skin-Editor')
    open_skin_editor(pg)
    check('Editor als Seitenleiste (Seite bleibt sichtbar)', pg.evaluate("document.querySelector('.layer').classList.contains('dock')"))
    check('Standard-Skin aktiv', css(pg, '--acc') == '#12b2e7')
    pg.get_by_role('button', name='Kodi-Blau').click()
    check('Vorlage "Kodi-Blau" ändert Akzent live', css(pg, '--acc') == '#12b2e7', css(pg, '--acc'))
    check('… und Ecken-Rundung', css(pg, '--r') == '4px', css(pg, '--r'))
    tab(pg, 'Farben')
    pg.evaluate("""() => { const i = [...document.querySelectorAll('.crow')].find(r => r.innerText.includes('Akzent / Fokus')).querySelector('input');
      i.value = '#ff0000'; i.dispatchEvent(new Event('input', {bubbles: true})); }""")
    check('Farbe ändern: wirkt sofort', css(pg, '--acc') == '#ff0000', css(pg, '--acc'))
    pg.wait_for_timeout(100)
    saved = pg.evaluate("JSON.parse(localStorage.getItem('mk.skins'))")
    check('Änderung an Vorlage legt eigene Kopie an', len(saved['list']) == 1 and saved['list'][0]['colors']['acc'] == '#ff0000' and not saved['list'][0].get('builtin'), saved)
    tab(pg, 'Farben')
    pg.get_by_role('button', name='Akzent #4c8dff').click()
    check('Schnellwahl Akzentfarbe', css(pg, '--acc') == '#4c8dff' and css(pg, '--acc-ink') == '#ffffff', (css(pg, '--acc'), css(pg, '--acc-ink')))

    tab(pg, 'Schrift & Form')
    pg.select_option('select >> nth=0', 'serif')
    check('Schriftart wechseln', 'Georgia' in css(pg, '--head'), css(pg, '--head'))
    pg.evaluate("""() => { const i = [...document.querySelectorAll('.field')].find(f => f.innerText.includes('Schriftgröße')).querySelector('input');
      i.value = '130'; i.dispatchEvent(new Event('input', {bubbles: true})); }""")
    check('Schriftgröße skaliert', css(pg, '--fscale') == '1.3', css(pg, '--fscale'))
    pg.select_option('xpath=//div[contains(@class,"field")][.//label[text()="Position"]]//select', 'bottom')
    check('Kopfzeile unten', pg.evaluate("document.body.classList.contains('sk-hdrbottom') && getComputedStyle(document.querySelector('header.top')).position") == 'fixed')
    pg.select_option('xpath=//div[contains(@class,"field")][.//label[text()="Position"]]//select', 'top')

    tab(pg, 'Poster & Kacheln')
    pg.select_option('xpath=//div[contains(@class,"field")][.//label[text()="Stil"]]//select', 'fill')
    check('Kachel-Stil', pg.evaluate("document.body.dataset.tile") == 'fill')

    tab(pg, 'Bilder')
    # Hintergrundbild per URL (data-URL, rot) + Logo-Text
    png = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPjxyZWN0IHdpZHRoPSI4IiBoZWlnaHQ9IjgiIGZpbGw9IiNmMDAiLz48L3N2Zz4='
    pg.fill('input[placeholder="https://…/bild.jpg"]', png)
    pg.dispatch_event('input[placeholder="https://…/bild.jpg"]', 'change')
    pg.wait_for_timeout(200)
    check('Hintergrundbild gesetzt (Seite wird durchscheinend)', pg.evaluate("document.body.classList.contains('sk-hasbg') && getComputedStyle(document.getElementById('skinBg')).backgroundImage.startsWith('url')"))
    pg.fill('xpath=//div[contains(@class,"field")][.//label[text()="Name, Teil 1"]]//input', 'Mein')
    pg.wait_for_timeout(100)
    check('Logo-Text ändern', pg.locator('#btnHome').inner_text().startswith('Mein'), pg.locator('#btnHome').inner_text())

    print('Anordnen')
    tab(pg, 'Anordnung')
    pg.locator('.ordrow', has_text='Quellen-Kacheln').get_by_label('Quellen-Kacheln nach oben').click()
    pg.wait_for_timeout(300)
    order = pg.evaluate("[...document.querySelectorAll('#view > .hsec')].map(s => s.dataset.sec)")
    check('Reihenfolge per Pfeil: Kacheln vor Streifen', order == ['favs', 'disc', 'news', 'media', 'tiles', 'status'], order)
    pg.locator('.ordrow', has_text='Quellen-Streifen').get_by_label('Quellen-Streifen ausblenden').click()
    pg.wait_for_timeout(300)
    check('Bereich ausblenden', pg.locator('#view > .hsec').count() == 5)
    pg.locator('.ordrow', has_text='Quellen-Streifen').get_by_label('Quellen-Streifen einblenden').click()
    pg.wait_for_timeout(300)
    pg.get_by_role('switch', name='Auf der Seite ziehen & ablegen').click()
    pg.wait_for_timeout(400)
    secs = pg.locator('#view > .hsec')
    check('Anordnen-Modus: Bereiche als Leisten', pg.evaluate("document.body.classList.contains('arrange')") and secs.count() == 9, secs.count())
    a, b = pg.locator('#view > .hsec').nth(0).bounding_box(), pg.locator('#view > .hsec').nth(8).bounding_box()
    pg.mouse.move(a['x'] + 20, a['y'] + a['height'] / 2)
    pg.mouse.down()
    pg.mouse.move(a['x'] + 20, a['y'] + a['height'] / 2 + 30, steps=4)
    pg.mouse.move(b['x'] + 20, b['y'] + b['height'] / 2 + 5, steps=12)
    pg.mouse.up()
    pg.wait_for_timeout(300)
    order = pg.evaluate("[...document.querySelectorAll('#view > .hsec')].map(s => s.dataset.sec)")
    check('Ziehen & Ablegen ändert die Reihenfolge (erster Bereich ans Ende)', order == ['quick', 'hist', 'favs', 'disc', 'news', 'media', 'tiles', 'status', 'nav'], order)
    saved = pg.evaluate("JSON.parse(localStorage.getItem('mk.skins')).list[0].layout.home")
    check('… und wird im Skin gespeichert', saved == order, (saved, order))
    # Kopfzeile ziehen: Einstellungen-Symbol vor das Suchfeld
    hb, sb = pg.locator('#top [data-hid=settings]').bounding_box(), pg.locator('#top [data-hid=search]').bounding_box()
    pg.mouse.move(hb['x'] + 10, hb['y'] + 10); pg.mouse.down()
    pg.mouse.move(hb['x'] - 40, hb['y'] + 10, steps=6)
    pg.mouse.move(sb['x'] + 30, sb['y'] + 10, steps=10)
    pg.mouse.up(); pg.wait_for_timeout(300)
    hdr = pg.evaluate("[...document.querySelectorAll('#top > [data-hid]')].map(e => e.dataset.hid)")
    check('Kopfzeile: Symbol verschoben', hdr.index('settings') < hdr.index('search'), hdr)
    pg.get_by_role('switch', name='Auf der Seite ziehen & ablegen').click()
    pg.wait_for_timeout(300)
    check('Anordnen beendet', not pg.evaluate("document.body.classList.contains('arrange')"))

    print('Skins speichern / teilen')
    tab(pg, 'Skins')
    pg.locator('input[maxlength="40"]').first.fill('Testskin')
    pg.get_by_role('button', name='Aktuellen Skin als Text').click()
    txt = pg.locator('textarea.ta').input_value()
    data = json.loads(txt)
    check('Export als Text', data['movieScoutSkin'] == 1 and data['skin']['name'] == 'Testskin' and data['skin']['colors']['acc'] == '#4c8dff', data['skin']['name'])
    pg.get_by_role('button', name='Löschen', exact=True).click()
    pg.wait_for_timeout(200)
    check('Skin löschen -> Standard', css(pg, '--acc') == '#12b2e7')
    pg.locator('textarea.ta').fill(txt)
    pg.get_by_role('button', name='Text übernehmen').click()
    pg.wait_for_timeout(300)
    check('Import aus Text: Skin ist wieder aktiv', css(pg, '--acc') == '#4c8dff' and pg.evaluate("document.body.dataset.tile") == 'fill')
    pg.locator('textarea.ta').fill(json.dumps({'minikodiSkin': 1, 'skin': {'name': 'Fremd', 'css': '@import url(http://evil/x.css); .tile{outline:1px solid red}', 'colors': {'acc': 'javascript:1'}}}))
    pg.get_by_role('button', name='Text übernehmen').click()
    pg.wait_for_timeout(300)
    check('Import entschärft @import und ungültige Farben', 'evil' not in pg.evaluate("document.getElementById('skinCss').textContent") and css(pg, '--acc') == '#12b2e7', css(pg, '--acc'))
    pg.reload()
    pg.wait_for_selector('.tile')
    check('Skin bleibt nach Neuladen aktiv', pg.evaluate("JSON.parse(localStorage.getItem('mk.skins')).active") != 'minikodi')
    pg.goto(BASE + '?skin=reset')
    pg.wait_for_selector('.tile')
    check('?skin=reset stellt Standard wieder her', css(pg, '--acc') == '#12b2e7' and 'skin=reset' not in pg.url)

    print('Poster-Modi')
    pg.evaluate("localStorage.setItem('mk.skins', JSON.stringify({active:'minikodi',list:[]}))")
    pg.reload(); pg.wait_for_selector('.tile')
    pg.click('[data-sec=tiles] .tile'); pg.wait_for_selector('.row, .card')
    pg.get_by_text('Filme', exact=True).first.click()
    pg.wait_for_selector('.card')
    check('Poster-Raster bei Einträgen mit Bild', pg.locator('.grid .card').count() >= 1)

    print('Quellen & System')
    pg.goto(BASE); pg.wait_for_selector('.tile')
    pg.click('#btnSettings'); pg.get_by_role('tab', name='Quellen & Listen').click(); pg.get_by_role('button', name='Quellen & System').click()
    pg.wait_for_selector('.ordrow')
    check('Quellen-Liste zeigt mitgelieferten Scraper', pg.locator('.ordrow', has_text='Fake').count() == 1)
    pg.get_by_role('button', name='Neu aus Vorlage').click()
    pg.wait_for_selector('textarea.ta')
    check('Werkstatt öffnet mit Vorlage', 'def get_hosters' in pg.locator('textarea.ta').input_value())
    pg.get_by_role('button', name='Testen (ausführen)').click()
    pg.wait_for_selector('text=Testlauf:')
    check('Testlauf zeigt Einträge', '2 Einträge' in pg.locator('.panel').inner_text(), pg.locator('.panel').inner_text()[-300:])
    pg.locator('textarea.ta').fill('def load(:\n')
    pg.get_by_role('button', name='Prüfen', exact=True).click()
    pg.wait_for_selector('.err')
    check('Syntaxfehler mit Zeilennummer', 'Zeile 1' in pg.locator('.err').first.inner_text(), pg.locator('.err').first.inner_text())
    pg.get_by_role('button', name='Vorlage laden').click()
    pg.get_by_role('button', name='Speichern', exact=True).click()
    pg.wait_for_selector('text=gespeichert')
    tab(pg, 'Quellen')
    pg.wait_for_selector('.ordrow >> text=Mein Scraper')
    check('Neuer Scraper in der Liste', pg.locator('.ordrow', has_text='Mein Scraper').count() == 1)
    pg.locator('.ordrow', has_text='Mein Scraper').get_by_role('switch').click()
    pg.wait_for_selector('.ordrow.off')
    check('Deaktivieren', pg.locator('.ordrow.off', has_text='Mein Scraper').count() == 1)
    pg.go_back(); pg.wait_for_timeout(500)
    pg.wait_for_selector('.tile')
    names = pg.locator('[data-sec=tiles] .tile .n').all_inner_texts()
    check('Deaktivierter Scraper fehlt auf der Startseite', names == ['Fake'], names)
    pg.click('#btnSettings'); pg.get_by_role('tab', name='Quellen & Listen').click(); pg.get_by_role('button', name='Quellen & System').click(); pg.wait_for_selector('.ordrow')
    pg.locator('.ordrow', has_text='Mein Scraper').get_by_role('switch').click()
    pg.wait_for_selector('.ordrow:not(.off) >> text=Mein Scraper')
    pg.locator('.ordrow', has_text='Mein Scraper').get_by_role('button', name='Löschen').click()
    pg.wait_for_selector('text=Papierkorb verschoben')
    tab(pg, 'Papierkorb')
    pg.wait_for_selector('.ordrow >> text=meinscraper.py')
    pg.locator('.ordrow', has_text='meinscraper.py').first.get_by_role('button', name='Zurückholen').click()
    tab(pg, 'Quellen')
    pg.wait_for_selector('.ordrow >> text=Mein Scraper')
    check('Papierkorb: Scraper zurückgeholt', pg.locator('.ordrow', has_text='Mein Scraper').count() == 1)

    print('Erweiterung + Sicherung')
    tab(pg, 'Erweiterungen')
    pg.get_by_role('button', name='Neu aus Vorlage').click()
    pg.wait_for_selector('textarea.ta')
    pg.get_by_role('button', name='Speichern', exact=True).click()
    pg.wait_for_selector('text=gespeichert')
    tab(pg, 'Erweiterungen')
    pg.wait_for_selector('.ordrow >> text=Beispiel-Erweiterung')
    check('Erweiterung mit Hooks und Link-Knopf', pg.locator('.ordrow', has_text='process_hosters').get_by_role('button', name='Hallo-Seite öffnen').count() == 1)
    tab(pg, 'Sicherung')
    with pg.expect_download() as dl:
        pg.get_by_role('button', name='Sicherung speichern').click()
    path = dl.value.path()
    import zipfile
    z = zipfile.ZipFile(path)
    names = z.namelist()
    ui = json.loads(z.read('ui.json'))
    check('Sicherung enthält Scraper, Erweiterung und Oberflächen-Daten', 'providers/meinscraper.py' in names and 'extensions/meineerweiterung.py' in names and 'skins' in ui, names)
    # alles löschen, dann einspielen
    pg.evaluate("localStorage.setItem('mk.favs', '[]')")
    tab(pg, 'Sicherung')
    pg.locator('input[type=file]').count()
    with pg.expect_file_chooser() as fc:
        pg.get_by_role('button', name='Sicherung wählen …').click()
    fc.value.set_files(path)
    pg.wait_for_selector('pre.log:not([hidden])')
    check('Einspielen meldet Ergebnis', 'eingespielt' in pg.locator('pre.log:not([hidden])').inner_text(), pg.locator('pre.log:not([hidden])').inner_text())
    print('DRM / Widevine')
    pg.goto(BASE); pg.wait_for_selector('.tile')
    wv = pg.evaluate("widevineInfo()")
    check('Widevine-Erkennung läuft (Test-Chromium ohne Widevine -> NONE)', wv.get('level') == 'NONE' and wv.get('secure') is True, wv)
    pg.click('[data-sec=tiles] .tile'); pg.wait_for_selector('.row, .card')
    pg.get_by_text('Filme', exact=True).first.click()
    pg.wait_for_selector('.card')
    with pg.expect_request(lambda r: r.url.endswith('/api/resolve')) as rq:
        pg.locator('.grid .card').first.click()
    body = rq.value.post_data_json or {}
    check('Auflösen meldet Browser-Fähigkeiten an die Engine', body.get('client') == {'widevine': 'NONE', 'android': False}, body.get('client'))
    pg.goto(BASE); pg.wait_for_selector('.tile')
    pg.click('#btnSettings')
    pg.get_by_role('tab', name='Konten & Inhalte').click()
    pg.wait_for_selector('text=Rakuten TV: Lizenzanfrage')
    check('Einstellung „Automatisch“ ist Standard und zeigt die Widevine-Stufe',
          pg.locator('xpath=//div[contains(@class,"field")][.//label[text()="Rakuten TV: Lizenzanfrage"]]//select').input_value() == 'auto'
          and 'nicht vorhanden' in pg.locator('xpath=//div[contains(@class,"field")][.//label[text()="Rakuten TV: Lizenzanfrage"]]').inner_text())
    pg.get_by_role('tab', name='System & Update').click()
    pg.get_by_role('button', name='Diagnose').click()
    pg.wait_for_selector('#wvLine')
    pg.wait_for_timeout(300)
    check('Diagnose zeigt Widevine-Stufe', 'nicht vorhanden' in pg.locator('#wvLine').inner_text(), pg.locator('#wvLine').inner_text())

    # Hardware-Widevine simulieren: nur HW_SECURE_ALL wird angenommen -> L1
    pg2 = pg.context.new_page()
    pg2.add_init_script("""navigator.requestMediaKeySystemAccess = (ks, cfg) =>
        (cfg[0].videoCapabilities[0].robustness === 'HW_SECURE_ALL' ? Promise.resolve({}) : Promise.reject(new Error('no')));""")
    pg2.goto(BASE); pg2.wait_for_selector('.tile')
    wv2 = pg2.evaluate("widevineInfo()")
    check('Hardware-Widevine wird erkannt und angefragt (L1, HW_SECURE_ALL)', wv2.get('level') == 'L1' and wv2.get('video') == 'HW_SECURE_ALL', wv2)
    pg2.close()

    print('MovieScout: Name, Hinweis, App')
    pg.goto(BASE); pg.wait_for_selector('.tile')
    check('Titel und Logo heißen MovieScout', pg.title() == 'MovieScout' and pg.locator('#btnHome').inner_text().replace('\n', '') == 'MovieScout',
          (pg.title(), pg.locator('#btnHome').inner_text()))
    legal = pg.locator('#view .legal').inner_text()
    check('Startseite: Hinweis unten (by IT(s) Possible, hostet nichts, keine Haftung)',
          "by IT('s) Possible" in legal and 'hostet keine' in legal and 'keine Haftung' in legal, legal)
    pg.click('#btnSettings'); pg.wait_for_selector('.panel .legal')
    check('Einstellungen: Hinweis vorhanden', 'bündelt nur Links' in pg.locator('.panel .legal').inner_text())
    pg.go_back()
    ctx2 = pg.context.browser.new_context(user_agent=pg.evaluate('navigator.userAgent') + ' MovieScoutApp/1.0')
    app = ctx2.new_page()
    app.goto(BASE); app.wait_for_selector('text=Mit der Engine verbinden')
    txt = app.locator('main').inner_text()
    check('App ohne Engine-Adresse: Verbindungs-Bildschirm mit App-Hinweis und Haftungshinweis',
          'python main.py --lan' in txt and 'hostet keine' in txt and 'Browser erlauben von hier' not in txt, txt[:300])
    ctx2.close()

    print('Favoriten mit Themen')
    pg.goto(BASE); pg.wait_for_selector('.tile')
    pg.evaluate("localStorage.removeItem('mk.topics'); localStorage.setItem('mk.favs', '[]')")
    pg.goto(BASE); pg.wait_for_selector('.tile')
    check('Startseite: Bereich Favoriten mit „Thema anlegen“ (noch ohne Themen)', pg.locator('.hsec[data-sec=favs] >> text=+ Thema anlegen').count() == 1)
    pg.click('[data-sec=tiles] .tile'); pg.wait_for_selector('.row, .card')
    pg.get_by_text('Filme', exact=True).first.click()
    pg.wait_for_selector('.card .star')
    check('Poster haben einen Stern', pg.locator('.card .star').count() >= 2)
    pg.locator('.card .star').first.click()
    pg.wait_for_selector('.favpick')
    check('Auswahl öffnet ohne Tastatur-Fokus im Textfeld', pg.evaluate("document.activeElement.tagName !== 'INPUT'"))
    pg.get_by_role('button', name='+ Weihnachten').click()
    pg.wait_for_selector('.favpick [role=checkbox]')
    pg.get_by_role('button', name='Fertig').click()
    pg.wait_for_timeout(200)
    topics = pg.evaluate("JSON.parse(localStorage.getItem('mk.topics'))")
    check('Neues Thema angelegt, Titel darin', len(topics) == 1 and topics[0]['name'] == 'Weihnachten' and len(topics[0]['items']) == 1, topics)
    check('Stern ist gefüllt', pg.locator('.card .star.on').count() == 1)
    pg.locator('.card .star').nth(1).click()
    pg.wait_for_selector('.favpick')
    pg.locator('.favpick input').fill('Meine Auswahl')
    pg.locator('.favpick input').press('Enter')
    pg.wait_for_timeout(150)
    pg.get_by_role('checkbox', name='Weihnachten').click()
    pg.get_by_role('button', name='Fertig').click()
    pg.wait_for_timeout(200)
    topics = pg.evaluate("JSON.parse(localStorage.getItem('mk.topics'))")
    check('Eigenes Thema per Eingabe, Titel in zwei Themen', [t['name'] for t in topics] == ['Weihnachten', 'Meine Auswahl'] and len(topics[0]['items']) == 2 and len(topics[1]['items']) == 1, topics)
    pg.locator('.card').first.focus()
    pg.keyboard.press('f')
    pg.wait_for_selector('.favpick')
    check('Taste F öffnet die Auswahl (Fernbedienung)', True)
    pg.get_by_role('button', name='Fertig').click(); pg.wait_for_timeout(150)
    pg.goto(BASE); pg.wait_for_selector('.tile')
    check('Startseite zeigt beide Themen mit Titeln', pg.locator('.topic').count() == 2 and pg.locator('.topic').first.locator('.card').count() == 2, pg.locator('.topic').count())
    pg.locator('.topic').first.locator('.card').first.focus()
    pg.wait_for_timeout(250)
    r = pg.evaluate("() => { const hs = document.querySelector('.hscroll'), c = hs.querySelector('.card'); const a = c.getBoundingClientRect(), b = hs.getBoundingClientRect(); return [a.left - b.left, a.top - b.top]; }")
    check('Fokus-Rahmen wird links/oben nicht abgeschnitten (mind. 9 px Platz)', r[0] >= 9 and r[1] >= 9, r)
    pg.locator('.tnbtn').first.click()
    pg.wait_for_selector('.panel >> text=Umbenennen')
    pg.get_by_role('button', name='Umbenennen').click()
    pg.locator('.panel input').fill('Advent')
    pg.locator('.panel input').press('Enter')
    pg.wait_for_selector('.panel h2:has-text("Advent")')
    pg.get_by_role('button', name='Entfernen').first.click()
    pg.get_by_role('button', name='Fertig').click(); pg.wait_for_timeout(300)
    topics = pg.evaluate("JSON.parse(localStorage.getItem('mk.topics'))")
    check('Thema umbenannt, Titel entfernt', topics[0]['name'] == 'Advent' and len(topics[0]['items']) == 1, topics)
    pg.click('#btnSettings'); pg.wait_for_selector('.panel')
    pg.wait_for_timeout(250)
    check('Einstellungen: kein Eingabefeld automatisch aktiv (Tastatur bleibt zu)', pg.evaluate("!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)"))
    pg.get_by_role('button', name='Favoriten & Themen').click()
    pg.wait_for_selector('.panel >> text=Deine Themen')
    pg.locator('.panel input').fill('Nur Test'); pg.get_by_role('button', name='Anlegen', exact=True).click()
    pg.wait_for_selector('.ordrow >> text=Nur Test')
    pg.locator('.ordrow', has_text='Nur Test').first.locator('button.t').click()
    pg.get_by_role('button', name='Thema löschen').click()
    pg.get_by_role('button', name='Wirklich löschen').click()
    pg.wait_for_timeout(300)
    check('Thema löschen', 'Nur Test' not in pg.locator('.panel').inner_text())
    pg.get_by_role('button', name='Fertig').click(); pg.wait_for_timeout(200)
    old = [{'provider_id': 'fake', 'url': 'x', 'title': 'Alt-Titel', 'kind': 'play'}]
    pg.evaluate("o => { localStorage.removeItem('mk.topics'); localStorage.setItem('mk.favs', JSON.stringify(o)); }", old)
    pg.goto(BASE); pg.wait_for_selector('.topic')
    check('Alte „Gemerkt“-Liste wird als Thema übernommen', pg.locator('.tnbtn', has_text='Gemerkt').count() == 1)

    print('Ränder & Fokus-Rahmen')
    open_skin_editor(pg)
    pg.wait_for_timeout(200)
    r = pg.evaluate("() => { const t = document.querySelector('.ed-tabs'), c = t.querySelector('.chip[aria-pressed=true]'); const a = c.getBoundingClientRect(), b = t.getBoundingClientRect(); return [a.left - b.left, a.top - b.top]; }")
    check('Skin-Editor: Reiter-Rahmen oben/links nicht abgeschnitten', r[0] >= 8 and r[1] >= 8, r)
    tab(pg, 'Schrift & Form')
    def slider(label, val):
        pg.evaluate("""([l, v]) => { const i = [...document.querySelectorAll('.field')].find(f => f.querySelector('label') && f.querySelector('label').innerText === l).querySelector('input');
          i.value = v; i.dispatchEvent(new Event('input', {bubbles: true})); }""", [label, str(val)])
    slider('Rand links und rechts', 40)
    check('Rand links/rechts einstellbar', css(pg, '--pad') == '40px', css(pg, '--pad'))
    slider('Rand oben', 24); slider('Rand unten', 16)
    check('Rand oben/unten einstellbar', css(pg, '--xt') == '24px' and css(pg, '--xb') == '16px', (css(pg, '--xt'), css(pg, '--xb')))
    check('… und wirkt auf die Kopfzeile', pg.evaluate("parseFloat(getComputedStyle(document.querySelector('header.top')).paddingTop)") >= 34)
    slider('Rand links und rechts', 0)
    check('Rand 0 = automatisch', css(pg, '--pad') not in ('', '0px', '40px'), css(pg, '--pad'))
    tab(pg, 'Poster & Kacheln')
    pg.get_by_role('switch', name='Stern ★ zum Merken auf dem Poster').click()
    check('Stern auf Postern abschaltbar', pg.evaluate("document.body.classList.contains('sk-nostar')"))
    pg.get_by_role('switch', name='Stern ★ zum Merken auf dem Poster').click()

    print('Filminfos')
    pg.goto(BASE); pg.wait_for_selector('.tile')
    pg.evaluate("localStorage.removeItem('mk.topics')")
    pg.click('#btnSettings'); pg.wait_for_selector('.panel')
    pg.get_by_role('button', name='Favoriten & Themen').click()
    pg.wait_for_selector('.panel >> text=Neues Thema')
    check('Themen-Fenster: kein „null“-Text', 'null' not in pg.locator('.panel').inner_text(), pg.locator('.panel').inner_text())
    pg.get_by_role('button', name='Fertig').click(); pg.wait_for_timeout(150)
    pg.click('[data-sec=tiles] .tile'); pg.wait_for_selector('.row, .card')
    pg.get_by_text('Filme', exact=True).first.click()
    pg.wait_for_selector('.card .infob')
    pg.locator('.card .star').first.click(); pg.wait_for_selector('.favpick')
    check('Favoriten-Auswahl: kein „null“-Text', 'null' not in pg.locator('.favpick').inner_text())
    pg.get_by_role('button', name='Fertig').click(); pg.wait_for_timeout(150)
    pg.evaluate("fetch('/api/settings', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({settings: {'api.tmdb': ''}})})")
    pg.wait_for_timeout(200)
    pg.locator('.card .infob').first.click(); pg.wait_for_selector('.infopanel h2')
    pg.wait_for_selector('.infopanel .infonote')
    t = pg.locator('.infopanel').inner_text()
    check('Info ohne Schlüssel: Titel, Jahr, Seitentext und TMDB-Hinweis', 'Film Eins' in t and '2020' in t and 'Test fett' in t and 'TMDB' in t, t)
    pg.get_by_role('button', name='Schließen').click(); pg.wait_for_timeout(150)
    pg.evaluate("fetch('/api/settings', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({settings: {'api.tmdb': 'testkey'}})})")
    pg.wait_for_timeout(200)
    pg.locator('.card .infob').first.click(); pg.wait_for_selector('.infopanel .cast')
    t = pg.locator('.infopanel').inner_text()
    check('Info mit Schlüssel: Länge, FSK, Jahr, Beschreibung, Cast',
          '1 Std. 52 Min.' in t and 'FSK 12' in t and '2020' in t and 'Ein Testfilm über Tests.' in t and 'Anna Beispiel' in t and 'Hauptrolle' in t, t)
    check('… ohne „null“/„undefined“', 'null' not in t and 'undefined' not in t)
    pg.get_by_role('button', name='Schließen').click(); pg.wait_for_timeout(150)
    pg.locator('.card').first.focus(); pg.keyboard.press('i')
    pg.wait_for_selector('.infopanel')
    check('Taste I öffnet die Info (Fernbedienung)', True)
    pg.get_by_role('button', name='Schließen').click(); pg.wait_for_timeout(150)
    pg.evaluate("fetch('/api/settings', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({settings: {'api.tmdb': ''}})})")
    open_skin_editor(pg); tab(pg, 'Poster & Kacheln')
    pg.get_by_role('switch', name='Info-Knopf ⓘ auf dem Poster').click()
    check('Info-Knopf auf Postern abschaltbar', pg.evaluate("document.body.classList.contains('sk-noinfo')"))
    pg.get_by_role('switch', name='Info-Knopf ⓘ auf dem Poster').click()

    print('App: DRM im nativen Player (Geräte-Widevine)')
    ctx3 = pg.context.browser.new_context(user_agent=pg.evaluate('navigator.userAgent') + ' MovieScoutApp/1.0')
    ctx3.add_init_script("""
      localStorage.setItem('mk.api', JSON.stringify('http://127.0.0.1:%d'));
      localStorage.setItem('mk.autoplay', 'false');
      window.MovieScoutApp = { nativeAvailable: () => true, nativeWidevineLevel: () => 'L1', keepScreenOn: () => {},
        playNative: (j) => { window.__native = JSON.parse(j); return true; } };""" % API)
    ap = ctx3.new_page()
    aerrs = []
    ap.on('pageerror', lambda e: aerrs.append(str(e)))
    ap.goto(BASE); ap.wait_for_selector('.tile')
    wv3 = ap.evaluate('widevineInfo()')
    check('App meldet Widevine des Geräts (L1, App-Player)', wv3.get('level') == 'L1' and wv3.get('native') is True, wv3)
    ap.locator('.tile', has_text='Fake').first.click(); ap.wait_for_selector('.row, .card')
    ap.get_by_text('Filme', exact=True).first.click(); ap.wait_for_timeout(500)
    if ap.get_by_role('button', name='Öffnen').count():          # App/TV: Klick öffnet erst das Aktionsmenü
        ap.get_by_role('button', name='Öffnen').click()
    ap.wait_for_selector('.grid .card')
    ap.locator('.grid .card').first.click(); ap.wait_for_timeout(400)
    with ap.expect_request(lambda r: r.url.endswith('/api/resolve')) as rq3:
        if ap.get_by_role('button', name='Abspielen').count():
            ap.get_by_role('button', name='Abspielen').first.click()
        else:
            ap.locator('.grid .card').first.click()
    check('App: Engine bekommt L1 gemeldet (-> Android-TV-Weg bei Rakuten)', (rq3.value.post_data_json or {}).get('client', {}).get('widevine') == 'L1')
    ap.get_by_role('button', name='DASH+DRM').first.click()
    ap.wait_for_function('window.__native')
    nat = ap.evaluate('window.__native')
    check('DRM-Quelle geht an den App-Player (Stream und Lizenz über den Engine-Proxy)',
          nat['format'] == 'dash' and '/api/proxy' in nat['url'] and '/api/proxy' in nat['license'] and 'DASH+DRM' in nat['title'], nat)
    check('… und nicht an den Browser-Player', ap.locator('#player video').count() == 0)
    ap.evaluate("msNativeDone({ok: false, error: 'ERROR_CODE_DRM_LICENSE_ACQUISITION_FAILED – HTTP 403 (Forbidden)'})")
    ap.wait_for_selector('#player .stat >> text=App-Player:')
    check('Fehler aus dem App-Player erscheint mit Ursache', 'HTTP 403' in ap.locator('#player .stat').inner_text(), ap.locator('#player .stat').inner_text()[:200])
    check('App-Seite ohne JavaScript-Fehler', not aerrs, aerrs[:3])
    ctx3.close()

    print('Konsole')
    check('Keine JavaScript-Fehler', not errs, errs[:5])


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'),
               MINIKODI_DATA=tmp, FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1',
               MOVIESCOUT_TMDB_BASE='http://127.0.0.1:%d/tmdb' % UP, MOVIESCOUT_TMDB_IMG='http://127.0.0.1:%d/img' % UP)
    env.pop('MINIKODI_TOKEN', None); env.pop('MOVIESCOUT_TOKEN', None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait_port(UP) and wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 1280, 'height': 800}, accept_downloads=True)
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
            try:
                run(pg, errs)
            except Exception as e:      # noqa: BLE001
                import traceback
                traceback.print_exc()
                global failed
                failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png'))
                print('Screenshot:', Path(tmp) / 'fail.png')
            b.close()
    finally:
        srv.terminate()
        up.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
