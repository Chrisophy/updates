# -*- coding: utf-8 -*-
"""Verständliche Hinweise bei Addons, die nichts anzeigen: eigene Fehlermeldung des Addons bei leerer Liste, Bytecode-Addons (.pyc) anderer Python-Version.

    python tests/addon_diag_test.py
"""
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
tmp = tempfile.mkdtemp(prefix='ms-dg-')
os.environ['MINIKODI_DATA'] = os.environ['MOVIESCOUT_DATA'] = tmp
sys.path.insert(0, str(ROOT))

from engine import addonhost, compat          # noqa: E402
from kodi_runtime import context              # noqa: E402

passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def axml(aid):
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<addon id="%s" name="Diag %s" version="1.0.0" provider-name="T">\n'
            '<requires><import addon="xbmc.python" version="3.0.0"/></requires>\n'
            '<extension point="xbmc.python.pluginsource" library="addon.py"><provides>video</provides></extension>\n'
            '<extension point="xbmc.addon.metadata"><summary lang="de">T</summary></extension></addon>') % (aid, aid)


def pack(aid, files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        z.writestr(aid + '/addon.xml', axml(aid))
        for k, v in files.items():
            z.writestr(aid + '/' + k, v)
    return b.getvalue()


def run(aid, url=''):
    ctx = context.RequestContext()
    try:
        with context.use(ctx):
            addonhost.run(aid, url)
    except Exception as e:                       # noqa: BLE001
        return ctx, (str(e) if isinstance(e, addonhost.AddonError) else addonhost.friendly_error(aid, e))
    return ctx, ''


# 1) Addon fängt den Netzwerkfehler ab, zeigt nichts, schreibt aber ins Log
EMPTY = '''
import sys, xbmc, xbmcplugin
xbmc.log('[Demo] _request ERROR url=https://beispiel.invalid/ err=<urlopen error [Errno -2] Name or service not known>', xbmc.LOGINFO)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
'''
z = pack('plugin.video.diagempty', {'addon.py': EMPTY})
addonhost.install_zip(z)
ctx, err = run('plugin.video.diagempty')
check('Leere Liste: Hinweis mit der Meldung des Addons', any('Meldung des Addons' in n['message'] and 'Name or service not known' in n['message'] for n in ctx.notes), ctx.notes)
check('Leere Liste: Meldung als Fehler markiert', any(n['level'] == 'error' for n in ctx.notes))

OK = '''
import sys, xbmc, xbmcgui, xbmcplugin
xbmc.log('[Demo] alles gut, 1 Eintrag', xbmc.LOGINFO)
xbmcplugin.addDirectoryItem(int(sys.argv[1]), 'plugin://x/?a=1', xbmcgui.ListItem('Eintrag'), True)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
'''
addonhost.install_zip(pack('plugin.video.diagok', {'addon.py': OK}))
ctx, err = run('plugin.video.diagok')
check('Volle Liste: kein Hinweis', len(ctx.items) == 1 and not ctx.notes, ctx.notes)

QUIET = '''
import sys, xbmc, xbmcplugin
xbmc.log('[Demo] nichts zu tun', xbmc.LOGINFO)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
'''
addonhost.install_zip(pack('plugin.video.diagquiet', {'addon.py': QUIET}))
ctx, err = run('plugin.video.diagquiet')
check('Leere Liste ohne Fehlermeldung: kein Hinweis', not ctx.notes, ctx.notes)

# 2) .pyc ohne Quelltext, andere Python-Version (3.8 = Kennung 3413)
OLD_MAGIC = (3413).to_bytes(2, 'little') + b'\r\n'
MAIN = 'import sys\nfrom lib.api import run\nrun(sys.argv)\n'
zp = pack('plugin.video.diagpyc', {'addon.py': MAIN, 'lib/__init__.pyc': OLD_MAGIC + b'\0' * 12, 'lib/api.pyc': OLD_MAGIC + b'\0' * 12})
info, rep = compat.scan_zip(zp)
f = [x for x in rep['findings'] if x['code'] == 'pyc-version']
check('Prüfbericht: Warnung „vorkompilierter Code, andere Python-Version“', f and f[0]['level'] == 'warn' and '3.8' in f[0]['text'], rep['findings'])
check('Prüfbericht: Urteil „eingeschränkt“', rep['verdict'] == 'limited', rep['verdict'])
addonhost.install_zip(zp)
ctx, err = run('plugin.video.diagpyc')
check('Start: Meldung nennt Bytecode und beide Python-Versionen', 'vorkompiliert' in err and '3.8' in err and '%d.%d' % sys.version_info[:2] in err, err)

# 3) gleiche Version: nur Hinweis
SAME = importlib_magic = __import__('importlib.util').util.MAGIC_NUMBER
zs = pack('plugin.video.diagsame', {'addon.py': MAIN, 'lib/__init__.pyc': SAME + b'\0' * 12, 'lib/api.pyc': SAME + b'\0' * 12})
info, rep = compat.scan_zip(zs)
check('Gleiche Python-Version: nur Info „pyc-only“', [x['level'] for x in rep['findings'] if x['code'] == 'pyc-only'] == ['info'] and rep['verdict'] == 'ok', rep['findings'])

# 3b) __pycache__ zählt nicht
zc = pack('plugin.video.diagcache', {'addon.py': MAIN, 'lib/__init__.py': '', 'lib/api.py': 'def run(a): pass\n',
                                      'lib/__pycache__/api.cpython-311.pyc': SAME + b'\0' * 12})
info, rep = compat.scan_zip(zc)
check('__pycache__: kein pyc-Hinweis', not [x for x in rep['findings'] if x['code'].startswith('pyc')], rep['findings'])

# 3c) Aufräumen „Übersetzte Python-Dateien“ lässt Addons nur mit .pyc heil
from engine import cleanup                    # noqa: E402
addonhost.install_zip(zs)
adir = addonhost.addon_path('plugin.video.diagsame')
(adir / '__pycache__').mkdir(exist_ok=True)
(adir / '__pycache__' / 'x.cpython-313.pyc').write_bytes(b'0000')
(adir / 'lib' / 'extra.py').write_text('x = 1\n')
(adir / 'lib' / 'extra.pyc').write_bytes(SAME + b'0' * 12)
tg = [f[0].replace('\\', '/') for f in cleanup._targets('pyc')]
check('Aufräumen: __pycache__ und .pyc mit Quelltext werden angeboten', any(t.endswith('__pycache__/x.cpython-313.pyc') for t in tg) and any(t.endswith('lib/extra.pyc') for t in tg), tg)
check('Aufräumen: .pyc ohne Quelltext (lib/api.pyc) bleibt', not any(t.endswith('lib/api.pyc') or t.endswith('lib/__init__.pyc') for t in tg), tg)

# 4) Fehlendes Modul: Meldung nennt den Originaltext
addonhost.install_zip(pack('plugin.video.diagmiss', {'addon.py': 'import gibtesnicht_xyz\n'}))
ctx, err = run('plugin.video.diagmiss')
check('Fehlendes Modul: Originalmeldung und Python-Version dabei', 'gibtesnicht_xyz' in err and 'Python %d.%d' % sys.version_info[:2] in err, err)

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
