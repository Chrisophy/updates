# -*- coding: utf-8 -*-
"""Oberfläche der script.*-Unterstützung: Verwaltung zeigt Programme/Bibliotheken, Starten und Entfernen funktionieren.

    python tests/script_ui_test.py
"""
import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 8923
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def xml(aid, point, req=''):
    return ('<addon id="%s" name="%s" version="1.0.0"><requires>%s</requires>%s</addon>' % (aid, aid, req, point))


def zipped(aid, files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for n, c in files.items():
            z.writestr(aid + '/' + n, c)
    return b.getvalue()


def main():
    tmp = tempfile.mkdtemp(prefix='ms_scrui_')
    out = Path(tmp) / 'ran.txt'
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, SCR_OUT=str(out), MOVIESCOUT_KODI_REPO='http://127.0.0.1:9/')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close(); break
            except OSError:
                time.sleep(0.5)
        time.sleep(1.5)

        def post(z):
            return json.loads(urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/api/admin/addon/install' % PORT, data=z, method='POST',
                                                                              headers={'Content-Type': 'application/zip'})).read())
        post(zipped('script.module.ui', {'addon.xml': xml('script.module.ui', '<extension point="xbmc.python.module" library="lib"/>'), 'lib/uimod.py': 'X = 7\n'}))
        post(zipped('script.uiprog', {'addon.xml': xml('script.uiprog', '<extension point="xbmc.python.script" library="default.py"/>',
                                                       '<import addon="script.module.ui"/><import addon="script.module.fehlt"/>'),
                                     'default.py': 'import os, uimod, xbmcgui\nopen(os.environ["SCR_OUT"], "a").write("lauf %d\\n" % uimod.X)\nxbmcgui.Dialog().notification("Prog", "fertig")\n'}))
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 420, 'height': 900})
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/' % PORT); pg.wait_for_timeout(1500)
            pg.evaluate("openManager('sources')")
            pg.wait_for_selector('text=Kodi-Programme, Dienste & Bibliotheken (2)', timeout=10000)
            check('Abschnitt „Kodi-Programme, Dienste & Bibliotheken“ mit 2 Einträgen', True)
            txt = pg.inner_text('body')
            check('Typen und fehlende Bibliothek stehen da', 'Programm' in txt and 'Bibliothek' in txt and 'fehlt: script.module.fehlt' in txt, txt[-600:])
            check('Hinweis: Skin-Fenster werden vereinfacht gezeigt', 'WindowXML' in txt and 'vereinfacht' in txt)
            pg.locator('#layers').get_by_role('button', name='Starten', exact=True).first.click()
            ok = False
            for _ in range(40):
                if out.exists() and 'lauf 7' in out.read_text():
                    ok = True; break
                time.sleep(0.25)
            check('„Starten“ führt das Programm mit seiner Bibliothek aus', ok)
            pg.wait_for_selector('text=fertig', timeout=8000)
            check('Meldung des Programms erscheint', True)
            pg.locator('#layers').get_by_role('button', name='Entfernen', exact=True).first.click()
            pg.locator('#layers').get_by_role('button', name='Ja', exact=True).last.click(timeout=5000)
            pg.wait_for_selector('text=Kodi-Programme, Dienste & Bibliotheken (1)', timeout=8000)
            check('Entfernen aktualisiert die Liste', True)
            pg.evaluate("openSupportReport()")
            pg.wait_for_function("document.querySelector('textarea[aria-label=\"Support-Bericht\"]') && document.querySelector('textarea[aria-label=\"Support-Bericht\"]').value.includes('Kodi-Addons')", timeout=10000)
            rep = pg.input_value('textarea[aria-label="Support-Bericht"]')
            check('Support-Bericht: Version, Quellen und Kodi-Addons mit fehlender Bibliothek', ('MovieScout ' + (ROOT / 'VERSION').read_text().strip()) in rep and 'Quellen (' in rep and 'script.uiprog' in rep and 'FEHLT: script.module.ui, script.module.fehlt' in rep, rep[:500])
            check('Keine Skriptfehler', not errs, errs)
            b.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
