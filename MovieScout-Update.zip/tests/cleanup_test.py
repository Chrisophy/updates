# -*- coding: utf-8 -*-
"""Speicher-Aufräumer: räumt nur Zwischenspeicher auf, nie Einstellungen/Downloads/Addons: python tests/cleanup_test.py"""
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
DATA = Path(tempfile.mkdtemp())
os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = str(DATA)
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('OK  ', name)
    else:
        failed += 1; print('FAIL', name, extra)


OLD = time.time() - 40 * 86400


def mk(rel, size=1000, age=None):
    p = DATA / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b'x' * size)
    t = OLD if age is None else (time.time() - age)
    os.utime(str(p), (t, t))
    return p


# Zwischenspeicher (aufräumbar)
mk('imgcache/ab/abcdef', 5000)
mk('temp/foo.tmp', 3000)
mk('thumbnails/t.jpg', 2000)
mk('logpath/kodi.log', 4000)
mk('plugin.video.xstream/htmlcache/page1', 7000)
mk('plugin.video.xstream/htmlcache/sub/deep/page2', 700)
mk('plugin.video.vodkool/vavoo_cache/c.json', 600)
mk('plugin.video.xship/channels_cache.json', 500)
mk('script.module.resolveurl/cache/host.json', 400)
mk('user/trash/old_scraper.py', 800)
mk('addons/plugin.video.xstream/resources/__pycache__/m.cpython-313.pyc', 900)
# Geschützt
mk('plugin.video.xstream/settings.json', 300)
mk('plugin.video.xstream/xstream.db', 6000)
mk('plugin.video.xstream/cache_notes_user.txt', 10, age=10)       # frisch: darf nicht gelöscht werden
mk('plugin.video.moviescout/settings.json', 200)
mk('downloads/film.mp4', 50000)
mk('downloads/library.json', 100)
mk('addons/plugin.video.xstream/default.py', 1200)
mk('database/MyVideos116.db', 800)
mk('user/providers/mein.py', 700)
mk('keymaps/k.xml', 100)
mk('health.json', 100)
mk('temp/frisch.tmp', 50, age=5)                                 # in Benutzung: bleibt

from engine import cleanup as C            # noqa: E402
from engine import cache as CA             # noqa: E402

print('Überblick')
sc = C.scan()
byid = {c['id']: c for c in sc['categories']}
check('Poster-Speicher gefunden', byid['img']['bytes'] == 5000, byid['img'])
check('Temporäres gefunden (temp + thumbnails)', byid['temp']['bytes'] == 3000 + 2000 + 50, byid['temp'])
check('Protokolle gefunden', byid['logs']['bytes'] == 4000, byid['logs'])
check('Addon-Zwischenspeicher: htmlcache, vavoo_cache, *_cache.json, resolveurl cache', byid['addon']['bytes'] == 7000 + 700 + 600 + 500 + 400 + 10, byid['addon'])
check('Papierkorb gefunden', byid['trash']['bytes'] == 800, byid['trash'])
check('pyc gefunden, aber nicht im Standard', byid['pyc']['bytes'] == 900 and not byid['pyc']['default'], byid['pyc'])
check('settings.json zählt nicht als Zwischenspeicher', all('settings' not in f[0] for f in C._targets('addon')))
check('Datenträger-Angabe vorhanden', sc['disk']['total'] > 0)
check('Geschütztes wird mit Größe gelistet', any(p['bytes'] >= 50000 for p in sc['protected']), sc['protected'])

print('Automatisch: nur Altes (Alter je Gruppe)')
mk('temp/jung.tmp', 111, age=3600)             # 1 h alt: unter 1 Tag -> bleibt
mk('logpath/neu.log', 222, age=2 * 86400)      # 2 Tage: unter 7 -> bleibt
mk('plugin.video.xstream/htmlcache/mittel', 333, age=5 * 86400)   # unter 14 Tage -> bleibt
r = C.clean(['temp', 'logs', 'addon', 'trash'], full=False)
check('altes temp weg', not (DATA / 'temp/foo.tmp').exists() and not (DATA / 'thumbnails/t.jpg').exists())
check('junges temp bleibt', (DATA / 'temp/jung.tmp').exists())
check('junge Logs bleiben, alte weg', (DATA / 'logpath/neu.log').exists() and not (DATA / 'logpath/kodi.log').exists())
check('mittleres Addon-Cache bleibt, altes weg', (DATA / 'plugin.video.xstream/htmlcache/mittel').exists() and not (DATA / 'plugin.video.xstream/htmlcache/page1').exists())
check('Papierkorb nach 30 Tagen geleert', not (DATA / 'user/trash/old_scraper.py').exists())
check('Cache-Hauptordner bleibt stehen', (DATA / 'plugin.video.xstream/htmlcache').is_dir())
check('leere tiefe Unterordner entfernt', not (DATA / 'plugin.video.xstream/htmlcache/sub/deep').exists())

print('Knopf: alles der Gruppe')
r = C.clean(['addon', 'temp', 'logs', 'img', 'db'], full=True)
check('Addon-Cache komplett weg', not (DATA / 'plugin.video.xstream/htmlcache/mittel').exists() and not (DATA / 'plugin.video.xship/channels_cache.json').exists())
check('Poster-Speicher geleert', not (DATA / 'imgcache/ab/abcdef').exists())
check('frische Dateien (<2 min) bleiben', (DATA / 'temp/frisch.tmp').exists() and (DATA / 'plugin.video.xstream/cache_notes_user.txt').exists())
check('Ergebnis nennt freie Bytes', r['freed'] >= 5600 and r['files'] >= 4, r['freed'])

print('Schutz')
keep = ['plugin.video.xstream/settings.json', 'plugin.video.xstream/xstream.db', 'plugin.video.moviescout/settings.json',
        'downloads/film.mp4', 'downloads/library.json', 'addons/plugin.video.xstream/default.py', 'database/MyVideos116.db',
        'user/providers/mein.py', 'keymaps/k.xml', 'health.json']
check('Einstellungen, Downloads, Addons, Datenbanken, eigene Scraper unangetastet', all((DATA / k).exists() for k in keep),
      [k for k in keep if not (DATA / k).exists()])
check('pyc nicht im Standard-Lauf', (DATA / 'addons/plugin.video.xstream/resources/__pycache__/m.cpython-313.pyc').exists())
C.clean(['pyc'], full=True)
check('pyc auf Wunsch entfernt, Quelltext bleibt', not (DATA / 'addons/plugin.video.xstream/resources/__pycache__/m.cpython-313.pyc').exists() and (DATA / 'addons/plugin.video.xstream/default.py').exists())
check('unbekannte Gruppe wird ignoriert', C.clean(['gibt_es_nicht', '../..'], full=True)['files'] == 0)

print('Engine-Zwischenspeicher (cache.sqlite)')
c = CA.Cache('t_clean', ttl=3600, persist=True)
for i in range(300):
    c.put('k%d' % i, {'v': 'y' * 200})
time.sleep(0.1)
db = DATA / 'cache.sqlite'
check('cache.sqlite entsteht', db.exists())
b1 = C.scan()['categories']
b1 = {x['id']: x for x in b1}['db']['bytes']
C.clean(['db'], full=True)
check('Datenbank nach Leeren kleiner', {x['id']: x for x in C.scan()['categories']}['db']['bytes'] < b1)
check('Eintrag danach weg, Cache funktioniert weiter', c.get('k1') is None and (c.put('n', 1) or True) and c.get('n') == 1)

print('Automatischer Lauf')
mk('temp/alt2.tmp', 100)
r = C.auto_run()
check('auto_run räumt Altes ohne Fehler', not (DATA / 'temp/alt2.tmp').exists() and 'scan' in r)
check('letzter Lauf wird gemerkt', C._last['ts'] > 0)

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
