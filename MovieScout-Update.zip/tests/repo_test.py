# -*- coding: utf-8 -*-
"""Test des Kodi-Repository-Browsers und des Kompatibilitäts-Checks über die Engine (mit Fake-Repositories).

    python tests/repo_test.py
"""
import gzip
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
PORT, REPO_PORT, EXTRA_PORT = 8941, 8942, 8943
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, raw=None):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    req = Request(BASE + path, data=data, method='POST' if data is not None else 'GET',
                  headers={'Content-Type': 'application/zip' if raw is not None else 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=90) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=10, step=0.2):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def addon_xml(aid, ver, points, requires=(), name=None, summary=''):
    req = ''.join('<import addon="%s" version="1.0.0"/>' % r for r in requires)
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<addon id="%s" name="%s" version="%s" provider-name="Tester">\n'
            '  <requires><import addon="xbmc.python" version="3.0.0"/>%s</requires>\n%s\n'
            '  <extension point="xbmc.addon.metadata"><summary lang="en_GB">%s</summary><summary lang="de_DE">%s</summary></extension>\n</addon>'
            % (aid, name or aid, ver, req, points, 'EN ' + summary, summary))


def zipped(aid, files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for n, c in files.items():
            z.writestr(aid + '/' + n, c)
    return b.getvalue()


PLUG = '<extension point="xbmc.python.pluginsource" library="default.py"><provides>video</provides></extension>'
SCRIPT = '<extension point="xbmc.python.script" library="default.py"/>'
MODULE = '<extension point="xbmc.python.module" library="lib"/>'
SERVICE = '<extension point="xbmc.service" library="service.py"/>'


def build(version_video='1.0.0'):
    """{id: (xml, zip-Bytes)}"""
    out = {}

    def add(aid, ver, points, files, requires=(), name=None, summary=''):
        xml = addon_xml(aid, ver, points, requires, name, summary)
        out[aid] = (xml, zipped(aid, dict({'addon.xml': xml}, **files)), ver)
    add('plugin.video.mondfilm', version_video, PLUG, {'default.py': 'import xbmc\nxbmc.log("ok")\n'}, name='Mondfilm', summary='Filme vom Mond')
    add('plugin.video.sonnenfilm', '2.0.0', PLUG, {'default.py': 'import xbmc\n'}, name='Sonnenfilm', summary='Filme von der Sonne mit Mond')
    add('plugin.audio.radio', '1.0.0', PLUG, {'default.py': 'pass\n'}, name='Radio Erde', summary='Radio')
    add('script.game.fenster', '1.0.0', SCRIPT, {'default.py': 'import tkinter\nroot = tkinter.Tk()\nroot.mainloop()\n'},
        name='Fensterspiel', summary='Braucht ein Desktop-Fenster')
    add('script.game.schlicht', '1.0.0', SCRIPT, {'default.py': 'import xbmcgui\nxbmcgui.Dialog().ok("a", "b")\n'}, ['script.module.hilfsbau'],
        name='Schlichtes Spiel', summary='Einfaches Spiel')
    add('script.module.hilfsbau', '3.1.0', MODULE, {'lib/hilfsbau.py': 'X = 1\n'}, name='Hilfsbau', summary='Bibliothek')
    add('service.uhr', '1.0.0', SERVICE, {'service.py': 'import xbmc\nmon = xbmc.Monitor()\nmon.waitForAbort(1)\n'}, name='Uhr', summary='Dienst')
    for aid, pt in (('skin.hell', '<extension point="xbmc.gui.skin"/>'), ('weather.wolke', '<extension point="xbmc.python.weather" library="w.py"/>'),
                    ('resource.language.xx_xx', '<extension point="xbmc.addon.resource"/>')):
        add(aid, '1.0.0', pt, {}, name=aid)
    for i in range(90):                                                  # viele Treffer für das Blättern
        aid = 'plugin.audio.massen%02d' % i
        xml = addon_xml(aid, '1.0.0', PLUG, name='Massen %02d' % i, summary='Massenware')
        out[aid] = (xml, None, '1.0.0')
    return out


class Repo(BaseHTTPRequestHandler):
    items = {}
    gz = True
    hits = []
    down = False

    def do_GET(self):
        cls = type(self)
        cls.hits.append(self.path)
        if Repo.down:
            self.send_response(503); self.end_headers(); return
        data = None
        if self.path in ('/addons.xml.gz', '/addons.xml'):
            body = ('<?xml version="1.0" encoding="UTF-8"?><addons>' + ''.join(
                x[0].split('?>', 1)[1] for x in cls.items.values()) + '</addons>').encode()
            if self.path.endswith('.gz'):
                data = gzip.compress(body) if cls.gz else None
            else:
                data = body
        else:
            parts = self.path.strip('/').split('/')
            ent = cls.items.get(parts[0]) if len(parts) == 2 else None
            if ent and ent[1] is not None and parts[1] == '%s-%s.zip' % (parts[0], ent[2]):
                data = ent[1]
        if data is None:
            self.send_response(404); self.end_headers(); return
        self.send_response(200); self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)

    def log_message(self, *a):
        pass


class Extra(Repo):
    items = {}
    hits = []
    gz = False


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_repo_'))
    Repo.items = build()
    Extra.items = {}
    xml = addon_xml('plugin.video.zusatz', '1.5.0', PLUG, name='Zusatzfilm', summary='Aus dem zweiten Repo')
    Extra.items['plugin.video.zusatz'] = (xml, zipped('plugin.video.zusatz', {'addon.xml': xml, 'default.py': 'pass\n'}), '1.5.0')
    s1 = HTTPServer(('127.0.0.1', REPO_PORT), Repo)
    s2 = HTTPServer(('127.0.0.1', EXTRA_PORT), Extra)
    for s in (s1, s2):
        threading.Thread(target=s.serve_forever, daemon=True).start()
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1', MINIKODI_ALLOW_PRIVATE='1',
               MOVIESCOUT_KODI_REPO='http://127.0.0.1:%d/' % REPO_PORT)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        if not wait(lambda: http('/api/providers')[0] == 200, 30):
            print('Engine startet nicht'); return 1

        print('Katalog durchsuchen')
        c, r = http('/api/admin/repo/search')
        ids = [i['id'] for i in r.get('items', [])]
        check('Suche ohne Begriff: Treffer, 40 pro Seite, mehrere Seiten', c == 200 and len(ids) == 40 and r['pages'] >= 3 and r['total'] >= 97, (c, r.get('total'), r.get('pages')))
        c, r = http('/api/admin/repo/search?q=')
        allids = []
        for pg in range(r['pages']):
            allids += [i['id'] for i in http('/api/admin/repo/search?page=%d' % pg)[1]['items']]
        check('Skins, Wetter und Sprachpakete werden nicht angeboten', not any(x.startswith(('skin.', 'weather.', 'resource.')) for x in allids), allids[:20])
        check('Videoquellen, Programme, Dienste und Bibliotheken sind da',
              {'plugin.video.mondfilm', 'script.game.schlicht', 'service.uhr', 'script.module.hilfsbau', 'plugin.audio.radio'} <= set(allids))
        c, r = http('/api/admin/repo/search?q=mond')
        names = [i['name'] for i in r['items']]
        check('Suchbegriff „mond“ findet Name und Beschreibung, Namenstreffer zuerst', names[:2] == ['Mondfilm', 'Sonnenfilm'], names)
        check('Eintrag trägt Version, Art, Beschreibung und Installiert-Stand',
              r['items'][0]['version'] == '1.0.0' and r['items'][0]['group'] == 'video' and r['items'][0]['summary'] == 'Filme vom Mond' and r['items'][0]['installed'] is False, r['items'][0])
        c, r = http('/api/admin/repo/search?group=service')
        check('Filter nach Art (Dienste)', [i['id'] for i in r['items']] == ['service.uhr'], r)
        c, r = http('/api/admin/repo/search?group=module')
        check('Filter nach Art (Bibliotheken)', [i['id'] for i in r['items']] == ['script.module.hilfsbau'], r)
        c, r = http('/api/admin/repo/search?q=gibtesnicht')
        check('Kein Treffer: leere Liste', c == 200 and r['items'] == [] and r['total'] == 0, r)
        c, r = http('/api/admin/repo/search?q=massen&page=99')
        check('Seitenzahl wird begrenzt', c == 200 and r['page'] == r['pages'] - 1 and r['items'], (r['page'], r['pages']))
        hits = len([h for h in Repo.hits if h.startswith('/addons.xml')])
        http('/api/admin/repo/search?q=radio')
        check('Index wird gemerkt (nicht bei jeder Suche neu geladen)', len([h for h in Repo.hits if h.startswith('/addons.xml')]) == hits, Repo.hits[-3:])

        print('Prüfen vor der Installation')
        c, r = http('/api/admin/repo/check?id=script.game.fenster')
        check('Fensterspiel: Urteil „läuft nicht“ (Desktop-Fenster)', c == 200 and r['report']['verdict'] == 'no' and 'desktop' in [f['code'] for f in r['report']['findings']], r)
        check('Prüfen installiert nichts', not [a for a in http('/api/admin/addons')[1]['addons'] if a['id'] == 'script.game.fenster'])
        c, r = http('/api/admin/repo/check?id=script.game.schlicht')
        check('Schlichtes Spiel: „läuft voraussichtlich“; Bibliothek wird als nachzuladen genannt', c == 200 and r['report']['verdict'] == 'ok' and r['report']['needs'] == ['script.module.hilfsbau'], r)
        check('Antwort nennt Größe und Eintrag', r['size'] > 100 and r['entry']['name'] == 'Schlichtes Spiel', r)
        c, r = http('/api/admin/repo/check?id=gibt.es.nicht')
        check('Unbekannte Kennung: verständliche Meldung', c == 502 and 'nicht im Kodi-Repository' in r['error'], r)

        print('Installieren')
        zipreq = len([h for h in Repo.hits if h.endswith('.zip')])
        c, r = http('/api/admin/repo/install', {'id': 'script.game.schlicht'})
        check('Installation mit Bibliothek', c == 200 and r['addon']['id'] == 'script.game.schlicht' and r['deps']['installed'] == ['script.module.hilfsbau'], r)
        zips = [h for h in Repo.hits if h.endswith('.zip')][zipreq:]
        check('Das geprüfte Paket wird nicht ein zweites Mal geladen (nur die Bibliothek kommt dazu)', zips == ['/script.module.hilfsbau/script.module.hilfsbau-3.1.0.zip'], zips)
        lst = {a['id']: a for a in http('/api/admin/addons')[1]['addons']}
        check('Liste führt Prüfergebnis in Kurzform', lst['script.game.schlicht']['compat']['verdict'] == 'ok' and lst['script.game.schlicht']['compat']['label'].startswith('Läuft'), lst['script.game.schlicht'])
        c, r = http('/api/admin/repo/search?q=schlicht')
        it = r['items'][0]
        check('Katalog markiert Installiertes', it['installed'] is True and it['installed_version'] == '1.0.0' and it['update'] is False, it)
        c, r = http('/api/admin/repo/install', {'id': 'gibt.es.nicht'})
        check('Installieren einer unbekannten Kennung: Fehlermeldung', c == 502 and 'nicht im Kodi-Repository' in r['error'], r)
        c, r = http('/api/admin/repo/install', {'id': 'script.game.fenster'})
        check('Auch Pakete mit Warnung lassen sich auf Wunsch installieren; Bericht kommt mit', c == 200 and r['addon']['compat_report']['verdict'] == 'no', r)

        print('Aktualisierung erkennen')
        c, r = http('/api/admin/repo/install', {'id': 'plugin.video.mondfilm'})
        check('Videoquelle installiert (Version 1.0.0)', c == 200 and r['addon']['version'] == '1.0.0', r)
        Repo.items.update(build('1.1.0'))
        time.sleep(0.1)
        c, r = http('/api/admin/repo/search?q=mondfilm')
        check('Zwischengespeicherter Katalog zeigt die neue Version noch nicht', r['items'][0]['version'] == '1.0.0', r['items'][0])
        c, r = http('/api/settings', {'settings': {'kodi_repos': 'http://127.0.0.1:%d/addons.xml' % EXTRA_PORT}})
        c, r = http('/api/admin/repo/search?q=mondfilm')
        mf = r['items'][0]
        check('Nach Änderung der Repositories wird neu geladen: Aktualisierung erkannt', mf['version'] == '1.1.0' and mf['installed_version'] == '1.0.0' and mf['update'] is True, mf)

        print('Weitere Repositories')
        c, r = http('/api/admin/repo/search?q=zusatz')
        check('Zusätzliches Repository (addons.xml ohne gz, Adresse mit addons.xml) liefert Treffer', c == 200 and [i['id'] for i in r['items']] == ['plugin.video.zusatz'], r)
        c, r = http('/api/admin/repo/install', {'id': 'plugin.video.zusatz'})
        check('Paket aus dem zusätzlichen Repository wird installiert', c == 200 and r['addon']['version'] == '1.5.0', r)
        c, r = http('/api/settings', {'settings': {'kodi_repos': 'http://127.0.0.1:%d/ http://127.0.0.1:9/' % EXTRA_PORT}})
        c, r = http('/api/admin/repo/search?q=mond')
        check('Ein unerreichbares zusätzliches Repository stört nicht, wird aber gemeldet', c == 200 and r['items'] and len(r['errors']) == 1 and '127.0.0.1:9' in r['errors'][0], r)
        http('/api/settings', {'settings': {'kodi_repos': ''}})

        print('Repository nicht erreichbar')
        Repo.down = True
        c, r = http('/api/settings', {'settings': {'kodi_repos': ''}})
        # Zwischenspeicher gilt noch: Suche geht, nur Download scheitert
        c, r = http('/api/admin/repo/install', {'id': 'service.uhr'})
        check('Download scheitert: Fehlermeldung statt Absturz', c == 502 and r.get('error'), (c, r))
        Repo.down = False

        print('Prüfung eines ZIP ohne Installation und installierter Addons')
        bad = zipped('script.x1', {'addon.xml': addon_xml('script.x1', '1.0.0', SCRIPT), 'default.py': 'print "alt"\n'})
        c, r = http('/api/admin/addon/scan', raw=bad)
        check('ZIP-Prüfung: Python 2 erkannt', c == 200 and r['report']['verdict'] == 'no' and r['addon']['id'] == 'script.x1', r)
        check('ZIP-Prüfung installiert nichts', not [a for a in http('/api/admin/addons')[1]['addons'] if a['id'] == 'script.x1'])
        c, r = http('/api/admin/addon/scan', raw=b'kein zip')
        check('ZIP-Prüfung: kaputte Datei gibt 400', c == 400, r)
        c, r = http('/api/admin/addon/install', raw=bad)
        check('Installation über ZIP trägt die Kurzfassung im Eintrag', c == 200 and r['addon']['compat']['verdict'] == 'no' and r['addon']['compat_report']['findings'], r)
        c, r = http('/api/admin/addon/compat?id=script.x1')
        check('Bericht eines installierten Addons', c == 200 and r['report']['verdict'] == 'no', r)
        c, r = http('/api/admin/addon/compat?id=script.gibtesnicht')
        check('Bericht eines unbekannten Addons: 404', c == 404, r)
        meta = json.loads((tmp / 'd' / 'addons' / 'script.x1' / 'moviescout-addon.json').read_text('utf-8'))
        check('Die Datei des Addons enthält nur die Kurzfassung, nicht den ganzen Bericht', 'compat' in meta and 'compat_report' not in meta, list(meta))

        print('Startdatei-Ordner wie in Kodi')
        out = tmp / 'entry.txt'
        ent = zipped('script.entry', {
            'addon.xml': addon_xml('script.entry', '1.0.0', '<extension point="xbmc.python.script" library="resources/lib/main.py"/>'),
            'resources/lib/main.py': 'import os\nimport nachbar\nopen(%r, "w").write(nachbar.WERT)\n' % str(out),
            'resources/lib/nachbar.py': 'WERT = "nachbar-ok"\n'})
        c, r = http('/api/admin/addon/install', raw=ent)
        check('Addon mit Startdatei in resources/lib: Prüfung findet keine fehlenden Module', c == 200 and r['addon']['compat']['verdict'] == 'ok', r['addon'].get('compat'))
        c, r = http('/api/admin/addon/run', {'id': 'script.entry'})
        check('… und `import nachbar` klappt zur Laufzeit', c == 200 and out.exists() and out.read_text() == 'nachbar-ok', (c, r))
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        s1.shutdown()
        s2.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
