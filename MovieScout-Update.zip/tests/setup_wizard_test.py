import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8964; ok = bad = 0
def check(n, c, x=''):
    global ok, bad
    if c: ok += 1; print('  ok   ', n)
    else: bad += 1; print('  FEHLER', n, x)
tmp = tempfile.mkdtemp()
env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT/'tests'/'fake_providers'), NO_PROXY='*')
srv = subprocess.Popen([sys.executable, str(ROOT/'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(100):
    try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
    except OSError: time.sleep(.25)
URL = 'http://127.0.0.1:%d/ui/' % API
try:
    with sync_playwright() as p:
        b = p.chromium.launch()
        # 1) frischer Nutzer, kein Automatisierungs-Merkmal: Assistent erscheint von selbst
        ctx = b.new_context(viewport={'width':900,'height':900}); ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>false})")
        pg = ctx.new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto(URL); pg.wait_for_selector('.wiz', timeout=15000)
        check('Frischer Start: Assistent erscheint', pg.locator('.wiz h2').inner_text().startswith('Willkommen'))
        check('Schritt 1 von 4/5, 6 Looks', 'Schritt 1 von' in pg.locator('.wizstep').inner_text() and pg.locator('.wiz .look').count() == 6, pg.locator('.wiz .look').count())
        pg.locator('.wiz .look', has_text='Netflix').click(); pg.wait_for_timeout(300)
        check('Look wirkt sofort', pg.evaluate("SK.active") == 'look-netflix' and pg.evaluate("localStorage.getItem('mk.skins')") is not None)
        pg.get_by_role('button', name='Weiter', exact=True).click(); pg.wait_for_timeout(200)
        check('Schritt 2: Bedienung', 'Wie viel Technik' in pg.locator('.wiz h2').inner_text())
        pg.get_by_role('button', name='Einfach (empfohlen)').click(); pg.wait_for_timeout(200)
        check('Einfach gewählt (gespeichert)', pg.evaluate("store.get('setadv')") is False)
        pg.get_by_role('switch', name='Akkustand neben der Uhr anzeigen').click(); pg.wait_for_timeout(100)
        check('Akku-Schalter wirkt', pg.evaluate("store.get('batt')") is True)
        pg.get_by_role('button', name='Weiter', exact=True).click(); pg.wait_for_timeout(200)
        check('Schritt 3: Quellen', 'Deine Quellen' in pg.locator('.wiz h2').inner_text() and 'Quelle' in pg.locator('.wiz .lead').inner_text())
        pg.get_by_role('button', name='Zurück').click(); pg.wait_for_timeout(150)
        check('Zurück geht', 'Wie viel Technik' in pg.locator('.wiz h2').inner_text())
        pg.get_by_role('button', name='Weiter', exact=True).click(); pg.get_by_role('button', name='Weiter', exact=True).click(); pg.wait_for_timeout(200)
        check('Letzter Schritt: Fertig (im Browser ohne Berechtigungs-Schritt)', pg.locator('.wiz h2').inner_text() == 'Fertig!' and 'Schritt 4 von 4' in pg.locator('.wizstep').inner_text())
        pg.locator('.wiz .btn.pri').click(); pg.wait_for_timeout(500)
        check('Assistent weg, setup_done gemerkt', pg.locator('.wiz').count() == 0 and pg.evaluate("store.get('setup_done')") is True)
        pg.reload(); pg.wait_for_timeout(3500)
        check('Nach Neuladen nicht wieder', pg.locator('.wiz').count() == 0)
        # Überspringen
        ctx2 = b.new_context(viewport={'width':900,'height':900}); ctx2.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>false})")
        pg2 = ctx2.new_page(); pg2.goto(URL); pg2.wait_for_selector('.wiz', timeout=15000)
        pg2.locator('.wiz').get_by_role('button', name='Überspringen').click(); pg2.wait_for_timeout(400)
        check('Überspringen schließt und merkt', pg2.locator('.wiz').count() == 0 and pg2.evaluate("store.get('setup_done')") is True)
        # 2) bestehender Nutzer: kein Überfall
        ctx3 = b.new_context(viewport={'width':900,'height':900}); ctx3.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>false}); localStorage.setItem('mk.hist', JSON.stringify([{item:{title:'A',provider:'P',provider_id:'p',url:'u'},ts:1}]))")
        pg3 = ctx3.new_page(); pg3.goto(URL); pg3.wait_for_timeout(4000)
        check('Bestehender Nutzer: kein Assistent', pg3.locator('.wiz').count() == 0 and pg3.evaluate("store.get('setup_done')") is True)
        # 3) Aus den Einstellungen wiederholbar
        pg3.evaluate("openSettings()"); pg3.wait_for_selector('.setsearch')
        pg3.get_by_role('button', name='Einrichtungsassistent').click(); pg3.wait_for_selector('.wiz')
        check('Aus Einstellungen startbar', True)
        check('keine Skriptfehler', not errs, errs)
        b.close()
finally:
    srv.terminate()
print(ok, bad)
