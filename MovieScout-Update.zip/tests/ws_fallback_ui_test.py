# -*- coding: utf-8 -*-
"""Ohne WebSocket-Paket (z. B. Pydroid): keine Dauer-Verbindungsversuche (Log-Spam), Chat kommt trotzdem an (Abfragen).

    python tests/ws_fallback_ui_test.py
"""
import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
API = 8924
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def main():
    if importlib.util.find_spec('websockets') or importlib.util.find_spec('wsproto'):
        print('websockets ist installiert - Test der Ersatzlösung entfällt'); return 0
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'))
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    log = open(os.path.join(tmp, 'engine.log'), 'w')
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(API)], env=env, cwd=str(ROOT), stdout=log, stderr=subprocess.STDOUT)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError:
            time.sleep(.25)
    time.sleep(1)
    try:
        info = json.loads(urllib.request.urlopen('http://127.0.0.1:%d/api/info' % API).read())
        check('/api/info meldet ws=false', info.get('ws') is False, info)
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_page(viewport={'width': 412, 'height': 890})
            wss = []
            pg.on('websocket', lambda w: wss.append(w.url))
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (API, API)); pg.wait_for_timeout(2500)
            urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/api/chat' % API, data=json.dumps({'text': 'Hallo aus dem Test', 'author': 'Tester'}).encode(),
                                                         headers={'Content-Type': 'application/json'})).read()
            got = False
            for _ in range(40):
                if pg.evaluate("chatMessages.some((m) => m.text === 'Hallo aus dem Test')"):
                    got = True; break
                pg.wait_for_timeout(500)
            check('Neue Chat-Nachricht kommt ohne WebSocket an (Abfrage alle 15 s)', got)
            check('Kein einziger WebSocket-Versuch zum Chat', not [u for u in wss if '/ws/chat' in u], wss)
            rep = pg.evaluate("supportReportText()")
            check('Support-Bericht nennt das fehlende Paket', 'pip install websockets' in rep, rep[:300])
            check('Keine Skriptfehler', not errs, errs)
            b.close()
    finally:
        srv.terminate()
        try:
            srv.wait(10)
        except Exception:                                  # noqa: BLE001
            srv.kill()
        log.close()
    txt = open(os.path.join(tmp, 'engine.log'), encoding='utf-8', errors='replace').read()
    check('Engine-Log ohne „Unsupported upgrade request“-Spam', txt.count('Unsupported upgrade request') == 0, txt.count('Unsupported upgrade request'))
    check('Einmaliger Hinweis auf das fehlende Paket im Log', txt.count('pip install websockets') == 1, txt[-800:])
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
