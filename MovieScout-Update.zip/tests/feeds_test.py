# -*- coding: utf-8 -*-
"""RSS-/Atom-Feeds in der Engine (Fake-Server, kein Netz nötig):

    python tests/feeds_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT, FEED_PORT = 8891, 8892
API = 'http://127.0.0.1:%d' % PORT
F = 'http://127.0.0.1:%d' % FEED_PORT
passed = failed = 0
HITS = []

RSS = '''<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:media="http://search.yahoo.com/mrss/"><channel>
<title>Tagesblick</title><link>http://news.test/</link>
<item><title>Erste &amp; wichtigste Meldung</title><link>/a1</link><pubDate>Mon, 02 Nov 2026 20:00:00 +0000</pubDate>
<description>&lt;p&gt;Hallo &lt;b&gt;Welt&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Zweiter Absatz&lt;/p&gt;&lt;img src="/bild.jpg"&gt;</description></item>
<item><title>Mit Vorschaubild</title><link>http://news.test/a2</link><pubDate>Sun, 01 Nov 2026 08:00:00 +0000</pubDate>
<description>Kurz</description><media:thumbnail url="http://img.test/t.jpg"/></item>
<item><description>Nur Beschreibung ohne Titel</description></item>
</channel></rss>'''
ATOM = '''<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom"><title>Atom-Blog</title><link href="http://blog.test/" rel="alternate"/>
<entry><title>Eintrag eins</title><link href="http://blog.test/e1" rel="alternate"/><link href="http://blog.test/e1.json" rel="related"/>
<updated>2026-11-02T10:30:00Z</updated><summary>Zusammenfassung</summary></entry>
<entry><title>Eintrag zwei</title><link href="/e2"/><published>2026-10-30T09:00:00+01:00</published><content type="html">&lt;p&gt;Inhalt&lt;/p&gt;</content></entry></feed>'''
RDF = '''<?xml version="1.0"?><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns="http://purl.org/rss/1.0/" xmlns:dc="http://purl.org/dc/elements/1.1/">
<channel><title>Alt-RSS</title><link>http://old.test/</link></channel>
<item><title>RDF-Meldung</title><link>http://old.test/1</link><dc:date>2026-11-01T12:00:00Z</dc:date><description>Text</description></item></rdf:RDF>'''
BOMB = '''<?xml version="1.0"?><!DOCTYPE lolz [<!ENTITY lol "lol"><!ENTITY lol2 "&lol;&lol;&lol;&lol;">]><rss version="2.0"><channel><title>&lol2;</title></channel></rss>'''
PAGE = '<html><head><title>Seite</title><link rel="alternate" type="application/rss+xml" href="/feed.xml"></head><body>Hallo</body></html>'
PLAIN = '<html><head><title>Ohne Feed</title></head><body>nichts</body></html>'


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


class Srv(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def do_GET(self):
        HITS.append(self.path)
        t = {'/feed.xml': ('application/rss+xml', RSS), '/atom.xml': ('application/atom+xml', ATOM), '/rdf.xml': ('application/rdf+xml', RDF),
             '/bomb.xml': ('text/xml', BOMB), '/': ('text/html', PAGE), '/plain': ('text/html', PLAIN), '/kaputt.xml': ('text/xml', '<rss><channel>')}.get(self.path)
        if self.path == '/big.xml':
            b = b'<rss><channel>' + b'x' * (3 * 1024 * 1024)
            self.send_response(200); self.end_headers(); self.wfile.write(b); return
        if not t:
            self.send_response(404); self.end_headers(); return
        b = t[1].encode()
        self.send_response(200); self.send_header('Content-Type', t[0]); self.end_headers(); self.wfile.write(b)


def call(path):
    try:
        r = urllib.request.urlopen(API + path, timeout=40)
    except urllib.error.HTTPError as e:
        r = e
    b = r.read()
    try:
        return r.status, json.loads(b)
    except Exception:
        return r.status, b


def feed(u, fresh=False):
    return call('/api/feed?url=' + urllib.parse.quote(u, safe='') + ('&fresh=1' if fresh else ''))


def wait_port(port):
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=.3).close(); return True
        except OSError:
            time.sleep(.25)
    return False


def main():
    s = HTTPServer(('127.0.0.1', FEED_PORT), Srv)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, PYTHONUNBUFFERED='1', MINIKODI_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        assert wait_port(PORT), 'Engine startet nicht'

        print('RSS 2.0')
        st, d = feed(F + '/feed.xml')
        check('Antwort 200, Feedname', st == 200 and d['title'] == 'Tagesblick', (st, d))
        it = d['items']
        check('Drei Meldungen, Titel entschlüsselt (&amp;)', len(it) == 3 and it[0]['title'] == 'Erste & wichtigste Meldung', it)
        check('Text ohne HTML, Absätze bleiben', it[0]['summary'] == 'Hallo Welt\n\nZweiter Absatz', repr(it[0]['summary']))
        check('Relativer Link wird absolut', it[0]['link'] == F + '/a1', it[0]['link'])
        check('Datum als Zeitstempel (02.11.2026 20:00 UTC)', it[0]['ts'] == 1793649600, it[0]['ts'])
        check('Bild aus <img> und aus media:thumbnail', it[0]['image'] == F + '/bild.jpg' and it[1]['image'] == 'http://img.test/t.jpg', (it[0]['image'], it[1]['image']))
        check('Ohne Titel: erste Zeile der Beschreibung', it[2]['title'] == 'Nur Beschreibung ohne Titel', it[2])
        n = len(HITS)
        feed(F + '/feed.xml')
        check('Zweiter Abruf kommt aus dem Zwischenspeicher', len(HITS) == n)
        feed(F + '/feed.xml', True)
        check('„fresh“ holt neu', len(HITS) == n + 1)

        print('Atom und RDF')
        st, d = feed(F + '/atom.xml')
        check('Atom: Name, zwei Einträge, Alternativ-Link statt „related“', st == 200 and d['title'] == 'Atom-Blog' and [i['link'] for i in d['items']] == ['http://blog.test/e1', F + '/e2'], (st, d))
        check('Atom: updated/published → Zeitstempel, HTML-Inhalt als Text', d['items'][0]['ts'] == 1793615400 and d['items'][1]['summary'] == 'Inhalt', d['items'])
        st, d = feed(F + '/rdf.xml')
        check('RSS 1.0 (RDF): Meldung mit dc:date', st == 200 and d['title'] == 'Alt-RSS' and d['items'][0]['title'] == 'RDF-Meldung' and d['items'][0]['ts'] > 0, (st, d))

        print('Webseite statt Feed')
        st, d = feed(F + '/')
        check('Feed wird über <link rel="alternate"> gefunden', st == 200 and d['url'] == F + '/feed.xml' and d['title'] == 'Tagesblick', (st, d))
        st, d = feed(F + '/plain')
        check('Seite ohne Feed: 400 „kein RSS- oder Atom-Feed“', st == 400 and 'kein' in d['error'], (st, d))

        print('Fehler und Sicherheit')
        st, d = feed(F + '/bomb.xml')
        check('Entity-Bombe wird abgelehnt', st == 400 and 'ENTITY' in d['error'], (st, d))
        st, d = feed(F + '/kaputt.xml')
        check('Kaputtes XML: lesbare Meldung', st == 400 and 'gültiger Feed' in d['error'], (st, d))
        st, d = feed(F + '/big.xml')
        check('Mehr als 2 MB: abgelehnt', st == 400 and '2 MB' in d['error'], (st, d))
        st, d = feed(F + '/gibtesnicht')
        check('HTTP 404 vom Server: Meldung', st == 400 and '404' in d['error'], (st, d))
        st, d = feed('ftp://x.test/feed')
        check('Nur http(s)', st == 400 and 'http' in d['error'], (st, d))
        st, d = feed('')
        check('Leere Adresse', st == 400, (st, d))
        st, d = feed('http://127.0.0.1:1/x')
        check('Nicht erreichbar: Meldung statt Absturz', st == 400 and 'erreichbar' in d['error'], (st, d))
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=8)
        except Exception:
            srv.kill()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
