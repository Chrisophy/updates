# -*- coding: utf-8 -*-
"""Weiterschauen im App-Player (Android): Oberfläche mit nachgebildeter App-Schnittstelle (window.MovieScoutApp).
Prüft: Startposition geht an playNative, Stelle kommt über msNativeDone zurück und wird gemerkt, „Von vorne“ startet bei 0.

    python tests/resume_native_test.py
"""
import os
import re
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
API = 8963
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


APP = """
window.__calls = [];
window.MovieScoutApp = {
  nativeAvailable: () => true, nativeWidevineLevel: () => 'L1', keepScreenOn: () => true,
  playNative: (j) => { window.__calls.push(JSON.parse(j)); return true; },
};
"""
PLAN = ("() => { const orig = api; api = async (p, o) => (p === '/api/play' ? { mode: 'media', format: 'dash', name: 'T', proxy_path: '/p', url: '',"
        " drm: { supported: true, key_system: 'com.widevine.alpha', license_path: '/l' } } : orig(p, o)); }")
START = ("() => { const c = { item: { provider_id: 't', url: 'x://film', title: 'Testfilm', poster: '' }, hosters: [{ name: 'Test', url: 'http://127.0.0.1:1/x.mpd', direct: true }], index: 0 };"
         " current = c; startPlayer(c, 0); }")
KEY = "{provider_id:'t', url:'x://film', title:'Testfilm'}"


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError:
            time.sleep(.25)
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 900, 'height': 600}, user_agent='Mozilla/5.0 (Linux; Android 13) MovieScoutApp/1.0')
            ctx.add_init_script(APP)
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_selector('header.top'); pg.wait_for_timeout(600)
            pg.evaluate(PLAN)

            pg.evaluate(START)
            pg.wait_for_function("() => window.__calls.length === 1", timeout=15000)
            c = pg.evaluate("() => window.__calls[0]")
            check('Erster Start: ohne Rückfrage, Startposition 0', c['start'] == 0 and pg.locator('.rsask').count() == 0, c)
            pg.evaluate("() => window.msNativeDone({ ok: true, pos: 150.4, dur: 400, ended: false })")
            pg.wait_for_timeout(600)
            pos = pg.evaluate("() => posGet(%s)" % KEY)
            check('Stelle aus dem App-Player gemerkt (150 von 400 s)', pos and pos['t'] == 150 and pos['d'] == 400, pos)
            check('Player-Ebene geschlossen', pg.locator('#player').count() == 0)

            pg.evaluate(START)
            pg.wait_for_selector('.rsask', timeout=15000)
            check('Zweiter Start: Rückfrage vor dem Öffnen des App-Players', pg.evaluate("() => window.__calls.length") == 1)
            pg.get_by_role('button', name=re.compile('Weiter bei')).click()
            pg.wait_for_function("() => window.__calls.length === 2", timeout=15000)
            c = pg.evaluate("() => window.__calls[1]")
            check('„Weiter bei“: Startposition ~147 s (3 s zurück)', c['start'] == 147000, c)
            pg.evaluate("() => window.msNativeDone({ ok: true, pos: 400, dur: 400, ended: true })")
            pg.wait_for_timeout(600)
            check('Bis zum Ende gesehen: Stelle gelöscht', pg.evaluate("() => posGet(%s)" % KEY) is None)

            pg.evaluate("() => posPut(%s, 200, 400)" % KEY)
            pg.evaluate(START)
            pg.wait_for_selector('.rsask', timeout=15000)
            pg.get_by_role('button', name='Von vorne beginnen').click()
            pg.wait_for_function("() => window.__calls.length === 3", timeout=15000)
            c = pg.evaluate("() => window.__calls[2]")
            check('„Von vorne“: Startposition 0 und alte Stelle vergessen', c['start'] == 0 and pg.evaluate("() => posGet(%s)" % KEY) is None, c)
            pg.evaluate("() => window.msNativeDone({ ok: true })")           # Länge unbekannt: nichts merken
            pg.wait_for_timeout(500)
            check('Keine Skriptfehler', not errs, errs)
            b.close()
    finally:
        srv.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
