# -*- coding: utf-8 -*-
"""Oberflächen-Tests (Playwright): Entdecken (TMDB), Trakt-Anmeldung und -Listen, Adresse abspielen.

    python tests/discover_ui_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import discover_test as DT                                            # noqa: E402  (gespielte TMDB-/Trakt-Antworten)

UP, API, TMDB, TRAKT = 8865, 8866, 8867, 8868
BASE = 'http://127.0.0.1:%d/ui/' % API
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def wait_port(port, tries=100):
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close(); return True
        except OSError:
            time.sleep(0.25)
    return False


def post(path, data):
    req = urllib.request.Request('http://127.0.0.1:%d%s' % (API, path), data=json.dumps(data).encode(), headers={'Content-Type': 'application/json'})
    return json.loads(urllib.request.urlopen(req, timeout=30).read())


def titles(pg):
    return pg.locator('.card .t, .row .t').all_inner_texts()


def run(pg, errs):
    print('Ohne Schlüssel')
    pg.goto(BASE); pg.wait_for_selector('[data-sec=disc] .tile'); pg.wait_for_timeout(300)
    check('Vier Kacheln unter „Entdecken“', pg.locator('[data-sec=disc] .tile .n').all_inner_texts() == ['🎞️ Filme', '📺 Serien', '❤️ Trakt', '🔗 Adresse'], pg.locator('[data-sec=disc] .tile .n').all_inner_texts())
    pg.locator('[data-sec=disc] .tile', has_text='Filme').click(); pg.wait_for_selector('.panel .err')
    check('Hinweis auf den TMDB-Schlüssel mit Knopf zu den Einstellungen', 'TMDB' in pg.locator('.panel .err').inner_text() and pg.get_by_role('button', name='Einstellungen öffnen').count() == 1)
    pg.evaluate("history.back()"); pg.wait_for_timeout(250)

    post('/api/settings', {'settings': {'api.tmdb': 'KEY123', 'trakt.client_id': 'CID', 'trakt.client_secret': 'SEC'}})

    print('Filme entdecken')
    pg.locator('[data-sec=disc] .tile', has_text='Filme').click(); pg.wait_for_selector('.panel .src')
    check('Fünf Listen', pg.locator('.panel .src').count() == 5, pg.locator('.panel .src').all_inner_texts())
    pg.locator('.panel .src', has_text='Am populärsten').click(); pg.wait_for_selector('.card', timeout=15000)
    t = titles(pg)
    check('Sechs Titel als Poster-Karten', len(t) == 6 and t[0] == 'Film 1', t)
    check('Jahr und Bewertung unter dem Titel', 'Film 1' in t[0] and pg.locator('.card .m').first.inner_text() == '2001 · ★ 7.3' or pg.locator('.card .m').first.inner_text() == '2001 · ★ 7.2', pg.locator('.card .m').first.inner_text())
    check('Keine Stern-/Info-Knöpfe auf Entdecken-Karten (nichts zum Merken)', pg.locator('.card .star, .card .info').count() == 0)
    pg.locator('.card').first.click(); pg.wait_for_timeout(600)
    check('Klick sucht den Titel in allen Quellen', pg.evaluate("(() => { const f = nav[nav.length - 1]; return f.type === 'search' && f.q === 'Film 1'; })()"))
    pg.evaluate("history.back()"); pg.wait_for_timeout(300); pg.evaluate("history.back()"); pg.wait_for_timeout(400)

    pg.locator('[data-sec=disc] .tile', has_text='Filme').click(); pg.wait_for_selector('.panel select')
    opts = pg.locator('.panel select option').all_inner_texts()
    check('Genres kommen von TMDB', 'Action' in opts and 'Komödie' in opts, opts)
    pg.locator('.panel select').select_option(label='Action'); pg.locator('.panel input[aria-label=Jahr]').fill('1999')
    pg.get_by_role('button', name='Anzeigen').click(); pg.wait_for_selector('.card', timeout=15000)
    check('Genre + Jahr: Titel der Liste', pg.locator('#view h1, #view h2, #top .ttl, .crumb').first.count() >= 0 and len(titles(pg)) == 6)
    check('… Ansicht heißt „Action · 1999“', 'Action · 1999' in pg.evaluate("nav[nav.length - 1].title"), pg.evaluate("nav[nav.length - 1].title"))
    pg.evaluate("history.back()"); pg.wait_for_timeout(400)
    pg.locator('[data-sec=disc] .tile', has_text='Filme').click(); pg.wait_for_selector('.panel select')
    pg.locator('.panel input[aria-label=Jahr]').fill('12')
    pg.get_by_role('button', name='Anzeigen').click(); pg.wait_for_timeout(300)
    check('Falsches Jahr: Hinweis, Fenster bleibt offen', pg.locator('.panel select').count() == 1)
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)

    print('Serien entdecken')
    pg.locator('[data-sec=disc] .tile', has_text='Serien').click(); pg.wait_for_selector('.panel .src')
    check('Vier Serien-Listen', pg.locator('.panel .src').count() == 4)
    pg.locator('.panel .src', has_text='Aktuell im TV').click(); pg.wait_for_selector('.card', timeout=15000)
    check('Serien-Titel', titles(pg)[0] == 'Serie 1', titles(pg))
    pg.evaluate("history.back()"); pg.wait_for_timeout(400)

    print('Trakt')
    pg.locator('[data-sec=disc] .tile', has_text='Trakt').click(); pg.wait_for_selector('.panel .btn.pri')
    check('Konfiguriert, aber nicht angemeldet: Knopf „Anmelden“', pg.get_by_role('button', name='Anmelden').count() == 1 and 'Noch nicht angemeldet' in pg.locator('.panel').inner_text())
    pg.get_by_role('button', name='Anmelden').click(); pg.wait_for_selector('.trcode')
    check('Gerätecode wird angezeigt', pg.locator('.trcode').inner_text() == 'ABCD1234' and 'trakt.tv/activate' in pg.locator('.panel').inner_text(), pg.locator('.panel').inner_text())
    pg.wait_for_function("document.querySelector('.panel').innerText.includes('Angemeldet als tester')", timeout=20000)
    check('Nach Bestätigung: „Angemeldet als tester“', True)
    check('Eigene Listen (Watchlist, Verlauf, Empfehlungen) und öffentliche', pg.locator('.panel .src').count() == 10, pg.locator('.panel .src').count())
    pg.locator('.panel .src', has_text='Watchlist – Filme').click(); pg.wait_for_selector('.card', timeout=15000)
    check('Watchlist zeigt Matrix und den Titel ohne Nummer', titles(pg) == ['Matrix', 'Ohne Nummer'], titles(pg))
    check('Poster aus TMDB bei bekannter Nummer', pg.evaluate("nav[nav.length - 1].items.map(x => !!x.poster)") == [True, False], pg.evaluate("nav[nav.length - 1].items.map(x => x.poster)"))
    pg.evaluate("history.back()"); pg.wait_for_timeout(400)
    pg.locator('[data-sec=disc] .tile', has_text='Trakt').click(); pg.wait_for_selector('.panel .src')
    pg.get_by_role('button', name='Abmelden').click(); pg.wait_for_timeout(500)
    check('Abmelden zeigt wieder „Anmelden“', pg.get_by_role('button', name='Anmelden').count() == 1)
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)

    print('Adresse abspielen')
    pg.locator('[data-sec=disc] .tile', has_text='Adresse').click(); pg.wait_for_selector('.panel input[type=url]')
    pg.locator('.panel input[type=url]').fill('kein link'); pg.get_by_role('button', name='Abspielen', exact=True).click(); pg.wait_for_timeout(300)
    check('Keine Adresse: Hinweis, Fenster bleibt', pg.locator('.panel input[type=url]').count() == 1 and pg.locator('#player').count() == 0)
    pg.locator('.panel input[type=url]').fill('http://127.0.0.1:%d/ordner/mein-film.mp4' % UP); pg.keyboard.press('Enter'); pg.wait_for_selector('#player', timeout=15000)
    check('Player startet mit dem Dateinamen als Titel', pg.locator('#player .ttl').inner_text() == 'mein-film.mp4', pg.locator('#player .ttl').inner_text())
    pg.evaluate("history.back()"); pg.wait_for_timeout(400)
    check('Zuletzt benutzte Adresse als Knopf', pg.evaluate("store.get('urls', [])[0]").endswith('/ordner/mein-film.mp4'))
    pg.locator('[data-sec=disc] .tile', has_text='Adresse').click(); pg.wait_for_selector('.panel input[type=url]')
    check('… und im Fenster wieder anwählbar', pg.locator('.panel .chip').count() == 1)
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)

    print('Menüleiste: neue Aktionen')
    r = pg.evaluate("normalizeNav({items:[{act:'discover',arg:'trakt',label:'T'},{act:'discover',arg:'x',label:'F'},{act:'url',label:'U'}]}).items.map(x => x.act + ':' + x.arg)")
    check('Entdecken/Trakt/Adresse sind gültige Aktionen', r == ['discover:trakt', 'discover:movie', 'url:'], r)
    pg.evaluate("(() => { editSkin((s) => { s.nav = { style: 'pill', items: [{ id: 'a', icon: '❤️', label: 'Trakt', act: 'discover', arg: 'trakt' }, { id: 'b', icon: '🔗', label: 'Link', act: 'url', arg: '' }] }; s.layout.homeHidden = []; }, { view: true }); })()")
    pg.wait_for_timeout(500)
    pg.locator('.navbar .nb', has_text='Link').click(); pg.wait_for_selector('.panel input[type=url]')
    check('Button „Adresse abspielen“ öffnet das Fenster', True)
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)
    pg.locator('.navbar .nb', has_text='Trakt').click(); pg.wait_for_selector('.panel .btn.pri')
    check('Button „Trakt“ öffnet das Trakt-Fenster', 'Trakt' in pg.locator('.panel h2').inner_text())
    pg.evaluate("history.back()"); pg.wait_for_timeout(300)

    print('Einstellungen: Trakt-Zugang')
    pg.evaluate("openSettings()"); pg.wait_for_selector('.panel')
    pg.get_by_role('tab', name='Konten & Inhalte').click(); pg.wait_for_timeout(300)
    check('Felder für Client-ID und Secret', pg.locator('.panel input[placeholder="Client-ID"]').count() == 1 and pg.locator('.panel input[placeholder="Client-Secret"]').count() == 1)
    check('Keine Fehler in der Konsole', not errs, errs)


def main():
    tmp = tempfile.mkdtemp()
    s1, s2 = DT.serve(TMDB, DT.Tmdb), DT.serve(TRAKT, DT.Trakt)
    env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp,
               FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1', MOVIESCOUT_TMDB_BASE='http://127.0.0.1:%d' % TMDB,
               MOVIESCOUT_TRAKT_BASE='http://127.0.0.1:%d' % TRAKT, MOVIESCOUT_TMDB_IMG='http://127.0.0.1:%d/img' % UP)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_TMDB_KEY'):
        env.pop(k, None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    global failed
    try:
        assert wait_port(UP) and wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_context(viewport={'width': 1280, 'height': 900}).new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text and '/img/' not in m.text else None)
            try:
                run(pg, errs)
            except Exception:      # noqa: BLE001
                import traceback
                traceback.print_exc(); failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png')); print('Screenshot:', Path(tmp) / 'fail.png')
            b.close()
    finally:
        srv.terminate(); up.terminate(); s1.shutdown(); s2.shutdown()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
