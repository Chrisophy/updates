# -*- coding: utf-8 -*-
"""Test der Kodi-Funktionen, die Addons wie multistream brauchen: RunPlugin(...), Action(...), Player-Untertitel-API, urllib3.

    python tests/runplugin_test.py
"""
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
tmp = tempfile.mkdtemp(prefix='ms-rp-')
os.environ['MINIKODI_DATA'] = os.environ['MOVIESCOUT_DATA'] = tmp
sys.path.insert(0, str(ROOT))

from engine import addonhost, compat          # noqa: E402
from kodi_runtime import context              # noqa: E402

passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


ADDON_XML = '''<?xml version="1.0" encoding="UTF-8"?>
<addon id="plugin.video.rptest" name="RP Test" version="1.0.0" provider-name="Test">
  <requires><import addon="xbmc.python" version="3.0.0"/></requires>
  <extension point="xbmc.python.pluginsource" library="addon.py"><provides>video</provides></extension>
  <extension point="xbmc.addon.metadata"><summary lang="de">Test</summary></extension>
</addon>'''

MAIN = r'''
import sys
from urllib.parse import parse_qsl, urlencode
import urllib3
import xbmc, xbmcgui, xbmcplugin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
h = int(sys.argv[1])
q = dict(parse_qsl(sys.argv[2].lstrip('?')))
act = q.get('action', '')
if act == 'play':
    li = xbmcgui.ListItem(path='https://example.org/%s.m3u8' % q.get('id', 'x'))
    li.setSubtitles(['https://example.org/en.srt', 'https://example.org/de.srt'])
    xbmcplugin.setResolvedUrl(h, True, li)
    p = xbmc.Player()
    streams = p.getAvailableSubtitleStreams()
    xbmcgui.Window(10000).setProperty('rp.streams', '|'.join(streams))
    for i, s in enumerate(streams):
        if 'de' in s.lower():
            p.setSubtitleStream(i)
            p.showSubtitles(True)
elif act == 'next':
    xbmc.executebuiltin('Action(reloadkeymaps)')
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.rptest/?%s)' % urlencode({'action': 'play', 'id': 'ep2'}))
elif act == 'wizard':
    xbmcgui.Dialog().notification('Assistent', 'läuft')
'''


def build():
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        z.writestr('plugin.video.rptest/addon.xml', ADDON_XML)
        z.writestr('plugin.video.rptest/addon.py', MAIN)
    return b.getvalue()


zdata = build()
info, rep = compat.scan_zip(zdata)
check('Prüfbericht: läuft ohne Einschränkung', rep.get('verdict') == 'ok' and rep.get('score') == 100, rep)
check('Prüfbericht: keine Warnung', not [f for f in rep.get('findings', []) if f.get('level') in ('warn', 'error')], rep.get('findings'))

addonhost.install_zip(zdata)
AID = 'plugin.video.rptest'


def run(url):
    ctx = context.RequestContext()
    with context.use(ctx):
        addonhost.run(AID, url, play=True)
    return ctx


c = run('plugin://%s/?action=play&id=ep1' % AID)
check('Wiedergabe aufgelöst', len(c.resolved) == 1 and c.resolved[0]['path'].endswith('ep1.m3u8'), c.resolved)
li = c.resolved[0]['listitem']
subs = li.subtitles
check('Untertitel-Liste (2 Einträge)', len(subs) == 2 and all(isinstance(x, dict) for x in subs), subs)
check('setSubtitleStream: Deutsch ist Vorgabe', [x['url'] for x in subs if x.get('default')] == ['https://example.org/de.srt'], subs)

from engine import normalize as N              # noqa: E402
hs = N.hoster_from_resolved(c.resolved[0]['path'], li, 'x', 'RP')
check('Hoster trägt Vorgabe-Untertitel', hs and [x['lang'] for x in hs['subtitles'] if x.get('default')] == ['de'], hs)

c = run('plugin://%s/?action=next' % AID)
check('RunPlugin: Wiedergabe der nächsten Folge übernommen', len(c.resolved) == 1 and c.resolved[0]['path'].endswith('ep2.m3u8'), c.resolved)
check('Action(...) ohne Fehler', True)

c = run('plugin://%s/?action=wizard' % AID)
check('RunPlugin/Dialog: Meldung kommt an', True)

ctx = context.RequestContext()
with context.use(ctx):
    from kodi_runtime import skin
    skin.builtin('RunPlugin(plugin://gibt.es.nicht/?a=1)')
    skin.builtin('RunPlugin(plugin://%s/?action=wizard)' % AID)
check('RunPlugin: unbekanntes Addon bricht nicht ab', True)
check('RunPlugin: Meldung des Ziels geht an den Aufrufer', any('läuft' in n.get('message', '') for n in ctx.notes), ctx.notes)
check('Zähler zurückgesetzt', getattr(addonhost._PLUGIN_DEPTH, 'n', 0) == 0)

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
