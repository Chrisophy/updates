# -*- coding: utf-8 -*-
"""Bildanpassung: Standard Strecken (kein Zoom), Platzhaltertext verschwindet, Einstellung wirkt.
    python tests/imgfit_test.py"""
import os, socket, subprocess, sys, tempfile, time, base64
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8976
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAQAAAACCAYAAAB/qH1jAAAAEklEQVR4nGP4z8Dwn4GBgQEAFAAD/7s0TQAAAABJRU5ErkJggg==')
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_page(viewport={'width': 900, 'height': 700})
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (API, API)); pg.wait_for_selector('header.top'); pg.wait_for_function('typeof providers !== "undefined" && providers.length', timeout=20000)
            pg.evaluate("""() => { const g = document.createElement('div'); g.id = 'tg'; g.className = 'grid'; document.body.append(g);
              g.append(card({title:'RTL 4K - Gute Zeiten', poster:'data:image/png;base64,PNGDATA', kind:'play'}, () => {}), card({title:'Ohne Bild', kind:'play'}, () => {})); }""".replace('PNGDATA', base64.b64encode(PNG).decode()))
            pg.wait_for_timeout(800)
            r = pg.evaluate("""() => { const c = document.querySelectorAll('#tg .card'); const im = c[0].querySelector('img');
              return { fit: getComputedStyle(im).objectFit, fb1: getComputedStyle(c[0].querySelector('.fb')).visibility, fb2: getComputedStyle(c[1].querySelector('.fb')).visibility }; }""")
            check('Standard: Strecken', r['fit'] == 'fill', r)
            check('Platzhaltertext hinter geladenem Bild verborgen', r['fb1'] == 'hidden', r)
            check('Ohne Bild bleibt der Titel sichtbar', r['fb2'] == 'visible', r)
            pg.evaluate("() => { const s = normalizeSkin({poster:{fit:'contain'}}); applySkin(s); }")
            check('Einstellung „Einpassen“ wirkt', pg.evaluate("getComputedStyle(document.querySelector('#tg img')).objectFit") == 'contain')
            pg.evaluate("() => applySkin(normalizeSkin({poster:{fit:'bogus'}}))")
            check('Ungültiger Wert fällt auf Strecken zurück', pg.evaluate("getComputedStyle(document.querySelector('#tg img')).objectFit") == 'fill')
            b.close()
    finally:
        srv.terminate()
    check('keine JS-Fehler', not errs, errs)
    print('\n%d ok, %d Fehler' % (passed, failed)); sys.exit(1 if failed else 0)
main()
