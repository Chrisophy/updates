# -*- coding: utf-8 -*-
"""Test-Scraper im Stil der echten (next_func-Dispatch, Hoster-Tupel, DRM, Embed)."""
import os

import xbmcgui
from resources.lib import multiquest, log

SITE_ID = 'fake'
SITE_NAME = 'Fake'
SITE_DOMAIN = 'site.test'
UP = os.environ.get('FAKE_UP', 'http://127.0.0.1:8811')


def load(url='', params=None):
    if not url:
        return [
            {'title': '[B]Filme[/B]', 'url': 'cat:filme', 'next_func': 'load', 'is_playable': False},
            {'title': 'Serien', 'url': 'cat:serien', 'next_func': 'get_seasons', 'is_playable': False},
            {'title': 'Suche', 'url': 'search', 'next_func': 'load', 'is_playable': False},
            {'title': 'Cache leeren', 'url': '', 'next_func': 'clear_cache', 'is_playable': False},
        ]
    if url == 'search':
        q = xbmcgui.Dialog().input('Suche')
        return search(q) if q else []
    if url == 'cat:filme':
        data = multiquest.get(UP + '/site/list', timeout=5).json()
        return [{'title': i['t'], 'url': i['id'], 'next_func': 'get_hosters', 'is_playable': True,
                 'poster': '//img.test/x.jpg|User-Agent=a', 'year': 2020, 'plot': 'Test [B]fett[/B]'}
                for i in data['items']]
    return []


def get_seasons(url='', params=None, **kw):
    return [{'title': 'Staffel %d' % s, 'url': url, 'season': s, 'episode': 0,
             'next_func': 'get_episodes', 'is_playable': False} for s in (1, 2)]


def get_episodes(url='', title='', season=0, params=None):
    return [{'title': 'Episode %d' % e, 'url': url, 'season': int(season), 'episode': e,
             'episode_anchor': 'A%d' % e, 'next_func': 'get_hosters', 'is_playable': False}
            for e in (1, 2)]


def clear_cache(url='', params=None):
    xbmcgui.Dialog().notification('Fake', 'Cache geleert')
    return []


def search(query='', params=None):
    return [{'title': 'Treffer für ' + query, 'url': 'f1', 'next_func': 'get_hosters', 'is_playable': True}]


def get_hosters(title='', year='', season=0, episode=0, imdb='', tmdb='', url='', params=None):
    if url == 'f1':
        return [
            ('Embed', UP + '/embed/abc', False, 'HD', 'de'),
            ('Kaputt', UP + '/embed/broken', False, 'SD', 'de'),
            ('HLS Referer', UP + '/master.m3u8|Referer=https://site.test/', True, 'HD', 'de'),
            ('MP4', UP + '/movie.mp4', True, 'HD', 'de'),
            ('Ohne Endung', UP + '/noext/stream', True, '', 'de'),
            ['DASH+DRM', UP + '/dash/manifest.mpd',
             {'drm_type': 'widevine', 'drm_license': UP + '/license', 'drm_token': 'TOK',
              'license_key': UP + '/license|Content-Type=application%2Foctet-stream|R{SSM}|JBlicense'},
             'HD', '', 'fake'],
        ]
    # Serien-Episode: Antwort enthält, was die Engine übergeben hat
    return [('Echo S%dE%d %s' % (int(season), int(episode), (params or {}).get('episode_anchor', '')),
             UP + '/movie.mp4', True, 'HD', 'de')]
