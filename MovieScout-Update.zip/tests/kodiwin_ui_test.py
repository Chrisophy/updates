# -*- coding: utf-8 -*-
"""Oberfläche für eigene Kodi-Fenster: Spiel startet aus der Quelle, Fenster erscheint maßstabsgerecht, Tasten/Antippen/Zurück wirken.

    python tests/kodiwin_ui_test.py
"""
import io
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from kodiwin_test import GAME, PNG, xml, zipped          # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
PORT = 8926
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def main():
    tmp = tempfile.mkdtemp(prefix='ms_kwui_')
    out = Path(tmp) / 'out.txt'
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, KW_OUT=str(out))
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=.3).close(); break
            except OSError:
                time.sleep(.25)
        time.sleep(1)
        urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/api/admin/addon/install' % PORT, method='POST', headers={'Content-Type': 'application/zip'},
                                                      data=zipped('script.game.fake', {'addon.xml': xml('script.game.fake', 'Fake-Spiel'), 'default.py': GAME, 'background.png': PNG}))).read()
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch()
            for vw, vh, mobile in ((412, 890, True), (1280, 720, False)):
                print('Bildschirm %dx%d' % (vw, vh))
                out.unlink(missing_ok=True)
                ctxb = b.new_context(viewport={'width': vw, 'height': vh}, has_touch=mobile, is_mobile=mobile)
                pg = ctxb.new_page()
                errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
                pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (PORT, PORT)); pg.wait_for_timeout(1500)
                pg.evaluate("openProvider(providers.find(p=>p.addon==='script.game.fake'))")
                pg.get_by_text('Starten: Fake-Spiel').first.click()
                try:
                    pg.wait_for_selector('text=1 Spieler', timeout=10000)
                except Exception:
                    pg.screenshot(path='/tmp/claude-0/-home-claude/a5c879af-98af-5c77-874d-c5c3390275cb/scratchpad/kw_fail.png'); print(pg.evaluate('document.body.innerText')[:800]); raise
                check('Modus-Abfrage erscheint', True)
                pg.get_by_role('button', name='2 Spieler').click()
                pg.wait_for_selector('.layer.kwin .kw-stage', timeout=10000)
                pg.wait_for_function("document.querySelectorAll('.kw-stage > *').length === 6", timeout=8000)
                check('Fenster mit 6 Steuerelementen', True)
                box = pg.evaluate("(() => { const r = document.querySelector('.kw-wrap').getBoundingClientRect(); return [r.width, r.height, r.left, r.right]; })()")
                check('Bühne im 16:9-Format, passt in die Breite', abs(box[0] / box[1] - 16 / 9) < 0.02 and box[0] <= vw + 1 and box[2] >= -1, box)
                st = pg.evaluate("(() => { const l = [...document.querySelectorAll('.kw-lbl')][1]; return [l.textContent, getComputedStyle(l).color, l.style.left, l.style.fontSize]; })()")
                check('Beschriftung: Text, Farbe schwarz, Lage, Schrift', st[0] == 'Modus 1 · Spalte 3 · Würfe 0' and st[1] == 'rgb(0, 0, 0)' and st[2] == '60px' and st[3] == '20px', st)
                img = pg.evaluate("(() => { const i = document.querySelector('.kw-img'); return [i.complete && i.naturalWidth, i.style.width]; })()")
                check('Hintergrundbild geladen', img[0] == 1 and img[1] == '1280px', img)
                check('Fokus-Markierung auf „EINWERFEN“', pg.evaluate("document.querySelector('.kw-btn.kf').textContent") == 'EINWERFEN')
                check('Versteckter Knopf ist unsichtbar', pg.evaluate("[...document.querySelectorAll('.kw-btn')].find(b=>b.textContent==='Neu starten').style.display") == 'none')
                pg.keyboard.press('ArrowRight')
                pg.wait_for_function("[...document.querySelectorAll('.kw-lbl')][1].textContent.includes('Spalte 4')", timeout=5000)
                check('Pfeiltaste -> onAction -> Anzeige ändert sich', True)
                pg.keyboard.press('Enter')
                pg.wait_for_function("[...document.querySelectorAll('.kw-lbl')][1].textContent.includes('Würfe 1')", timeout=5000)
                check('OK-Taste klickt den markierten Knopf (einmal)', pg.evaluate("[...document.querySelectorAll('.kw-lbl')][1].textContent").endswith('Würfe 1'))
                pg.locator('.kw-btn', has_text='EINWERFEN').click()
                pg.wait_for_selector('.panel input', timeout=8000)
                check('Antippen -> zweiter Wurf -> Namens-Abfrage über dem Fenster', pg.locator('.layer.kwin').count() == 1)
                pg.wait_for_timeout(600)                                            # nach der letzten Pfeiltaste: Feld nur markieren gilt 350 ms, dann echter Fokus
                pg.click('.panel input'); pg.fill('.panel input', 'Anna'); pg.keyboard.press('Enter')
                pg.wait_for_function("[...document.querySelectorAll('.kw-lbl')][0].innerHTML.includes('Sieger: Anna')", timeout=8000)
                col = pg.evaluate("getComputedStyle([...document.querySelectorAll('.kw-lbl')][0].querySelector('span span')).color")
                check('[COLOR red] wird rot dargestellt', col == 'rgb(255, 0, 0)', col)
                check('„Neu starten“ jetzt sichtbar', pg.evaluate("[...document.querySelectorAll('.kw-btn')].find(b=>b.textContent==='Neu starten').style.display") == '')
                check('Touch-Steuerkreuz ist standardmäßig aus (Einstellung „Tasten-Block“)', pg.locator('.kw-pad').count() == 0)
                pg.go_back()                                                        # Hardware-Zurück
                pg.wait_for_selector('.layer.kwin', state='detached', timeout=10000)
                check('Zurück -> Programm schließt sein Fenster', True)
                ok = False
                for _ in range(40):
                    if out.exists():
                        ok = True; break
                    time.sleep(0.25)
                check('Programm lief bis zum Ende (Spalte 4, 2 Würfe)', ok and out.read_text() == 'ende 4 2', out.read_text() if out.exists() else '')
                pg.wait_for_timeout(800)
                check('Danach wieder die Liste der Quelle', pg.get_by_text('Erneut starten').count() >= 1)
                check('Keine Skriptfehler', not errs, errs)
                ctxb.close()
            b.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
