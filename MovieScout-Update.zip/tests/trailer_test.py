# -*- coding: utf-8 -*-
"""Trailer in der Engine (gespieltes TMDB, ein nachgebautes MultiTrailer-Addon, kein Netz nötig):

    python tests/trailer_test.py
"""
import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent.parent
PORT, TMDB_PORT = 8881, 8882
API = 'http://127.0.0.1:%d' % PORT
passed = failed = 0
SEEN = []


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


VIDEOS = {
    '/movie/603/videos': [
        {'key': 'CLIP1', 'site': 'YouTube', 'type': 'Clip', 'name': 'Szene', 'iso_639_1': 'de', 'official': True, 'published_at': '2020-01-01T00:00:00.000Z'},
        {'key': 'TEN', 'site': 'YouTube', 'type': 'Trailer', 'name': 'Official Trailer', 'iso_639_1': 'en', 'official': True, 'published_at': '2019-01-01T00:00:00.000Z'},
        {'key': 'TDE', 'site': 'YouTube', 'type': 'Trailer', 'name': 'Offizieller Trailer', 'iso_639_1': 'de', 'official': True, 'published_at': '2018-01-01T00:00:00.000Z'},
        {'key': 'VIM1', 'site': 'Vimeo', 'type': 'Teaser', 'name': 'Teaser', 'iso_639_1': 'en', 'official': False, 'published_at': '2017-01-01T00:00:00.000Z'},
        {'key': 'BTS', 'site': 'YouTube', 'type': 'Behind the Scenes', 'name': 'Making of', 'iso_639_1': 'en', 'official': True},
        {'key': 'XXX', 'site': 'Dailymotion', 'type': 'Trailer', 'name': 'Fremd', 'iso_639_1': 'en'},
    ],
    '/tv/1399/videos': [{'key': 'GOT', 'site': 'YouTube', 'type': 'Trailer', 'name': 'Season Trailer', 'iso_639_1': 'en', 'official': True}],
    '/movie/700/videos': [],
}


class Tmdb(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        SEEN.append((u.path, q))
        if q.get('api_key') != 'KEY123':
            self.send_response(401); self.end_headers(); self.wfile.write(b'{}'); return
        if u.path == '/search/movie':
            t = q.get('query', '')
            out = {'results': [{'id': 603, 'title': 'Matrix', 'release_date': '1999-03-31', 'popularity': 50}] if 'matrix' in t.lower()
                   else [{'id': 700, 'title': 'Ohne Video', 'release_date': '2001-01-01', 'popularity': 5}] if 'ohne' in t.lower() else []}
        elif u.path == '/search/tv':
            out = {'results': []}
        elif u.path in VIDEOS:
            out = {'results': VIDEOS[u.path]}
        else:
            out = {}
        b = json.dumps(out).encode()
        self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(b)


ADDON_XML = '<addon id="plugin.video.multitrailer" version="1.0.0" name="MultiTrailer"><requires><import addon="xbmc.python" version="3.0.0"/></requires>' \
            '<extension point="xbmc.python.pluginsource" library="default.py"><provides>video</provides></extension></addon>'
DEFAULT = '''import sys, xbmc, xbmcgui, xbmcplugin, xbmcaddon
from urllib.parse import parse_qs
h = int(sys.argv[1]); q = {k: v[0] for k, v in parse_qs(sys.argv[2].lstrip("?")).items()}
if q.get("action") == "play":
    if q.get("title") == "Kein Treffer":
        xbmcgui.Dialog().notification("MultiTrailer", "Kein Trailer gefunden.", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
    elif q.get("title") == "Nur DASH":
        li = xbmcgui.ListItem("Dash", path="http://trailer.test/dash/manifest")
        li.setMimeType("application/dash+xml")
        xbmcplugin.setResolvedUrl(h, True, li)
    elif q.get("title") == "Nur Lokal":
        xbmcplugin.setResolvedUrl(h, True, xbmcgui.ListItem("Lokal", path="file:///tmp/multitrailer_x.mpd"))
    else:
        li = xbmcgui.ListItem(q.get("title", "") + " (Addon)", path="http://trailer.test/%s/%s.mp4?dash=%s" % (q.get("tmdb_id", "x"), q.get("media_type"), xbmcaddon.Addon().getSetting("prefer_dash")))
        xbmcplugin.setResolvedUrl(h, True, li)
else:
    xbmcplugin.addDirectoryItem(h, sys.argv[0] + "?action=play", xbmcgui.ListItem(label="Los"), False)
    xbmcplugin.endOfDirectory(h)
'''


def fake_addon():
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        z.writestr('plugin.video.multitrailer/addon.xml', ADDON_XML)
        z.writestr('plugin.video.multitrailer/default.py', DEFAULT)
        z.writestr('plugin.video.multitrailer/resources/settings.xml', '<settings><category label="A"><setting id="prefer_dash" type="bool" label="DASH" default="true"/></category></settings>')
    return b.getvalue()


def call(path, data=None, raw=None):
    body = raw if raw is not None else (json.dumps(data).encode() if data is not None else None)
    req = urllib.request.Request(API + path, data=body, headers={'Content-Type': 'application/json'} if body and raw is None else {})
    try:
        r = urllib.request.urlopen(req, timeout=60)
    except urllib.error.HTTPError as e:
        r = e
    b = r.read()
    try:
        return r.status, json.loads(b)
    except Exception:
        return r.status, b


def wait_port(port):
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=.3).close(); return True
        except OSError:
            time.sleep(.25)
    return False


def main():
    srv_t = HTTPServer(('127.0.0.1', TMDB_PORT), Tmdb)
    threading.Thread(target=srv_t.serve_forever, daemon=True).start()
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, PYTHONUNBUFFERED='1', MOVIESCOUT_TMDB_BASE='http://127.0.0.1:%d' % TMDB_PORT)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_TMDB_KEY'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        assert wait_port(PORT), 'Engine startet nicht'

        print('Ohne Schlüssel und ohne Addon')
        s, d = call('/api/trailer', {'item': {'title': 'Matrix', 'year': 1999}})
        check('404 mit Hinweis auf den TMDB-Schlüssel und MultiTrailer', s == 404 and 'TMDB' in d.get('error', '') and 'MultiTrailer' in d.get('error', ''), (s, d))
        s, d = call('/api/trailer', {'item': {}})
        check('Ohne Titel: Fehlermeldung', s == 404 and 'Titel' in d.get('error', ''), (s, d))

        call('/api/settings', {'settings': {'api.tmdb': 'KEY123'}})

        print('TMDB-Trailer')
        s, d = call('/api/trailer', {'item': {'title': 'Matrix', 'year': 1999}})
        hs = d.get('hosters') or []
        check('Antwort 200 mit Quellen', s == 200 and hs, (s, d))
        check('Nur YouTube/Vimeo, Making-of und Fremdanbieter fehlen', [h['url'].split('/embed/')[-1].split('/video/')[-1].split('?')[0] for h in hs] == ['TDE', 'TEN', 'VIM1', 'CLIP1'],
              [h['url'] for h in hs])
        check('Deutscher Trailer steht vor dem englischen, Teaser/Clip dahinter', hs[0]['lang'] == 'de' and hs[1]['lang'] == 'en' and hs[2]['name'].startswith('Teaser'), [h['name'] for h in hs])
        check('Einbettung ohne Cookies, mit Autoplay', hs[0]['url'].startswith('https://www.youtube-nocookie.com/embed/TDE?') and 'autoplay=1' in hs[0]['url'], hs[0]['url'])
        check('Vimeo über player.vimeo.com', hs[2]['url'].startswith('https://player.vimeo.com/video/VIM1'), hs[2]['url'])
        check('Jede Quelle ist als Trailer/Einbettung markiert und nummeriert', all(h['trailer'] and h['format'] == 'embed' and h['direct'] is False for h in hs) and [h['id'] for h in hs] == list(range(len(hs))))
        check('TMDB wurde deutsch mit Sprachen de,en,null gefragt', any(p.endswith('/videos') and p.startswith('/movie/603') and q.get('language') == 'de-DE' and q.get('include_video_language') == 'de,en,null' for p, q in SEEN), SEEN[-3:])
        n = len(SEEN)
        call('/api/trailer', {'item': {'title': 'Matrix', 'year': 1999}})
        check('Zweite Anfrage kommt aus dem Zwischenspeicher', len(SEEN) == n)

        s, d = call('/api/trailer', {'item': {'title': 'Serie', 'tmdb': 1399, 'kind': 'tv'}})
        check('Mit TMDB-Nummer und Art „tv“ direkt ohne Suche', s == 200 and d['hosters'][0]['url'].find('/embed/GOT') > 0 and d['kind'] == 'tv', (s, d))
        s, d = call('/api/trailer', {'item': {'title': 'Ohne Video', 'year': 2001}})
        check('Titel ohne Video: 404 „kein Trailer gefunden“', s == 404 and 'kein Trailer' in d.get('error', ''), (s, d))
        s, d = call('/api/trailer', {'item': {'title': 'Gibt es nicht'}})
        check('Unbekannter Titel: 404', s == 404 and 'kein Trailer' in d.get('error', ''), (s, d))

        print('Abspielen im Player')
        s, p = call('/api/play', {'hoster': hs[0]})
        check('YouTube-Trailer: Plan „embed“ direkt (ohne Hoster-Auflösung), als Trailer markiert', s == 200 and p.get('mode') == 'embed' and p.get('trailer') is True and p['embed_url'] == hs[0]['url'], (s, p))
        s, p = call('/api/play', {'hoster': {'name': 'x', 'url': 'https://www.youtube-nocookie.com/embed/ABC', 'format': 'embed'}})
        check('Ohne Trailer-Markierung geht es den normalen Weg (kein Kurzschluss)', not p.get('trailer'), p)

        print('Mit MultiTrailer-Addon')
        s, d = call('/api/admin/addon/install', raw=fake_addon())
        check('Addon installiert', s == 200 and d.get('ok'), (s, d))
        s, d = call('/api/trailer', {'item': {'title': 'Matrix', 'year': 1999}})
        hs = d.get('hosters') or []
        check('Addon-Stream steht vor den YouTube-Quellen', s == 200 and len(hs) == 5 and hs[0]['url'] == 'http://trailer.test/603/movie.mp4?dash=false' and 'MultiTrailer' in hs[0]['name'], [(h['name'], h['url']) for h in hs])
        check('„DASH bevorzugen“ ist für den Web-Player aus (dash=false), die Nummern laufen durch', hs[0]['trailer'] is True and [h['id'] for h in hs] == list(range(5)), hs[:2])
        s, d = call('/api/trailer', {'item': {'title': 'Kein Treffer'}})
        check('Findet das Addon nichts und TMDB auch nicht: Meldung des Addons', s == 404 and 'Kein Trailer' in d.get('error', ''), (s, d))
        s, d = call('/api/trailer', {'item': {'title': 'Matrix', 'year': 1999, 'tmdb': 603}})
        check('Gleiche Nummer an das Addon weitergereicht', d['hosters'][0]['url'] == 'http://trailer.test/603/movie.mp4?dash=false', d)

        print('DASH-Einstellung im Formular „an“ gespeichert (Fehler „DASH-Fehler … is not available“ im Player)')
        s, d = call('/api/admin/addon/settings?id=plugin.video.multitrailer', {'values': {'prefer_dash': True}})
        check('Formular speichert „DASH bevorzugen = an“', s == 200 and d.get('saved', {}).get('prefer_dash') == 'true', (s, d))
        s, d = call('/api/trailer', {'item': {'title': 'Matrix', 'year': 1999, 'tmdb': 604}})
        check('Trailer-Abruf schaltet es für den Web-Player trotzdem aus (dash=false)', s == 200 and d['hosters'][0]['url'].endswith('?dash=false'), (s, d))
        call('/api/admin/addon/settings?id=plugin.video.multitrailer', {'values': {'prefer_dash': True}})
        s, d = call('/api/resolve', {'provider_id': 'addon_plugin_video_multitrailer', 'item': {'title': 'Resident', 'url': 'plugin://plugin.video.multitrailer/?action=play&title=Resident', 'next_func': 'get_hosters'}})
        check('Auch beim normalen Abspielen aus der Quellenliste bleibt „DASH bevorzugen“ aus', s == 200 and d['hosters'] and d['hosters'][0]['url'].endswith('?dash=false'), (s, d))
        s, d = call('/api/admin/addon/settings?id=plugin.video.multitrailer')
        check('Einstellungsformular zeigt „DASH bevorzugen“ als aus, mit Erklärung', s == 200 and [f for f in d['fields'] if f['id'] == 'prefer_dash'][0]['value'] is False and 'immer aus' in [f for f in d['fields'] if f['id'] == 'prefer_dash'][0]['help'], d)
        s, d = call('/api/trailer', {'item': {'title': 'Nur Lokal'}})
        check('Nur lokale Dateiadresse (file://): wird nicht angeboten, Meldung statt kaputtem Player', s == 404 and 'Trailer' in d.get('error', ''), (s, d))

        s, d = call('/api/trailer', {'item': {'title': 'Nur DASH'}})
        check('DASH-Quelle des Addons wird nie angeboten (Player kann sie nicht) – Meldung statt „DASH-Fehler“', s == 404 and 'DASH' in d.get('error', ''), (s, d))

        print('Nur Addon (ohne TMDB-Schlüssel)')
        call('/api/settings', {'settings': {'api.tmdb': ''}})
        s, d = call('/api/trailer', {'item': {'title': 'Matrix', 'year': 1999, 'kind': 'tv'}})
        check('Ohne Schlüssel liefert das Addon allein', s == 200 and len(d['hosters']) == 1 and d['hosters'][0]['url'] == 'http://trailer.test/x/tv.mp4?dash=false', (s, d))
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=8)
        except Exception:
            srv.kill()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
