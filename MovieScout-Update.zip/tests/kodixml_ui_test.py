# -*- coding: utf-8 -*-
"""Oberfläche für Fenster aus Skin-Dateien (WindowXML): Start aus der Quelle, Zeichnung (Knöpfe, Liste mit Zeilen, Bedingungen),
Tasten, Antippen, Zurück.

    python tests/kodixml_ui_test.py
"""
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from kodixml_test import DEMO, INCLUDES, MAIN, PNG, PO, addon_xml, zipped          # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
PORT = 8947
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def main():
    tmp = tempfile.mkdtemp(prefix='ms_kxui_')
    out = Path(tmp) / 'out.txt'
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, KW_OUT=str(out))
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=.3).close(); break
            except OSError:
                time.sleep(.25)
        time.sleep(1)
        urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/api/admin/addon/install' % PORT, method='POST', headers={'Content-Type': 'application/zip'},
                                                      data=zipped('script.xml.demo', {
                                                          'addon.xml': addon_xml('script.xml.demo', 'Skin-Demo'), 'default.py': DEMO,
                                                          'resources/skins/Default/1080i/Main.xml': MAIN, 'resources/skins/Default/1080i/Includes.xml': INCLUDES,
                                                          'resources/skins/Default/media/bg.png': PNG,
                                                          'resources/language/resource.language.en_gb/strings.po': PO}))).read()
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch()
            for vw, vh, mobile in ((412, 890, True), (1280, 720, False)):
                print('Bildschirm %dx%d' % (vw, vh))
                out.unlink(missing_ok=True)
                ctxb = b.new_context(viewport={'width': vw, 'height': vh}, has_touch=mobile, is_mobile=mobile)
                pg = ctxb.new_page()
                errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
                pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (PORT, PORT)); pg.wait_for_timeout(1500)
                pg.evaluate("openProvider(providers.find(p=>p.addon==='script.xml.demo'))")
                pg.get_by_text('Starten: Skin-Demo').first.click()
                pg.wait_for_selector('.layer.kwin .kw-stage', timeout=15000)
                pg.wait_for_function("document.querySelectorAll('.kw-list > .kr').length === 3 && [...document.querySelectorAll('.kw-lbl')].some(l => l.textContent === 'Hallo Anna')", timeout=10000)
                check('Skin-Fenster erscheint als Dialog (halb durchsichtiger Hintergrund)', pg.evaluate("document.querySelector('.layer.kwin').classList.contains('kdlg')"))
                check('Alle Steuerelemente sind gezeichnet (11)', pg.evaluate("document.querySelectorAll('.kw-stage > *').length") == 11)
                check('Fokus-Markierung auf dem Standardknopf „Los“', pg.evaluate("document.querySelector('.kw-btn.kf').textContent") == 'Los')
                box = pg.evaluate("(() => { const r = document.querySelector('.kw-wrap').getBoundingClientRect(); return [r.width, r.left, r.right]; })()")
                check('Bühne passt in die Bildschirmbreite', box[1] >= -1 and box[2] <= vw + 1, box)
                rows = pg.evaluate("[...document.querySelectorAll('.kw-list > .kr')].map(r => r.querySelector('.kt1').textContent + '|' + (r.querySelector('.kt2') ? r.querySelector('.kt2').textContent : ''))")
                check('Liste: drei Zeilen, erste mit zweiter Zeile', rows == ['Eins|erste', 'Zwei|', 'Drei|'], rows)
                hidden = pg.evaluate("[...document.querySelectorAll('.kw-btn')].find(b => b.textContent === 'Geheim').style.display")
                check('Bedingung: „Geheim“ ist versteckt', hidden == 'none', hidden)
                check('Bedingung am Fokus: Text „Fokus auf Start“ sichtbar', pg.evaluate("[...document.querySelectorAll('.kw-lbl')].find(l => l.textContent === 'Fokus auf Start').style.display") == '')
                pg.keyboard.press('ArrowDown')
                pg.wait_for_function("document.querySelector('.kw-btn.kf') && document.querySelector('.kw-btn.kf').textContent === 'Weiter'", timeout=5000)
                check('Pfeil runter: Fokus wandert zu „Weiter“', True)
                check('…und „Fokus auf Start“ verschwindet', pg.evaluate("[...document.querySelectorAll('.kw-lbl')].find(l => l.textContent === 'Fokus auf Start').style.display") == 'none')
                pg.locator('.kw-btn', has_text='Weiter').click()
                pg.wait_for_function("[...document.querySelectorAll('.kw-btn')].find(b => b.textContent === 'Geheim').style.display === ''", timeout=8000)
                check('Antippen „Weiter“: Programm setzt Eigenschaft, „Geheim“ erscheint', True)
                pg.keyboard.press('ArrowRight')
                pg.wait_for_function("document.querySelector('.kw-list.kf')", timeout=5000)
                pg.keyboard.press('ArrowDown')
                pg.wait_for_function("document.querySelectorAll('.kw-list > .kr')[1].classList.contains('ks')", timeout=5000)
                check('Liste: Fokus per Pfeil rechts, Zeile 2 markiert', True)
                pg.locator('.kw-list > .kr').nth(2).click()
                pg.wait_for_function("document.querySelectorAll('.kw-list > .kr')[2].classList.contains('ks')", timeout=5000)
                check('Antippen einer Zeile markiert sie', 'item Drei' in out.read_text() if out.exists() else False, out.read_text() if out.exists() else '')
                ow = pg.evaluate('document.documentElement.scrollWidth')
                check('Kein seitliches Scrollen', ow <= vw + 1, ow)
                pg.keyboard.press('Escape')
                pg.wait_for_selector('.layer.kwin', state='detached', timeout=10000)
                check('Escape -> onAction(10) -> Fenster schließt', 'action 10' in out.read_text() and 'ende' in out.read_text())
                check('Keine Skriptfehler', not errs, errs)
                ctxb.close()
            b.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
