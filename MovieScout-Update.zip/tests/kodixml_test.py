# -*- coding: utf-8 -*-
"""Fenster aus Kodi-Skin-Dateien (WindowXML / WindowXMLDialog): XML mit Includes, Konstanten, Variablen, 1080i, Sichtbarkeits-Bedingungen,
Gruppenlisten, Listen, Fokus-Navigation, Klicks, Eigenschaften -> Neuzeichnen, onInit/onClick/onAction, Fehlerfälle.

    python tests/kodixml_test.py
"""
import base64
import io
import json
import os
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
PORT = 8946
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==')


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, raw=None, timeout=60):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    req = Request(BASE + path, data=data, method='POST' if data is not None else 'GET',
                  headers={'Content-Type': 'application/zip' if raw is not None else 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=timeout) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt


def zipped(aid, files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for n, c in files.items():
            z.writestr(aid + '/' + n, c)
    return b.getvalue()


def addon_xml(aid, name):
    return ('<addon id="%s" name="%s" version="1.0.0"><requires><import addon="xbmc.python" version="3.0.0"/></requires>'
            '<extension point="xbmc.python.script" library="default.py"><provides>executable</provides></extension></addon>') % (aid, name)


INCLUDES = '''<?xml version="1.0" encoding="UTF-8"?>
<includes>
  <constant name="BtnW">600</constant>
  <expression name="BtnH">90</expression>
  <include name="Btn">
    <param name="id" default="0"/>
    <param name="text" default=""/>
    <definition>
      <control type="button" id="$PARAM[id]">
        <width>$CONSTANT[BtnW]</width>
        <height>$EXP[BtnH]</height>
        <label>$PARAM[text]</label>
        <onclick>SetProperty(last,$PARAM[id])</onclick>
      </control>
    </definition>
  </include>
  <variable name="Greeting">
    <value condition="!String.IsEmpty(Window.Property(user))">Hallo $INFO[Window.Property(user)]</value>
    <value>Hallo Fremder</value>
  </variable>
</includes>
'''

MAIN = '''<?xml version="1.0" encoding="UTF-8"?>
<window>
  <defaultcontrol always="true">200</defaultcontrol>
  <coordinates><left>240</left><top>135</top></coordinates>
  <onload>SetProperty(geladen,ja)</onload>
  <controls>
    <control type="image"><left>0</left><top>0</top><width>100%</width><height>100%</height><texture>bg.png</texture><aspectratio>scale</aspectratio></control>
    <control type="group" id="50">
      <left>100</left><top>100</top>
      <control type="label" id="100">
        <left>0</left><top>0</top><width>900</width><height>60</height>
        <label>$VAR[Greeting]</label><font>font14</font><textcolor>FFEEEEEE</textcolor>
      </control>
      <control type="grouplist" id="60">
        <left>0</left><top>100</top><width>600</width><height>600</height><itemgap>20</itemgap><orientation>vertical</orientation>
        <onright>300</onright>
        <include content="Btn"><param name="id" value="200"/><param name="text" value="Start"/></include>
        <include content="Btn"><param name="id" value="201"/><param name="text" value="$LOCALIZE[30001]"/></include>
        <control type="button" id="202">
          <width>600</width><height>90</height><label>Geheim</label>
          <visible>String.IsEqual(Window.Property(show),yes)</visible>
        </control>
        <control type="radiobutton" id="203">
          <width>600</width><height>90</height><label>Ton</label>
          <selected>String.IsEqual(Window.Property(sound),on)</selected>
          <onclick>SetProperty(sound,on)</onclick>
        </control>
      </control>
      <control type="list" id="300">
        <left>800</left><top>100</top><width>800</width><height>600</height>
        <itemlayout height="100" width="800"><control type="label"><label>$INFO[ListItem.Label]</label></control></itemlayout>
        <onleft>200</onleft>
      </control>
      <control type="label" id="400">
        <left>800</left><top>720</top><width>800</width><height>60</height>
        <label>$INFO[Container(300).NumItems] Einträge · gewählt: $INFO[Container(300).ListItem.Label]</label>
        <visible>Integer.IsGreater(Container(300).NumItems,0)</visible>
      </control>
      <control type="label" id="401">
        <left>0</left><top>800</top><width>800</width><height>60</height>
        <label>Fokus auf Start</label>
        <visible>Control.HasFocus(200)</visible>
      </control>
    </control>
  </controls>
</window>
'''

DEMO = r'''
import os, xbmc, xbmcaddon, xbmcgui
OUT = os.environ['KW_OUT']
def log(s):
    with open(OUT, 'a') as f:
        f.write(s + '\n')
class Dlg(xbmcgui.WindowXMLDialog):
    def __init__(self, *a, **k):
        xbmcgui.WindowXMLDialog.__init__(self)
    def onInit(self):
        log('init %d geladen=%s' % (self.getFocusId(), self.getProperty('geladen')))
        li = xbmcgui.ListItem('Eins'); li.setLabel2('erste')
        self.getControl(300).addItems([li, xbmcgui.ListItem('Zwei'), xbmcgui.ListItem('Drei')])
        log('size %d' % self.getListSize())
        self.setProperty('user', 'Anna')
        self.getControl(200).setLabel('Los')
    def onClick(self, cid):
        log('click %d' % cid)
        if cid == 201:
            log('last=' + self.getProperty('last'))
        if cid == 201:
            self.setProperty('show', 'yes')
        if cid == 300:
            log('item ' + self.getControl(300).getSelectedItem().getLabel())
            log('pos %d %s' % (self.getCurrentListPosition(), self.getListItem(0).getLabel()))
    def onFocus(self, cid):
        log('focus %d' % cid)
    def onAction(self, a):
        log('action %d' % a.getId())
        if a.getId() in (10, 92):
            self.close()
path = xbmcaddon.Addon().getAddonInfo('path')
d = Dlg('Main.xml', path, 'Default', '1080i')
d.doModal()
log('ende %s' % xbmcgui.getCurrentWindowDialogId())
del d
'''

BROKEN = r'''
import xbmcaddon, xbmcgui
path = xbmcaddon.Addon().getAddonInfo('path')
xbmcgui.WindowXML('Gibtsnicht.xml', path, 'Default', '720p').doModal()
open(__import__("os").environ["KW_OUT"] + ".broken", "w").write("weiter")
'''

PO = '''msgid ""
msgstr ""

msgctxt "#30001"
msgid "Weiter"
msgstr "Weiter"
'''


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_kxml_'))
    out = tmp / 'out.txt'
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1', KW_OUT=str(out),
               MOVIESCOUT_DIALOG_GONE='6')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=.3).close(); break
            except OSError:
                time.sleep(.25)
        time.sleep(1)
        c, r = http('/api/admin/addon/install', raw=zipped('script.xml.demo', {
            'addon.xml': addon_xml('script.xml.demo', 'Skin-Demo'), 'default.py': DEMO,
            'resources/skins/Default/1080i/Main.xml': MAIN, 'resources/skins/Default/1080i/Includes.xml': INCLUDES,
            'resources/skins/Default/media/bg.png': PNG, 'resources/language/resource.language.en_gb/strings.po': PO}))
        check('Addon mit Skin-Fenster installiert', c == 200, r)
        http('/api/admin/addon/install', raw=zipped('script.xml.broken', {'addon.xml': addon_xml('script.xml.broken', 'Kaputt'), 'default.py': BROKEN}))

        print('Fenster öffnen')
        rid = secrets.token_hex(12)
        res = {}
        th = threading.Thread(target=lambda: res.update(r=http('/api/admin/addon/run', {'id': 'script.xml.demo', 'rid': rid}, timeout=120)))
        th.start()

        def poll(wid='', wv=-1, wait=3):
            return http('/api/dialog?rid=%s&wait=%s&wid=%s&wv=%d' % (rid, wait, wid, wv))[1]

        def until(pred, wid, wv, tries=12):
            d = {}
            for _ in range(tries):
                d = poll(wid, wv, wait=1)
                w = d.get('window')
                if w:
                    wv = w['ver']
                    if pred(w):
                        return d, w
            return d, d.get('window') or {}
        d = poll()
        w = d.get('window')
        check('Das Fenster kommt als Skin-Fenster (Abbild des Dialogs)', bool(w) and w.get('xml') is True and w.get('dlg') is True and w['full'], d)
        wid, wv = w['id'], w['ver']
        d, w = until(lambda w: any(c['id'] == 100 and c.get('label') == 'Hallo Anna' for c in w['controls']), wid, wv)
        by = {c['id']: c for c in w.get('controls', [])}
        check('Alle 11 Steuerelemente aus dem XML (inkl. der Includes; das Bild ohne Kennung bekommt eine eigene) sind da', len(by) == 11 and {100, 200, 201, 202, 203, 300, 400, 401, 50, 60} <= set(by), sorted(by))
        check('Includes: Knopf aus Vorlage mit Parametern, Konstante und Ausdruck (600x90 in 1080i -> 400x60)',
              (by[201]['w'], by[201]['h']) == (400, 60) and by[200]['t'] == 'button', by.get(201))
        check('Variable $VAR: „Hallo Anna“, nachdem onInit die Eigenschaft gesetzt hat', by[100]['label'] == 'Hallo Anna', by.get(100))
        check('Python setLabel („Los“) geht vor dem XML („Start“)', by[200]['label'] == 'Los', by.get(200))
        check('$LOCALIZE[30001] aus der Sprachdatei des Addons', by[201]['label'] == 'Weiter', by.get(201))
        check('Lage: Fensterversatz + Gruppe + 1080i->720p (Beschriftung bei 227/157)', (by[100]['x'], by[100]['y'], by[100]['w'], by[100]['h']) == (227, 157, 600, 40), by.get(100))
        check('Gruppenliste legt Knöpfe untereinander (90 + Abstand 20 -> 60 + 13)', by[200]['y'] == 223 and by[201]['y'] == 297 and by[200]['x'] == by[201]['x'] == 227, (by[200], by[201]))
        check('Bedingung <visible>: „Geheim“ versteckt, braucht keinen Platz (Ton rückt auf)', by[202]['vis'] is False and by[203]['y'] == 370, (by[202], by[203]))
        img = next(c for c in w['controls'] if c['t'] == 'image')
        check('Bild: 100 % = 1280x720, Textur aus dem Skin-Medienordner, „scale“ = füllen', (img['w'], img['h']) == (1280, 720) and img['img'].startswith('/api/dialog/file/') and img['aspect'] == 1, img)
        check('Standardfokus laut <defaultcontrol> (200)', w['focus'] == 200, w['focus'])
        lst = by[300]
        check('Liste mit Zeilen (Titel, zweite Zeile) und Zeilenbreite', lst['t'] == 'list' and [r[0] for r in lst['rows']] == ['Eins', 'Zwei', 'Drei'] and lst['rows'][0][1] == 'erste', lst)
        check('$INFO[Container(300).NumItems] und ListItem.Label in der Beschriftung', by[400]['label'] == '3 Einträge · gewählt: Eins' and by[400]['vis'] is True, by.get(400))
        check('Control.HasFocus(200) in <visible> -> „Fokus auf Start“ sichtbar', by[401]['vis'] is True, by.get(401))
        wv = w['ver']

        print('Tasten und Fokus')
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 4}})
        d, w = until(lambda w: w['focus'] != 200, wid, wv)
        by = {c['id']: c for c in w['controls']}
        check('Pfeil runter: Fokus auf den nächsten Knopf (201)', w['focus'] == 201, w['focus'])
        check('Bedingung folgt dem Fokus: „Fokus auf Start“ jetzt versteckt', by[401]['vis'] is False, by.get(401))
        wv = w['ver']
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 2}})
        d, w = until(lambda w: w['focus'] == 300, wid, wv)
        check('Pfeil rechts: <onright> springt in die Liste (300)', w['focus'] == 300, w['focus'])
        wv = w['ver']
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 4}})
        d, w = until(lambda w: next(c for c in w['controls'] if c['id'] == 300)['sel'] == 1, wid, wv)
        by = {c['id']: c for c in w['controls']}
        check('Pfeil runter in der Liste: nächste Zeile; Beschriftung „gewählt: Zwei“', by[300]['sel'] == 1 and by[400]['label'] == '3 Einträge · gewählt: Zwei', (by[300].get('sel'), by[400]['label']))
        wv = w['ver']
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 7}})
        time.sleep(0.5)
        txt = out.read_text()
        check('OK auf der Liste -> onClick(300) mit gewähltem Eintrag, dazu onAction(7)', 'click 300\nitem Zwei' in txt and 'action 7' in txt, txt)
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 1}})
        d, w = until(lambda w: w['focus'] == 200, wid, wv)
        check('Hauptliste des Fensters: getListSize / getCurrentListPosition / getListItem', 'size 3' in txt and 'pos 1 Eins' in txt, txt)
        check('Pfeil links: <onleft> geht zurück zu „Start“ (200)', w['focus'] == 200, w['focus'])
        wv = w['ver']

        print('Klicks, XML-Befehle und Eigenschaften')
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'click', 'cid': 201}})
        d, w = until(lambda w: any(c['id'] == 202 and c['vis'] for c in w['controls']), wid, wv)
        by = {c['id']: c for c in w['controls']}
        check('Klick auf „Weiter“ -> onClick(201) -> Python setzt Eigenschaft -> „Geheim“ erscheint', by[202]['vis'] is True and 'click 201' in out.read_text(), by.get(202))
        check('<onclick>SetProperty(last,201)</onclick> lief vor onClick', 'last=201' in out.read_text(), out.read_text())
        wv = w['ver']
        check('Ton-Schalter zuerst aus', by[203]['on'] is False, by.get(203))
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'click', 'cid': 203}})
        d, w = until(lambda w: any(c['id'] == 203 and c.get('on') for c in w['controls']), wid, wv)
        by = {c['id']: c for c in w['controls']}
        check('Schalter: <selected> folgt der Eigenschaft, die <onclick> setzt', by[203].get('on') is True, by.get(203))
        wv = w['ver']

        print('Schließen')
        http('/api/dialog', {'rid': rid, 'win': wid, 'ev': {'t': 'act', 'id': 92}})
        th.join(15)
        c, r = res.get('r', (0, {}))
        check('Zurück -> Standard schließt das Fenster, Aufruf endet', c == 200 and r.get('ok'), res)
        txt = out.read_text()
        check('Reihenfolge: init (Fokus 200, <onload> gelaufen) -> … -> action 92 -> ende', txt.startswith('init 200 geladen=ja\n') and 'action 92' in txt and txt.strip().endswith('ende 9999'), txt)
        check('onFocus meldete die Fokuswechsel', 'focus 201' in txt and 'focus 300' in txt and 'focus 200' in txt, txt)

        print('Fehlerfälle')
        c, r = http('/api/admin/addon/run', {'id': 'script.xml.broken'})
        notes = r.get('notes', []) if isinstance(r, dict) else []
        check('Fehlende Fensterdatei: Klartext-Hinweis, Programm läuft danach weiter', c == 200 and any('Gibtsnicht.xml' in n.get('message', '') for n in notes), r)
        check('…und das Programm wurde nicht abgebrochen', Path(str(out) + '.broken').exists())
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
