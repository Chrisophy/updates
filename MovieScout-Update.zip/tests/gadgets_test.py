# -*- coding: utf-8 -*-
"""Test der mitgelieferten Gadgets (Statistik, Gesehen-Haken, Jugendschutz-Filter, Zufallsfilm) mit echter Engine.

    python tests/gadgets_test.py
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8895
passed = failed = 0
GADGETS = ('statistik', 'gesehen', 'jugendschutz', 'zufall', 'quellen_waechter', 'feiertage', 'filmtipp', 'handy_verbinden', 'notizen', 'countdown', 'himmel', 'spruch', 'minispiele')

TP = '''# -*- coding: utf-8 -*-
SITE_ID = 'tp'
SITE_NAME = 'Testquelle'
SITE_DOMAIN = 'tp.test'


def load(url='', params=None):
    if not url:
        return [
            {'title': 'Filme', 'url': 'cat:filme', 'next_func': 'load', 'is_playable': False},
            {'title': 'Serien', 'url': 'cat:serien', 'next_func': 'get_seasons', 'is_playable': False},
            {'title': 'Seite 2', 'url': 'p2', 'next_func': 'load', 'is_playable': False},
            {'title': 'Erotik Kanal', 'url': 'cat:erotik', 'next_func': 'load', 'is_playable': False},
        ]
    if url == 'cat:filme':
        return [{'title': t, 'url': 'u-' + t.lower().replace(' ', '-'), 'next_func': 'get_hosters', 'is_playable': True}
                for t in ('Alpha', 'Beta', 'Erotik Nacht', 'Essex Krimi', 'Gamma XXX Special', 'Sex Tape Party')]
    return []


def get_seasons(url='', params=None, **kw):
    return []


def search(query='', params=None):
    return []


def get_hosters(title='', year='', season=0, episode=0, imdb='', tmdb='', url='', params=None):
    return []
'''
TP3 = '''# -*- coding: utf-8 -*-
import os
SITE_ID = 'tp3'
SITE_NAME = 'Kaputt Test'
SITE_DOMAIN = 'tp3.test'
FLAG = os.environ.get('GAD_FLAG', '')


def load(url='', params=None):
    if FLAG and os.path.exists(FLAG):
        raise RuntimeError('Seite ist down')
    return [{'title': 'Lebt', 'url': 'x', 'next_func': 'get_hosters', 'is_playable': True}]


def search(query='', params=None):
    return []


def get_hosters(title='', year='', season=0, episode=0, imdb='', tmdb='', url='', params=None):
    return []
'''
TP2 = TP.replace("'tp'", "'tp2'").replace("'Testquelle'", "'Tube8 Test'").replace("tp.test", "tp2.test")


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request('http://127.0.0.1:%d%s' % (PORT, path), data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=60) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=6):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(0.15)
    return False


def titles(pid='tp', url='cat:filme'):
    code, out = http('/api/open', {'provider_id': pid, 'item': {'url': url, 'next_func': 'load'}})
    return [i['title'] for i in out.get('items', [])] if code == 200 else None


def setv(ext, **values):
    code, js = http('/api/admin/ext/settings', {'ext': ext, 'values': values})
    http('/api/cache/clear', {})
    return code


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_gad_'))
    provs = tmp / 'providers'
    provs.mkdir()
    (provs / 'tp.py').write_text(TP, 'utf-8')
    (provs / 'tp2.py').write_text(TP2, 'utf-8')
    (provs / 'tp3.py').write_text(TP3, 'utf-8')
    flag = tmp / 'down.flag'
    flag.write_text('x')
    env = dict(os.environ, MINIKODI_PROVIDERS=str(provs), MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1', GAD_FLAG=str(flag))
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)
        print('Installieren')
        for gid in GADGETS:
            code, js = http('/api/admin/examples/install', {'id': gid})
            check('%s installiert' % gid, code == 200 and js.get('ok'), (code, js))
        code, lst = http('/api/admin/list?kind=extension')
        rows = {r['file']: r for r in (lst if isinstance(lst, list) else lst.get('files') or lst.get('items') or [])}
        code, js = http('/api/admin/examples/install', {'all': True})
        got = js.get('installed') or []
        check('„Alle installieren“: übrige Gadgets kommen mit, Filter (Jugendschutz, Titel-Putzer, Hoster-Sortierer) nicht', code == 200 and 'pong' in got and 'tetris' in got
              and not ({'jugendschutz', 'titel_putzer', 'hoster_sortierer'} & set(got)), (code, js))
        code, js = http('/api/admin/examples/install', {'all': True})
        check('Zweites „Alle installieren“ installiert nichts doppelt', code == 200 and js.get('installed') == [], (code, js))
        code, ex = http('/api/admin/examples')
        check('Beispiele-Liste meldet je Eintrag, ob er zu „Alle“ gehört', code == 200 and any(e.get('bulk') is False for e in ex['examples']), ex)
        check('alle vier geladen, ohne Fehler', all(f + '.py' in rows for f in GADGETS), list(rows))
        bad = [f for f, r in rows.items() if (r.get('info') or {}).get('error')]
        check('keine Erweiterung meldet einen Fehler', not bad and all((rows[f + '.py'].get('info') or {}).get('hooks') is not None for f in GADGETS), bad)

        print('Jugendschutz-Filter')
        t = titles()
        check('Standardwörter: "Erotik Nacht" und "Gamma XXX Special" weg', t and 'Erotik Nacht' not in t and 'Gamma XXX Special' not in t, t)
        check('Harmlose Titel bleiben ("Alpha", "Beta", "Essex Krimi")', t and {'Alpha', 'Beta', 'Essex Krimi'} <= set(t), t)
        root = titles(url='')
        check('Ordner "Erotik Kanal" verschwindet aus dem Menü, "Filme" bleibt', root and 'Erotik Kanal' not in root and 'Filme' in root, root)
        code, page = http('/api/x/jugendschutz/index')
        check('Kontrollseite zeigt, was entfernt wurde', code == 200 and 'Erotik Nacht' in page and 'Wort: ' in page, str(page)[:200])
        setv('jugendschutz', woerter='sex, nackt*')
        t = titles()
        check('Ganze Wörter: "sex" blendet "Sex Tape Party" aus, "Essex Krimi" bleibt', t and 'Sex Tape Party' not in t and 'Essex Krimi' in t and 'Erotik Nacht' in t, t)
        setv('jugendschutz', woerter='')
        t = titles()
        check('Leere Wörterliste: nichts wird ausgeblendet', t and len(t) == 6, t)
        setv('jugendschutz', quellen='tube8')
        check('Quelle ausblenden: "Tube8 Test" liefert nichts, "Testquelle" schon', titles('tp2') == [] and len(titles('tp')) == 6, (titles('tp2'), titles('tp')))
        setv('jugendschutz', quellen='', aktiv=False, woerter='alpha')
        check('Filter aus: alles sichtbar', len(titles()) == 6)
        setv('jugendschutz', aktiv=True, woerter='erotik*, porn*, xxx')
        check('Filter wieder an', 'Erotik Nacht' not in titles())
        code, js = http('/api/x/jugendschutz/leeren', method='GET')
        check('Liste leeren nur per POST', code == 405, (code, js))

        print('Gesehen-Haken')
        item = {'title': 'Alpha', 'url': 'u-alpha', 'provider_id': 'tp', 'provider': 'Testquelle', 'kind': 'play'}
        check('Vorher kein Haken', 'Alpha' in titles())
        http('/api/event', {'type': 'stop', 'item': item, 'info': {'position': 3500, 'duration': 3600, 'finished': False}})
        check('Fast zu Ende geschaut (97 %) -> "✓ Alpha"', wait(lambda: '✓ Alpha' in titles()), titles())
        beta = dict(item, title='Beta', url='u-beta')
        http('/api/event', {'type': 'stop', 'item': beta, 'info': {'position': 100, 'duration': 3600, 'finished': False}})
        time.sleep(0.6)
        check('Nur kurz geschaut (3 %) -> kein Haken', 'Beta' in titles() and '✓ Beta' not in titles(), titles())
        code, js = http('/api/ext/action', {'ext': 'gesehen', 'id': 'gesehen_ungesehen', 'item': beta})
        if code != 200:                                    # Kennung aus der Oberfläche holen
            ui = http('/api/ext/ui')[1]
            aid = [a['id'] for a in ui['actions'] if a['ext'] == 'gesehen'][0]
            code, js = http('/api/ext/action', {'ext': 'gesehen', 'id': aid, 'item': beta})
        check('Knopf markiert von Hand als gesehen', code == 200 and 'gesehen' in js.get('message', '') and '✓ Beta' in titles(), (code, js, titles()))
        ui = http('/api/ext/ui')[1]
        aid = [a['id'] for a in ui['actions'] if a['ext'] == 'gesehen'][0]
        code, js = http('/api/ext/action', {'ext': 'gesehen', 'id': aid, 'item': dict(beta, title='✓ Beta')})
        check('Zweiter Druck nimmt den Haken wieder weg', code == 200 and 'Beta' in titles() and '✓ Beta' not in titles(), (js, titles()))
        check('Gesehen-Liste zeigt Alpha', 'Alpha' in http('/api/x/gesehen/liste')[1])

        print('Statistik')
        code, d = http('/api/x/statistik/daten')
        check('Alpha (3500 s) und Beta (100 s) sind gezählt - ohne play-Meldung gilt die Position', code == 200 and d['count'] == 2 and d['sums']['week'] == 3600, d['sums'])
        check('Titel ohne Haken gespeichert', d['titles'] and d['titles'][0]['name'] == 'Alpha', d['titles'])
        http('/api/event', {'type': 'stop', 'item': dict(item, title='Gamma'), 'info': {'position': 20, 'duration': 3600}})
        time.sleep(0.5)
        check('Unter 60 s zählt nicht', http('/api/x/statistik/daten')[1]['count'] == 2)
        setv('statistik', min_sek=0)
        http('/api/event', {'type': 'play', 'item': dict(item, title='Delta', url='u-d'), 'info': {}})
        time.sleep(1.3)
        http('/api/event', {'type': 'stop', 'item': dict(item, title='Delta', url='u-d'), 'info': {'position': 900, 'duration': 3600}})
        check('Mit play-Meldung zählt die echte Zeit (ca. 1 s statt Position 900 s)', wait(lambda: http('/api/x/statistik/daten')[1]['count'] == 3), http('/api/x/statistik/daten')[1])
        d = http('/api/x/statistik/daten')[1]
        last = d['sums']['week'] - 3600
        check('... also 1-4 Sekunden', 1 <= last <= 4, last)
        ep = {'title': 'Folge 3', 'parent_title': 'Serienheld', 'season': 1, 'episode': 3, 'provider': 'Testquelle', 'provider_id': 'tp', 'url': 'u-s'}
        http('/api/event', {'type': 'stop', 'item': ep, 'info': {'position': 1800, 'duration': 2400}})
        check('Serie wird nach Serientitel gezählt', wait(lambda: any(t['name'] == 'Serienheld' for t in http('/api/x/statistik/daten')[1]['titles'])), http('/api/x/statistik/daten')[1]['titles'])
        d = http('/api/x/statistik/daten')[1]
        check('Film/Serie-Anteile', d['kinds']['serie'] == 1800 and d['kinds']['film'] >= 3500, d['kinds'])
        check('14 Tage im Diagramm, heute zuletzt', len(d['days']) == 14 and d['days'][-1]['sec'] >= 5400, d['days'][-2:])
        code, page = http('/api/x/statistik/index')
        check('Seite zeigt "Meine Statistik", Stunden und Serienheld', code == 200 and 'Meine Statistik' in page and '1 h' in page and 'Serienheld' in page, str(page)[:150])
        ws = http('/api/ext/widgets?fresh=1')[1]['widgets']
        w = [x for x in ws if x['ext'] == 'statistik']
        check('Kachel "Diese Woche" mit Sehzeit', w and w[0]['text'].startswith('1 h') and 'Wiedergaben' in w[0]['sub'], w)
        check('Zurücksetzen nur per POST', http('/api/x/statistik/reset')[0] == 405)
        http('/api/x/statistik/reset', {})
        check('Zurücksetzen leert', http('/api/x/statistik/daten')[1]['count'] == 0)
        setv('statistik', aktiv=False)
        http('/api/event', {'type': 'stop', 'item': item, 'info': {'position': 3000, 'duration': 3600}})
        time.sleep(0.6)
        check('Ausgeschaltet zählt nichts', http('/api/x/statistik/daten')[1]['count'] == 0)

        print('Zufallsfilm')
        ui = http('/api/ext/ui')[1]
        menu = [m for m in ui['menus'] if m['ext'] == 'zufall']
        check('Kachel "🎲 Zufall" ist angemeldet', len(menu) == 1, ui['menus'])
        mid = menu[0]['id']
        setv('zufall', quellen='testquelle', anzahl=3)
        code, r = http('/api/ext/items?kind=menus&ext=zufall&id=' + mid)
        its = r.get('items', []) if code == 200 else []
        check('Liefert höchstens 3 abspielbare Titel', code == 200 and 1 <= len(its) <= 3 and all(i['kind'] == 'play' for i in its), (code, r))
        check('Keine Treffer aus gesperrten Wörtern (Jugendschutz greift auch hier)', all('Erotik' not in i['title'] and 'XXX' not in i['title'] for i in its), [i['title'] for i in its])
        seen = set()
        for _ in range(8):
            seen |= {i['title'] for i in http('/api/ext/items?kind=menus&ext=zufall&id=' + mid)[1].get('items', [])}
        check('Wechselnde Auswahl (nicht immer dieselben)', len(seen) >= 4, seen)
        setv('zufall', quellen='gibtesnicht')
        code, r = http('/api/ext/items?kind=menus&ext=zufall&id=' + mid)
        check('Keine passende Quelle: verständliche Meldung', code == 400 and 'Keine Vorschläge' in json.dumps(r, ensure_ascii=False), (code, r))

        print('Quellen-Wächter')
        chat = lambda: json.dumps(http('/api/chat')[1], ensure_ascii=False)
        http('/api/health?run=1')
        check('Kaputte Quelle wird von der Diagnose als gestört erkannt', any(h.get('id') == 'tp3' and h.get('status') == 'error' for h in http('/api/health')[1]['health']), http('/api/health')[1])
        setv('quellen_waechter', ab_minuten=0)
        code, js = http('/api/x/quellen_waechter/jetzt', {})
        check('Ausfall wird gemeldet (1 Meldung)', code == 200 and js.get('gesendet') == 1 and 'Kaputt Test ist ausgefallen' in chat(), (js, chat()[:300]))
        code, js = http('/api/x/quellen_waechter/jetzt', {})
        check('... aber nicht ein zweites Mal', js.get('gesendet') == 0, js)
        Path(flag).unlink()
        http('/api/health?run=1')
        code, js = http('/api/x/quellen_waechter/jetzt', {})
        check('Wenn sie wieder läuft: "läuft wieder"', js.get('gesendet') == 1 and 'Kaputt Test läuft wieder' in chat(), (js, chat()[-300:]))
        check('Übersichtsseite listet die Quellen', 'Kaputt Test' in http('/api/x/quellen_waechter/index')[1] and 'Testquelle' in http('/api/x/quellen_waechter/index')[1])
        check('Auslösen nur per POST', http('/api/x/quellen_waechter/jetzt')[0] == 405)

        print('Feiertage')
        ns = {}
        from engine import examples as EXM
        exec(next(e for e in EXM.EXAMPLES if e['id'] == 'feiertage')['code'], ns)
        from datetime import date
        check('Ostern 2024/2025/2026 stimmt', (ns['ostern'](2024), ns['ostern'](2025), ns['ostern'](2026)) == (date(2024, 3, 31), date(2025, 4, 20), date(2026, 4, 5)))
        nw = ns['feiertage'](2026, 'NW')
        check('NRW 2026: Karfreitag 3.4., Fronleichnam 4.6., Allerheiligen, kein Reformationstag',
              date(2026, 4, 3) in nw and date(2026, 6, 4) in nw and date(2026, 11, 1) in nw and date(2026, 10, 31) not in nw and date(2026, 1, 6) not in nw)
        check('Sachsen: Buß- und Bettag am 18.11.2026, Reformationstag', ns['feiertage'](2026, 'SN').get(date(2026, 11, 18)) == 'Buß- und Bettag' and date(2026, 10, 31) in ns['feiertage'](2026, 'SN'))
        check('Bayern: Heilige Drei Könige; Berlin: Frauentag', date(2026, 1, 6) in ns['feiertage'](2026, 'BY') and date(2026, 3, 8) in ns['feiertage'](2026, 'BE'))
        check('Jahreswechsel: nach dem 27.12. kommt Neujahr 2027', ns['naechste'](date(2026, 12, 27), 'NW', 1)[0] == (date(2027, 1, 1), 'Neujahr'))
        check('Heute zählt als "heute"', ns['_tage'](date(2026, 10, 3), date(2026, 10, 3)) == 'heute' and ns['_tage'](date(2026, 10, 4), date(2026, 10, 3)) == 'morgen')
        ws = http('/api/ext/widgets?fresh=1')[1]['widgets']
        w = [x for x in ws if x['ext'] == 'feiertage']
        check('Kachel zeigt Countdown und Namen', w and w[0]['text'] and w[0]['sub'] and len(w[0]['lines']) == 2, w)
        setv('feiertage', land='SN')
        check('Bundesland wählbar (Sachsen hat Buß- und Bettag)', 'Buß- und Bettag' in json.dumps(http('/api/x/feiertage/liste')[1], ensure_ascii=False))

        print('Filmtipp des Tages')
        setv('filmtipp', quellen='testquelle')
        code, js = http('/api/x/filmtipp/jetzt', {})
        check('Tipp wird gepostet', code == 200 and js.get('gepostet') == 1 and 'Filmtipp des Tages:' in chat(), (code, js))
        check('Auslösen nur per POST', http('/api/x/filmtipp/jetzt')[0] == 405)
        setv('filmtipp', quellen='gibtesnicht')
        check('Keine passende Quelle: nichts gepostet, kein Fehler', http('/api/x/filmtipp/jetzt', {})[1].get('gepostet') == 0)

        print('Handy verbinden')
        code, a = http('/api/x/handy_verbinden/adresse')
        check('Adresse enthält den Port der Engine', code == 200 and a['port'] == PORT and (a['url'] == '' or a['url'].endswith(':%d/ui/' % PORT)), a)
        ws = http('/api/ext/widgets?fresh=1')[1]['widgets']
        check('Kachel "Handy verbinden" ist da', any(x['ext'] == 'handy_verbinden' and x['text'] for x in ws), ws)

        print('Notizzettel')
        code, r = http('/api/x/notizen/neu', {'text': 'Milch kaufen'})
        nid = r.get('notiz', {}).get('id')
        check('Notiz anlegen', code == 200 and nid, (code, r))
        http('/api/x/notizen/neu', {'text': 'Popcorn'})
        code, r = http('/api/x/notizen/neu', {'text': '   '})
        check('Leere Notiz wird abgelehnt', code == 400, (code, r))
        check('Nur per POST', http('/api/x/notizen/neu')[0] == 405)
        http('/api/x/notizen/aendern', {'id': nid, 'pinned': True})
        lst = http('/api/x/notizen/liste')[1]
        check('Angeheftete Notiz steht oben, 2 offen', lst['notizen'][0]['id'] == nid and lst['offen'] == 2, lst)
        w = [x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'notizen']
        check('Kachel zeigt die angeheftete Notiz und "2 offen"', w and w[0]['text'] == 'Milch kaufen' and w[0]['sub'] == '2 offen' and w[0]['lines'] == ['Popcorn'], w)
        http('/api/x/notizen/aendern', {'id': nid, 'done': True})
        lst = http('/api/x/notizen/liste')[1]
        check('Abgehakt: wandert nach unten, 1 offen', lst['notizen'][-1]['id'] == nid and lst['offen'] == 1, lst)
        ui = http('/api/ext/ui')[1]
        aid = [a['id'] for a in ui['actions'] if a['ext'] == 'notizen'][0]
        code, r = http('/api/ext/action', {'ext': 'notizen', 'id': aid, 'item': {'title': 'Folge 2', 'parent_title': 'Serienheld', 'provider': 'Testquelle', 'url': 'x'}})
        check('Knopf in der Titel-Info legt eine Notiz an', code == 200 and any('Serienheld - Folge 2' in n['text'] for n in http('/api/x/notizen/liste')[1]['notizen']), (code, r))
        code, r = http('/api/x/notizen/aufraeumen', {})
        check('Erledigte entfernen', r.get('entfernt') == 1 and all(not n['done'] for n in http('/api/x/notizen/liste')[1]['notizen']), r)
        check('Notiz löschen', http('/api/x/notizen/loeschen', {'id': 'gibtesnicht'})[0] == 200)
        for n in http('/api/x/notizen/liste')[1]['notizen']:
            http('/api/x/notizen/loeschen', {'id': n['id']})
        w = [x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'notizen']
        check('Leer: Kachel sagt "Notizzettel leer"', w and 'leer' in w[0]['text'], w)
        html = http('/api/x/notizen/index')[1]
        check('Seite liefert Formular und Skript', '<form id="f">' in html and "call('liste')" in html and 'textContent' in html)

        print('Countdown')
        ns = {}
        exec(next(e for e in EXM.EXAMPLES if e['id'] == 'countdown')['code'], ns)
        t = ns['parse']('Urlaub; 2027-07-12\nHochzeitstag; 14.06.\nAnna; 03.05.1990; j\nKaputt; 31.02.2027\nOhne Datum\n; 01.01.2027\nEinmalig; 24.12.2026')
        check('Parser: 5 gültige Zeilen, Unsinn wird übersprungen', [e['name'] for e in t] == ['Urlaub', 'Hochzeitstag', 'Anna', 'Einmalig'], [e['name'] for e in t])
        k = ns['kommende'](t, date(2026, 10, 29))
        check('Sortierung: Weihnachten vor Hochzeitstag 2027 vor Geburtstag', [x[1]['name'] for x in k] == ['Einmalig', 'Anna', 'Hochzeitstag', 'Urlaub'], [x[1]['name'] for x in k])
        anna = [x for x in k if x[1]['name'] == 'Anna'][0]
        check('Geburtstag: nächstes Mal 3.5.2027, wird 37', anna[0] == date(2027, 5, 3) and anna[2] == 37, anna)
        check('Heute/morgen/Tage', ns['wann'](date(2026, 1, 1), date(2026, 1, 1)) == 'heute!' and ns['wann'](date(2026, 1, 2), date(2026, 1, 1)) == 'morgen' and ns['wann'](date(2026, 1, 11), date(2026, 1, 1)) == '10 Tage')
        check('Vergangene einmalige Termine entfallen', ns['kommende'](ns['parse']('Alt; 2020-01-01'), date(2026, 1, 1)) == [])
        leap = ns['kommende'](ns['parse']('Schalt; 29.02.'), date(2027, 1, 1))
        check('29.2. in Nicht-Schaltjahr -> 28.2.', leap[0][0] == date(2027, 2, 28), leap)
        setv('countdown', termine='Silvester; 31.12.\nAnna; 03.05.1990; j')
        w = [x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'countdown']
        check('Kachel zeigt den nächsten Termin mit Tagen', w and (w[0]['text'].endswith('Tage') or w[0]['text'] in ('heute!', 'morgen')) and w[0]['sub'].startswith(('Silvester', 'Anna')), w)
        check('Route "liste" nennt Termine', len(http('/api/x/countdown/liste')[1]['termine']) == 2)

        print('Himmel')
        ns = {}
        exec(next(e for e in EXM.EXAMPLES if e['id'] == 'himmel')['code'], ns)
        auf, unter = ns['sonne_ut'](date(2026, 6, 21), 51.2277, 6.7735, True), ns['sonne_ut'](date(2026, 6, 21), 51.2277, 6.7735, False)
        check('Düsseldorf Sommer: Aufgang ~03:23 UTC, Untergang ~19:53 UTC (±12 min)', abs(auf - 3.38) < 0.2 and abs(unter - 19.88) < 0.2, (auf, unter))
        auf, unter = ns['sonne_ut'](date(2026, 12, 21), 51.2277, 6.7735, True), ns['sonne_ut'](date(2026, 12, 21), 51.2277, 6.7735, False)
        check('Düsseldorf Winter: Aufgang ~07:30 UTC, Untergang ~15:30 UTC (±12 min)', abs(auf - 7.5) < 0.25 and abs(unter - 15.5) < 0.25, (auf, unter))
        check('Polarnacht: Tromsø im Dezember', ns['sonne_ut'](date(2026, 12, 21), 69.65, 18.96, True) is None)
        from datetime import datetime, timezone
        f1 = ns['mond'](datetime(2024, 4, 8, 18, 21, tzinfo=timezone.utc))
        f2 = ns['mond'](datetime(2024, 4, 23, 23, 49, tzinfo=timezone.utc))
        check('Neumond 8.4.2024: Phase ~0, Vollmond 23.4.2024: ~0,5', (f1[0] < 0.03 or f1[0] > 0.97) and abs(f2[0] - 0.5) < 0.03 and f1[2] == '🌑' and f2[2] == '🌕' and f2[1] >= 98, (f1, f2))
        nv = ns['naechster'](datetime(2024, 4, 10, tzinfo=timezone.utc), 0.5)
        check('Nächster Vollmond nach 10.4.2024 ist am 23./24.4.', nv.date() in (date(2024, 4, 23), date(2024, 4, 24)), nv)
        w = [x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'himmel']
        check('Kachel: Auf-/Untergang, Mond, 3 Zeilen', w and '↑' in w[0]['text'] and '%' in w[0]['sub'] and len(w[0]['lines']) == 3, w)

        print('Spruch des Tages')
        ns = {}
        exec(next(e for e in EXM.EXAMPLES if e['id'] == 'spruch')['code'], ns)
        check('Jeder Spruch passt in die Kachel (<= 120 Zeichen)', all(len(s) <= 120 for s, a in ns['SPRUECHE']) and len(ns['SPRUECHE']) >= 25)
        a1, a2 = ns['waehle'](date(2026, 10, 29), [], False), ns['waehle'](date(2026, 10, 30), [], False)
        check('Gleicher Tag = gleicher Spruch, nächster Tag anders', a1 == ns['waehle'](date(2026, 10, 29), [], False) and a1 != a2)
        e = ns['eigene']('Wer rastet, der rostet. - Oma Gerda\nOhne Autor\n\n')
        check('Eigene Sprüche: Autor abgetrennt', e == [('Wer rastet, der rostet.', 'Oma Gerda'), ('Ohne Autor', '')], e)
        check('Nur eigene: kommt immer ein eigener dran', ns['waehle'](date(2026, 10, 29), e, True) in e)
        setv('spruch', eigene='Familie zuerst - Papa', nur_eigene=True)
        w = [x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'spruch']
        check('Kachel zeigt den eigenen Spruch mit Autor', w and w[0]['text'] == 'Papa' and w[0]['sub'] == 'Familie zuerst', w)

        print('Minispiele')
        P = '/api/x/minispiele/punkte'
        check('Noch keine Rekorde', http(P)[1] == {})
        check('Snake-Rekord 5 wird gespeichert', http(P, {'spiel': 'snake', 'wert': 5})[1] == {'snake': 5})
        check('Schlechterer Wert (3) überschreibt nicht, besserer (9) schon', http(P, {'spiel': 'snake', 'wert': 3})[1]['snake'] == 5 and http(P, {'spiel': 'snake', 'wert': 9})[1]['snake'] == 9)
        http(P, {'spiel': 'memory', 'wert': 12})
        check('Memory: weniger Züge ist besser (10 < 12), 14 nicht', http(P, {'spiel': 'memory', 'wert': 10})[1]['memory'] == 10 and http(P, {'spiel': 'memory', 'wert': 14})[1]['memory'] == 10)
        check('Memory: unmögliche 5 Züge (weniger als 8) werden ignoriert', http(P, {'spiel': 'memory', 'wert': 5})[1]['memory'] == 10)
        check('Unbekanntes Spiel / kaputter Wert -> 400', http(P, {'spiel': 'tetris', 'wert': 1})[0] == 400 and http(P, {'spiel': 'snake', 'wert': 'abc'})[0] == 400 and http(P, {'spiel': 'snake', 'wert': -4})[0] == 400)
        w = [x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'minispiele']
        check('Kachel zeigt Rekorde', w and '🐍 9' in w[0]['sub'] and '🃏 10 Züge' in w[0]['sub'], w)

        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            br = pw.chromium.launch()
            pg = br.new_page(viewport={'width': 1280, 'height': 720})
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/api/x/minispiele/index' % PORT)
            pg.wait_for_selector('#menu button')
            check('Menü: drei Spiele, Rekorde stehen darunter', pg.locator('#menu button').count() == 3 and 'Rekord: 9' in pg.inner_text('#r-snake') and '10 Züge' in pg.inner_text('#r-memory'), pg.inner_text('#menu'))
            ev = lambda js: pg.evaluate(js)
            check('2048: [2,2,4,0] -> [4,4,0,0], 4 Punkte', ev('JSON.stringify(MS.slide([2,2,4,0]))') == '{"line":[4,4,0,0],"gained":4}')
            check('2048: [2,2,2,2] -> [4,4,0,0]; [0,2,0,2] -> [4,0,0,0]; [4,2,2,0] -> [4,4,0,0]',
                  ev('JSON.stringify([MS.slide([2,2,2,2]).line,MS.slide([0,2,0,2]).line,MS.slide([4,2,2,0]).line])') == '[[4,4,0,0],[4,0,0,0],[4,4,0,0]]')
            check('2048: Zug nach rechts auf Brett mit Lücken; voll und ohne Paare = kein Zug mehr',
                  ev('(()=>{const g={b:[2,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,2],score:0};const m=MS.move2048(g,"right");return JSON.stringify([m,g.b[3],g.b[15],g.score])})()') == '[true,2,2,0]'
                  and ev('MS.can2048({b:[2,4,2,4, 4,2,4,2, 2,4,2,4, 4,2,4,2],score:0})') is False)
            check('Snake: Start 3 lang, Schritt nach rechts', ev('(()=>{const s=MS.snakeNew(()=>0);MS.snakeStep(s);return JSON.stringify([s.body.length,s.body[0],s.over])})()') == '[3,[10,9],false]')
            check('Snake: Futter fressen = wächst und gibt Punkt', ev('(()=>{const s=MS.snakeNew();s.food=[10,9];MS.snakeStep(s);return JSON.stringify([s.body.length,s.score,s.food!==null])})()') == '[4,1,true]')
            check('Snake: Rand wird durchquert (links raus, rechts rein)', ev('(()=>{const s=MS.snakeNew();s.body=[[17,9],[16,9],[15,9]];s.food=[3,3];MS.snakeStep(s);return JSON.stringify(s.body[0])})()') == '[0,9]')
            check('Snake: Umkehren auf der Stelle ist gesperrt', ev('(()=>{const s=MS.snakeNew();MS.snakeTurn(s,"left");return s.queue.length})()') == 0)
            check('Snake: sich selbst beißen beendet das Spiel', ev('(()=>{const s=MS.snakeNew();s.body=[[5,5],[5,6],[6,6],[6,5],[6,4],[5,4]];s.dir=[1,0];s.food=[0,0];MS.snakeStep(s);return s.over})()') is True)
            check('Snake: Schwanzspitze ist frei (kein Fehlalarm)', ev('(()=>{const s=MS.snakeNew();s.body=[[5,5],[6,5],[6,6],[5,6]];s.dir=[0,1];s.food=[0,0];MS.snakeStep(s);return s.over})()') is False)
            check('Memory: Paar bleibt offen, Fehlgriff schließt wieder, Sieg wird erkannt', ev('''(()=>{
              const m=MS.memNew(()=>0.5);const by={};m.cards.forEach((c,i)=>(by[c.e]=by[c.e]||[]).push(i));const ks=Object.keys(by);
              MS.memFlip(m,by[ks[0]][0],false);MS.memFlip(m,by[ks[1]][0],false);const closed=!m.cards[by[ks[0]][0]].open&&m.moves===1;
              ks.forEach(k=>{MS.memFlip(m,by[k][0],false);MS.memFlip(m,by[k][1],false)});return JSON.stringify([closed,m.won,m.moves])})()''') == '[true,true,9]')
            # Fernbedienung: Pfeile + OK
            pg.keyboard.press('Enter')
            pg.wait_for_selector('#cv', state='visible')
            check('Menü: OK startet Snake', ev('MS.state().mode') == 'snake')
            pg.keyboard.press('ArrowDown')
            pg.wait_for_function('JSON.stringify(MS.state().cur.dir)==="[0,1]"')
            check('Snake: Pfeil runter lenkt nach unten', True)
            pg.keyboard.press('Enter')
            check('OK pausiert', pg.locator('#msg.on').count() == 1 and 'Pause' in pg.inner_text('#msg'))
            pg.keyboard.press('Enter')
            pg.keyboard.press('Escape')
            check('Zurück/Esc führt ins Menü', ev('MS.state().mode') == 'menu')
            pg.keyboard.press('ArrowDown')
            pg.keyboard.press('Enter')
            pg.wait_for_selector('#grid .t')
            before = ev('MS.state().cur.b.join(",")')
            moved = False
            for k in ('ArrowLeft', 'ArrowUp', 'ArrowRight', 'ArrowDown'):
                pg.keyboard.press(k)
                if ev('MS.state().cur.b.join(",")') != before:
                    moved = True
                    break
            check('2048 per Pfeiltasten: Brett ändert sich, neue Kachel kommt dazu', moved and ev('MS.state().cur.b.filter(x=>x).length') >= 2, ev('MS.state().cur.b'))
            pg.keyboard.press('Backspace')
            pg.keyboard.press('ArrowDown')
            pg.keyboard.press('Enter')
            pg.wait_for_selector('.c')
            check('Memory: 16 Karten, OK dreht die erste um', pg.locator('.c').count() == 16)
            pg.keyboard.press('Enter')
            check('... Karte ist aufgedeckt, Zähler zeigt Züge', pg.locator('.c.o').count() == 1 and 'Züge: 0' in pg.inner_text('#sc'))
            pg.keyboard.press('ArrowRight')
            pg.keyboard.press('Enter')
            pg.wait_for_function("document.querySelector('#sc').textContent.includes('Züge: 1')")
            check('Zweite Karte: Zug zählt', True)
            # Touch: wischen
            pg.keyboard.press('Escape')
            ctx2 = br.new_context(has_touch=True, viewport={'width': 390, 'height': 800})
            tp = ctx2.new_page()
            tp.goto('http://127.0.0.1:%d/api/x/minispiele/index' % PORT)
            tp.wait_for_selector('#menu button')
            tp.tap('#menu button[data-g="snake"]')
            tp.wait_for_selector('#cv', state='visible')
            check('Touch: Tippen im Menü startet Snake, Steuerkreuz sichtbar', tp.is_visible('#pad button[data-d="up"]'))
            tp.tap('#pad button[data-d="up"]')
            tp.wait_for_function('JSON.stringify(MS.state().cur.dir)==="[0,-1]"')
            check('Touch: Steuerkreuz lenkt', True)
            swipe = """(d)=>{const st=document.getElementById('stage');const mk=(x,y)=>new Touch({identifier:1,target:st,clientX:x,clientY:y});
              const a=mk(200,300),b=mk(200+d[0]*80,300+d[1]*80);
              st.dispatchEvent(new TouchEvent('touchstart',{touches:[a],changedTouches:[a],bubbles:true}));
              st.dispatchEvent(new TouchEvent('touchend',{touches:[],changedTouches:[b],bubbles:true}))}"""
            tp.evaluate(swipe, [1, 0])
            tp.wait_for_function('JSON.stringify(MS.state().cur.dir)==="[1,0]"')
            check('Touch: nach rechts wischen lenkt nach rechts', True)
            tp.goto('http://127.0.0.1:%d/api/x/minispiele/index' % PORT)
            tp.tap('#menu button[data-g="2048"]')
            tp.wait_for_selector('#grid .t')
            b0 = tp.evaluate('MS.state().cur.b.join(",")')
            ch = False
            for d in ([-1, 0], [0, -1], [1, 0], [0, 1]):
                tp.evaluate(swipe, d)
                if tp.evaluate('MS.state().cur.b.join(",")') != b0:
                    ch = True
                    break
            check('Touch: 2048 per Wischen', ch)
            ctx2.close()
            check('Keine Skriptfehler auf der Seite', not errs, errs)
            br.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except subprocess.TimeoutExpired:
            p.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
