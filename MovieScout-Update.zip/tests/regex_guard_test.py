# -*- coding: utf-8 -*-
"""Hängende Suchmuster (katastrophales Backtracking auf geänderter Webseite) dürfen die Engine nicht einfrieren.
    python tests/regex_guard_test.py"""
import os, sys, threading, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from kodi_runtime import safere, context
passed = failed = 0
def check(n, ok, x=''):
    global passed, failed
    if ok: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)

def run(mode):
    safere._MODE = mode; safere._ok_once = False; safere._broken = False
    print('--- Verfahren: ' + mode)
    global re
    re = safere.module()
    safere.TIMEOUT = 3
    t = '<a href="x">hi</a>\n' * 1000
    check('findall groß = normal', re.findall(r'<a href="(.*?)">(.*?)</a>', t) == __import__('re').findall(r'<a href="(.*?)">(.*?)</a>', t))
    m = re.search(r'href="(.*?)"', t); check('search liefert echtes Match', m.group(1) == 'x' and m.start() == 3)
    check('finditer, sub, split', len(list(re.finditer('hi', t))) == 1000 and re.sub('hi', 'HO', t).count('HO') == 1000 and len(re.split('</a>', t)) == 1001)
    check('compile/Pattern-Typ', isinstance(re.compile('x'), re.Pattern) and re.compile('a+', re.I).match('AAA' + 'x' * 7000).group() == 'AAA')
    check('kleine Texte lokal', re.findall('a', 'banana') == ['a', 'a', 'a'] and re.escape('a.b') == 'a\\.b' and re.IGNORECASE == __import__('re').IGNORECASE)
    bad = '<div class="col-md-3"><a href="x/"><img alt="a" src="https://i">\n' * 300
    pat = r'<div.class="col-md-3">.*?<a.href="(.*?)".*?alt="(.*?)".*?<img.src="(https:.*?)".*?</noscript>'
    t0 = time.time(); err = None
    try: re.findall(pat, bad, re.DOTALL)
    except Exception as e: err = e
    dt = time.time() - t0
    check('Hängendes Muster wird nach Zeitlimit beendet', isinstance(err, safere.RegexTimeout) and 2.5 < dt < 6, (err, dt))
    # Hauptprozess bleibt währenddessen reaktionsfähig
    ticks = []
    def tick():
        while not stop.is_set(): ticks.append(time.time()); time.sleep(0.1)
    stop = threading.Event(); th = threading.Thread(target=tick, daemon=True); th.start()
    try: re.search(pat, bad, re.DOTALL)
    except safere.RegexTimeout: pass
    stop.set(); gaps = [b - a for a, b in zip(ticks, ticks[1:])]
    check('Andere Threads laufen während des Hängers weiter', len(ticks) > 15 and max(gaps) < 0.5, (len(ticks), max(gaps) if gaps else None))
    check('Danach funktioniert es weiter (Hilfsprozess neu)', re.findall(r'<a href="(.*?)">', t)[:1] == ['x'])
    # Abbruch durch die Engine beendet den Lauf sofort
    ctx = context.RequestContext()
    def cancel_soon(): time.sleep(1); ctx.cancelled.set()
    safere.TIMEOUT = 30
    threading.Thread(target=cancel_soon, daemon=True).start()
    t0 = time.time(); err = None
    with context.use(ctx):
        try: re.findall(pat, bad, re.DOTALL)
        except Exception as e: err = e
    check('Abbruch der Engine beendet das Muster sofort', isinstance(err, safere.RegexTimeout) and time.time() - t0 < 3, (err, time.time() - t0))


import os
modes = ['fork'] if os.name == 'posix' else []
modes += ['proc']
for m in modes:
    run(m)
safere.shutdown()
print('\n%d ok, %d Fehler' % (passed, failed)); sys.exit(1 if failed else 0)
