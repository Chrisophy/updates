# -*- coding: utf-8 -*-
"""Test der Meldungen für die Android-App (/api/notify): Chat, Erweiterungs-Nachrichten, Long-Poll, Neustart.

    python tests/notify_test.py
"""
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 8831
UP_PORT = 8832
API = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def call(path, data=None):
    req = urllib.request.Request(API + path, data=(json.dumps(data).encode() if data is not None else None),
                                 headers={'Content-Type': 'application/json'} if data is not None else {})
    with urllib.request.urlopen(req, timeout=40) as r:
        return json.loads(r.read())


def wait_port(port, tries=80):
    import socket
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, PYTHONUNBUFFERED='1', MOVIESCOUT_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MINIKODI_DATA'):
        env.pop(k, None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP_PORT)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(PORT)], env=env, cwd=str(ROOT),
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        assert wait_port(PORT) and wait_port(UP_PORT), 'Engine startet nicht'
        d = call('/api/notify')
        check('Anfangs leer', d['events'] == [] and d['last'] == 0, d)

        call('/api/chat', {'text': 'Hallo zusammen', 'author': 'Mama'})
        d = call('/api/notify?since=0')
        ev = d['events']
        check('Chat-Nachricht erscheint als Meldung', len(ev) == 1 and ev[0]['kind'] == 'chat'
              and ev[0]['title'] == 'Mama' and ev[0]['text'] == 'Hallo zusammen', d)
        last = d['last']

        call('/api/chat', {'text': '', 'author': 'Papa', 'item': {'title': 'Tatort', 'provider_id': 'x'}})
        d = call('/api/notify?since=%d' % last)
        check('Nur neuere Meldungen; Titel statt Text bei angehängtem Film',
              len(d['events']) == 1 and d['events'][0]['text'] == 'Tatort', d)

        # Long-Poll: wartet, bis etwas kommt
        last = d['last']
        t0 = time.time()
        threading.Timer(1.0, lambda: call('/api/chat', {'text': 'spät', 'author': 'Oma'})).start()
        d = call('/api/notify?since=%d&wait=10' % last)
        dt = time.time() - t0
        check('Long-Poll liefert die neue Meldung nach ~1 s', len(d['events']) == 1 and d['events'][0]['text'] == 'spät' and 0.7 < dt < 5, (dt, d))

        t0 = time.time()
        d = call('/api/notify?since=%d&wait=1' % d['last'])
        check('Long-Poll ohne Neues kehrt nach der Wartezeit leer zurück', d['events'] == [] and 0.8 < time.time() - t0 < 4, d)

        d = call('/api/notify?since=9999')
        check('Zu hohe ID (Engine wurde neu gestartet) -> es wird von vorn geliefert', len(d['events']) == d['last'], d)

        d = call('/api/notify?since=abc&wait=zz')
        check('Ungültige Werte stürzen nicht ab', 'events' in d, d)

        # Downloads: fertig -> Meldung "Download fertig", fehlgeschlagen -> Meldung mit Fehler
        base = call('/api/notify')['last']
        up_url = 'http://127.0.0.1:%d' % UP_PORT
        jid = call('/api/downloads', {'provider_id': 'x', 'title': 'Testfilm', 'item': {},
                                      'hoster': {'url': up_url + '/master.m3u8', 'headers': {'Referer': 'https://site.test/'}, 'format': 'hls'}})['id']
        st = {}
        for _ in range(80):
            st = call('/api/downloads/' + jid)
            if st.get('state') in ('done', 'error'):
                break
            time.sleep(0.5)
        d = call('/api/notify?since=%d' % base)
        dl = [e for e in d['events'] if e['kind'] == 'download']
        check('Download endet (%s)' % st.get('state'), st.get('state') in ('done', 'error'), st)
        check('Download: genau eine Meldung mit Titel und Ergebnis',
              len(dl) == 1 and dl[0]['title'] == 'Testfilm' and dl[0]['ok'] == (st.get('state') == 'done'), dl)
        if st.get('state') == 'done':
            check('Fertiger Download: Text "Download fertig"', dl[0]['text'] == 'Download fertig', dl)
        base = d['last']
        jid2 = call('/api/downloads', {'provider_id': 'x', 'title': 'Kaputt', 'item': {},
                                       'hoster': {'url': up_url + '/gibt-es-nicht.mp4', 'format': 'mp4'}})['id']
        for _ in range(60):
            st2 = call('/api/downloads/' + jid2)
            if st2.get('state') in ('done', 'error'):
                break
            time.sleep(0.5)
        d = call('/api/notify?since=%d' % base)
        dl = [e for e in d['events'] if e['kind'] == 'download']
        check('Fehlgeschlagener Download: Meldung mit Fehler', st2.get('state') == 'error' and len(dl) == 1
              and dl[0]['ok'] is False and dl[0]['text'].startswith('Download fehlgeschlagen'), (st2, dl))
        # selbst abgebrochen -> keine Meldung
        base = d['last']
        jid3 = call('/api/downloads', {'provider_id': 'x', 'title': 'Abbruch', 'item': {},
                                       'hoster': {'url': up_url + '/master.m3u8', 'headers': {'Referer': 'https://site.test/'}, 'format': 'hls'}})['id']
        urllib.request.urlopen(urllib.request.Request(API + '/api/downloads/' + jid3, method='DELETE'), timeout=20).read()
        time.sleep(3)
        d = call('/api/notify?since=%d' % base)
        check('Selbst abgebrochener Download meldet nichts', not [e for e in d['events'] if e['kind'] == 'download' and e['title'] == 'Abbruch'], d)

        # Download-Meldung direkt über das Modul (Engine-interne Funktion)
        sys.path.insert(0, str(ROOT))
        from engine import notify as NF
        NF.reset()
        e1 = NF.push('download', 'Film', 'Download fertig', job='1', ok=True)
        check('push: ID, Art und Zusatzfelder', e1['id'] == 1 and e1['kind'] == 'download' and e1['ok'] is True and e1['job'] == '1')
        try:
            NF.push('quatsch', 'x')
            check('push: unbekannte Art wird abgelehnt', False)
        except ValueError:
            check('push: unbekannte Art wird abgelehnt', True)
        for i in range(250):
            NF.push('chat', 'a', str(i))
        check('Ringspeicher begrenzt auf 200', len(NF.since(0)) == 200 and NF.last_id() == 251)
    finally:
        srv.terminate()
        up.terminate()
        try:
            out = srv.stdout.read().decode('utf-8', 'replace')
            if failed:
                print('\n--- Server-Log ---\n' + out[-3000:])
        except Exception:
            pass
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
