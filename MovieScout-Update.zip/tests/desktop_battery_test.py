import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8977; ok = bad = 0
def check(n, c, x=''):
    global ok, bad
    if c: ok += 1; print('  ok   ', n)
    else: bad += 1; print('  FEHLER', n, x)
tmp = tempfile.mkdtemp()
env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT/'tests'/'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0', NO_PROXY='*')
for k in ('MINIKODI_TOKEN','MOVIESCOUT_TOKEN'): env.pop(k, None)
srv = subprocess.Popen([sys.executable, str(ROOT/'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(100):
    try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
    except OSError: time.sleep(.25)
errs = []
try:
    with sync_playwright() as p:
        b = p.chromium.launch(); ctx = b.new_context(viewport={'width':1100,'height':760})
        ctx.add_init_script("""navigator.getBattery = () => { const l = {}; const b = { level: .82, charging: false, chargingTime: Infinity, dischargingTime: 7200,
          addEventListener(e, f) { (l[e] = l[e] || []).push(f); }, _fire(e) { (l[e] || []).forEach(f => f()); } }; window.__bat = b; return Promise.resolve(b); };""")
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (API, API)); pg.wait_for_selector('header.top'); pg.wait_for_function('typeof providers !== "undefined" && providers.length', timeout=20000); pg.wait_for_timeout(500)
        pg.evaluate("""async () => { SK.active = 'look-desk-win'; skinsSave(); applySkin(activeSkin()); await renderView(); }"""); pg.wait_for_timeout(600)
        check('Desktop an', pg.locator('#deskbar').is_visible())
        check('Eine Seite: keine Punkte, kein +', pg.locator('.dpages .dpg').count() == 0 and not pg.locator('.dpages').is_visible())
        check('Akku standardmäßig aus', not pg.locator('#deskbar .bat').is_visible())
        pg.screenshot(path='s1.png')
        # Editor
        pg.evaluate("openSkinEditor()"); pg.wait_for_timeout(500)
        pg.get_by_role('tab', name='Desktop & Uhr').click(); pg.wait_for_timeout(300)
        check('Tab zeigt 1 Seite', pg.locator('.navrow').count() == 1)
        pg.get_by_text('＋ Neue Seite anlegen').click(); pg.wait_for_timeout(400)
        check('Neue Seite angelegt (2 Zeilen)', pg.locator('.navrow').count() == 2 and pg.evaluate("deskGet().pages") == 2)
        check('Jetzt Punkte sichtbar (2 + 2 Pfeile)', pg.locator('.dpages .dpg').count() == 4, pg.locator('.dpages .dpg').count())
        pg.get_by_text('＋ Neue Seite anlegen').click(); pg.wait_for_timeout(300)
        check('3 Seiten', pg.evaluate("deskGet().pages") == 3)
        pg.locator('.navrow').nth(2).get_by_text('Löschen').click(); pg.wait_for_timeout(300)
        check('Leere Seite gelöscht', pg.evaluate("deskGet().pages") == 2 and pg.locator('.navrow').count() == 2)
        pg.locator('.navrow').nth(1).get_by_text('Löschen').click(); pg.wait_for_timeout(300)
        check('Zurück auf 1 Seite: Punkte weg', pg.evaluate("deskGet().pages") == 1 and pg.locator('.dpages .dpg').count() == 0)
        pg.locator('.navrow').nth(0).get_by_text('Löschen').click(); pg.wait_for_timeout(300)
        check('Letzte Seite bleibt', pg.evaluate("deskGet().pages") == 1)
        # Akku
        pg.get_by_role('switch', name='Akkustand neben der Uhr anzeigen').click(); pg.wait_for_timeout(500)
        check('Akku sichtbar in Taskleiste', pg.locator('#deskbar .bat').is_visible())
        t = pg.locator('#deskbar .bat').inner_text(); check('82 %', '82' in t, t)
        pg.evaluate("__bat.level = .1; __bat._fire('levelchange')"); pg.wait_for_timeout(200)
        check('niedrig markiert', pg.evaluate("document.querySelector('#deskbar .bat').classList.contains('low')") and '10' in pg.locator('#deskbar .bat').inner_text())
        pg.evaluate("__bat.charging = true; __bat._fire('chargingchange')"); pg.wait_for_timeout(200)
        check('lädt: Blitz im Icon, nicht low', pg.locator('#deskbar .bat svg path').count() == 1 and not pg.evaluate("document.querySelector('#deskbar .bat').classList.contains('low')"))
        check('Datum bleibt', bool(pg.locator('#deskbar .dd').inner_text()))
        pg.screenshot(path='s2.png')
        pg.evaluate("__bat.level = 1; __bat.charging = true; __bat.chargingTime = 0; __bat.dischargingTime = Infinity; __bat._fire('levelchange')"); pg.wait_for_timeout(200)
        check('Gerät ohne Akku: nichts', not pg.locator('#deskbar .bat').is_visible())
        pg.evaluate("__bat.level = .5; __bat.charging = false; __bat.dischargingTime = 3000; __bat._fire('levelchange')"); pg.wait_for_timeout(200)
        pg.get_by_role('switch', name='Akkustand neben der Uhr anzeigen').click(); pg.wait_for_timeout(300)
        check('Ausschalten blendet aus', not pg.locator('#deskbar .bat').is_visible() and pg.evaluate("store.get('batt')") is False)
        pg.get_by_role('switch', name='Akkustand neben der Uhr anzeigen').click(); pg.wait_for_timeout(300)
        pg.evaluate("history.back()"); pg.wait_for_timeout(700)
        pg.screenshot(path='s4.png')
        # Standard-Look: Uhr-Kachel
        pg.evaluate("""async () => { SK.active = SK.skins ? (Object.keys(SK.skins||{})[0] || SK.active) : SK.active; }""")
        pg.set_viewport_size({'width':420,'height':800}); pg.wait_for_timeout(400)
        check('Schmal: Akku bleibt, Datum weg', pg.locator('#deskbar .bat').is_visible() and not pg.locator('#deskbar .dd').is_visible())
        pg.set_viewport_size({'width':1100,'height':760})
        pg.evaluate("""async () => { SK.active = 'look-standard'; skinsSave(); applySkin(activeSkin()); await renderView(); }"""); pg.wait_for_timeout(800)
        print('looks', pg.evaluate("LOOKS.map(l=>l.id)"))
        print('clock tile', pg.locator('.wtile.clock').count(), pg.locator('.wtile.clock .bat').count(), pg.locator('.wtile.clock .bat').is_visible() if pg.locator('.wtile.clock .bat').count() else None)
        pg.screenshot(path='s3.png')
finally:
    srv.terminate()
print(ok, bad, errs)
