# -*- coding: utf-8 -*-
"""Addons, die nur settings-kodi19.xml / settings-kodi20.xml mitbringen (wie das Kodi-Addon MovieScout): python tests/addon_settings_test.py"""
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ['MOVIESCOUT_DATA'] = tempfile.mkdtemp()
os.environ['MINIKODI_DATA'] = os.environ['MOVIESCOUT_DATA']
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


from engine import addonhost as A                                     # noqa: E402
import engine.resolvers                                               # noqa: E402,F401
from kodi_runtime import context                                      # noqa: E402

ADDON_XML = '<addon id="plugin.video.demoset" version="1.0.0" name="Demo"><requires><import addon="xbmc.python" version="3.0.0"/></requires>' \
            '<extension point="xbmc.python.pluginsource" library="default.py"><provides>video</provides></extension></addon>'
DEFAULT = '''import sys, xbmcgui, xbmcplugin, xbmcaddon
h = int(sys.argv[1])
a = xbmcaddon.Addon()
li = xbmcgui.ListItem(label="Eintrag " + a.getSetting("scout.enable") + "/" + a.getSetting("tmdb.api_key"))
xbmcplugin.addDirectoryItem(h, sys.argv[0] + "?x=1", li, True)
xbmcplugin.endOfDirectory(h)
'''
S20 = '''<?xml version='1.0' encoding='UTF-8'?>
<settings version="1"><section id="plugin.video.demoset"><category id="general" label="Allgemein"><group id="1" label="Gruppe">
<setting id="tmdb.api_key" type="string" label="TMDB Schlüssel"><level>0</level><default/><control type="edit" format="string"><heading>Schlüssel</heading></control></setting>
<setting id="scout.enable" type="boolean" label="Scout an"><level>0</level><default>true</default><control type="toggle"/></setting>
</group></category></section></settings>'''
S19 = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><settings><category label="A"><setting id="tmdb.api_key" type="text" label="Schlüssel" default=""/>' \
      '<setting id="scout.enable" type="bool" label="Scout an" default="true"/></category></settings>'


def build(files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        z.writestr('plugin.video.demoset/addon.xml', ADDON_XML)
        z.writestr('plugin.video.demoset/default.py', DEFAULT)
        for n, t in files.items():
            z.writestr('plugin.video.demoset/resources/' + n, t)
    return b.getvalue()


for label, files, want in (('nur settings-kodi20.xml', {'settings-kodi20.xml': S20}, 2),
                           ('nur settings-kodi19.xml', {'settings-kodi19.xml': S19}, 2),
                           ('beide Fassungen', {'settings-kodi19.xml': S19, 'settings-kodi20.xml': S20}, 2)):
    print(label)
    info = A.install_zip(build(files))
    d = A.addon_path('plugin.video.demoset')
    check('settings.xml wurde angelegt', (d / 'resources' / 'settings.xml').is_file())
    f = [x for x in A.settings_schema('plugin.video.demoset') if x['id']]
    check('Formular hat %d Felder' % want, len(f) == want, [x['id'] for x in f])
    check('Schalter hat Standardwert „an“', any(x['id'] == 'scout.enable' and x['type'] == 'bool' and x['value'] is True for x in f), f)
    ctx = context.begin() if hasattr(context, 'begin') else context.current()
    ctx.items.clear()
    A.run('plugin.video.demoset')
    c = context.current()
    titles = [i.get('title') for i in c.items]
    check('Startmenü zeigt Eintrag mit Standardwert aus settings.xml', any((t or '').startswith('Eintrag true') for t in titles), titles)
    check('„Einstellungen“-Eintrag wird angehängt', any(t == 'Einstellungen' for t in titles), titles)
    A.remove('plugin.video.demoset')

print('Eigene settings.xml bleibt unangetastet')
b = io.BytesIO()
with zipfile.ZipFile(b, 'w') as z:
    z.writestr('plugin.video.demoset/addon.xml', ADDON_XML)
    z.writestr('plugin.video.demoset/default.py', DEFAULT)
    z.writestr('plugin.video.demoset/resources/settings.xml', S19)
    z.writestr('plugin.video.demoset/resources/settings-kodi20.xml', S20)
A.install_zip(b.getvalue())
check('vorhandene settings.xml gewinnt', 'type="text"' in (A.addon_path('plugin.video.demoset') / 'resources' / 'settings.xml').read_text())
A.remove('plugin.video.demoset')
print('Kodi-Addon mit derselben Kennung wie die Engine (plugin.video.moviescout)')
from kodi_runtime import xbmcaddon                                    # noqa: E402
SAME = DEFAULT.replace('xbmcplugin.endOfDirectory(h)', 'a.setSetting("hosted.only", "ja")\nli2 = xbmcgui.ListItem(label="Pfad " + a.getAddonInfo("path") + "|" + a.getAddonInfo("profile"))\n'
                       'xbmcplugin.addDirectoryItem(h, sys.argv[0] + "?x=2", li2, True)\nxbmcplugin.endOfDirectory(h)')
b = io.BytesIO()
with zipfile.ZipFile(b, 'w') as z:
    z.writestr('plugin.video.moviescout/addon.xml', ADDON_XML.replace('plugin.video.demoset', 'plugin.video.moviescout'))
    z.writestr('plugin.video.moviescout/default.py', SAME)
    z.writestr('plugin.video.moviescout/resources/settings-kodi20.xml', S20.replace('plugin.video.demoset', 'plugin.video.moviescout'))
xbmcaddon.save_settings({'api.tmdb': 'ENGINEKEY', 'm3u_urls': 'http://x/list.m3u'})
A.install_zip(b.getvalue())
ctx = context.begin() if hasattr(context, 'begin') else context.current()
ctx.items.clear()
A.run('plugin.video.moviescout')
titles = [i.get('title') for i in context.current().items]
check('Addon sieht seine eigenen Standardwerte', any((t or '').startswith('Eintrag true') for t in titles), titles)
eng = xbmcaddon.all_settings()
check('Einstellungen der Engine bleiben unberührt', eng.get('api.tmdb') == 'ENGINEKEY' and eng.get('m3u_urls') == 'http://x/list.m3u' and 'hosted.only' not in eng, eng)
check('Einstellung des Addons liegt im eigenen Ordner', xbmcaddon.all_settings('ao.plugin.video.moviescout').get('hosted.only') == 'ja')
pf = [t for t in titles if (t or '').startswith('Pfad ')]
check('Addon bekommt seinen eigenen Pfad und Profilordner', bool(pf) and '/addons/plugin.video.moviescout|' in pf[0] and '/ao.plugin.video.moviescout' in pf[0], pf)
check('Formular zeigt Werte des Addons, nicht der Engine', {x['id']: x['value'] for x in A.settings_schema('plugin.video.moviescout') if x['id']}.get('tmdb.api_key') in ('', None))
A.save_settings('plugin.video.moviescout', {'tmdb.api_key': 'ADDONKEY'})
check('Formular speichert getrennt von der Engine', xbmcaddon.all_settings('ao.plugin.video.moviescout').get('tmdb.api_key') == 'ADDONKEY' and xbmcaddon.all_settings().get('tmdb.api_key') != 'ADDONKEY')
A.remove('plugin.video.moviescout')
check('Entfernen lässt die Engine-Einstellungen stehen', xbmcaddon.all_settings().get('api.tmdb') == 'ENGINEKEY')

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
