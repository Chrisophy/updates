# -*- coding: utf-8 -*-
"""Oberflächen-Tests (Playwright) für: Mediaplayer, Dateibrowser, Widgets & Dash, Sammlungen, Regler/Lupe-Fokus,
Sicherung aus Ordner.

    python tests/media_ui_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
UP, API = 8851, 8852
BASE = 'http://127.0.0.1:%d/ui/' % API
passed = failed = 0

EXT_CODE = '''
EXT_ID = "demoext"
EXT_NAME = "Demo-Erweiterung"
EXT_LINKS = [("Demo-Seite", "seite")]

def register(api):
    api.widget("Demo", lambda: {"text": "42", "sub": "Demo-Wert", "icon": "🧪"}, ttl=5, id="demo", icon="🧪")
    api.route("seite", lambda req: "<html><body>Demo</body></html>")
    api.home_row("Demo-Reihe", lambda: [{"title": "Demo-Titel", "url": "x", "provider_id": "fake", "provider": "Fake"}], ttl=5)
'''


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def wait_port(port, tries=100):
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def api_post(path, data):
    import urllib.request
    req = urllib.request.Request('http://127.0.0.1:%d%s' % (API, path), data=json.dumps(data).encode(), headers={'Content-Type': 'application/json'})
    return json.loads(urllib.request.urlopen(req, timeout=60).read())


def run(pg, errs, tmp):
    print('Start')
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    pg.wait_for_selector('[data-sec=media]')
    check('Bereich „Mediaplayer“ mit 3 Kacheln', pg.locator('[data-sec=media] .tile').count() == 3, pg.locator('[data-sec=media]').inner_text())
    check('… Standard-Skin legt ihn vor die Quellen', pg.evaluate("[...document.querySelectorAll('#view > .hsec')].map(e => e.dataset.sec).join(',')") == 'favs,disc,news,media,status,tiles',
          pg.evaluate("[...document.querySelectorAll('#view > .hsec')].map(e => e.dataset.sec).join(',')"))

    print('Fokus: Lupe und Regler')
    pg.focus('#searchForm button')
    ol = pg.evaluate("(() => { const b = document.querySelector('#searchForm button'); const cs = getComputedStyle(b); return [cs.outlineStyle, cs.outlineWidth, cs.backgroundColor]; })()")
    check('Lupe zeigt beim Fokus eine Umrandung', ol[0] != 'none' and ol[1] != '0px', ol)
    pg.evaluate("""() => { const i = document.createElement('input'); i.type = 'range'; i.min = 0; i.max = 100; i.step = 10; i.value = 50;
      i.setAttribute('data-f', ''); i.id = 'tr'; i.style.cssText = 'position:fixed;left:20px;top:200px;width:300px;z-index:9999';
      window.__ev = 0; i.addEventListener('input', () => window.__ev++); document.body.append(i); }""")
    pg.focus('#tr')
    pg.keyboard.press('ArrowRight'); pg.keyboard.press('ArrowRight')
    check('Regler: Pfeil rechts erhöht (2 Schritte = 70)', pg.evaluate("document.getElementById('tr').value") == '70', pg.evaluate("document.getElementById('tr').value"))
    pg.keyboard.press('ArrowLeft')
    check('Regler: Pfeil links senkert', pg.evaluate("document.getElementById('tr').value") == '60')
    check('Regler bleibt fokussiert (springt nicht weg)', pg.evaluate("document.activeElement.id") == 'tr')
    check('Regler löst „input“ aus', pg.evaluate("window.__ev") == 3, pg.evaluate("window.__ev"))
    pg.keyboard.press('End')
    check('Regler: Ende = Maximum', pg.evaluate("document.getElementById('tr').value") == '100')
    ro = pg.evaluate("(() => { const cs = getComputedStyle(document.getElementById('tr')); return [cs.outlineStyle, cs.outlineWidth]; })()")
    check('Regler zeigt beim Fokus eine Umrandung', ro[0] != 'none' and ro[1] != '0px', ro)
    pg.evaluate("document.getElementById('tr').remove()")

    print('Mediaplayer')
    pg.locator('[data-sec=media] .tile', has_text='Musik').click()
    pg.wait_for_selector('.layer.mp')
    check('Mediaplayer öffnet leer', 'Noch nichts in' in pg.locator('.layer.mp').inner_text(), pg.locator('.layer.mp').inner_text()[:200])
    pg.get_by_role('button', name='＋ Dateien / Ordner hinzufügen').click()
    pg.wait_for_selector('.fsb')
    check('Dateibrowser zeigt Startpunkte', pg.locator('.fsb .fsrow').count() >= 2, pg.locator('.fsb').inner_text()[:200])
    pg.locator('.fsb .fsrow', has_text='Daten von MovieScout').click()
    pg.wait_for_selector('.fsb .fsrow >> text=media')
    pg.locator('.fsb .fsrow', has_text='media').first.click()
    pg.wait_for_selector('.fsb .fsrow >> text=Alben')
    names = pg.locator('.fsb .fslist').inner_text()
    check('Ordner im Dateibrowser: Alben, Filme, Fotos', all(n in names for n in ('Alben', 'Filme', 'Fotos')), names)
    check('Hinzufügen ist ohne Auswahl gesperrt', pg.locator('.fsb .actions .btn.pri').is_disabled())
    pg.locator('.fsb .fsrow2', has_text='Alben').get_by_role('button', name='＋ ganzer Ordner').click()
    pg.locator('.fsb .fsrow2', has_text='Filme').get_by_role('button', name='＋ ganzer Ordner').click()
    check('Mehrfachwahl: 2 ausgewählt', '2 ausgewählt' in pg.locator('.fsb .fscount').inner_text(), pg.locator('.fsb .fscount').inner_text())
    pg.locator('.fsb .fsrow2', has_text='Fotos').locator('.fsrow').click()
    pg.wait_for_selector('.fsb .fsrow.sel')
    pg.locator('.fsb .fsrow.sel', has_text='p.png').click()
    check('Einzelne Datei angekreuzt (3 ausgewählt)', '3 ausgewählt' in pg.locator('.fsb .fscount').inner_text(), pg.locator('.fsb .fscount').inner_text())
    pg.locator('.fsb .actions .btn.pri').click()
    pg.wait_for_selector('.mp-tabs .chip >> text=Musik (2)')
    tabs = pg.locator('.mp-tabs').inner_text()
    check('Auswahl landet sortiert in Musik (2) / Videos (2) / Bilder (1)', 'Musik (2)' in tabs and 'Videos (2)' in tabs and 'Bilder (1)' in tabs, tabs)
    check('Liste zeigt die Musik-Einträge', pg.locator('.mp-row').count() == 2, pg.locator('.mp-list').inner_text())
    first = pg.locator('.mp-row .mp-t').first.inner_text()
    pg.locator('.mp-row').first.get_by_role('button', name='Nach unten').click()
    pg.wait_for_timeout(300)
    check('Nach unten verschieben', pg.locator('.mp-row .mp-t').nth(1).inner_text() == first, pg.locator('.mp-list').inner_text())
    check('Fokus bleibt nach dem Verschieben auf dem Knopf', pg.evaluate("document.activeElement.getAttribute('aria-label')") == 'Nach oben', pg.evaluate("document.activeElement.getAttribute('aria-label')"))
    pg.locator('.mp-row').nth(1).get_by_role('button', name='Verschieben').click()
    pg.wait_for_selector('.panel >> text=Wohin soll der Eintrag')
    pg.get_by_role('button', name='🎬 In die Liste „Videos“').click()
    pg.wait_for_selector('.mp-tabs .chip >> text=Musik (1)')
    check('In andere Liste verschoben (Musik 1, Videos 3)', 'Videos (3)' in pg.locator('.mp-tabs').inner_text(), pg.locator('.mp-tabs').inner_text())
    pg.locator('.mp-row .mp-name').first.click()
    pg.wait_for_function("document.querySelector('.mp-media').getAttribute('src')")
    src = pg.evaluate("document.querySelector('.mp-media').getAttribute('src')")
    check('Wiedergabe lädt über die Engine (/api/media/file/…)', '/api/media/file/' in src, src)
    check('Musik zeigt Cover statt Video', pg.evaluate("document.querySelector('.mp-stage').dataset.kind") == 'music')
    pg.locator('.mp-tabs .chip', has_text='Bilder').click()
    pg.locator('.mp-row .mp-name').first.click()
    pg.wait_for_function("document.querySelector('.mp-img').getAttribute('src')")
    check('Bild wird angezeigt', pg.evaluate("document.querySelector('.mp-stage').dataset.kind") == 'image')
    vol = pg.locator('.mp-vol input')
    vol.focus()
    before = int(vol.input_value())
    pg.keyboard.press('ArrowLeft')
    check('Lautstärke-Regler per Pfeil verstellbar', int(vol.input_value()) == before - 5, (before, vol.input_value()))
    pg.locator('.mp-row').first.get_by_role('button', name='Entfernen').click()
    pg.wait_for_selector('.mp-tabs .chip >> text=Bilder (0)')
    check('Eintrag entfernt, Datei bleibt', (Path(tmp) / 'media' / 'Fotos' / 'p.png').exists())
    pg.keyboard.press('Escape')
    pg.wait_for_selector('.layer.mp', state='detached')
    pg.wait_for_selector('[data-sec=media] .tile >> text=3 Einträge')
    tiles = pg.locator('[data-sec=media]').inner_text()
    check('Startseite zeigt Zahlen (Musik 1, Videos 3)', '1 Einträge' in tiles and '3 Einträge' in tiles, tiles)

    print('Widgets & Dash')
    api_post('/api/admin/save', {'kind': 'extension', 'file': 'demoext.py', 'code': EXT_CODE})
    pg.goto(BASE)
    pg.wait_for_selector('.wstrip .wtile >> text=Demo-Wert')
    check('Standard: Widget sichtbar, Dash nicht', pg.locator('[data-sec=quick]').count() == 0)
    check('Anpassen-Knopf im Streifen', pg.locator('.wstrip .wtile.cfg').count() == 1)
    pg.locator('.wstrip .wtile.cfg').click()
    pg.wait_for_selector('.xman .xrow')
    check('Manager listet die Erweiterung', 'Demo-Erweiterung' in pg.locator('.xman').inner_text(), pg.locator('.xman').inner_text()[:200])
    row = pg.locator('.xman .xrow', has_text='Demo-Erweiterung')
    segs = row.locator('.seg').all_inner_texts()
    check('Vier Wahlmöglichkeiten: Aus, Widget, Dash, Widget und Dash', segs == ['Aus', 'Widget', 'Dash', 'Widget und Dash'], segs)
    check('Aktuell: Widget', row.locator('.seg[aria-checked=true]').inner_text() == 'Widget')
    bk = pg.locator('.xman .xrow', has_text='Scraper-Baukasten')
    check('Erweiterung nur mit Seite: Widget-Wahl gesperrt', bk.count() == 1 and bk.get_by_role('radio', name='Widget', exact=True).is_disabled())
    row.get_by_role('radio', name='Dash', exact=True).click()
    pg.keyboard.press('Escape')
    pg.wait_for_selector('[data-sec=quick] .wtile >> text=Demo-Seite')
    check('Nur Dash: Seite-Knopf da, Widget weg', pg.locator('.wstrip .wtile', has_text='Demo-Wert').count() == 0 and pg.locator('[data-sec=quick] .wtile', has_text='Demo-Seite').count() == 1)
    pg.locator('[data-sec=quick] .wtile.cfg').click()
    pg.wait_for_selector('.xman .xrow')
    pg.locator('.xman .xrow', has_text='Demo-Erweiterung').get_by_role('radio', name='Widget und Dash').click()
    pg.keyboard.press('Escape')
    pg.wait_for_selector('.wstrip .wtile >> text=Demo-Wert')
    check('Widget und Dash: beides sichtbar', pg.locator('.wstrip .wtile', has_text='Demo-Wert').count() == 1 and pg.locator('[data-sec=quick] .wtile', has_text='Demo-Seite').count() == 1)
    pg.locator('.wstrip .wtile.cfg').first.click()
    pg.wait_for_selector('.xman .xrow')
    row = pg.locator('.xman .xrow', has_text='Demo-Erweiterung')
    row.get_by_role('radio', name='Aus', exact=True).click()
    row.get_by_role('switch', name='Reihe auf der Startseite').click()
    pg.keyboard.press('Escape')
    pg.wait_for_timeout(500)
    check('Aus: weder Widget noch Dash', pg.locator('.wstrip .wtile', has_text='Demo-Wert').count() == 0 and pg.locator('[data-sec=quick]').count() == 0)
    check('Reihe der Erweiterung ausgeblendet', pg.locator('[data-sec=ext-row]').count() == 0)
    saved = pg.evaluate("[localStorage.getItem('mk.xmode'), localStorage.getItem('mk.xhide')]")
    check('Auswahl wird gespeichert', '"demoext":"off"' in saved[0] and '"rows":true' in saved[1], saved)

    print('Sammlungen')
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    pg.locator('[data-sec=tiles] .tile', has_text='Fake').click()
    pg.get_by_text('Filme', exact=True).first.click()
    pg.wait_for_selector('.card')
    pg.get_by_role('button', name='📚 Ordner zu einer Sammlung').click()
    pg.wait_for_selector('.bundlepick')
    pg.locator('.bundlepick input').fill('Wochenende')
    pg.get_by_role('button', name='Anlegen').click()
    pg.wait_for_selector('.bundlepick .favrow[aria-checked=true]')
    check('Ordner in neue Sammlung gelegt', pg.locator('.bundlepick .favrow', has_text='Wochenende').count() == 1)
    pg.get_by_role('button', name='Fertig').click()
    pg.wait_for_timeout(300)
    b = pg.evaluate("JSON.parse(localStorage.getItem('mk.bundles'))")
    check('Sammlung gespeichert (1 Ordner)', len(b) == 1 and len(b[0]['folders']) == 1 and b[0]['folders'][0]['kind'] == 'provider', b)
    pg.goto(BASE)
    pg.wait_for_selector('[data-sec=favs] .tile.bundles, [data-sec=favs] .bundles .tile')
    pg.get_by_role('button', name='Sammlungen verwalten').click()
    pg.wait_for_selector('.bundleman')
    pg.get_by_role('button', name='＋ Ordner vom Gerät').click()
    pg.wait_for_selector('.fsb')
    pg.locator('.fsb .fsrow', has_text='Daten von MovieScout').click()
    pg.locator('.fsb .fsrow', has_text='media').first.click()
    pg.wait_for_selector('.fsb .fsrow >> text=Filme')
    pg.locator('.fsb .fsrow2', has_text='Filme').get_by_role('button', name='＋ Ordner').click()
    pg.locator('.fsb .actions .btn.pri').click()
    pg.wait_for_selector('.bundleman >> text=📁 Filme')
    check('Ordner vom Gerät zur Sammlung hinzugefügt', 'Filme' in pg.locator('.bundleman').inner_text())
    pg.keyboard.press('Escape')
    pg.wait_for_selector('[data-sec=favs] .bundles .tile >> text=2 Ordner')
    tile = pg.locator('[data-sec=favs] .bundles .tile').text_content()
    check('Startseite: eine Kachel „Wochenende“ (2 Ordner gebündelt)', 'Wochenende' in tile and '2 Ordner' in tile, tile)
    pg.locator('[data-sec=favs] .bundles .tile').click()
    pg.wait_for_selector('.crumbs h1 >> text=Wochenende')
    pg.wait_for_selector('.card, .row')
    txt = pg.locator('#view').inner_text()
    check('Gebündelte Ansicht zeigt Inhalte beider Ordner (Quelle + Gerät)', 'f' in txt and pg.locator('.card, .row').count() >= 2, txt[:300])
    pg.go_back()
    pg.wait_for_selector('.tile')

    print('Sicherung einspielen ohne Dateiauswahl des Systems')
    z = api_post_raw('/api/admin/export', {'ui': {}, 'full': False})
    Path(tmp, 'media', 'sicherung.zip').write_bytes(z)
    pg.click('#btnSettings'); pg.get_by_role('tab', name='Quellen & Listen').click(); pg.get_by_role('button', name='Quellen & System').click()
    pg.wait_for_selector('.ordrow')
    pg.get_by_role('tab', name='Sicherung', exact=True).click()
    pg.get_by_role('button', name='Aus Ordner wählen …').click()
    pg.wait_for_selector('.fsb')
    pg.locator('.fsb .fsrow', has_text='Daten von MovieScout').click()
    pg.locator('.fsb .fsrow', has_text='media').first.click()
    pg.wait_for_selector('.fsb .fsrow >> text=sicherung.zip')
    check('Nur Ordner und ZIP-Dateien werden gezeigt', 'p.png' not in pg.locator('.fsb .fslist').inner_text())
    pg.locator('.fsb .fsrow', has_text='sicherung.zip').click()
    pg.wait_for_selector('pre.log:not([hidden])')
    logtxt = pg.locator('pre.log:not([hidden])').first.inner_text()
    check('Sicherung eingespielt (Bericht)', 'Mediathek' in logtxt or 'Einstellungen' in logtxt, logtxt)
    pg.evaluate("window.msNoPicker && 0")
    check('Kein „Gerät ohne Dateiauswahl“-Haken: msNoPicker vorhanden', pg.evaluate("typeof window.msNoPicker") == 'function')
    check('Vom-Handy-Weg vorhanden', pg.get_by_role('button', name='Vom Handy (Familienchat) …').count() == 1)

    print('Konsole')
    check('Keine JavaScript-Fehler', not errs, errs[:5])


def api_post_raw(path, data):
    import urllib.request
    req = urllib.request.Request('http://127.0.0.1:%d%s' % (API, path), data=json.dumps(data).encode(), headers={'Content-Type': 'application/json'})
    return urllib.request.urlopen(req, timeout=60).read()


def main():
    tmp = tempfile.mkdtemp()
    media = Path(tmp) / 'media'
    (media / 'Alben' / 'Eins').mkdir(parents=True)
    (media / 'Filme').mkdir()
    (media / 'Fotos').mkdir()
    import struct
    def wav(sec):
        n = 8000 * sec
        return b'RIFF' + struct.pack('<I', 36 + n) + b'WAVEfmt ' + struct.pack('<IHHIIHH', 16, 1, 1, 8000, 8000, 1, 8) + b'data' + struct.pack('<I', n) + b'\x80' * n
    (media / 'Alben' / 'Eins' / 'a.wav').write_bytes(wav(30))
    (media / 'Alben' / 'Eins' / 'b.wav').write_bytes(wav(20))
    (media / 'Filme' / 'f.mp4').write_bytes(b'\0\0\0\x18ftypmp42' + b'\1' * 5000)
    (media / 'Filme' / 'g.mkv').write_bytes(b'\x1a\x45\xdf\xa3' + b'\2' * 100)
    import base64
    (media / 'Fotos' / 'p.png').write_bytes(base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='))
    env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'),
               MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1')
    env.pop('MINIKODI_TOKEN', None); env.pop('MOVIESCOUT_TOKEN', None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait_port(UP) and wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 1280, 'height': 900})
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text and 'media' not in m.text.lower() else None)
            try:
                run(pg, errs, tmp)
            except Exception:      # noqa: BLE001
                import traceback
                traceback.print_exc()
                global failed
                failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png'))
                print('Screenshot:', Path(tmp) / 'fail.png')
            b.close()
    finally:
        srv.terminate()
        up.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
