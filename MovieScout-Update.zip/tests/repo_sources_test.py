# -*- coding: utf-8 -*-
"""Offline-Test: Eingabeformen für zusätzliche Kodi-Repositories (GitHub-Link, repository.*.zip, Ordner, addons.xml).

    python tests/repo_sources_test.py
"""
import io
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from engine import addonrepo as AR  # noqa: E402

failed = 0


def check(name, cond, extra=''):
    global failed
    print('  ok   ' if cond else '  FEHLER', name, '' if cond else extra)
    failed += 0 if cond else 1


REPO_XML = b'''<addon id="repository.demo" name="Demo" version="1.0" provider-name="x">
<extension point="xbmc.addon.repository" name="Demo">
 <dir><info compressed="false">https://raw.githubusercontent.com/u/r/main/addons.xml</info>
 <checksum>https://raw.githubusercontent.com/u/r/main/addons.xml.md5</checksum>
 <datadir zip="true">https://raw.githubusercontent.com/u/r/main/zips</datadir></dir>
</extension></addon>'''


def mkzip(xml):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        z.writestr('repository.demo/addon.xml', xml)
    return b.getvalue()


c = AR._candidates
check('GitHub-Wurzel: main/master, auch zips/', c('https://github.com/u/r/') == [
    ('dir', 'https://raw.githubusercontent.com/u/r/main/'), ('dir', 'https://raw.githubusercontent.com/u/r/main/zips/'),
    ('dir', 'https://raw.githubusercontent.com/u/r/master/'), ('dir', 'https://raw.githubusercontent.com/u/r/master/zips/')], c('https://github.com/u/r/'))
check('GitHub-Ordner (tree)', c('https://github.com/u/r/tree/dev/repo/')[0] == ('dir', 'https://raw.githubusercontent.com/u/r/dev/repo/'))
check('GitHub-Datei-Link auf ZIP', c('https://github.com/u/r/blob/main/repository.demo.zip') == [('zip', 'https://raw.githubusercontent.com/u/r/main/repository.demo.zip')])
check('ZIP-Link anderswo', c('https://example.org/repository.demo.zip') == [('zip', 'https://example.org/repository.demo.zip')])
check('Ordner: auch zips/', c('https://example.org/repo/') == [('dir', 'https://example.org/repo/'), ('dir', 'https://example.org/repo/zips/')])
check('Index|Datenordner', c('https://a/x/addons.xml|https://a/x/zips/') == [('index', 'https://a/x/addons.xml', 'https://a/x/zips/')])

name, rid = None, None
rid, name, dirs = AR._repo_dirs(REPO_XML)
check('repository.*.zip: info und datadir gelesen', dirs == [('https://raw.githubusercontent.com/u/r/main/addons.xml', 'https://raw.githubusercontent.com/u/r/main/zips/')], dirs)
check('zip_repo_info erkennt Repository-Addon', AR.zip_repo_info(mkzip(REPO_XML))[0] == 'repository.demo')
check('normales Addon ist kein Repository', AR.zip_repo_info(mkzip(b'<addon id="plugin.video.x" version="1"><extension point="xbmc.python.pluginsource" library="a.py"/></addon>')) is None)
check('Keine ZIP -> None', AR.zip_repo_info(b'kein zip') is None)
try:
    AR._repo_dirs(b'<!DOCTYPE a [<!ENTITY x "y">]><addon id="a"/>')
    check('ENTITY wird abgelehnt', False)
except AR.RepoError:
    check('ENTITY wird abgelehnt', True)

import tempfile, os  # noqa: E402
os.environ.setdefault('MOVIESCOUT_DATA', tempfile.mkdtemp())
from kodi_runtime import xbmcaddon  # noqa: E402
xbmcaddon.save_settings({'kodi_repos': 'https://github.com/u/r\nhttps://example.org/a/addons.xml, https://example.org/a/ "https://example.org/r.zip"'})
ex = AR.extra_bases()
check('extra_bases: bereinigt, ohne Doppelte', ex == ['https://github.com/u/r/', 'https://example.org/a/', 'https://example.org/r.zip'], ex)
r = AR.register_repo(mkzip(REPO_XML))
check('register_repo trägt ein (mit Namen)', r and r['added'] == ['https://raw.githubusercontent.com/u/r/main/addons.xml|https://raw.githubusercontent.com/u/r/main/zips/|Demo'], r)
check('register_repo doppelt: nichts Neues', AR.register_repo(mkzip(REPO_XML))['added'] == [])
check('Eintrag erscheint in extra_bases', ex[0] in AR.extra_bases() and any('|' in x for x in AR.extra_bases()), AR.extra_bases())
xbmcaddon.save_settings({'kodi_repos': ''})
check('Beschriftung aus dem Eintrag: GitHub', AR._label('https://github.com/u/r/') == 'u/r' and AR._label('https://raw.githubusercontent.com/u/r/main/addons.xml|x') == 'u/r', AR._label('https://github.com/u/r/'))
check('Beschriftung aus dem Eintrag: Adresse / ZIP', AR._label('https://example.org/a/b/') == 'example.org/a/b' and AR._label('https://example.org/repository.x.zip') == 'repository.x.zip')
check('Name im Eintrag wird für die Beschriftung genutzt (URL-kodiert)', AR._candidates('https://a/addons.xml|https://a/zips/|Mein%20Repo')[0][2] == 'https://a/zips/')
xbmcaddon.save_settings({'kodi_repos': 'https://a.example/x/\nhttps://b.example/y/'})
before = AR.extra_bases()
rm = AR.remove_repo(before[0])
check('remove_repo entfernt genau diesen Eintrag', rm == {'removed': True} and AR.extra_bases() == before[1:], AR.extra_bases())
try:
    AR.remove_repo('https://gibtes.nicht/')
    check('remove_repo: unbekannter Eintrag wird gemeldet', False)
except AR.RepoError:
    check('remove_repo: unbekannter Eintrag wird gemeldet', True)
xbmcaddon.save_settings({'kodi_repos': ''})
print('FEHLER: %d' % failed if failed else 'Alles ok')
sys.exit(1 if failed else 0)
