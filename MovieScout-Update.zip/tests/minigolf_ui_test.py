# -*- coding: utf-8 -*-
"""Minigolf (Erweiterung): Seite über die Engine, Bedienung per Joystick + Knopf, Loch, Münzen, Shop, Speicherstand, Runde.

    python tests/minigolf_ui_test.py
"""
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
API = 8981
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError:
            time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 900, 'height': 420}, has_touch=True)
            pg = ctx.new_page()
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/api/x/minigolf/index' % API)
            pg.wait_for_function('window.MG && MG.L', timeout=15000)
            check('Menü beim Start', pg.locator('#ov h1').inner_text().startswith('⛳'))
            check('18 Bahnen', pg.evaluate('MG.HOLES.length') == 18)
            check('10 Ballmuster', pg.evaluate('MG.SKINS.length') == 10)
            pg.locator('[data-a=new]').click(); pg.wait_for_timeout(300)
            check('Spiel läuft, Menü zu', pg.evaluate("document.getElementById('ov').style.display") == 'none' and pg.evaluate('MG.G.state') == 'aim')
            check('Joystick und Knopf sichtbar', pg.locator('#joy').is_visible() and pg.locator('#pw').is_visible())

            # Joystick: Richtung nach rechts -> Zielwinkel ~ 0
            j = pg.locator('#joy').bounding_box()
            cx, cy = j['x'] + j['width'] / 2, j['y'] + j['height'] / 2
            pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx + 40, cy, steps=4)
            a = pg.evaluate('MG.G.aim')
            check('Joystick rechts stellt Winkel ≈ 0 ein', abs(a) < .1, a)
            pg.mouse.move(cx, cy - 40, steps=4)
            check('Joystick hoch stellt Winkel ≈ -90° ein', abs(pg.evaluate('MG.G.aim') + 1.5708) < .1)
            pg.mouse.up()
            check('Zielrichtung bleibt nach Loslassen', abs(pg.evaluate('MG.G.aim') + 1.5708) < .1)

            # Knopf halten und loslassen
            pw = pg.locator('#pw').bounding_box()
            pg.mouse.move(pw['x'] + pw['width'] / 2, pw['y'] + pw['height'] / 2); pg.mouse.down(); pg.wait_for_timeout(450)
            pwv = pg.evaluate('MG.G.pw')
            check('Kraft baut sich auf', pwv > .15, pwv)
            pg.mouse.up(); pg.wait_for_timeout(150)
            check('Schlag gezählt, Ball rollt', pg.evaluate('MG.G.strokes') == 1 and pg.evaluate('MG.G.state') in ('roll', 'aim'))
            pg.wait_for_function("MG.G.state==='aim'", timeout=30000)
            check('Ball liegt wieder, bewegt sich nicht', pg.evaluate('Math.hypot(MG.B.vx,MG.B.vy)') == 0)
            check('Ball ist weitergerollt (oben)', pg.evaluate('MG.B.y') < pg.evaluate('MG.L.tee[1]') - 20)

            # Lochen: Ball dicht am Loch, langsam
            pg.evaluate("() => { const B=MG.B,c=MG.L.cup; B.x=c[0]+14;B.y=c[1];B.vx=-40;B.vy=0; MG.G.state='roll'; MG.G.strokes=2; }")
            pg.wait_for_function("MG.G.state==='card'", timeout=15000)
            txt = pg.locator('#ov').inner_text()
            check('Ergebnis-Karte nennt Par und Münzen', 'Par 2' in txt and '🪙' in txt, txt)
            coins = pg.evaluate('MG.S.coins')
            check('Münzen gutgeschrieben', coins >= 10, coins)
            check('Bestwert gemerkt', pg.evaluate('MG.S.best[0]') == 2)

            # Weiter bis zum Ende: schnelle Runde
            for i in range(1, 18):
                pg.locator('[data-a=next]').click(); pg.wait_for_timeout(120)
                pg.evaluate("() => { MG.G.strokes = MG.L.d.par; MG.finishHole(false); }")
            check('Letzte Bahn: Ergebnis-Knopf', 'Ergebnis' in pg.locator('[data-a=next]').inner_text())
            pg.locator('[data-a=next]').click(); pg.wait_for_timeout(200)
            check('Rundenergebnis', 'Runde geschafft' in pg.locator('#ov').inner_text() and pg.evaluate('MG.S.round') is None)
            check('Beste Runde gespeichert', pg.evaluate('MG.S.bestRound') > 0)

            # Shop
            pg.evaluate("() => { MG.S.coins = 120; }")
            pg.locator('[data-a=menu]').click(); pg.locator('[data-a=skins]').click(); pg.wait_for_timeout(200)
            check('Shop zeigt 10 Muster', pg.locator('.skin').count() == 10)
            before = pg.evaluate('MG.S.coins')
            pg.locator('.skin').nth(5).click(); pg.wait_for_timeout(150)
            check('Kaufen zieht Münzen ab und wählt aus', pg.evaluate('MG.S.coins') == before - 90 and pg.evaluate('MG.S.skin') == 5)
            pg.locator('.skin').nth(9).click(); pg.wait_for_timeout(150)
            check('Zu teuer: nicht gekauft', pg.evaluate('MG.S.skin') == 5 and 9 not in pg.evaluate('MG.S.owned'))

            # Speicherstand überlebt Neuladen
            pg.evaluate("() => { MG.S.coins = MG.S.coins; }")
            pg.reload(); pg.wait_for_function('window.MG && MG.L', timeout=15000)
            check('Münzen/Ball nach Neuladen', pg.evaluate('MG.S.skin') == 5 and 5 in pg.evaluate('MG.S.owned') and pg.evaluate('MG.S.coins') > 0)
            check('Bestwerte nach Neuladen', pg.evaluate('MG.S.best[0]') == 2)

            # Hochkant
            pg.set_viewport_size({'width': 420, 'height': 800}); pg.wait_for_timeout(300)
            pg.locator('[data-a=holes]').click(); pg.locator('.cell').nth(2).click(); pg.wait_for_timeout(400)
            check('Einzelne Bahn 3 startet im Hochformat', pg.evaluate('MG.G.hole') == 2 and pg.evaluate('MG.G.mode') == 'single')
            box = pg.locator('#pw').bounding_box()
            check('Knopf liegt im Bild', box and 0 <= box['x'] and box['x'] + box['width'] <= 421 and box['y'] + box['height'] <= 801)
            # Wasser: Strafschlag
            pg.evaluate("() => { const B=MG.B; B.x=140;B.y=200;B.vx=0;B.vy=-30;MG.G.state='roll'; }")
            pg.wait_for_function("MG.G.state==='aim' && MG.G.strokes>=1", timeout=15000)
            check('Wasser: Strafschlag, Ball zurück am Start', pg.evaluate('MG.G.strokes') == 1 and abs(pg.evaluate('MG.B.y') - pg.evaluate('MG.B.sy')) < 1)
            b.close()
    finally:
        srv.terminate()
    check('keine JS-Fehler', not errs, errs)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
