# -*- coding: utf-8 -*-
"""Test der Sprachsteuerung (Befehle, Mikrofon, Eingabefeld, Player-Steuerung) mit echter Engine und Browser.

    python tests/voice_test.py
"""
import json
import threading
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from datetime import date
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8906
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=30) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=8, step=0.1):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def setv(ext, **values):
    return http('/api/admin/ext/settings', {'ext': ext, 'values': values})[0]


def code_of(gid):
    from engine import examples as EXM
    return next(e for e in EXM.EXAMPLES if e['id'] == gid)['code']


class CorsHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def do_GET(self):                                      # Range-Unterstützung (sonst lässt sich das Video nicht spulen)
        rng = self.headers.get('Range')
        f = Path(self.translate_path(self.path))
        if not rng or not f.is_file():
            return super().do_GET()
        data = f.read_bytes()
        a, _, b = rng.replace('bytes=', '').partition('-')
        start = int(a or 0)
        end = int(b) if b else len(data) - 1
        end = min(end, len(data) - 1)
        chunk = data[start:end + 1]
        self.send_response(206)
        self.send_header('Content-Type', 'video/webm')
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Range', 'bytes %d-%d/%d' % (start, end, len(data)))
        self.send_header('Content-Length', str(len(chunk)))
        self.end_headers()
        try:
            self.wfile.write(chunk)
        except Exception:                                  # noqa: BLE001
            pass

    def log_message(self, *a):
        pass


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_voice_'))
    vd = tmp / 'v'
    vd.mkdir()
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=160x90:rate=10:duration=30', '-c:v', 'libvpx', '-b:v', '100k', str(vd / 't.webm')], check=True)
    fport = 8907
    fake = ThreadingHTTPServer(('127.0.0.1', fport), partial(CorsHandler, directory=str(vd)))
    threading.Thread(target=fake.serve_forever, daemon=True).start()
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'),
               FAKE_UP='http://127.0.0.1:%d' % fport, PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            br = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
            ctx = br.new_context(viewport={'width': 1000, 'height': 700})
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(BASE + '/ui/?api=' + BASE)
            pg.wait_for_function('typeof voiceRun === "function" && providers.length > 0', timeout=30000)
            say = lambda t: pg.evaluate("(t) => voiceRun(t)", t)
            top = lambda: pg.evaluate("JSON.stringify(nav[nav.length - 1])")
            toast = lambda: pg.evaluate("[...document.querySelectorAll('.toast')].map((e) => e.textContent).join(' | ')")

            print('Befehle: Suchen, Starten, Öffnen')
            check('Mikrofon-Knopf in der Kopfzeile', pg.locator('#btnVoice').count() == 1)
            say('Suche Film Matrix')
            pg.wait_for_function("nav[nav.length - 1].type === 'search'", timeout=5000)
            check('„Suche Film Matrix“ öffnet die Suche nach „matrix“', pg.evaluate("nav[nav.length - 1].q") == 'matrix' and not pg.evaluate("!!nav[nav.length - 1].auto"))
            pg.wait_for_function("document.body.innerText.includes('Treffer für matrix')", timeout=20000)
            check('Treffer erscheinen', True)
            say('Hey MovieScout, bitte suche die Serie Dark')
            pg.wait_for_function("nav[nav.length - 1].q === 'dark'", timeout=5000)
            check('Anrede und „bitte“ werden ignoriert („Suche die Serie Dark“)', True)
            pg.evaluate("window.__act = null; activate = (it) => { window.__act = it; }")
            say('Starte den Film Matrix')
            pg.wait_for_function("window.__act", timeout=25000)
            check('„Starte Matrix“ sucht und wählt den besten Treffer', 'matrix' in pg.evaluate("window.__act.title").lower() and pg.evaluate("voiceStart") is True, pg.evaluate("window.__act.title"))
            pg.evaluate("voiceStart = false")
            say('Öffne Fake')
            pg.wait_for_function("nav[nav.length - 1].type === 'list'", timeout=5000)
            check('„Öffne Fake“ öffnet die Quelle', pg.evaluate("nav[nav.length - 1].pid") == pg.evaluate("providers.find((p) => /fake/i.test(p.name)).id"))
            say('Öffne Gibtesnicht')
            check('Unbekannte Quelle: Hinweis', 'nicht gefunden' in toast(), toast())
            say('Startseite')
            say('Öffne Einstellungen')
            pg.wait_for_selector('.layer .panel', timeout=4000)
            check('„Öffne Einstellungen“ öffnet die Einstellungen', True)
            pg.evaluate("history.back()"); pg.wait_for_timeout(500)
            say('Hilfe')
            pg.wait_for_selector('.panel:has-text("Sprachbefehle")', timeout=4000)
            check('„Hilfe“ zeigt die Befehle', True)
            pg.evaluate("history.back()"); pg.wait_for_timeout(500)
            say('Quatsch mit Soße')
            check('Unverständliches wird gemeldet', 'Nicht verstanden' in toast(), toast())

            print('Befehle im Player')
            hos = {'id': 0, 'name': 'W', 'url': 'http://127.0.0.1:%d/t.webm' % fport, 'format': 'webm', 'direct': True, 'headers': {}, 'drm': None}
            pg.evaluate("([h]) => startPlayer({ item: { title: 'Voice' }, hosters: [h], index: 0 }, 0)", [hos])
            pg.wait_for_function("document.querySelector('video') && document.querySelector('video').readyState >= 3", timeout=20000)
            vid = lambda js: pg.evaluate("(() => { const v = document.querySelector('video'); return " + js + "; })()")
            say('Pause')
            check('„Pause“ hält an', vid('v.paused') is True)
            say('Weiter')
            pg.wait_for_timeout(300)
            check('„Weiter“ spielt', vid('v.paused') is False)
            t0 = vid('v.currentTime'); say('Vorspulen 5 Sekunden'); pg.wait_for_timeout(300)
            check('„Vorspulen 5 Sekunden“', vid('v.currentTime') >= t0 + 4.5, (t0, vid('v.currentTime')))
            say('Pause'); t1 = vid('v.currentTime'); say('Zurückspulen 2 Sekunden'); pg.wait_for_timeout(300)
            check('„Zurückspulen 2 Sekunden“', abs(vid('v.currentTime') - (t1 - 2)) < 0.6, (t1, vid('v.currentTime')))
            say('Vorspulen zwei Minuten'); pg.wait_for_timeout(300)
            check('Zahlwort + Minuten wird am Ende begrenzt', vid('v.currentTime') <= 30)
            say('Springe auf Sekunde 3'); pg.wait_for_timeout(300)
            check('„Springe auf Sekunde 3“', abs(vid('v.currentTime') - 3) < 0.6, vid('v.currentTime'))
            say('Von vorn'); pg.wait_for_timeout(300)
            check('„Von vorn“', vid('v.currentTime') < 0.6)
            vid('(v.volume = 0.5, 0)'); say('Lauter')
            check('„Lauter“', vid('v.volume') > 0.6)
            say('Leiser'); say('Leiser')
            check('„Leiser“', vid('v.volume') < 0.5)
            say('Stumm'); check('„Stumm“', vid('v.muted') is True)
            say('Ton an'); check('„Ton an“', vid('v.muted') is False)
            say('Untertitel')
            pg.wait_for_selector('.panel:has-text("Untertitel")', timeout=4000)
            check('„Untertitel“ öffnet das Untertitel-Menü', True)
            pg.evaluate("history.back()"); pg.wait_for_timeout(500)
            check('Mikrofon-Knopf im Player', pg.locator('#micBtn').count() == 1)
            say('Stopp'); pg.wait_for_timeout(700)
            check('„Stopp“ schließt den Player', pg.evaluate("playerCtl === null") and pg.locator('video').count() == 0)

            print('Mikrofon und Eingabefeld')
            pg.evaluate("""(() => { window.__recs = []; window.webkitSpeechRecognition = window.SpeechRecognition = class { constructor() { window.__recs.push(this); } start() { this.started = true; } stop() { this.onend && this.onend(); } }; })()""")
            pg.click('#btnVoice')
            pg.wait_for_function("window.__recs.length === 1 && window.__recs[0].started", timeout=3000)
            check('Spracherkennung startet in Deutsch', pg.evaluate("window.__recs[0].lang") == 'de-DE')
            check('„Ich höre zu“ wird angezeigt', 'höre zu' in toast())
            pg.evaluate("""(() => { const r = window.__recs[0]; const res = [[{ transcript: 'suche film inception' }]]; res[0].isFinal = true; r.onresult({ resultIndex: 0, results: res }); })()""")
            pg.wait_for_function("nav[nav.length - 1].q === 'inception'", timeout=4000)
            check('Gesprochener Befehl wird ausgeführt', True)
            pg.evaluate("window.__recs.length = 0; window.webkitSpeechRecognition = window.SpeechRecognition = undefined; delete window.SpeechRecognition; delete window.webkitSpeechRecognition")
            pg.click('#btnVoice')
            pg.wait_for_selector('.panel input[aria-label="Sprachbefehl"]', timeout=4000)
            pg.fill('.panel input[aria-label="Sprachbefehl"]', 'suche serie tatort')
            pg.press('.panel input[aria-label="Sprachbefehl"]', 'Enter')
            pg.wait_for_function("nav[nav.length - 1].q === 'tatort'", timeout=4000)
            check('Ohne Spracherkennung: Eingabefeld (Tastatur-Diktat) führt den Befehl aus', True)
            pg.evaluate("window.MovieScoutApp = { startVoice() { window.__nv = 1; } }")
            pg.click('#btnVoice'); pg.wait_for_timeout(300)
            check('App mit startVoice() wird bevorzugt, Ergebnis über msVoice', pg.evaluate("window.__nv") == 1)
            pg.evaluate("msVoice('suche film alien')")
            pg.wait_for_function("nav[nav.length - 1].q === 'alien'", timeout=4000)
            check('msVoice führt den Befehl aus', True)
            pg.evaluate("msVoiceFail()")
            pg.wait_for_selector('.panel input[aria-label="Sprachbefehl"]', timeout=4000)
            check('Fehlt die Spracheingabe am Gerät, erscheint das Eingabefeld', 'Keine Spracheingabe' in toast())
            check('Keine Skriptfehler', not errs, errs)
            ctx.close(); br.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        fake.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
