# -*- coding: utf-8 -*-
"""Test der Solitaire (Logik, Bedienung per Tastatur/Touch, Bestwerte, Layout) mit echter Engine und Browser.

    python tests/solitaire_test.py
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from datetime import date
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8900
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=30) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=8, step=0.1):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def setv(ext, **values):
    return http('/api/admin/ext/settings', {'ext': ext, 'values': values})[0]


def code_of(gid):
    from engine import examples as EXM
    return next(e for e in EXM.EXAMPLES if e['id'] == gid)['code']


def main():
    tmp = Path(tempfile.mkdtemp(prefix='ms_sol_'))
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)
        code, js = http('/api/admin/examples/install', {'id': 'solitaire'})
        check('installiert', code == 200 and js.get('ok'), (code, js))
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            br = pw.chromium.launch()
            pg = br.new_page(viewport={'width': 1000, 'height': 700})
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(BASE + '/api/x/solitaire/index?seed=7')
            pg.wait_for_function('window.SOL && SOL.state()')
            ev = pg.evaluate
            print('Logik')
            check('Austeilen: 7 Spalten mit 1..7 Karten, nur oberste offen, 24 im Stapel, 52 insgesamt',
                  ev('(()=>{const g=SOL.state();return g.tab.every((p,i)=>p.length===i+1&&p.every((c,j)=>c.up===(j===i)))&&g.stock.length===24&&g.stock.every(c=>!c.up)&&g.tab.flat().length+g.stock.length===52})()'))
            check('Alle 52 Karten verschieden', ev('(()=>{const g=SOL.state();const a=[...g.tab.flat(),...g.stock];return new Set(a.map(c=>c.s*20+c.r)).size===52})()'))
            check('Gleicher Startwert = gleiches Blatt, anderer = anderes', ev('(()=>{const a=JSON.stringify(SOL.deal(SOL.mulberry(5),1)),b=JSON.stringify(SOL.deal(SOL.mulberry(5),1)),c=JSON.stringify(SOL.deal(SOL.mulberry(6),1));return a===b&&a!==c})()'))
            check('Tableau: absteigend, Farbe wechselt; König nur auf leere Spalte', ev("""(()=>{const c=(r,s)=>({r,s,up:true});
              return [SOL.canTab(c(6,2),[c(7,0)]),SOL.canTab(c(6,0),[c(7,0)]),SOL.canTab(c(6,2),[c(8,0)]),SOL.canTab(c(13,0),[]),SOL.canTab(c(12,0),[]),SOL.canTab(c(6,2),[{r:7,s:0,up:false}])].join()})()""") == 'true,false,false,true,false,false')
            check('Ablage: nur Ass zuerst, dann der Reihe nach pro Farbe', ev("""(()=>{const g=SOL.deal(SOL.mulberry(1),1);return [SOL.canFound(g,{r:1,s:0}),SOL.canFound(g,{r:2,s:0})].join()})()""") == 'true,false')
            check('Ziehen 1: eine Karte vom Stapel auf den Ablagestapel (aufgedeckt)', ev('(()=>{const g=SOL.deal(SOL.mulberry(2),1);SOL.drawStock(g);return g.stock.length===23&&g.waste.length===1&&g.waste[0].up&&g.moves===1})()'))
            check('Ziehen 3: drei Karten', ev('(()=>{const g=SOL.deal(SOL.mulberry(2),3);SOL.drawStock(g);return g.stock.length===21&&g.waste.length===3})()'))
            check('Stapel leer: Ablage wird umgedreht, Reihenfolge bleibt erhalten', ev("""(()=>{const g=SOL.deal(SOL.mulberry(3),1);const first=g.stock[g.stock.length-1];while(g.stock.length)SOL.drawStock(g);SOL.drawStock(g);return g.stock.length===24&&g.waste.length===0&&g.stock[g.stock.length-1]===first&&g.stock.every(c=>!c.up)})()"""))
            check('Zug: Karte versetzen deckt die darunter liegende auf, falsche Züge werden abgelehnt', ev("""(()=>{const c=(r,s,up=true)=>({r,s,up});const g=SOL.deal(SOL.mulberry(1),1);
              g.tab=[[c(9,1,false),c(9,0)],[c(10,1,false),c(8,2)],[],[],[],[],[]];
              const ok=SOL.doMove(g,{t:'tab',i:1,k:1},{t:'tab',i:0});const bad=SOL.doMove(g,{t:'tab',i:0,k:1},{t:'found',i:0});
              return JSON.stringify([ok,bad,g.tab[0].length,g.tab[1].length,g.tab[1][0].up])})()""") == '[true,false,3,1,true]')
            check('Mehrere Karten werden zusammen verschoben, nur wenn alle offen sind', ev("""(()=>{const c=(r,s,up=true)=>({r,s,up});const g=SOL.deal(SOL.mulberry(1),1);
              g.tab=[[c(9,1,false),c(8,2),c(7,0)],[c(9,0)],[],[],[],[],[]];
              const a=SOL.doMove(g,{t:'tab',i:0,k:3},{t:'tab',i:1});const b=SOL.doMove(g,{t:'tab',i:0,k:2},{t:'tab',i:1});
              return JSON.stringify([a,b,g.tab[1].length,g.tab[0].length,g.tab[0][0].up])})()""") == '[false,true,3,1,true]')
            check('Auto-Ablage nimmt Asse und passende Folgekarten', ev("""(()=>{const c=(r,s,up=true)=>({r,s,up});const g=SOL.deal(SOL.mulberry(1),1);
              g.tab=[[c(2,0),c(1,0)],[],[],[],[],[],[]];g.waste=[];g.stock=[];let n=0;while(SOL.autoOne(g))n++;return n+':'+g.found[0].length})()""") == '2:2')
            check('Gewonnen wird erkannt (alle Ablagen voll)', ev("""(()=>{const g=SOL.deal(SOL.mulberry(1),1);g.tab=[[],[],[],[],[],[],[]];g.stock=[];g.waste=[];
              for(let s=0;s<4;s++)for(let r=1;r<=12;r++)g.found[s].push({r,s,up:true});g.tab[0]=[{r:13,s:0,up:true}];g.tab[1]=[{r:13,s:1,up:true}];g.tab[2]=[{r:13,s:2,up:true}];g.tab[3]=[{r:13,s:3,up:true}];
              SOL.autoOne(g);SOL.autoOne(g);SOL.autoOne(g);const mid=g.won;SOL.autoOne(g);return mid===false&&g.won===true})()"""))

            print('Bedienung per Tastatur (Fernbedienung)')
            pg.goto(BASE + '/api/x/solitaire/index?seed=7')
            pg.wait_for_function('window.SOL && SOL.state()')
            ev('(()=>{const g=SOL.state();g.tab=[[],[],[],[],[],[],[]];const c=(r,s,up=true)=>({r,s,up});g.tab[0]=[c(9,1,false),c(8,2),c(7,0)];g.tab[1]=[c(9,3)];g.tab[2]=[c(1,0)];g.stock=[c(5,1,false),c(4,1,false)];g.waste=[];g.found=[[],[],[],[]];SOL.layout();document.dispatchEvent(new Event("x"))})()')
            pg.keyboard.press('ArrowDown') if False else None
            check('Cursor startet unten links', ev('JSON.stringify(SOL.cursor())') == '{"row":1,"col":0,"k":1}')
            pg.keyboard.press('ArrowRight')
            check('Pfeil rechts: nächste Spalte', ev('SOL.cursor().col') == 1)
            pg.keyboard.press('ArrowLeft'); pg.keyboard.press('ArrowUp')
            check('Pfeil hoch in der Spalte wählt zwei Karten (nur offene)', ev('SOL.cursor().k') == 2)
            pg.keyboard.press('ArrowUp')
            check('Weiter hoch: nicht über die offenen Karten hinaus, sondern in die obere Reihe', ev('SOL.cursor().row') == 0 and ev('SOL.cursor().col') == 0)
            pg.keyboard.press('Enter')
            check('OK auf dem Stapel zieht eine Karte', ev('SOL.state().waste.length') == 1 and ev('SOL.state().moves') == 1)
            pg.keyboard.press('z')
            check('Z macht den Zug rückgängig', ev('SOL.state().waste.length') == 0 and ev('SOL.state().moves') == 0)
            pg.keyboard.press('ArrowDown')
            pg.keyboard.press('ArrowUp')
            pg.keyboard.press('ArrowUp')
            pg.keyboard.press('ArrowDown')
            check('Runter wählt wieder weniger Karten', ev('SOL.cursor().row') in (0, 1))
            ev('(()=>{const c=SOL.cursor();c.row=1;c.col=0;c.k=2})()')
            pg.keyboard.press('Enter')
            check('OK auf der Spalte nimmt 2 Karten auf', ev('JSON.stringify(SOL.held())') == '{"t":"tab","i":0,"k":2}')
            pg.keyboard.press('ArrowRight')
            pg.keyboard.press('Enter')
            check('OK auf Ziel-Spalte legt ab (9♥ ← 8♥,7♠? Farbe passt nicht -> abgelehnt, Aufnahme beendet)', ev('SOL.held()') is None and ev('SOL.state().tab[1].length') in (1, 3))
            ev('(()=>{const g=SOL.state();const c=(r,s,up=true)=>({r,s,up});g.tab[0]=[c(9,1,false),c(8,2)];g.tab[1]=[c(9,1)]})()')
            ev('(()=>{const c=SOL.cursor();c.row=1;c.col=0;c.k=1})()')
            pg.keyboard.press('Enter'); pg.keyboard.press('ArrowRight'); pg.keyboard.press('Enter')
            check('Gültiger Zug 8♥ auf 9♣ klappt, die verdeckte Karte wird aufgedeckt', ev('SOL.state().tab[1].length') == 2 and ev('SOL.state().tab[0].length') == 1 and ev('SOL.state().tab[0][0].up') is True)
            pg.keyboard.press('Escape')
            check('Zurück/Escape ohne Aufnahme ändert nichts', ev('SOL.held()') is None)
            ev('(()=>{const c=SOL.cursor();c.row=1;c.col=2;c.k=1})()')
            pg.keyboard.press('Enter')
            check('Aufnehmen und Escape bricht ab', ev('SOL.held()') is not None)
            pg.keyboard.press('Escape')
            check('... abgebrochen', ev('SOL.held()') is None)
            pg.keyboard.press('Enter'); pg.keyboard.press('Enter')
            check('Dieselbe Karte nochmal = Ass kommt auf die Ablage', ev('SOL.state().found[0].length') == 1 and ev('SOL.state().tab[2].length') == 0)
            pg.keyboard.press('ArrowUp'); pg.keyboard.press('ArrowUp')
            ev('(()=>{const c=SOL.cursor();c.row=-1;c.col=0})()')
            pg.keyboard.press('ArrowRight')
            check('Knopfzeile: Cursor wandert über die Knöpfe', ev('SOL.cursor().row') == -1 and ev('SOL.cursor().col') == 1 and pg.locator('#bar button.f').count() == 1)
            check('Keine Skriptfehler (Tastatur)', not errs, errs)

            print('Touch')
            tc = br.new_context(has_touch=True, viewport={'width': 800, 'height': 400})
            tp = tc.new_page()
            terr = []
            tp.on('pageerror', lambda e: terr.append(str(e)))
            tp.goto(BASE + '/api/x/solitaire/index?seed=11')
            tp.wait_for_function('window.SOL && SOL.state()')
            tev = tp.evaluate
            tev("""(()=>{const g=SOL.state();const c=(r,s,up=true)=>({r,s,up});g.tab=[[c(9,1,false),c(8,2)],[c(9,1)],[c(1,0)],[],[],[],[]];SOL.layout();document.querySelector('#cv').dispatchEvent(new Event('resize'))})()""")
            tp.evaluate("window.dispatchEvent(new Event('resize'))")
            def tap(sel_expr):
                pt = tev("(()=>{const r=document.querySelector('#cv').getBoundingClientRect();const p=(%s);return [r.left+p[0],r.top+p[1]]})()" % sel_expr)
                tp.touchscreen.tap(pt[0], pt[1])
            center = "(()=>{const R=SOL.rects();const s=R.find(q=>q.t==='%s'&&(%s));return [s.x+s.w/2,s.y+(s.t==='tab'?SOL.layout().ch*0.5+(s.o[%d]||0):s.h/2)]})()"
            tap(center % ('tab', 'q.i===0', 1))
            check('Tippen auf eine offene Karte nimmt sie auf', tev('JSON.stringify(SOL.held())') == '{"t":"tab","i":0,"k":1}')
            tap(center % ('tab', 'q.i===1', 0))
            check('Tippen auf die Ziel-Spalte legt ab (8♥ auf 9♣)', tev('SOL.state().tab[1].length') == 2 and tev('SOL.held()') is None)
            tap(center % ('tab', 'q.i===2', 0))
            tap(center % ('tab', 'q.i===2', 0))
            check('Dieselbe Karte zweimal antippen = Ass auf die Ablage', tev('SOL.state().found[0].length') == 1)
            tap("(()=>{const s=SOL.rects().find(q=>q.t==='stock');return [s.x+s.w/2,s.y+s.h/2]})()")
            check('Tippen auf den Stapel zieht', tev('SOL.state().waste.length') >= 1)
            tp.click('#bu')
            check('Knopf „Zurück“ macht rückgängig', tev('SOL.state().waste.length') == 0)
            tev("""(()=>{const g=SOL.state();const c=(r,s,up=true)=>({r,s,up});g.tab=[[c(13,0)],[],[],[],[],[],[]];g.stock=[];g.waste=[];g.found=[[],[],[],[],[]].slice(0,4);for(let s=0;s<4;s++)for(let r=1;r<=12;r++)g.found[s].push(c(r,s));g.tab[1]=[c(13,1)];g.tab[2]=[c(13,2)];g.tab[3]=[c(13,3)];})()""")
            tp.click('#ba')
            check('Auto legt alles ab, Gewinn wird gemeldet', tp.locator('#msg.on').count() == 1 and 'Gewonnen' in tp.inner_text('#msg'), tp.inner_text('#msg'))
            check('Bestwert wurde gespeichert (1 Sieg)', wait(lambda: http('/api/x/solitaire/punkte')[1].get('siege') == 1), http('/api/x/solitaire/punkte')[1])
            check('Keine Skriptfehler (Touch)', not terr, terr)
            tc.close()

            print('Layout')
            for w, h in ((800, 400), (360, 740), (1920, 1080), (640, 360)):
                lp = br.new_page(viewport={'width': w, 'height': h})
                lp.goto(BASE + '/api/x/solitaire/index?seed=3')
                lp.wait_for_function('window.SOL && SOL.state()')
                lp.evaluate("(()=>{const g=SOL.state();const c=(r,s)=>({r,s,up:true});g.tab[6]=Array.from({length:12},(_, i)=>c(13-i,i%2?2:0));SOL.layout();window.dispatchEvent(new Event('resize'))})()")
                bad = lp.evaluate("""(()=>{const L=SOL.layout();const R=SOL.rects();let bad=[];for(const s of R){if(s.x<0||s.x+s.w>L.W+0.5)bad.push('x:'+s.t);if(s.y+s.h>L.H+0.5)bad.push('y:'+s.t+s.i+':'+Math.round(s.y+s.h)+'>'+Math.round(L.H))}
                  return bad.concat(document.documentElement.scrollHeight>innerHeight?['scroll']:[])})()""")
                check('%dx%d: alles im Bild, kein Scrollen' % (w, h), not bad, bad)
                lp.close()
            dp = br.new_page(viewport={'width': 800, 'height': 500})
            dp.goto(BASE + '/api/x/solitaire/index?seed=3&draw=3')
            dp.wait_for_function('window.SOL && SOL.state()')
            dp.evaluate('SOL.drawStock(SOL.state())')
            check('draw=3: drei Karten', dp.evaluate('SOL.state().waste.length') == 3)
            setv('solitaire', ziehen='3')
            check('Einstellung „3 Karten“ wirkt', http('/api/x/solitaire/konfig')[1]['ziehen'] == 3)
            ws = http('/api/ext/widgets?fresh=1')[1]['widgets']
            w = next((q for q in ws if q['ext'] == 'solitaire'), None)
            check('Kachel zeigt Siege und Bestwerte', w and '1 gewonnen' in w['sub'], w)
            check('Ungültige Werte werden abgelehnt', http('/api/x/solitaire/punkte', {'zuege': 0, 'sekunden': 5})[0] == 400 and http('/api/x/solitaire/punkte', {'zuege': 'x', 'sekunden': 5})[0] == 400)
            br.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
