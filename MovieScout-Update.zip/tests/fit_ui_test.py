# -*- coding: utf-8 -*-
"""Die Seite sitzt fest: kein seitliches Wackeln auf schmalen Displays (alle Looks, Startseite, Einstellungen, Skin-Editor).

    python tests/fit_ui_test.py
"""
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
API = 8898
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError:
            time.sleep(.25)
    M = "() => { const d = document.documentElement; return d.scrollWidth - d.clientWidth; }"
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            for w in (320, 360, 412):
                pg = b.new_context(viewport={'width': w, 'height': 890}, has_touch=True, is_mobile=True).new_page()
                pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_selector('header.top'); pg.wait_for_timeout(800)
                bad = []
                for look in ('', 'look-netflix', 'look-disney', 'look-sky', 'look-joyn', 'look-arte', 'look-ard', 'look-zdf', 'look-prime', 'look-appletv', 'look-firetv'):
                    if look:
                        pg.evaluate("(l) => { SK.active = l; applySkin(activeSkin()); refreshView(); }", look); pg.wait_for_timeout(250)
                    for nm, js in (('Startseite', None), ('Einstellungen', 'openSettings()'), ('Skin-Editor', 'openSkinEditor()')):
                        if js:
                            pg.evaluate(js); pg.wait_for_timeout(300)
                        if pg.evaluate(M) > 0:
                            bad.append('%s/%s' % (look or 'Standard', nm))
                        if js:
                            pg.evaluate("document.querySelectorAll('#layers .layer').length && history.back()"); pg.wait_for_timeout(200)
                check('%d px breit: nirgends überbreit (8 Looks x 3 Ansichten)' % w, not bad, bad)
                hw = pg.evaluate("(() => { const h = document.querySelector('header.top'); return [Math.round(h.getBoundingClientRect().right), document.documentElement.clientWidth]; })()")
                check('%d px: Kopfzeile endet am Displayrand' % w, hw[0] <= hw[1], hw)
            b.close()
    finally:
        srv.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
