# -*- coding: utf-8 -*-
"""Oberflächen-Test (Playwright): Trailer von Entdecken-Karten und aus dem Info-Fenster.

    python tests/trailer_ui_test.py
"""
import json
import os
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import discover_test as DT                                            # noqa: E402
import trailer_test as TT                                             # noqa: E402

UP, API, TMDB = 8885, 8886, 8887
BASE = 'http://127.0.0.1:%d/ui/' % API
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


class Tmdb(TT.Tmdb):
    def do_GET(self):
        if self.path.startswith('/movie/popular'):
            b = json.dumps({'results': [{'id': 603, 'title': 'Matrix', 'release_date': '1999-03-31', 'poster_path': '/m.jpg', 'vote_average': 8.1},
                                         {'id': 700, 'title': 'Ohne Video', 'release_date': '2001-01-01', 'poster_path': '/o.jpg', 'vote_average': 5}], 'total_pages': 1}).encode()
            self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(b); return
        super().do_GET()


def post(path, data):
    req = urllib.request.Request('http://127.0.0.1:%d%s' % (API, path), data=json.dumps(data).encode(), headers={'Content-Type': 'application/json'})
    return json.loads(urllib.request.urlopen(req, timeout=30).read())


def leave_player(pg):
    pg.evaluate("history.back()"); pg.wait_for_timeout(500)


def run(pg, errs):
    post('/api/settings', {'settings': {'api.tmdb': 'KEY123'}})
    pg.goto(BASE); pg.wait_for_selector('[data-sec=disc] .tile'); pg.wait_for_timeout(300)
    pg.locator('[data-sec=disc] .tile', has_text='Filme').click(); pg.wait_for_selector('.panel .src')
    pg.locator('.panel .src', has_text='Am populärsten').click(); pg.wait_for_selector('.card', timeout=15000)

    print('Trailer-Symbol auf Entdecken-Karten')
    check('Jede Karte hat ein Trailer-Symbol', pg.locator('.card .trlb').count() == 2, pg.locator('.card .trlb').count())
    pg.locator('.card', has_text='Matrix').locator('.trlb').click(); pg.wait_for_selector('#player iframe', timeout=20000)
    src = pg.locator('#player iframe').get_attribute('src')
    check('Player bettet den deutschen YouTube-Trailer ein', src.startswith('https://www.youtube-nocookie.com/embed/TDE'), src)
    check('Titel im Player: „Matrix – Trailer“', pg.locator('#player .ttl').inner_text() == 'Matrix – Trailer', pg.locator('#player .ttl').inner_text())
    check('Hinweis nennt den Trailer (nicht „kein direkter Stream“)', 'Trailer:' in pg.locator('#player').inner_text() and 'keinen direkten Stream' not in pg.locator('#player').inner_text(), pg.locator('#player').inner_text()[:200])
    leave_player(pg)
    check('Zurück: wieder die Liste, keine Suche gestartet', pg.locator('.card').count() == 2 and pg.evaluate("nav[nav.length - 1].type") == 'list')

    print('Titel ohne Trailer')
    pg.locator('.card', has_text='Ohne Video').locator('.trlb').click(); pg.wait_for_selector('.panel h2:has-text("Kein Trailer")', timeout=20000)
    check('Meldung statt leerem Player', 'kein Trailer' in pg.locator('.panel .lead').inner_text() and pg.locator('#player').count() == 0, pg.locator('.panel').inner_text())
    pg.evaluate("history.back()"); pg.wait_for_timeout(400)

    print('Fernbedienung: Taste T')
    pg.locator('.card', has_text='Matrix').focus(); pg.keyboard.press('t'); pg.wait_for_selector('#player iframe', timeout=20000)
    check('Taste T auf der fokussierten Karte startet den Trailer', 'embed/TDE' in pg.locator('#player iframe').get_attribute('src'))
    leave_player(pg)

    print('Info-Fenster')
    pg.evaluate("openInfo({ title: 'Matrix', year: '1999', kind: 'play', provider: 'x', provider_id: 'x', url: 'u' })"); pg.wait_for_selector('.infopanel .actions .btn')
    check('Knopf „Trailer“ neben „Abspielen“', pg.locator('.infopanel .btn', has_text='Trailer').count() >= 1)
    pg.locator('.infopanel .btn', has_text='Trailer').first.click(); pg.wait_for_selector('#player iframe', timeout=20000)
    check('Info → Trailer startet den Player', 'embed/TDE' in pg.locator('#player iframe').get_attribute('src'))
    leave_player(pg)
    print('Quelle kaputt: automatisch die nächste')
    pg.route('**/api/trailer', lambda route: route.fulfill(status=200, content_type='application/json', body=json.dumps({'hosters': [
        {'id': 0, 'name': 'MultiTrailer · kaputt', 'url': 'http://127.0.0.1:%d/gibtes/nicht.mp4' % UP, 'direct': True, 'format': 'mp4', 'trailer': True, 'quality': '', 'lang': '', 'source': 'MultiTrailer'},
        {'id': 1, 'name': 'YouTube', 'url': 'https://www.youtube-nocookie.com/embed/ABC?autoplay=1', 'direct': False, 'format': 'embed', 'trailer': True, 'quality': '', 'lang': 'de', 'source': 'TMDB'}]})))
    pg.evaluate("cfg.autoplay = false")
    pg.evaluate("openTrailer({ title: 'Egal', year: '2000', kind: 'movie' })")
    pg.wait_for_selector('#player iframe', timeout=40000)
    check('Ohne Zutun wechselt der Player zur nächsten Quelle (auch bei ausgeschaltetem Autoplay)', 'embed/ABC' in pg.locator('#player iframe').get_attribute('src') and pg.evaluate("cfg.autoplay") is False)
    leave_player(pg)
    check('Keine Fehler in der Konsole', not errs, errs)


def main():
    tmp = tempfile.mkdtemp()
    s1 = DT.serve(TMDB, Tmdb)
    env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp,
               FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1', MOVIESCOUT_TMDB_BASE='http://127.0.0.1:%d' % TMDB,
               MOVIESCOUT_TMDB_IMG='http://127.0.0.1:%d/img' % UP)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_TMDB_KEY'):
        env.pop(k, None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    global failed
    try:
        assert DT.wait_port(UP) and DT.wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_context(viewport={'width': 1280, 'height': 900}).new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text and '/img/' not in m.text else None)
            try:
                run(pg, errs)
            except Exception:      # noqa: BLE001
                import traceback
                traceback.print_exc(); failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png')); print('Screenshot:', Path(tmp) / 'fail.png')
            b.close()
    finally:
        srv.terminate(); up.terminate(); s1.shutdown()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
