# -*- coding: utf-8 -*-
"""Entdecken (TMDB-Listen) und Trakt in der Engine, mit gespielten Antworten (kein Netz nötig):

    python tests/discover_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent.parent
PORT, TMDB_PORT, TRAKT_PORT = 8871, 8872, 8873
API = 'http://127.0.0.1:%d' % PORT
passed = failed = 0
SEEN = []
STATE = {'polls': 0}


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def movie(i, kind='movie'):
    k = 'title' if kind == 'movie' else 'name'
    d = 'release_date' if kind == 'movie' else 'first_air_date'
    return {'id': i, k: '%s %d' % ('Film' if kind == 'movie' else 'Serie', i), d: '20%02d-05-01' % (i % 30), 'poster_path': '/p%d.jpg' % i, 'overview': 'Handlung %d' % i, 'vote_average': 7.25}


class Tmdb(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        SEEN.append((u.path, q))
        page = int(q.get('page') or 1)
        if q.get('api_key') != 'KEY123':
            self.send_response(401); self.end_headers(); self.wfile.write(b'{}'); return
        kind = 'tv' if '/tv' in u.path else 'movie'
        if u.path.startswith('/genre/'):
            out = {'genres': [{'id': 28, 'name': 'Action'}, {'id': 35, 'name': 'Komödie'}]}
        elif u.path in ('/movie/603', '/tv/1399'):
            out = {'poster_path': '/meta.jpg', 'overview': 'Aus TMDB', 'vote_average': 8.1}
        else:
            base = (page - 1) * 3
            out = {'results': [movie(base + 1 + n, kind) for n in range(3)], 'total_pages': 9, 'page': page}
        b = json.dumps(out).encode()
        self.send_response(200); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(b)


class Trakt(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header('Content-Type', 'application/json'); self.end_headers(); self.wfile.write(b)

    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); body = json.loads(self.rfile.read(n) or b'{}')
        if self.path == '/oauth/device/code':
            return self._send(200, {'device_code': 'DC', 'user_code': 'ABCD1234', 'verification_url': 'https://trakt.tv/activate', 'interval': 1, 'expires_in': 600}) if body.get('client_id') == 'CID' else self._send(401, {})
        if self.path == '/oauth/device/token':
            STATE['polls'] += 1
            if body.get('code') != 'DC': return self._send(404, {})
            if STATE['polls'] < 2: return self._send(400, {})
            return self._send(200, {'access_token': 'AT', 'refresh_token': 'RT', 'expires_in': 7776000})
        if self.path == '/oauth/revoke':
            STATE['revoked'] = body.get('token'); return self._send(200, {})
        self._send(404, {})

    def do_GET(self):
        u = urlparse(self.path)
        auth = self.headers.get('Authorization')
        SEEN.append(('trakt' + u.path, {'auth': auth, 'key': self.headers.get('trakt-api-key')}))
        if self.headers.get('trakt-api-key') != 'CID': return self._send(403, {})
        if u.path == '/users/settings': return self._send(200, {'user': {'username': 'tester'}})
        if u.path.startswith('/sync/') or u.path.startswith('/recommendations/'):
            if auth != 'Bearer AT': return self._send(401, {})
        if u.path == '/sync/watchlist/movies':
            return self._send(200, [{'type': 'movie', 'movie': {'title': 'Matrix', 'year': 1999, 'ids': {'tmdb': 603}}}, {'type': 'movie', 'movie': {'title': 'Ohne Nummer', 'year': 2001, 'ids': {}}}])
        if u.path == '/sync/history/shows':
            return self._send(200, [{'show': {'title': 'GoT', 'year': 2011, 'ids': {'tmdb': 1399}}}, {'show': {'title': 'GoT', 'year': 2011, 'ids': {'tmdb': 1399}}}])
        if u.path == '/movies/trending':
            return self._send(200, [{'watchers': 9, 'movie': {'title': 'Trend', 'year': 2024, 'ids': {'tmdb': 603}}}])
        self._send(200, [])


def serve(port, handler):
    srv = HTTPServer(('127.0.0.1', port), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def call(path, data=None, method=None):
    body = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(API + path, data=body, headers={'Content-Type': 'application/json'} if body else {}, method=method)
    try:
        r = urllib.request.urlopen(req, timeout=40)
    except urllib.error.HTTPError as e:
        r = e
    b = r.read()
    try:
        return r.status, json.loads(b)
    except Exception:
        return r.status, b


def wait_port(port):
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=.3).close(); return True
        except OSError:
            time.sleep(.25)
    return False


def main():
    s1, s2 = serve(TMDB_PORT, Tmdb), serve(TRAKT_PORT, Trakt)
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, PYTHONUNBUFFERED='1',
               MOVIESCOUT_TMDB_BASE='http://127.0.0.1:%d' % TMDB_PORT, MOVIESCOUT_TRAKT_BASE='http://127.0.0.1:%d' % TRAKT_PORT, MOVIESCOUT_TMDB_IMG='http://img.test/w342')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_TMDB_KEY'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        assert wait_port(PORT), 'Engine startet nicht'

        print('Ohne Schlüssel')
        s, d = call('/api/discover?kind=movie&list=popular')
        check('Klare Meldung statt Absturz', s == 400 and 'TMDB' in d.get('error', ''), (s, d))
        s, d = call('/api/discover/meta')
        check('Meta: kein Schlüssel, Listen vorhanden', s == 200 and d['has_key'] is False and len(d['lists']['movie']) == 5 and len(d['lists']['tv']) == 4, d)

        call('/api/settings', {'settings': {'api.tmdb': 'KEY123', 'trakt.client_id': 'CID', 'trakt.client_secret': 'SEC'}})

        print('TMDB-Listen')
        s, d = call('/api/discover?kind=movie&list=popular')
        check('Beliebt: 2 Seiten à 3 Titel', s == 200 and len(d['items']) == 6 and d['title'] == 'Am populärsten', (s, d))
        it = d['items'][0]
        check('Titel, Jahr, Poster, Beschreibung', it['title'] == 'Film 1' and it['year'] == '2001' and it['poster'] == 'http://img.test/w342/p1.jpg' and it['plot'] == 'Handlung 1' and it['kind'] == 'movie', it)
        check('Seiten 1 und 2 angefragt', {q.get('page') for p, q in SEEN if p == '/movie/popular'} == {'1', '2'}, SEEN)
        s, d = call('/api/discover?kind=movie&list=kino')
        check('Im Kino mit Region DE', any(p == '/movie/now_playing' and q.get('region') == 'DE' for p, q in SEEN))
        s, d = call('/api/discover?kind=movie&list=revenue&pages=1')
        check('Box Office sortiert nach Umsatz', any(p == '/discover/movie' and q.get('sort_by') == 'revenue.desc' for p, q in SEEN) and len(d['items']) == 3)
        s, d = call('/api/discover?kind=tv&list=airing&pages=1')
        check('Serien: aktuell im TV', s == 200 and d['items'][0]['kind'] == 'tv' and d['items'][0]['title'] == 'Serie 1', d)
        s, d = call('/api/discover?kind=movie&genre=28&year=1999&pages=1')
        check('Genre + Jahr: Titel mit Genre-Name', s == 200 and d['title'] == 'Action · 1999' and any(q.get('with_genres') == '28' and q.get('primary_release_year') == '1999' for p, q in SEEN), d)
        s, d = call('/api/discover?kind=tv&year=2010&pages=1')
        check('Serien-Jahr nutzt first_air_date_year', any(q.get('first_air_date_year') == '2010' for p, q in SEEN))
        s, d = call('/api/discover?kind=movie&q=Matrix&pages=1')
        check('Suche', s == 200 and d['title'] == 'Suche „Matrix“' and any(p == '/search/movie' and q.get('query') == 'Matrix' for p, q in SEEN))
        s, d = call('/api/discover?kind=movie&genre=abc')
        check('Ungültiges Genre abgelehnt', s == 400, (s, d))
        s, d = call('/api/discover?kind=movie&year=12')
        check('Ungültiges Jahr abgelehnt', s == 400, (s, d))
        s, d = call('/api/discover?kind=movie&list=gibtsnicht')
        check('Unbekannte Liste abgelehnt', s == 400, (s, d))
        n = len(SEEN)
        call('/api/discover?kind=movie&list=popular')
        check('Zweiter Abruf kommt aus dem Zwischenspeicher', len(SEEN) == n, len(SEEN) - n)
        s, d = call('/api/discover/meta?kind=movie')
        check('Genres der Filme', d['genres'][0] == {'id': 28, 'name': 'Action'} and d['has_key'] is True, d)

        print('Trakt: Anmeldung')
        s, d = call('/api/trakt/list?name=watchlist&kind=movie')
        check('Ohne Anmeldung: Hinweis', s == 400 and 'nicht angemeldet' in d['error'], d)
        s, d = call('/api/trakt/list?name=trending&kind=movie')
        check('Angesagt geht ohne Anmeldung (nur Client-ID)', s == 200 and d['items'][0]['title'] == 'Trend' and d['title'] == 'Trakt · Angesagt', (s, d))
        check('… mit Poster und Beschreibung aus TMDB', d['items'][0]['poster'].endswith('/meta.jpg') and d['items'][0]['plot'] == 'Aus TMDB', d)
        s, d = call('/api/trakt/auth', {'action': 'start'})
        check('Gerätecode wird geholt', s == 200 and d['user_code'] == 'ABCD1234' and d['device_code'] == 'DC' and 'trakt.tv' in d['url'], d)
        s, d = call('/api/trakt/auth', {'action': 'poll', 'device_code': 'DC'})
        check('Erster Abruf: noch nicht bestätigt', s == 200 and d['state'] == 'pending', d)
        s, d = call('/api/trakt/auth', {'action': 'poll', 'device_code': 'DC'})
        check('Zweiter Abruf: angemeldet als tester', s == 200 and d['state'] == 'ok' and d['user'] == 'tester', d)
        s, d = call('/api/discover/meta')
        check('Status: verbunden', d['trakt']['connected'] is True and d['trakt']['user'] == 'tester' and d['trakt']['configured'] is True, d)
        tok = json.loads((Path(tmp) / 'trakt.json').read_text())
        check('Token liegt in trakt.json, nicht in den Einstellungen', tok['access_token'] == 'AT' and 'AT' not in json.dumps(call('/api/settings')[1]), tok)

        print('Trakt: Listen')
        s, d = call('/api/trakt/list?name=watchlist&kind=movie')
        check('Watchlist: 2 Filme', s == 200 and [x['title'] for x in d['items']] == ['Matrix', 'Ohne Nummer'], d)
        check('Anmeldung wird mitgeschickt', any(p == 'trakt/sync/watchlist/movies' and q['auth'] == 'Bearer AT' for p, q in SEEN))
        check('Poster nur bei bekannter TMDB-Nummer', d['items'][0]['poster'] and not d['items'][1]['poster'], d)
        s, d = call('/api/trakt/list?name=history&kind=tv')
        check('Verlauf der Serien ohne Doppelte', s == 200 and len(d['items']) == 1 and d['items'][0]['kind'] == 'tv', d)
        s, d = call('/api/trakt/list?name=gibtsnicht')
        check('Unbekannte Liste abgelehnt', s == 400)
        s, d = call('/api/trakt/auth', {'action': 'logout'})
        check('Abmelden', s == 200 and d['connected'] is False and STATE.get('revoked') == 'AT', (s, d))
        check('trakt.json ist weg', not (Path(tmp) / 'trakt.json').exists())
        s, d = call('/api/trakt/list?name=watchlist&kind=movie')
        check('Nach dem Abmelden wieder Hinweis', s == 400)
        s, d = call('/api/trakt/auth', {'action': 'nix'})
        check('Unbekannte Aktion', s == 400)
        call('/api/settings', {'settings': {'trakt.client_id': '', 'trakt.client_secret': ''}})
        s, d = call('/api/trakt/auth', {'action': 'start'})
        check('Ohne Client-Daten: Hinweis mit Anleitung', s == 400 and 'Client-ID' in d['error'], d)
    finally:
        srv.terminate()
        try:
            srv.wait(10)
        except Exception:
            srv.kill()
        s1.shutdown(); s2.shutdown()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
