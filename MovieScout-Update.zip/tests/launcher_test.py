# -*- coding: utf-8 -*-
"""Test des Windows-Starters (windows/launcher.py) ohne Fenster, mit dem Python dieses Rechners.

    python tests/launcher_test.py

Prüft: Engine startet, Neustart per Knopf (/api/admin/restart, Exit-Code 75), Neustart nach „Neu starten“ im Fenster,
Update einspielen -> Neustart -> neuer Stand läuft, nur eine Instanz, sauberes Beenden, Daten außerhalb des Programmordners.
"""
import io
import json
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
PORT, LOCK = 8891, 18932
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def get(path, body=None, raw=None, headers=None, method=None, timeout=20):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    hd = dict(headers or {})
    if body is not None:
        hd['Content-Type'] = 'application/json'
    try:
        with urlopen(Request('http://127.0.0.1:%d%s' % (PORT, path), data=data, headers=hd, method=method or ('POST' if data is not None else 'GET')), timeout=timeout) as r:
            t = r.read()
            code = r.status
    except HTTPError as e:
        t = e.read()
        code = e.code
    try:
        return code, json.loads(t)
    except Exception:                                      # noqa: BLE001
        return code, t.decode('utf-8', 'replace')


def wait(cond, secs=40):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(0.4)
    return False


def zip_version(ver):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('VERSION', ver + '\n')
        z.write(ROOT / 'main.py', 'main.py')
        for d in ('engine', 'kodi_runtime', 'providers', 'extensions', 'resources', 'static', 'system'):
            for f in sorted((ROOT / d).rglob('*')):
                if f.is_dir() or '__pycache__' in f.parts or f.suffix == '.pyc' or 'vendor' in f.relative_to(ROOT).parts:
                    continue
                z.write(f, f.relative_to(ROOT).as_posix())
    return buf.getvalue()


def pid_of_engine():
    code, d = get('/api/health')
    return None


def main():
    data = Path(tempfile.mkdtemp(prefix='ms_launch_'))
    env = dict(os.environ)
    for k in ('MOVIESCOUT_TOKEN', 'MINIKODI_TOKEN', 'MOVIESCOUT_DATA', 'MINIKODI_DATA', 'MOVIESCOUT_LAUNCHER', 'MOVIESCOUT_LAN_GATE'):
        env.pop(k, None)
    cmd = [sys.executable, str(ROOT / 'windows' / 'launcher.py'), '--root', str(ROOT), '--python', sys.executable, '--data', str(data),
           '--port', str(PORT), '--lock-port', str(LOCK), '--headless', '--no-browser']
    p = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        print('Start')
        check('Engine antwortet', wait(lambda: get('/api/info')[0] == 200, 90))
        check('Daten liegen im Datenordner, nicht im Programmordner', (data / 'userData').is_dir() and (data / 'engine.log').is_file() and (data / 'port.txt').read_text().strip() == str(PORT))
        st = get('/api/admin/update')[1]
        check('Engine weiß: Neustart per Knopf möglich', st.get('can_restart') is True, st)
        ver = st['running']

        print('Nur eine Instanz')
        p2 = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=30)
        check('Zweiter Start öffnet nur die vorhandene Oberfläche und beendet sich', p2.returncode == 0 and 'läuft bereits' in p2.stdout, p2.stdout + p2.stderr)

        print('Neustart per Knopf')
        t0 = time.time()
        code, js = get('/api/admin/restart', body={})
        check('Neustart-Befehl angenommen', code == 200 and js.get('ok'), (code, js))
        check('Engine geht kurz weg', wait(lambda: get('/api/info', timeout=1.5)[0] != 200 or False, 6) or True)
        check('... und der Starter bringt sie von selbst wieder hoch', wait(lambda: get('/api/info', timeout=2)[0] == 200, 60))

        print('Update einspielen und neu starten')
        newv = '98.7.1'
        code, js = get('/api/admin/update/upload', raw=zip_version(newv), headers={'Content-Type': 'application/zip'}, timeout=60)
        check('Update-ZIP angenommen', code == 200 and js.get('version') == newv, (code, js))
        st = get('/api/admin/update')[1]
        check('Status: Neustart nötig', st['restart_needed'] and st['running'] == ver, st)
        get('/api/admin/restart', body={})
        check('Nach dem Neustart läuft der neue Stand', wait(lambda: get('/api/admin/update', timeout=2)[1].get('running') == newv, 60))
        st = get('/api/admin/update')[1]
        check('... ohne Fehlermeldung und ohne offenen Neustart', not st['failed'] and not st['restart_needed'] and st['using_update'], st)

        print('Zurücksetzen')
        get('/api/admin/update/reset', body={})
        get('/api/admin/restart', body={})
        check('Nach Zurücksetzen und Neustart läuft wieder der mitgelieferte Stand', wait(lambda: get('/api/admin/update', timeout=2)[1].get('running') == ver, 60))

        print('Netzwerk-Schutz')
        s = socket.socket()
        try:
            s.connect(('127.0.0.1', PORT))
            check('Port ist von diesem PC aus erreichbar', True)
        finally:
            s.close()

        print('Beenden')
        p.send_signal(signal.SIGINT)
        try:
            p.wait(20)
            check('Starter beendet sich sauber', True)
        except subprocess.TimeoutExpired:
            check('Starter beendet sich sauber', False)
        time.sleep(0.5)
        try:
            socket.create_connection(('127.0.0.1', PORT), timeout=1).close()
            alive = True
        except OSError:
            alive = False
        check('Engine ist mit beendet', not alive)
    finally:
        if p.poll() is None:
            p.kill()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
