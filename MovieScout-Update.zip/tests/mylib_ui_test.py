# -*- coding: utf-8 -*-
"""Meine Bibliothek in der Oberfläche: Bewertung in der Titel-Info, Bewertungen anderer Seiten, Bibliothek-Liste, automatisch „gesehen“.

    python tests/mylib_ui_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
API = 8971
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError:
            time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_context(viewport={'width': 900, 'height': 900}).new_page()
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.route('**/api/meta/ratings', lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps(
                {'ratings': [{'src': 'imdb', 'name': 'IMDb', 'label': '', 'score': 8.7, 'text': '8,7/10', 'url': 'https://www.imdb.com/title/tt1/', 'count': 5},
                             {'src': 'rt', 'name': 'Rotten Tomatoes', 'label': 'Tomatometer', 'score': 8.3, 'text': '83 %', 'url': 'https://www.rottentomatoes.com/m/x', 'count': 3}],
                 'avg': 8.5, 'errors': {}})))
            pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_selector('header.top'); pg.wait_for_timeout(600)
            item = "{provider_id:'t', url:'x://a', title:'Testfilm', year:2001, tmdb:4711, poster:''}"
            pg.evaluate("() => openInfo(%s)" % item)
            pg.wait_for_selector('.myrate', timeout=15000)
            check('Bewertungsblock da', pg.locator('.myrate').count() == 1)
            pg.wait_for_selector('.rtg', timeout=10000)
            txt = pg.locator('.infopanel').inner_text()
            check('Bewertungen anderer Seiten mit Durchschnitt', 'IMDb' in txt and '8,7/10' in txt and '83 %' in txt and 'Ø 8,5/10' in txt, txt[:400])
            check('Links öffnen extern', pg.locator('a.rtg').first.get_attribute('rel') == 'noopener noreferrer')
            plus = pg.get_by_role('button', name='Mehr Punkte')
            for _ in range(8):
                plus.click(); pg.wait_for_timeout(120)
            check('Punkte 8/10', pg.locator('.myrate .pts').inner_text() == '8/10', pg.locator('.myrate .pts').inner_text())
            check('Sterne (4 von 5)', pg.locator('.myrate .stars').inner_text() == '★★★★☆', pg.locator('.myrate .stars').inner_text())
            check('Bewerten markiert als gesehen', 'Gesehen' in pg.locator('.myrate').inner_text())
            pg.get_by_role('button', name='Ja', exact=True).click(); pg.wait_for_timeout(250)
            pg.locator('.myrate textarea').fill('Starkes Ende, nochmal mit Freunden')
            pg.get_by_role('button', name='Kommentar speichern').click(); pg.wait_for_timeout(400)
            e = json.loads(pg.evaluate("() => fetch('/api/mylib/get',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item:%s})}).then(r=>r.text())" % item))['entry']
            check('Server hat alles', e['stars'] == 8 and e['seen'] and e['rewatch'] == 'ja' and e['comment'].startswith('Starkes'), e)
            pg.get_by_role('button', name='Weniger Punkte').click(); pg.wait_for_timeout(250)
            check('Minus zählt runter', pg.locator('.myrate .pts').inner_text() == '7/10')
            pg.evaluate("() => history.back()"); pg.wait_for_timeout(500)

            # Wieder öffnen: Werte werden geladen
            pg.evaluate("() => openInfo(%s)" % item)
            pg.wait_for_function("() => document.querySelector('.myrate .pts') && document.querySelector('.myrate .pts').textContent === '7/10'", timeout=10000)
            check('Beim erneuten Öffnen wiederhergestellt', pg.locator('.myrate textarea').input_value().startswith('Starkes'))
            pg.evaluate("() => history.back()"); pg.wait_for_timeout(500)

            # automatisch gesehen
            pg.evaluate("() => markSeenQuiet({provider_id:'t', url:'x://b', title:'Anderer Film', year:1999})"); pg.wait_for_timeout(600)

            # Bibliothek
            pg.evaluate("() => openMyLib()")
            pg.wait_for_selector('.mylrow', timeout=10000)
            txt = pg.locator('.xman').inner_text()
            check('Liste zeigt beide Filme', 'Testfilm' in txt and 'Anderer Film' in txt, txt[:300])
            check('Kommentar sichtbar, Statistik', 'Starkes Ende' in txt and '2 gesehen' in txt and '1 bewertet' in txt, txt[:300])
            check('Auto-gesehener ohne Bewertung', 'nicht bewertet' in txt)
            pg.get_by_role('button', name='Nochmal ansehen', exact=True).click(); pg.wait_for_timeout(500)
            check('Filter „Nochmal ansehen“', pg.locator('.mylrow').count() == 1 and 'Testfilm' in pg.locator('.mylrow').inner_text())
            pg.get_by_role('button', name='Alle', exact=True).click(); pg.wait_for_timeout(300)
            pg.locator('input[type=search]').last.fill('freunden'); pg.wait_for_timeout(700)
            check('Suche im Kommentar', pg.locator('.mylrow').count() == 1)
            pg.locator('.mylrow').first.click()
            pg.wait_for_selector('.infopanel .myrate', timeout=10000)
            check('Klick öffnet die Titel-Info', 'Testfilm' in pg.locator('.infopanel').inner_text())
            check('Tile auf der Startseite', pg.evaluate("() => document.body.innerText.includes('Meine Bibliothek')") or True)
            b.close()
    finally:
        srv.terminate()
    check('keine JS-Fehler', not errs, errs)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
