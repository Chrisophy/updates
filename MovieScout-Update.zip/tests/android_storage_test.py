# -*- coding: utf-8 -*-
"""Android-Speicher (/storage/emulated, FUSE): Ordner dürfen dort oft nicht umbenannt werden („Operation not permitted“).
Addon-Installation und Ordnertausch müssen trotzdem klappen.

    python tests/android_storage_test.py
"""
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
TMP = Path(tempfile.mkdtemp(prefix='ms_fuse_'))
os.environ['MINIKODI_DATA'] = os.environ['MOVIESCOUT_DATA'] = str(TMP / 'd')
sys.path.insert(0, str(ROOT))
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


_real_replace, _real_rename = os.replace, os.rename


def _deny_dirs(a, b, *k, **kw):
    if os.path.isdir(a):
        raise PermissionError(1, 'Operation not permitted', str(a), None, str(b))
    return _real_replace(a, b)


def addon_zip(ver):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        z.writestr('plugin.video.fuse/addon.xml', '<addon id="plugin.video.fuse" name="Fuse" version="%s"><extension point="xbmc.python.pluginsource" library="main.py"/></addon>' % ver)
        z.writestr('plugin.video.fuse/main.py', 'V = %r\n' % ver)
        z.writestr('plugin.video.fuse/resources/lib/x.py', 'pass\n')
    return b.getvalue()


def main():
    from engine import addonhost as AH
    from engine import fsutil as FS
    with mock.patch('os.replace', _deny_dirs), mock.patch('os.rename', _deny_dirs), mock.patch('pathlib.Path.rename', lambda s, t: _deny_dirs(str(s), str(t))):
        print('Addon installieren ohne Ordner-Umbenennen')
        info = AH.install_zip(addon_zip('1.0.0'))
        adir = AH.addon_path('plugin.video.fuse')
        check('Installation klappt (Kopie statt Umbenennen)', info['version'] == '1.0.0' and (adir / 'main.py').read_text() == "V = '1.0.0'\n" and (adir / 'resources/lib/x.py').is_file())
        check('Kein .tmp-Ordner bleibt liegen', not any(p.name.startswith('.tmp_') for p in AH.ADDONS_DIR.iterdir()), list(AH.ADDONS_DIR.iterdir()))
        (adir / '__pycache__').mkdir(exist_ok=True)
        (adir / '__pycache__' / 'main.cpython-313.pyc').write_bytes(b'x')
        info = AH.install_zip(addon_zip('2.0.0'))
        check('Update über eine vorhandene Installation (mit __pycache__) klappt', info['version'] == '2.0.0' and (adir / 'main.py').read_text() == "V = '2.0.0'\n")
        check('Alte Cache-Dateien sind weg', not (adir / '__pycache__').exists())
        check('meta() liest die neue Version', AH.meta('plugin.video.fuse').get('version') == '2.0.0')

        print('Ordnertausch (System-Update)')
        a, b = TMP / 'stage', TMP / 'current'
        (a / 'engine').mkdir(parents=True); (a / 'engine' / 'app.py').write_text('neu')
        (b / 'engine').mkdir(parents=True); (b / 'engine' / 'app.py').write_text('alt'); (b / 'alt.txt').write_text('x')
        how = FS.move_dir(a, b)
        check('move_dir kopiert, wenn Umbenennen verboten ist', how == 'copy' and (b / 'engine' / 'app.py').read_text() == 'neu' and not a.exists() and not (b / 'alt.txt').exists(), how)
    how = FS.move_dir(b, TMP / 'prev')
    check('Ohne Sperre wird weiterhin schnell umbenannt', how == 'rename' and (TMP / 'prev' / 'engine' / 'app.py').is_file())
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
