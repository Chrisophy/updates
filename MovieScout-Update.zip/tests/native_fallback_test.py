# -*- coding: utf-8 -*-
"""4K/HEVC/HDR (Stalker u. a.): schwere Streams gehen gleich in den App-Player, kaputte nach dem Fehler.   python tests/native_fallback_test.py"""
import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8976
ok = fail = 0
def check(n, c, x=''):
    global ok, fail
    if c: ok += 1; print('  ok   ', n)
    else: fail += 1; print('  FEHLER', n, x)
APP = "window.__calls=[];window.MovieScoutApp={nativeAvailable:()=>true,nativeWidevineLevel:()=>'L1',keepScreenOn:()=>true,playNative:(j)=>{window.__calls.push(JSON.parse(j));return true;}};"
def plan(name, url):
    return "() => { const orig = api; api = async (p, o) => (p === '/api/play' ? { mode: 'media', format: 'mp4', name: %r, proxy_path: '/p', url: %r } : orig(p, o)); }" % (name, url)
START = "(t) => { const c = { item: { provider_id: 't', url: 'x://film', title: t, poster: '' }, hosters: [{ name: 'Test', url: 'http://127.0.0.1:1/x', direct: true }], index: 0 }; current = c; startPlayer(c, 0); }"
def close(pg):
    for _ in range(6):
        if not pg.evaluate('layers.length'): break
        pg.evaluate('history.back()'); pg.wait_for_timeout(400)
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 900, 'height': 600}, user_agent='Mozilla/5.0 (Linux; Android 13) MovieScoutApp/1.0'); ctx.add_init_script(APP)
            pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_selector('header.top'); pg.wait_for_timeout(600)
            pg.evaluate(plan('Film', 'http://x/film.mkv')); pg.evaluate(START, 'Film')
            pg.wait_for_function('() => window.__calls.length === 1', timeout=15000)
            check('MKV geht gleich in den App-Player', pg.evaluate('window.__calls[0].format') == 'mp4')
            close(pg)
            pg.evaluate('window.__calls.length = 0')
            pg.evaluate(plan('Test', 'http://x/video')); pg.evaluate(START, 'Der Film 2160p HDR HEVC')
            pg.wait_for_function('() => window.__calls.length === 1', timeout=15000)
            check('4K/HDR/HEVC im Namen: gleich App-Player', True)
            close(pg)
            pg.evaluate('window.__calls.length = 0')
            pg.evaluate(plan('Test', 'http://127.0.0.1:1/nope')); pg.evaluate(START, 'Normaler Film')
            pg.wait_for_function('() => window.__calls.length >= 1', timeout=30000)
            check('Browser-Player scheitert: Rückfall auf den App-Player', pg.evaluate('window.__calls.length') == 1)
            b.close()
    finally: srv.terminate()
    check('Keine Skriptfehler', not errs, errs[:3])
    print('\n%d ok, %d Fehler' % (ok, fail)); return 1 if fail else 0
if __name__ == '__main__': sys.exit(main())
