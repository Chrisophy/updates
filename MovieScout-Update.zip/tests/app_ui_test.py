# -*- coding: utf-8 -*-
"""Oberflächen-Test für die App-Funktionen (Playwright/Chromium) mit nachgebauter App-Schnittstelle (MovieScoutApp):
Einstellungen "Android-App", Teilen/Link öffnen, Tipp auf eine Benachrichtigung, Chat-Name für den Dienst.

    python tests/app_ui_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.request import urlopen

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
UP, API = 8841, 8842
BASE = 'http://127.0.0.1:%d/ui/?api=%s' % (API, 'http://127.0.0.1:%d' % API)
passed = failed = 0

BRIDGE = """
window.__calls = [];
window.__st = { bg: true, nt: true, allowed: true, intent: '' };
window.MovieScoutApp = {
  version() { return 'test'; },
  keepScreenOn() {}, nativeAvailable() { return false; },
  takeIntent() { const r = __st.intent; __st.intent = ''; return r; },
  backgroundEnabled() { return __st.bg; }, setBackground(v) { __st.bg = v; __calls.push(['bg', v]); },
  notificationsEnabled() { return __st.nt; }, setNotifications(v) { __st.nt = v; __calls.push(['nt', v]); },
  notificationsAllowed() { return __st.allowed; }, openNotificationSettings() { __calls.push(['ns']); },
  setNotifyPrefs(j) { __calls.push(['prefs', JSON.parse(j)]); },
};
try { localStorage.setItem('mk.chatName', JSON.stringify('Test')); } catch (e) {}
"""


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def wait_port(port, tries=80):
    for _ in range(tries):
        try:
            socket.create_connection(('127.0.0.1', port), timeout=0.3).close()
            return True
        except OSError:
            time.sleep(0.25)
    return False


def calls(pg):
    return pg.evaluate('window.__calls')


def intent(pg, d):
    pg.evaluate('d => { __st.intent = JSON.stringify(d); window.msIntent(); }', d)


def run(pg):
    print('Start in der App')
    pg.goto(BASE)
    pg.wait_for_selector('.tile')
    prefs = [c[1] for c in calls(pg) if c[0] == 'prefs']
    check('Beim Start bekommt der Dienst den Chat-Namen', prefs and prefs[-1] == {'me': 'Test', 'addr': '', 'key': ''}, prefs)

    print('Einstellungen')
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    check('Abschnitt "Android-App" ist da', pg.get_by_text('Android-App', exact=True).count() == 1)
    sw_bg = pg.get_by_role('switch', name='Im Hintergrund weiterlaufen')
    sw_nt = pg.get_by_role('switch', name='Benachrichtigungen (Chat, Erinnerungen, Downloads)')
    check('Schalter zeigen den Zustand der App (beide an)', sw_bg.get_attribute('aria-checked') == 'true' and sw_nt.get_attribute('aria-checked') == 'true')
    sw_bg.click()
    check('Hintergrund aus: App wird informiert', ['bg', False] in calls(pg) and sw_bg.get_attribute('aria-checked') == 'false', calls(pg))
    sw_bg.click()
    check('Hintergrund wieder an', ['bg', True] in calls(pg) and sw_bg.get_attribute('aria-checked') == 'true')
    sw_nt.click()
    check('Benachrichtigungen aus: App wird informiert', ['nt', False] in calls(pg))
    sw_nt.click()
    pg.get_by_role('button', name='Android-Meldungseinstellungen').click()
    check('Knopf öffnet die Android-Meldungseinstellungen', ['ns'] in calls(pg))
    check('Kein Hinweis, solange Android Meldungen erlaubt', 'blockiert' not in pg.inner_text('.panel'))
    pg.go_back()
    pg.wait_for_timeout(200)
    pg.evaluate('__st.allowed = false')
    pg.click('#btnSettings')
    pg.wait_for_selector('.panel')
    check('Hinweis, wenn Android Meldungen blockiert', 'blockiert' in pg.inner_text('.panel'))
    pg.go_back()
    pg.wait_for_timeout(200)

    print('Teilen')
    intent(pg, {'kind': 'share', 'text': 'Dune (2021) https://example.org/film.mp4', 'title': ''})
    pg.wait_for_selector('text=Mit MovieScout geteilt')
    val = pg.input_value('.panel input')
    check('Titel wird aus dem geteilten Text vorbelegt (ohne Link)', val == 'Dune (2021)', val)
    check('"Link abspielen" nur, weil ein Link dabei ist', pg.get_by_role('button', name='Link abspielen').count() == 1)
    pg.get_by_role('button', name='An den Familienchat').click()
    pg.wait_for_timeout(500)
    msgs = json.loads(urlopen('http://127.0.0.1:%d/api/chat' % API).read())['messages']
    check('An den Familienchat: Nachricht liegt im Chat (mit Namen)', any(m['text'].startswith('Dune (2021) https://example.org') and m['author'] == 'Test' for m in msgs), msgs)
    check('Dialog schließt sich danach', pg.locator('text=Mit MovieScout geteilt').count() == 0)

    intent(pg, {'kind': 'share', 'text': 'Dune (2021) https://example.org/film.mp4', 'title': ''})
    pg.wait_for_selector('text=Mit MovieScout geteilt')
    pg.locator('.panel').get_by_role('button', name='Suchen', exact=True).click()
    pg.wait_for_selector('text=Suche: Dune (2021)')
    check('Suchen: Suchergebnis-Ansicht mit dem Titel', True)
    pg.go_back()
    pg.wait_for_timeout(300)

    intent(pg, {'kind': 'share', 'text': 'Nur ein Titel ohne Link', 'title': ''})
    pg.wait_for_selector('text=Mit MovieScout geteilt')
    check('Ohne Link kein "Link abspielen"', pg.get_by_role('button', name='Link abspielen').count() == 0)
    pg.get_by_role('button', name='Abbrechen').click()
    pg.wait_for_timeout(200)
    check('Abbrechen schließt den Dialog', pg.locator('text=Mit MovieScout geteilt').count() == 0)

    print('Link öffnen / moviescout://')
    intent(pg, {'kind': 'play', 'url': 'http://127.0.0.1:%d/nichts.m3u8' % UP, 'title': 'Testsender'})
    pg.wait_for_selector('#player')
    check('Video-Link startet den Player mit dem Titel', pg.inner_text('#player .ttl') == 'Testsender', pg.inner_text('#player .ttl'))
    pg.go_back()
    pg.wait_for_timeout(300)
    check('Zurück schließt den Player', pg.locator('#player').count() == 0)

    intent(pg, {'kind': 'search', 'q': 'Tatort'})
    pg.wait_for_selector('text=Suche: Tatort')
    check('moviescout://search öffnet die Suche', True)
    pg.go_back()
    pg.wait_for_timeout(300)

    print('Tipp auf eine Benachrichtigung')
    intent(pg, {'kind': 'open', 'target': 'chat'})
    pg.wait_for_selector('.chatlist')
    check('Chat-Meldung öffnet den Chat', True)
    pg.go_back()
    pg.wait_for_timeout(300)
    intent(pg, {'kind': 'open', 'target': 'downloads'})
    pg.wait_for_selector('text=Noch nichts heruntergeladen')
    check('Download-Meldung öffnet die Downloads', True)
    pg.go_back()
    pg.wait_for_timeout(300)

    print('Robustheit')
    pg.evaluate("__st.intent = 'kein json'; window.msIntent()")
    pg.evaluate("__st.intent = JSON.stringify({kind: 'unbekannt'}); window.msIntent()")
    pg.evaluate("__st.intent = JSON.stringify({kind: 'play', url: 'javascript:alert(1)'}); window.msIntent()")
    pg.wait_for_timeout(300)
    check('Kaputte/unbekannte Übergaben tun nichts (kein Player, kein Dialog)', pg.locator('#player').count() == 0 and pg.locator('.panel').count() == 0)
    check('Nichts mehr übrig', pg.evaluate("window.MovieScoutApp.takeIntent()") == '')


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MINIKODI_ALLOW_PRIVATE='1', MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'),
               MINIKODI_DATA=tmp, FAKE_UP='http://127.0.0.1:%d' % UP, PYTHONUNBUFFERED='1')
    env.pop('MINIKODI_TOKEN', None)
    env.pop('MOVIESCOUT_TOKEN', None)
    up = subprocess.Popen([sys.executable, str(ROOT / 'tests' / 'fake_upstream.py'), str(UP)])
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT),
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait_port(UP) and wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 1280, 'height': 800}, user_agent='Mozilla/5.0 (Linux; Android 12) MovieScoutApp/test')
            ctx.add_init_script(BRIDGE)
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            try:
                run(pg)
                check('Keine Skriptfehler in der Oberfläche', not errs, errs)
            except Exception:                                   # noqa: BLE001
                import traceback
                traceback.print_exc()
                global failed
                failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png'))
                print('Screenshot:', Path(tmp) / 'fail.png', errs)
            # Normaler Browser (keine App): kein Abschnitt "Android-App" und kein verirrtes "null" in den Einstellungen
            ctx2 = b.new_context(viewport={'width': 1280, 'height': 800})
            pg2 = ctx2.new_page()
            pg2.goto('http://127.0.0.1:%d/ui/' % API)
            pg2.wait_for_selector('.tile')
            pg2.click('#btnSettings')
            pg2.wait_for_selector('.panel')
            txt = pg2.inner_text('.panel')
            check('Browser: Einstellungen ohne Abschnitt "Android-App"', 'Android-App' not in txt)
            check('Browser: kein verirrtes "null" in den Einstellungen', not any(l.strip() == 'null' for l in txt.splitlines()), txt[-200:])
            b.close()
    finally:
        srv.terminate()
        up.terminate()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
