# -*- coding: utf-8 -*-
"""Addon-Dienst: `from lib.loggers import X` geht auch ohne __init__.py im Ordner lib.   python tests/addon_namespace_test.py"""
import io, os, sys, tempfile, zipfile, threading, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
tmp = tempfile.mkdtemp(prefix='ms_ns_')
os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = tmp
ok = fail = 0
def check(n, c, x=''):
    global ok, fail
    if c: ok += 1; print('  ok   ', n)
    else: fail += 1; print('  FEHLER', n, x)
XML = '<?xml version="1.0"?><addon id="plugin.video.nsdemo" name="NS" version="1.0.0" provider-name="x"><requires><import addon="xbmc.python" version="3.0.0"/></requires><extension point="xbmc.python.pluginsource" library="default.py"><provides>video</provides></extension><extension point="xbmc.python.module" library="lib"/><extension point="xbmc.service" library="service_entry.py" start="startup"/><extension point="xbmc.addon.metadata"><summary>x</summary></extension></addon>'
def main():
    import kodi_runtime  # noqa: F401
    from engine import addonhost as A
    from kodi_runtime import context
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        z.writestr('plugin.video.nsdemo/addon.xml', XML)
        z.writestr('plugin.video.nsdemo/default.py', 'import xbmcplugin, sys\nxbmcplugin.endOfDirectory(int(sys.argv[1]))\n')
        z.writestr('plugin.video.nsdemo/lib/loggers.py', 'class Logger:\n    name = "ok"\n')
        z.writestr('plugin.video.nsdemo/lib/ownpkg/__init__.py', 'V = 1\n')
        z.writestr('plugin.video.nsdemo/service_entry.py', 'from lib.loggers import Logger\nimport time, xbmc\ntime.sleep(0.5)\nimport ownpkg\nxbmc.log("NS-" + Logger.name + str(ownpkg.V))\n')
    A.install_zip(b.getvalue())
    A.start_service('plugin.video.nsdemo'); time.sleep(2.5)
    st = A.service_status('plugin.video.nsdemo')
    check('Dienst importiert lib.loggers (ohne __init__.py) und später ownpkg aus dem eigenen lib-Ordner', not any('Dienst beendet' in l for l in st['log']), st['log'])
    print('\n%d ok, %d Fehler' % (ok, fail)); return 1 if fail else 0
if __name__ == '__main__': sys.exit(main())
