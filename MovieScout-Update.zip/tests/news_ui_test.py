# -*- coding: utf-8 -*-
"""Oberflächen-Test (Playwright): Nachrichten & Notizen (RSS-Feeds, eigene Texte).

    python tests/news_ui_test.py
"""
import os
import subprocess
import sys
import tempfile
from http.server import HTTPServer
from pathlib import Path
import threading

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import feeds_test as FT                                               # noqa: E402

API, FEED = 8895, 8892
F = 'http://127.0.0.1:%d' % FEED
BASE = 'http://127.0.0.1:%d/ui/' % API
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def tiles(pg):
    return pg.locator('[data-sec=news] .tile .n').all_inner_texts()


def add_feed(pg, url, name=''):
    pg.get_by_role('button', name='+ Feed hinzufügen').click(); pg.wait_for_selector('.panel input[aria-label="Adresse des Feeds"]')
    pg.locator('.panel input[aria-label="Adresse des Feeds"]').fill(url)
    if name:
        pg.locator('.panel input[aria-label="Name des Feeds"]').fill(name)
    pg.get_by_role('button', name='Hinzufügen', exact=True).click()


def run(pg, errs):
    pg.goto(BASE); pg.wait_for_selector('[data-sec=news]'); pg.wait_for_timeout(300)
    print('Leerer Bereich')
    check('Bereich „Nachrichten & Notizen“ ist da, mit zwei Knöpfen', pg.locator('[data-sec=news] h2').inner_text() == 'Nachrichten & Notizen'
          and pg.locator('[data-sec=news] .chip').all_inner_texts() == ['+ Feed hinzufügen', '+ Text anlegen'], pg.locator('[data-sec=news] .chip').all_inner_texts())
    check('Steht hinter „Entdecken“', pg.evaluate("[...document.querySelectorAll('#view > .hsec')].map(s => s.dataset.sec).join()").find('disc,news') >= 0)

    print('Feed hinzufügen')
    add_feed(pg, 'kein link')
    pg.wait_for_selector('.panel .err:not([hidden])')
    check('Keine Adresse: Hinweis, Fenster bleibt', 'http' in pg.locator('.panel .err').inner_text() and pg.locator('.panel input[aria-label="Adresse des Feeds"]').count() == 1)
    pg.locator('.panel input[aria-label="Adresse des Feeds"]').fill(F + '/plain'); pg.get_by_role('button', name='Hinzufügen', exact=True).click()
    pg.wait_for_function("document.querySelector('.panel .err') && !document.querySelector('.panel .err').hidden && document.querySelector('.panel .err').textContent.includes('kein RSS')", timeout=15000)
    check('Webseite ohne Feed: Meldung von der Engine', True)
    pg.locator('.panel input[aria-label="Adresse des Feeds"]').fill(F + '/'); pg.get_by_role('button', name='Hinzufügen', exact=True).click()
    pg.wait_for_selector('[data-sec=news] .tile.news', timeout=15000)
    check('Webseite mit Feed: Feed wird gefunden, Name aus dem Feed', tiles(pg) == ['📰 Tagesblick'], tiles(pg))
    pg.wait_for_function("document.querySelector('[data-sec=news] .tile .d').textContent.includes('Erste')", timeout=15000)
    check('Kachel zeigt die neueste Überschrift', pg.locator('[data-sec=news] .tile .d').first.inner_text() == 'Erste & wichtigste Meldung', pg.locator('[data-sec=news] .tile .d').first.inner_text())
    check('Jetzt auch „Verwalten“', pg.get_by_role('button', name='Verwalten').count() == 1)
    add_feed(pg, F + '/feed.xml')
    pg.wait_for_selector('.panel .err:not([hidden])', timeout=15000)
    check('Doppelter Feed wird abgelehnt', 'schon' in pg.locator('.panel .err').inner_text(), pg.locator('.panel .err').inner_text())
    pg.locator('.panel input[aria-label="Adresse des Feeds"]').fill(F + '/atom.xml'); pg.locator('.panel input[aria-label="Name des Feeds"]').fill('Mein Blog')
    pg.get_by_role('button', name='Hinzufügen', exact=True).click(); pg.wait_for_function("document.querySelectorAll('[data-sec=news] .tile.news').length === 2", timeout=15000)
    check('Eigener Name wird übernommen', tiles(pg) == ['📰 Tagesblick', '📰 Mein Blog'], tiles(pg))

    print('Meldungen lesen')
    pg.locator('[data-sec=news] .tile', has_text='Tagesblick').click(); pg.wait_for_selector('.panel .feeditem', timeout=15000)
    check('Drei Meldungen mit Datum', pg.locator('.panel .feeditem').count() == 3 and '02.11.2026' in pg.locator('.panel .feeditem').first.inner_text(), pg.locator('.panel .feeditem').first.inner_text())
    pg.locator('.panel .feeditem').first.click(); pg.wait_for_selector('.panel.reader .readtext')
    check('Lesefenster: Titel, Text in Absätzen, Knopf „Im Browser öffnen“', pg.locator('.panel h2').inner_text() == 'Erste & wichtigste Meldung' and pg.locator('.readtext p').all_inner_texts() == ['Hallo Welt', 'Zweiter Absatz']
          and pg.get_by_role('button', name='Im Browser öffnen').count() == 1, pg.locator('.readtext').inner_text())
    pg.evaluate("history.back()"); pg.wait_for_timeout(400)

    print('Eigene Texte')
    pg.get_by_role('button', name='+ Text anlegen').click(); pg.wait_for_selector('.panel textarea')
    pg.get_by_role('button', name='Speichern').click(); pg.wait_for_timeout(300)
    check('Leerer Text wird nicht gespeichert (Fenster bleibt)', pg.locator('.panel textarea').count() == 1)
    pg.locator('.panel input[aria-label="Überschrift"]').fill('Einkauf'); pg.locator('.panel textarea').fill('Milch\nEier\n\nBrot')
    pg.get_by_role('button', name='Speichern').click(); pg.wait_for_selector('[data-sec=news] .tile.note')
    check('Text erscheint als Kachel mit Vorschau', pg.locator('[data-sec=news] .tile.note .n').inner_text() == '📝 Einkauf' and 'Milch' in pg.locator('[data-sec=news] .tile.note .d').inner_text())
    pg.locator('[data-sec=news] .tile.note').click(); pg.wait_for_selector('.panel.reader')
    check('Anzeigen: Text mit Absätzen', pg.locator('.readtext').inner_text().replace('\n', ' ').split() == ['Milch', 'Eier', 'Brot'], pg.locator('.readtext').inner_text())
    pg.get_by_role('button', name='Bearbeiten').click(); pg.wait_for_selector('.panel textarea')
    pg.locator('.panel textarea').fill('Nur Milch'); pg.get_by_role('button', name='Speichern').click(); pg.wait_for_timeout(500)
    check('Bearbeiten: Kachel zeigt neuen Text', pg.locator('[data-sec=news] .tile.note .d').inner_text() == 'Nur Milch', pg.locator('[data-sec=news] .tile.note .d').inner_text())

    print('Verwalten')
    pg.get_by_role('button', name='Verwalten').click(); pg.wait_for_selector('.bundleman .ordrow')
    check('Zwei Feeds und ein Text gelistet', pg.locator('.bundleman .ordrow').count() == 3, pg.locator('.bundleman .ordrow').all_inner_texts())
    pg.get_by_label('Nach oben').nth(1).click(); pg.wait_for_timeout(300)
    check('Reihenfolge per ▲ ändern', pg.locator('.bundleman .ordrow .t').all_inner_texts()[:2] == ['📰 Mein Blog', '📰 Tagesblick'], pg.locator('.bundleman .ordrow .t').all_inner_texts())
    pg.locator('.bundleman .ordrow').nth(0).get_by_label('Umbenennen').click(); pg.wait_for_selector('#layers .layer >> nth=1 >> input')
    pg.locator('#layers .layer >> nth=1 >> input').fill('Blog 2'); pg.keyboard.press('Enter'); pg.wait_for_timeout(500)
    check('Umbenennen', pg.locator('.bundleman .ordrow .t').first.inner_text() == '📰 Blog 2', pg.locator('.bundleman .ordrow .t').first.inner_text())
    pg.locator('.bundleman .ordrow').nth(2).get_by_label('Entfernen').click(); pg.wait_for_timeout(300)
    pg.locator('#layers .layer').last.get_by_role('button', name='Entfernen', exact=True).click(); pg.wait_for_timeout(400)
    check('Text entfernen (mit Rückfrage)', pg.locator('.bundleman .ordrow').count() == 2)
    pg.get_by_role('button', name='Fertig').click(); pg.wait_for_timeout(500)
    check('Startseite folgt: zwei Feed-Kacheln, Reihenfolge neu, kein Text mehr', tiles(pg) == ['📰 Blog 2', '📰 Tagesblick'], tiles(pg))

    print('Speichern & Sicherung')
    pg.reload(); pg.wait_for_selector('[data-sec=news] .tile'); pg.wait_for_timeout(300)
    check('Nach dem Neuladen noch da', tiles(pg) == ['📰 Blog 2', '📰 Tagesblick'], tiles(pg))
    ui = pg.evaluate("collectUi().news")
    check('Sicherung enthält Feeds und Texte', [f['name'] for f in ui['feeds']] == ['Blog 2', 'Tagesblick'] and ui['notes'] == [], ui)
    pg.evaluate("(() => { applyUi({ v: 2, news: { feeds: [{ id: 'x1', name: 'Neu', url: 'http://neu.test/rss' }, { name: 'Doppelt', url: '%s/feed.xml' }, { name: 'Böse', url: 'javascript:alert(1)' }],"
                " notes: [{ title: 'Aus Sicherung', text: 'Hallo' }] } }); })()" % F)
    n = pg.evaluate("newsGet()")
    check('Wiederherstellen ergänzt, ohne Doppelte und ohne ungültige Adressen', [f['name'] for f in n['feeds']] == ['Blog 2', 'Tagesblick', 'Neu'] and [x['title'] for x in n['notes']] == ['Aus Sicherung'], n)

    print('Anordnung')
    check('In den Skin-Bereichen wählbar', pg.evaluate("HOME_IDS.includes('news') && !!HOME_NAMES.news && !!NAV_SECS.news"))
    pg.evaluate("(() => { editSkin((s) => { s.layout.homeHidden = ['news']; }, { view: true }); })()"); pg.wait_for_timeout(400)
    check('Bereich lässt sich ausblenden', pg.locator('[data-sec=news]').count() == 0)
    pg.evaluate("(() => { editSkin((s) => { s.layout.homeHidden = []; }, { view: true }); })()"); pg.wait_for_timeout(400)
    check('… und wieder einblenden', pg.locator('[data-sec=news]').count() == 1)
    check('Keine Fehler in der Konsole', not errs, errs)


def main():
    s = HTTPServer(('127.0.0.1', FEED), FT.Srv)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'):
        env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    global failed
    try:
        assert FT.wait_port(API), 'Server startet nicht'
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_context(viewport={'width': 1280, 'height': 900}).new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
            try:
                run(pg, errs)
            except Exception:      # noqa: BLE001
                import traceback
                traceback.print_exc(); failed += 1
                pg.screenshot(path=str(Path(tmp) / 'fail.png')); print('Screenshot:', Path(tmp) / 'fail.png')
            b.close()
    finally:
        srv.terminate(); s.shutdown()
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    sys.exit(1 if failed else 0)


if __name__ == '__main__':
    main()
