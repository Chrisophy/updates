# -*- coding: utf-8 -*-
"""Desktop-Look: Startleiste, Startmenü, Symbole ziehen, Fernbedienung (OK halten, Verschieben), Speicher; Trailer nicht im Verlauf.
    python tests/desktop_test.py"""
import json, os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8975
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def hold(pg):
    pg.keyboard.down('Enter'); pg.wait_for_timeout(900); pg.keyboard.up('Enter'); pg.wait_for_timeout(850)


def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch()
            ctx = b.new_context(viewport={'width': 1100, 'height': 760}, user_agent='Mozilla/5.0 MovieScoutApp')
            pg = ctx.new_page()
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (API, API)); pg.wait_for_selector('header.top'); pg.wait_for_function('typeof providers !== "undefined" && providers.length', timeout=20000); pg.wait_for_timeout(500)

            # --- Trailer nicht im Verlauf ---
            r = pg.evaluate("""() => { store.set('hist', [{item:{title:'Alt – Trailer',provider:'Trailer',provider_id:'',url:''},ts:1},{item:{title:'Film A',provider:'P',provider_id:'p1',url:'u1'},ts:2}]);
              addHistory({title:'Neu – Trailer',provider:'Trailer',provider_id:'',url:''}); addHistory({title:'Film B',provider:'P',provider_id:'p1',url:'u2'});
              return store.get('hist', []).map(x => x.item.title); }""")
            check('Trailer wird nicht in den Verlauf geschrieben', 'Neu – Trailer' not in r and 'Film B' in r, r)
            pg.evaluate("renderView()"); pg.wait_for_timeout(500)
            r = pg.evaluate("store.get('hist', []).map(x => x.item.title)")
            check('Alte Trailer-Einträge werden aufgeräumt', not any('Trailer' in t for t in r) and 'Film A' in r, r)
            pg.evaluate("store.set('hist', [])")

            # --- Desktop-Look einschalten ---
            def look(i):
                pg.evaluate("""async (id) => { SK.active = id; skinsSave(); applySkin(activeSkin()); await renderView(); }""", i); pg.wait_for_timeout(500)
            look('look-desk-win')
            check('Startleiste unten sichtbar', pg.locator('#deskbar').is_visible() and pg.evaluate("document.querySelector('#deskbar').getBoundingClientRect().bottom") >= 755)
            check('Kopfzeile ausgeblendet, Desktop-Fläche da', not pg.locator('#top').is_visible() and pg.locator('.dkarea').count() == 1)
            check('Hinweis bei leerem Desktop', pg.locator('.dhint').is_visible())
            check('Kein Seiten-Scrollbalken', pg.evaluate("document.documentElement.scrollWidth <= innerWidth"))

            # --- Startmenü ---
            pg.locator('.dstart').click(); pg.wait_for_selector('.startm .sme'); pg.wait_for_timeout(300)
            names = pg.evaluate("[...document.querySelectorAll('.sme b')].map(e => e.textContent)")
            check('Startmenü listet Funktionen', 'Filme entdecken' in names and 'Einstellungen' in names, names[:8])
            check('Startmenü listet Quellen', pg.evaluate("providers.length") > 0 and pg.evaluate("providers[0].name") in names, names)
            pg.fill('.smq', 'Trakt'); pg.wait_for_timeout(150)
            check('Suche im Startmenü filtert', pg.locator('.sme').count() >= 1 and pg.locator('.sme').count() < len(names))
            pg.fill('.smq', ''); pg.wait_for_timeout(150)

            # --- Ziehen auf den Desktop (Maus) ---
            src = pg.locator('.sme', has_text='Meine Bibliothek').first
            bb = src.bounding_box()
            pg.mouse.move(bb['x'] + 40, bb['y'] + 20); pg.mouse.down(); pg.mouse.move(bb['x'] + 200, bb['y'] + 40, steps=4); pg.mouse.move(700, 250, steps=6)
            check('Beim Ziehen: Ghost + Drop-Rahmen', pg.locator('.dghost').count() == 1 and pg.evaluate("document.querySelector('.dkarea').dataset.drop") == '1')
            pg.mouse.up(); pg.wait_for_timeout(500)
            check('Symbol liegt auf dem Desktop', pg.locator('.dicon').count() == 1 and pg.locator('.startm').count() == 0, pg.locator('.dicon').count())
            check('Hinweis verschwindet', not pg.locator('.dhint').is_visible())
            ic = pg.locator('.dicon').first.bounding_box()
            check('Symbol liegt nahe dem Ablegepunkt', abs(ic['x'] - 650) < 130 and abs(ic['y'] - 220) < 130, ic)
            saved = pg.evaluate("store.get('desk', {})")
            check('Gespeichert (mk.desk)', len(saved.get('items', [])) == 1 and saved['items'][0]['ref'] == 'mylib', saved)

            # --- Symbol auf dem Desktop verschieben (Maus) ---
            ib = pg.locator('.dicon').first.bounding_box()
            pg.mouse.move(ib['x'] + 45, ib['y'] + 30); pg.mouse.down(); pg.mouse.move(ib['x'] + 60, ib['y'] + 50, steps=3); pg.mouse.move(300, 150, steps=6); pg.mouse.up(); pg.wait_for_timeout(300)
            ib2 = pg.locator('.dicon').first.bounding_box()
            check('Ziehen verschiebt das Symbol', abs(ib2['x'] - 250) < 130 and abs(ib2['y'] - 100) < 130 and ib2['x'] != ib['x'], (ib, ib2))
            check('Ziehen öffnet nichts', pg.locator('.layer').count() == 0 and pg.evaluate("nav.length") == 1)

            # --- Persistenz ---
            pg.reload(); pg.wait_for_selector('#deskbar'); pg.wait_for_timeout(800)
            check('Nach Neustart: Look + Symbol noch da', pg.locator('.dicon').count() == 1 and pg.evaluate("document.body.dataset.desk") == 'win')
            pos = pg.evaluate("[document.querySelector('.dicon').dataset.c, document.querySelector('.dicon').dataset.r]")

            # --- Klick öffnet ---
            pg.locator('.dicon').first.click(); pg.wait_for_timeout(700)
            check('Klick auf Symbol öffnet die Funktion', pg.locator('.layer').count() >= 1, pg.evaluate("nav.length"))
            pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            if pg.locator('.layer').count(): pg.evaluate("history.back()"); pg.wait_for_timeout(300)

            # --- Fernbedienung: Startmenü -> OK halten -> Auf Desktop legen ---
            pg.locator('.dstart').focus(); pg.keyboard.press('Enter'); pg.wait_for_selector('.startm .sme'); pg.wait_for_timeout(300)
            pg.fill('.smq', 'Einstellungen'); pg.wait_for_timeout(200)
            pg.evaluate("document.querySelector('.sme').focus()")
            hold(pg)
            check('OK halten im Startmenü: Menü mit „Auf Desktop legen“', pg.locator('.cardmenu').get_by_role('button', name='Auf Desktop legen').count() == 1)
            pg.locator('.cardmenu').get_by_role('button', name='Auf Desktop legen').click(); pg.wait_for_timeout(600)
            check('Per Menü auf den Desktop gelegt (2 Symbole)', pg.locator('.dicon').count() == 2)
            check('Startmenü bleibt offen für weitere', pg.locator('.startm').count() == 1)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            if pg.locator('.startm').count(): pg.evaluate("history.back()"); pg.wait_for_timeout(300)

            # --- Fernbedienung: Verschieben ---
            pg.evaluate("document.querySelectorAll('.dicon')[1].focus()")
            before = pg.evaluate("[...document.querySelectorAll('.dicon')[1].dataset.c ? [document.querySelectorAll('.dicon')[1].dataset.c, document.querySelectorAll('.dicon')[1].dataset.r] : []]")
            hold(pg)
            check('OK halten auf Symbol: Menü', pg.locator('.cardmenu').get_by_role('button', name='Verschieben').count() == 1)
            pg.locator('.cardmenu').get_by_role('button', name='Verschieben').click(); pg.wait_for_timeout(500)
            check('Verschieben-Modus aktiv', pg.locator('.dicon.moving').count() == 1)
            for k in ('ArrowRight', 'ArrowRight', 'ArrowRight', 'ArrowDown'): pg.keyboard.press(k)
            pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
            after = pg.evaluate("[document.querySelectorAll('.dicon')[1].dataset.c, document.querySelectorAll('.dicon')[1].dataset.r]")
            check('Pfeiltasten + OK verschieben und legen ab', int(after[0]) == int(before[0]) + 3 and int(after[1]) == int(before[1]) + 1 and pg.locator('.dicon.moving').count() == 0, (before, after))
            saved = pg.evaluate("store.get('desk').items.map(i => [i.c, i.r])")
            check('Neue Position gespeichert', [int(after[0]), int(after[1])] in saved, (after, saved))
            # abbrechen
            hold(pg)
            pg.locator('.cardmenu').get_by_role('button', name='Verschieben').click(); pg.wait_for_timeout(400)
            pg.keyboard.press('ArrowLeft'); pg.keyboard.press('ArrowLeft'); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            after2 = pg.evaluate("[document.querySelectorAll('.dicon')[1].dataset.c, document.querySelectorAll('.dicon')[1].dataset.r]")
            check('Zurück bricht das Verschieben ab', after2 == after and pg.locator('.dicon.moving').count() == 0 and pg.evaluate("nav.length") == 1, (after, after2))
            # Besetzte Zelle: kein Überlappen
            a0 = pg.evaluate("[document.querySelectorAll('.dicon')[0].dataset.c, document.querySelectorAll('.dicon')[0].dataset.r]")
            pg.evaluate("document.querySelectorAll('.dicon')[1].focus()")
            hold(pg)
            pg.locator('.cardmenu').get_by_role('button', name='Verschieben').click(); pg.wait_for_timeout(300)
            for _ in range(12): pg.keyboard.press('ArrowLeft')
            for _ in range(12): pg.keyboard.press('ArrowUp')
            pg.keyboard.press('ArrowRight' if False else 'Enter'); pg.wait_for_timeout(300)
            cells = pg.evaluate("[...document.querySelectorAll('.dicon')].map(e => e.dataset.c + ',' + e.dataset.r)")
            check('Keine zwei Symbole auf derselben Stelle', len(set(cells)) == len(cells), cells)

            # --- Tastatur öffnet sich nie von selbst (Fokus verloren, dann Pfeiltaste) ---
            def kb():
                return pg.evaluate("(() => { const a = document.activeElement; return !!(a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA')); })()")
            pg.locator('.dstart').focus(); pg.keyboard.press('Enter'); pg.wait_for_selector('.startm .sme'); pg.wait_for_timeout(300)
            pg.evaluate("document.querySelector('.smchips .chip:nth-child(3)').focus()")
            pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
            check('Filter geklickt: Fokus bleibt auf dem Filter', pg.evaluate("document.activeElement.classList.contains('chip')"))
            pg.evaluate("document.activeElement.blur()")        # Fokus weg, wie nach dem Neuzeichnen
            for k in ('ArrowDown', 'ArrowUp', 'ArrowRight', 'ArrowDown'):
                pg.keyboard.press(k)
                if kb(): break
            check('Pfeiltaste ohne Fokus fokussiert kein Eingabefeld (keine Tastatur)', not kb(), pg.evaluate("document.activeElement.outerHTML.slice(0, 80)"))
            pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            if pg.locator('.startm').count(): pg.evaluate("history.back()"); pg.wait_for_timeout(300)
            pg.evaluate("document.activeElement.blur()")
            pg.keyboard.press('ArrowDown'); pg.keyboard.press('ArrowRight')
            check('Auf dem Desktop ohne Fokus: kein Eingabefeld', not kb())

            # --- Sicherung: erreicht eine Pfeiltaste auf irgendeinem Weg ein Eingabefeld, bleibt die Tastatur zu ---
            pg.locator('.dstart').focus(); pg.keyboard.press('Enter'); pg.wait_for_selector('.startm .smq'); pg.wait_for_timeout(300)
            pg.keyboard.press('ArrowRight')
            pg.evaluate("document.querySelector('.smq').focus()")              # z. B. Android-eigene Navigation
            pg.wait_for_timeout(100)
            check('Pfeiltaste + Fokus auf Eingabefeld: nur markiert, keine Tastatur', not kb() and pg.evaluate("document.querySelector('.smq').classList.contains('vfocus')"))
            pg.keyboard.press('Enter'); pg.wait_for_timeout(200)
            check('OK öffnet das Feld dann wirklich (Tastatur)', kb())
            pg.evaluate("document.activeElement.blur()"); pg.wait_for_timeout(500)
            pg.evaluate("document.querySelector('.smq').focus()"); pg.wait_for_timeout(100)
            check('Ohne vorherige Pfeiltaste (Antippen) funktioniert der Fokus wie gewohnt', kb())
            pg.evaluate("document.activeElement.blur()")
            pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
            if pg.locator('.startm').count(): pg.evaluate("history.back()"); pg.wait_for_timeout(300)

            # --- Erreichbarkeit mit Pfeiltasten: Desktop <-> Startleiste ---
            pg.evaluate("document.querySelectorAll('.dicon')[0].focus()")
            seen = set()
            for _ in range(14):
                pg.keyboard.press('ArrowDown'); pg.keyboard.press('ArrowRight')
                seen.add(pg.evaluate("document.activeElement.className.split(' ')[0]"))
            check('Pfeiltasten erreichen die Startleiste', any(c.startswith('dbb') for c in seen), seen)
            pg.evaluate("document.querySelector('.dstart').focus()")
            ups = set()
            for _ in range(3):
                pg.keyboard.press('ArrowUp'); ups.add(pg.evaluate("document.activeElement.className.split(' ')[0]"))
            check('Von der Startleiste zurück zu den Symbolen', 'dicon' in ups, ups)

            # --- Gadget-Symbole: wie bei den Schnellzugriff-Kacheln, nicht Puzzle ---
            r = pg.evaluate("""async () => { await loadExtInfos(); await loadWidgets(true);
              const inf = (extInfoCache.list || []).find((i) => (i.links || []).length && (widgetsCache.list || []).some((w) => w.ext === i.id && w.icon));
              if (!inf) return null;
              const w = widgetsCache.list.find((x) => x.ext === inf.id), path = inf.links[0].path;
              const d = deskGet(); d.items.push({ id: 'gtest', k: 'ext', ref: path, label: 'G', icon: '🧩', c: 5, r: 3 }); deskSet(d); deskLayout();
              const onDesk = document.querySelector('.dicon[data-id="gtest"] .di').textContent;
              const cat = deskCatalog().find((e) => e.k === 'ext' && e.ref === path);
              const res = { want: w.icon, cat: cat && cat.icon, desk: onDesk }; d.items = d.items.filter((i) => i.id !== 'gtest'); deskSet(d); deskLayout(); return res; }""")
            check('Gadget-Symbol aus dem Gadget selbst (Startmenü und Desktop)', r is not None and r['want'] != '🧩' and r['cat'] == r['want'] and r['desk'] == r['want'], r)

            # --- Entfernen / Umbenennen ---
            pg.evaluate("document.querySelectorAll('.dicon')[1].focus()")
            hold(pg)
            pg.locator('.cardmenu').get_by_role('button', name='Vom Desktop entfernen').click(); pg.wait_for_timeout(500)
            check('Entfernen', pg.locator('.dicon').count() == 1 and len(pg.evaluate("store.get('desk').items")) == 1)

            # --- Zurück / Desktop in der Startleiste ---
            pg.evaluate("pushView({type:'list', title:'X', pid: providers[0].id, item: null, search: false})"); pg.wait_for_timeout(700)
            check('Unterseite: Desktop weg, Leiste bleibt', pg.locator('.dkarea').count() == 0 and pg.locator('#deskbar').is_visible())
            pg.locator('.dback').click(); pg.wait_for_timeout(500)
            check('Zurück-Knopf der Leiste', pg.evaluate("nav.length") == 1 and pg.locator('.dkarea').count() == 1)
            pg.evaluate("pushView({type:'list', title:'X', pid: providers[0].id, item: null, search: false})"); pg.wait_for_timeout(500)
            pg.locator('.dhome').click(); pg.wait_for_timeout(700)
            check('Desktop-Knopf der Leiste', pg.evaluate("nav.length") == 1 and pg.locator('.dkarea').count() == 1)

            # --- Sicherung enthält den Desktop ---
            check('Sicherung (collectUi) enthält den Desktop', len(pg.evaluate("collectUi().desk.items")) == 1)

            # --- Alle vier Stile, dann zurück zum normalen Look ---
            for sid, st in (('look-desk-ubuntu', 'ubuntu'), ('look-desk-mac', 'mac'), ('look-desk-android', 'android'), ('look-desk-win', 'win')):
                look(sid)
                check('Stil %s' % st, pg.evaluate("document.body.dataset.desk") == st and pg.locator('#deskbar').is_visible() and pg.locator('.dicon').count() == 1
                      and pg.evaluate("document.documentElement.scrollWidth <= innerWidth"))
            look('minikodi')
            check('Normaler Look: Leiste weg, Kopfzeile da', pg.locator('#deskbar').count() == 0 and pg.locator('#top').is_visible() and pg.evaluate("document.body.dataset.desk") is None)

            # --- Raster: Querformat 4 Reihen, Hochformat gleiche Ränder links/rechts ---
            def geo():
                return pg.evaluate("""() => { const g = deskGrid(), a = DK.el.getBoundingClientRect();
                  const d = deskGet(); d.items = Array.from({length: g.cols * g.rows}, (_, i) => ({ id: 'q' + i, k: 'act', ref: 'x' + i, label: 'Q' + i, icon: '⭐', c: Math.floor(i / g.rows), r: i % g.rows })); deskSet(d); deskLayout();
                  const ic = [...document.querySelectorAll('.dicon')].map((e) => e.getBoundingClientRect());
                  const left = Math.min(...ic.map((r) => r.left)) - a.left, right = a.right - Math.max(...ic.map((r) => r.right));
                  const bottom = Math.max(...ic.map((r) => r.bottom)), top = Math.min(...ic.map((r) => r.top)), res = { cols: g.cols, rows: g.rows, left, right, top, bottom, areaBottom: a.bottom };
                  d.items = []; deskSet(d); return res; }""")
            for style in ('look-desk-mac', 'look-desk-win', 'look-desk-android', 'look-desk-ubuntu'):
                look(style)
                pg.set_viewport_size({'width': 1070, 'height': 481}); pg.wait_for_timeout(500)
                g1 = geo()
                check('Querformat (%s): 4 Reihen, nichts unter der Leiste' % style[10:], g1['rows'] >= 4 and g1['bottom'] <= g1['areaBottom'] + 1 and g1['top'] >= 0, g1)
                pg.set_viewport_size({'width': 481, 'height': 1000}); pg.wait_for_timeout(500)
                g2 = geo()
                check('Hochformat (%s): links und rechts gleich viel Rand' % style[10:], g2['cols'] >= 4 and abs(g2['left'] - g2['right']) <= 2, g2)
            pg.set_viewport_size({'width': 1100, 'height': 760}); pg.wait_for_timeout(300)
            g3 = geo()
            check('Großer Bildschirm: Ränder gleich, 5+ Reihen', g3['rows'] >= 5 and abs(g3['left'] - g3['right']) <= 2, g3)

            # --- Handy-Breite ---
            look('look-desk-mac')
            pg.set_viewport_size({'width': 390, 'height': 780}); pg.wait_for_timeout(400)
            r = pg.evaluate("(() => { const r = document.querySelector('#deskbar').getBoundingClientRect(); return [r.left, r.right, innerWidth, document.documentElement.scrollWidth]; })()")
            check('Handy: Dock passt in den Bildschirm', r[0] >= 0 and r[1] <= r[2] + 1 and r[3] <= r[2], r)
            look('look-desk-android'); pg.wait_for_timeout(300)
            r = pg.evaluate("(() => { const r = document.querySelector('#deskbar').getBoundingClientRect(); return [r.left, r.right, innerWidth, document.documentElement.scrollWidth]; })()")
            check('Handy: Android-Leiste passt', r[0] >= 0 and r[1] <= r[2] + 1 and r[3] <= r[2], r)
            pg.locator('.dstart').click(); pg.wait_for_selector('.startm .sme'); pg.wait_for_timeout(300)
            r = pg.evaluate("(() => { const r = document.querySelector('.startl .panel').getBoundingClientRect(); return [r.left, r.right, r.bottom, innerHeight]; })()")
            check('Handy: Startmenü passt', r[0] >= 0 and r[1] <= 391 and r[2] <= r[3], r)
            pg.screenshot(path='/tmp/g/desk_mobile.png')
            b.close()
    finally:
        srv.terminate()
    check('Keine Skriptfehler', not errs, errs)
    print('\n%d ok, %d Fehler' % (passed, failed)); return 1 if failed else 0
if __name__ == '__main__': sys.exit(main())
