import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8961; ok = bad = 0
def check(n, c, x=''):
    global ok, bad
    if c: ok += 1; print('  ok   ', n)
    else: bad += 1; print('  FEHLER', n, x)
tmp = tempfile.mkdtemp()
env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT/'tests'/'fake_providers'), NO_PROXY='*')
srv = subprocess.Popen([sys.executable, str(ROOT/'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for _ in range(100):
    try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
    except OSError: time.sleep(.25)
try:
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_context(viewport={'width':900,'height':800}).new_page(); errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.goto('http://127.0.0.1:%d/ui/' % API); pg.wait_for_function('typeof providers!=="undefined" && providers.length', timeout=20000)
        cases = {
          '403 Client Error: Forbidden for url: https://x/y': '403',
          'HTTP Error 404: Not Found': '404',
          'Status 429 Too Many Requests': '429',
          '503 Server Error: Service Unavailable for url': '5xx',
          'HTTPSConnectionPool(host=x): Max retries exceeded: Name or service not known': 'DNS',
          'Zeitüberschreitung - die Quelle antwortet nicht': 'Zeitüberschreitung',
          'Failed to fetch': 'Keine Verbindung',
          'SSL: CERTIFICATE_VERIFY_FAILED': 'Sichere Verbindung',
          'Cloudflare: Just a moment...': 'Sicherheitsprüfung',
          'Engine nicht erreichbar: http://127.0.0.1:18765': 'Engine nicht erreichbar',
        }
        for raw, want in cases.items():
            r = pg.evaluate("(t) => { const x = explainError(t); return x ? x.short + '|' + x.title : null }", raw)
            check('Klartext: %s' % raw[:40], r and want.lower() in r.lower(), r)
        for raw in ['Das Addon braucht das Python-Modul „urllib3“.', 'Mehr als 8 Seiten sind nicht möglich', 'Seite 403 ist leer', 'Keine Quelle gefunden']:
            check('Unverändert: %s' % raw[:40], pg.evaluate("(t) => explainError(t)", raw) is None)
        pg.evaluate("document.querySelector('main').replaceChildren(failure('403 Client Error: Forbidden for url: https://x', () => {}))")
        t = pg.locator('main').inner_text()
        check('failure(): Titel + Tipp + technische Meldung eingeklappt', 'Zugriff verweigert' in t and 'Anderes Netz' in t and pg.locator('details.techerr').count() == 1 and 'Erneut versuchen' in t, t[:200])
        pg.evaluate("toast('HTTP Error 429: Too Many Requests', true)"); pg.wait_for_timeout(200)
        check('Toast in Klartext', 'Zu viele Anfragen' in pg.locator('.toast').last.inner_text(), pg.locator('.toast').last.inner_text())
        check('keine Skriptfehler', not errs, errs)
        b.close()
finally:
    srv.terminate()
print(ok, bad)
