# -*- coding: utf-8 -*-
"""tools/update_install.py: Update von Hand ohne Altlasten (Modi update, clean, custom).

    python tests/update_install_test.py
"""
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOOL = str(ROOT / 'tools' / 'update_install.py')
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def run(*args):
    r = subprocess.run([sys.executable, TOOL, *args, '--yes'], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


t = Path(tempfile.mkdtemp())
pkg = t / 'p.zip'
with zipfile.ZipFile(pkg, 'w') as z:
    z.writestr('VERSION', '9.9.9\n'); z.writestr('main.py', 'print(1)\n'); z.writestr('engine/app.py', 'x = 1\n')
    z.writestr('static/index.html', '<html></html>'); z.writestr('userData/settings.json', '{"vom":"zip"}')   # userData aus dem ZIP wird nie übernommen
f = t / 'f'
(f / 'engine').mkdir(parents=True); (f / 'userData' / 'user').mkdir(parents=True); (f / 'userData' / 'update' / 'current').mkdir(parents=True)
(f / 'VERSION').write_text('1.0.0\n'); (f / 'engine' / 'alt.py').write_text('alt')
(f / 'userData' / 'settings.json').write_text('{"mein":"wert"}'); (f / 'userData' / 'user' / 's.py').write_text('s')

rc, out = run(str(pkg), '--folder', str(f))
check('update: läuft durch', rc == 0, out)
check('update: Version neu, alte Datei weg', (f / 'VERSION').read_text().strip() == '9.9.9' and not (f / 'engine' / 'alt.py').exists())
check('update: Einstellungen bleiben, userData aus dem ZIP ignoriert', (f / 'userData' / 'settings.json').read_text() == '{"mein":"wert"}')
check('update: altes In-App-Update entfernt', not (f / 'userData' / 'update').exists())
bk = list((f / 'backup').glob('userData-*.zip'))
check('update: Sicherung mit Einstellungen angelegt', len(bk) == 1 and 'userData/settings.json' in zipfile.ZipFile(bk[0]).namelist())

rc, out = run(str(pkg), '--folder', str(f), '--mode', 'clean')
check('clean: userData leer', rc == 0 and not any((f / 'userData').iterdir()), out)
(f / 'userData' / 'settings.json').write_text('{}'); (f / 'userData' / 'user').mkdir(exist_ok=True); (f / 'userData' / 'user' / 'x').write_text('x')
rc, out = run(str(pkg), '--folder', str(f), '--mode', 'custom', '--keep', 'settings.json')
check('custom: nur gewählter Eintrag bleibt', rc == 0 and (f / 'userData' / 'settings.json').exists() and not (f / 'userData' / 'user').exists(), out)
bad = t / 'b.zip'
with zipfile.ZipFile(bad, 'w') as z:
    z.writestr('x.txt', 'nix')
rc, out = run(str(bad), '--folder', str(f))
check('Kein MovieScout-Paket: Abbruch, Ordner unverändert', rc != 0 and (f / 'VERSION').read_text().strip() == '9.9.9', out)
print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
