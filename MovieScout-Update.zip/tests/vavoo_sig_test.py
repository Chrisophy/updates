# -*- coding: utf-8 -*-
"""Vavoo Live TV: Portal verlangt die App-Signatur (Ping -> addonSig). Prüft Senderliste, Auflösen, Live-Felder und die Fehleranzeige.
    python tests/vavoo_sig_test.py"""
import json, os, shutil, socket, subprocess, sys, tempfile, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
FAKE, API = 8978, 8977
mode = {'ping': True, 'sig': True, 'val': 'SIG-ABC123'}
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def items():
    mk = lambda n, g, c: {'type': 'iptv', 'ids': {'id': c}, 'name': n, 'group': g, 'url': 'https://vavoo.to/vavoo-iptv/play/' + c, 'logo': ''}
    return [mk('Das Erste HD', 'Germany', 'de1'), mk('ZDF HD', 'Germany', 'de2'), mk('ORF 1 HD', 'Austria', 'at1')]
class H(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *a): pass
    def _s(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code); self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        n = int(self.headers.get('Content-Length') or 0); body = json.loads(self.rfile.read(n) or b'{}'); p = self.path.split('?')[0]
        if p == '/mediahubmx.json': return self._s(200, {'catalogs': []})
        if p == '/ping':
            return self._s(200, {'addonSig': mode['val']}) if mode['ping'] else self._s(500, {})
        if p == '/mediahubmx-catalog.json':
            if mode['sig'] and self.headers.get('mediahubmx-signature') != mode['val']: return self._s(403, {'error': 'signature'})
            return self._s(200, {'items': items()})
        if p == '/mediahubmx-resolve.json':
            if mode['sig'] and self.headers.get('mediahubmx-signature') != mode['val']: return self._s(403, {'error': 'signature'})
            return self._s(200, [{'url': 'http://127.0.0.1:%d/v/index.m3u8' % FAKE}])
        self._s(404, {})
def call(path, body=None):
    req = urllib.request.Request('http://127.0.0.1:%d%s' % (API, path), data=json.dumps(body).encode() if body is not None else None, headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=90) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, {}
def start_engine(extra):
    pdir = tempfile.mkdtemp(); shutil.copy(str(ROOT / 'tests' / 'vavoo_fixture' / 'vavoolive.py'), pdir)
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=pdir, MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0',
               NO_PROXY='127.0.0.1,localhost', no_proxy='127.0.0.1,localhost', VAVOO_PORTAL='http://127.0.0.1:%d' % FAKE, VAVOO_PING='http://localhost:%d/ping' % FAKE, **extra)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    return srv
def main():
    fake = ThreadingHTTPServer(('', FAKE), H); threading.Thread(target=fake.serve_forever, daemon=True).start()
    srv = start_engine({})
    try:
        s, d = call('/api/open', {'provider_id': 'vavoolive'})
        s, g = call('/api/open', {'provider_id': 'vavoolive', 'item': d['items'][0]})
        titles = [i['title'] for i in g['items']]
        check('Mit Signatur: Gruppen sichtbar', titles[0].startswith('Germany (2)'), titles)
        s, ch = call('/api/open', {'provider_id': 'vavoolive', 'item': g['items'][0]})
        names = [i['title'] for i in ch['items']]
        check('Sender gesäubert', names == ['Das Erste', 'ZDF'], names)
        it = ch['items'][0]
        check('Sender sind als Live gekennzeichnet', it.get('live') is True and it['kind'] == 'play', it)
        s, r = call('/api/resolve', {'provider_id': 'vavoolive', 'item': it})
        check('Stream wird mit Signatur aufgelöst', len(r.get('hosters', [])) == 1 and r['hosters'][0]['live'], r)
        # Portal hat die Signatur gewechselt (alte im Speicher ist ungültig), Ping liefert die neue -> wird automatisch erneuert
        mode['val'] = 'SIG-NEU'
        s, d = call('/api/open', {'provider_id': 'vavoolive'})
        reload_item = next(i for i in d['items'] if i['title'].startswith('Senderliste neu'))
        s, rr = call('/api/open', {'provider_id': 'vavoolive', 'item': reload_item})
        check('Signatur wechselt: wird neu geholt, Liste lädt', any('3 Sender geladen' in n.get('message', '') for n in rr.get('notes', [])), rr)
        # Wechsel und Ping kaputt -> verständlicher Eintrag statt leerer Seite
        mode['val'] = 'SIG-NOCH-NEUER'; mode['ping'] = False
        s, rr = call('/api/open', {'provider_id': 'vavoolive', 'item': reload_item})
        t = [i['title'] for i in rr.get('items', [])]
        check('Ohne gültige Signatur: Hinweis statt leerer Liste', bool(t) and t[0].startswith('Keine Senderliste erhalten'), rr)
        check('… mit Grund', bool(t) and ('ignatur' in (rr['items'][0].get('plot') or '') or '403' in (rr['items'][0].get('plot') or '')), t and rr['items'][0].get('plot'))
        # Portal ohne Signaturpflicht, Ping kaputt -> Notfallweg ohne Signatur
        mode['sig'] = False
        s, rr = call('/api/open', {'provider_id': 'vavoolive', 'item': reload_item})
        check('Portal ohne Signaturpflicht: Notfallweg liefert Sender', any('Sender geladen' in n.get('message', '') for n in rr.get('notes', [])), rr)
    finally:
        srv.terminate(); fake.shutdown()
    print('\n%d ok, %d Fehler' % (passed, failed)); sys.exit(1 if failed else 0)
main()
