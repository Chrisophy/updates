# -*- coding: utf-8 -*-
"""Captcha-Dienst in den Einstellungen (Konten): Feld vorhanden, Speichern, Engine nutzt den Dienst.

    python tests/captcha_ui_test.py
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PORT = 8931
API = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, ok, extra=''):
    global passed, failed
    if ok:
        passed += 1; print('  ok   ', name)
    else:
        failed += 1; print('  FEHLER', name, extra)


def call(path):
    return json.loads(urllib.request.urlopen(API + path, timeout=60).read())


def main():
    tmp = tempfile.mkdtemp(prefix='ms_cap_')
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp)
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER', 'MOVIESCOUT_CAPTCHA_PROVIDER', 'MOVIESCOUT_CAPTCHA_KEY'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:
                socket.create_connection(('127.0.0.1', PORT), timeout=.3).close(); break
            except OSError:
                time.sleep(.25)
        time.sleep(1)
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch(); pg = b.new_page(viewport={'width': 412, 'height': 890})
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(API + '/ui/?api=' + API); pg.wait_for_timeout(1500)
            pg.evaluate("openSettings()"); pg.wait_for_selector('.panel h2', timeout=8000); pg.wait_for_timeout(500)
            pg.get_by_role('tab', name='Konten & Inhalte').click(); pg.wait_for_timeout(300)
            has = pg.evaluate("""() => { const l = [...document.querySelectorAll('.panel label')].map((x) => x.textContent); return [l.includes('Captcha-Dienst'), l.includes('Captcha-Dienst: API-Schlüssel')]; }""")
            check('Felder „Captcha-Dienst“ und „API-Schlüssel“ sind da', has == [True, True], has)
            pg.evaluate("""() => { const f = (t) => [...document.querySelectorAll('.panel .field')].find((x) => x.querySelector('label') && x.querySelector('label').textContent === t);
              const s = f('Captcha-Dienst').querySelector('select'); s.value = '2captcha'; s.dispatchEvent(new Event('change', { bubbles: true }));
              const i = f('Captcha-Dienst: API-Schlüssel').querySelector('input'); i.value = '  TESTKEY123456789  '; i.dispatchEvent(new Event('input', { bubbles: true })); }""")
            pg.get_by_role('button', name='Speichern', exact=True).click(); pg.wait_for_timeout(1000)
            st = call('/api/settings')['settings']
            check('Dienst und Schlüssel (ohne Leerzeichen) gespeichert', st.get('captcha_provider') == '2captcha' and st.get('captcha_key') == 'TESTKEY123456789', {k: st.get(k) for k in ('captcha_provider', 'captcha_key')})
            pg.evaluate("openSettings()"); pg.wait_for_selector('.panel h2', timeout=8000); pg.wait_for_timeout(500)
            pg.get_by_role('tab', name='Konten & Inhalte').click(); pg.wait_for_timeout(300)
            vals = pg.evaluate("""() => { const f = (t) => [...document.querySelectorAll('.panel .field')].find((x) => x.querySelector('label') && x.querySelector('label').textContent === t);
              return [f('Captcha-Dienst').querySelector('select').value, f('Captcha-Dienst: API-Schlüssel').querySelector('input').value]; }""")
            check('Beim erneuten Öffnen stehen die Werte wieder drin', vals == ['2captcha', 'TESTKEY123456789'], vals)
            check('Keine Skriptfehler', not errs, errs)
            b.close()
    finally:
        p.terminate()
    sys.path.insert(0, str(ROOT))
    os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = tmp
    import kodi_runtime  # noqa: F401
    from resources.lib.captcha import captcha_solver as cs
    check('Der Solver nutzt den gespeicherten Dienst', cs._configured() == [('2captcha', 'TESTKEY123456789')], cs._configured())
    print('\n%d ok, %d Fehler' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
