# -*- coding: utf-8 -*-
"""Test der Vielfalt-Gadgets (Nachrichten/RSS, Bilderrahmen, Küchen-Timer, Schoner-Bilder) mit echter Engine und Browser.

    python tests/variety_test.py
"""
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from datetime import date
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8897
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=30) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=8, step=0.1):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def setv(ext, **values):
    return http('/api/admin/ext/settings', {'ext': ext, 'values': values})[0]


def code_of(gid):
    from engine import examples as EXM
    return next(e for e in EXM.EXAMPLES if e['id'] == gid)['code']


RSS = """<?xml version="1.0"?><rss version="2.0" xmlns:media="http://search.yahoo.com/mrss/"><channel><title>T</title>
<item><title>Erste &amp; wichtige Meldung</title><link>https://ex.test/1</link><description>&lt;p&gt;Hallo &lt;b&gt;Welt&lt;/b&gt;&lt;/p&gt;</description><pubDate>Mon, 01 Jan 2024 10:00:00 GMT</pubDate></item>
<item><title>Folge 7</title><link>https://ex.test/7</link><description>Podcast</description><enclosure url="http://127.0.0.1:%(p)d/a.mp3" type="audio/mpeg" length="5"/><media:thumbnail url="http://x/t.jpg"/></item>
<item><title>Nur Bild</title><enclosure url="http://x/bild.jpg" type="image/jpeg" length="5"/></item>
</channel></rss>"""
ATOM = """<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Atom-Eintrag</title><link href="https://a.test/1"/><summary>Kurz</summary><updated>2024-02-02T00:00:00Z</updated></entry></feed>"""
JPG = b'\xff\xd8\xff\xe0' + b'0' * 50


def serve(port):
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            body = {'/rss': RSS % {'p': port}, '/atom': ATOM}.get(self.path)
            if body is None:
                self.send_response(404); self.end_headers(); return
            self.send_response(200); self.send_header('Content-Type', 'text/xml'); self.end_headers(); self.wfile.write(body.encode())

        def log_message(self, *a):
            pass
    s = HTTPServer(('127.0.0.1', port), H)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    return s


class FakeApi:
    def __init__(self, **v):
        self.v, self.store, self.chats = v, {}, []

    def get(self, k, d=None):
        return self.v.get(k, self.store.get(k, d)) if k in self.v else self.store.get(k, d)

    def set(self, k, val):
        self.store[k] = val

    def chat(self, t, *a, **kw):
        self.chats.append(t)


def main():
    fport = 8898
    fake = serve(fport)
    tmp = Path(tempfile.mkdtemp(prefix='ms_var_'))
    photos = tmp / 'fotos'
    (photos / 'sub').mkdir(parents=True)
    (photos / 'a.jpg').write_bytes(JPG)
    (photos / 'sub' / 'b.png').write_bytes(b'\x89PNG' + b'1' * 20)
    (photos / 'x.txt').write_text('geheim')
    (tmp / 'geheim.jpg').write_bytes(JPG)
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)

        print('Nachrichten (reine Funktionen)')
        ns = {}
        exec(code_of('nachrichten'), ns)
        check('Feeds: Name; Adresse, Kommentare/ohne http ignoriert', ns['feeds']('A; https://a.test/x\n# k\nkaputt\nhttp://b.test/y\nB; ftp://z') == [('A', 'https://a.test/x'), ('b.test', 'http://b.test/y')])
        it = ns['parse'](RSS % {'p': 1}.encode() if False else (RSS % {'p': 1}).encode())
        check('RSS: 3 Einträge, Entities und HTML bereinigt', len(it) == 3 and it[0]['title'] == 'Erste & wichtige Meldung' and it[0]['desc'] == 'Hallo Welt', it[:1])
        check('RSS: Audio-Anhang wird Medium, Bild-Anhang nicht', it[1]['media'].endswith('a.mp3') and it[1]['image'] == 'http://x/t.jpg' and it[2]['media'] == '' and it[2]['image'] == 'http://x/bild.jpg', it[1:])
        at = ns['parse'](ATOM.encode())
        check('Atom wird gelesen', len(at) == 1 and at[0]['title'] == 'Atom-Eintrag' and at[0]['link'] == 'https://a.test/1' and at[0]['desc'] == 'Kurz', at)

        print('Küchen-Timer (reine Funktionen)')
        tn = {}
        exec(code_of('kuechentimer'), tn)
        api = FakeApi()
        tn['_api'] = api
        check('Presets lesen', tn['presets']('Ei; 5\nUnsinn\nTee; 0,5\nNull; 0\nZu lang; 99999') == [('Ei', 5.0), ('Tee', 0.5)])
        check('Ungültige Minuten werden abgelehnt', tn['starten']('x', 'abc') is None and tn['starten']('x', 0) is None and tn['starten']('x', -3) is None)
        r = tn['starten']('Nudeln', 0.001)
        check('Timer startet', r and r['name'] == 'Nudeln' and len(tn['liste']()) == 1)
        check('Alarm im Chat und Timer als fertig markiert', wait(lambda: api.chats == ['⏰ Nudeln ist fertig!'] and tn['liste']()[0]['fertig'], 5), (api.chats, tn['liste']()))
        r2 = tn['starten']('Lang', 10)
        check('Stoppen entfernt den Timer', tn['stoppen'](r2['id']) is True and tn['stoppen'](r2['id']) is False)
        check('Zeitformat', tn['fmt'](65) == '1:05' and tn['fmt'](3725) == '1:02:05' and tn['fmt'](-5) == '0:00')

        print('Engine: Nachrichten')
        for gid in ('nachrichten', 'bilderrahmen', 'kuechentimer'):
            code, js = http('/api/admin/examples/install', {'id': gid})
            check('%s installiert' % gid, code == 200 and js.get('ok'), (code, js))
        lst = http('/api/admin/list?kind=extension')[1]
        rows = {r_['file']: r_ for r_ in (lst if isinstance(lst, list) else lst.get('files') or lst.get('items') or [])}
        check('alle drei ohne Ladefehler', all(f + '.py' in rows and not (rows[f + '.py'].get('info') or {}).get('error') for f in ('nachrichten', 'bilderrahmen', 'kuechentimer')),
              {k: (v.get('info') or {}).get('error') for k, v in rows.items()})
        setv('nachrichten', feeds='Test; http://127.0.0.1:%d/rss\nAtom; http://127.0.0.1:%d/atom\nTot; http://127.0.0.1:%d/gibtsnicht' % (fport, fport, fport), anzahl=10)
        ws = http('/api/ext/widgets?fresh=1')[1]['widgets']
        w = next((x for x in ws if x['ext'] == 'nachrichten'), None)
        check('Kachel zeigt die erste Schlagzeile', w and w['text'].startswith('Erste & wichtige') and w['sub'] == 'Test' and 'Folge 7' in w['lines'], w)
        code, page = http('/api/x/nachrichten/index')
        check('Leseseite: Meldungen, Link, Fehlerhinweis für toten Feed', code == 200 and 'Erste &amp; wichtige' in page and 'https://ex.test/1' in page and 'Atom-Eintrag' in page and 'Tot:' in page, page[:300])
        mi = http('/api/ext/items?kind=menus&ext=nachrichten&id=nachrichten')
        items = mi[1].get('items') if isinstance(mi[1], dict) else mi[1]
        check('Menü: nur abspielbare Beiträge, direkte Adresse', mi[0] == 200 and len(items) == 1 and items[0]['url'].endswith('/a.mp3') and items[0]['provider_id'] == 'm3u_iptv' and items[0]['is_playable'], mi)

        print('Engine: Bilderrahmen')
        setv('bilderrahmen', ordner=str(photos), adressen='https://x.test/a.jpg\nkeine adresse')
        ws = http('/api/ext/widgets?fresh=1')[1]['widgets']
        w = next((x for x in ws if x['ext'] == 'bilderrahmen'), None)
        check('Widget liefert nur Bilder (2 Dateien + 1 Adresse)', w and len(w['bilder']) == 3 and w['text'] == '' and any(b.startswith('https://x.test') for b in w['bilder']), w)
        local = [b for b in w['bilder'] if b.startswith('/api/x/')]
        from urllib.request import urlopen as uo
        r_ = uo(BASE + local[0], timeout=10)
        check('Bild wird mit Bild-Content-Type ausgeliefert', r_.status == 200 and r_.headers['Content-Type'] in ('image/jpeg', 'image/png'), r_.headers['Content-Type'])
        check('Pfad-Ausbruch und fremde Dateien werden abgelehnt', all(http('/api/x/bilderrahmen/bild?f=' + f)[0] == 404 for f in ('../geheim.jpg', 'x.txt', '..%2Fgeheim.jpg', '/etc/passwd', 'fehlt.jpg', '')))
        check('Übersichtsseite listet die Bilder', http('/api/x/bilderrahmen/index')[1].count('<img') == 3)

        print('Engine: Küchen-Timer')
        code, js = http('/api/x/kuechentimer/start', {'name': 'Pizza', 'minuten': 12})
        check('Start über die Seite-Route', code == 200 and js['ok'])
        check('Ungültig -> 400', http('/api/x/kuechentimer/start', {'name': 'x', 'minuten': 'abc'})[0] == 400)
        lj = http('/api/x/kuechentimer/liste')[1]
        check('Liste enthält den Timer und die Serverzeit', len(lj['timer']) == 1 and abs(lj['timer'][0]['ende'] - lj['jetzt'] - 720) < 5, lj)
        w = next((x for x in http('/api/ext/widgets?fresh=1')[1]['widgets'] if x['ext'] == 'kuechentimer'), None)
        check('Kachel zeigt den laufenden Timer', w and w['text'].startswith('Pizza 11:') and '1 Timer' in w['sub'], w)
        check('Stoppen', http('/api/x/kuechentimer/stop', {'id': lj['timer'][0]['id']})[1]['ok'] is True and http('/api/x/kuechentimer/liste')[1]['timer'] == [])
        check('Seite enthält Presets', 'Nudeln · 10 min' in http('/api/x/kuechentimer/index')[1])

        print('Oberfläche: Bildschirmschoner mit Widget-Bildern')
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            br = pw.chromium.launch()
            pg = br.new_page(viewport={'width': 1000, 'height': 700})
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.route('https://x.test/**', lambda r_: r_.fulfill(status=200, content_type='image/jpeg', body=JPG))
            pg.goto(BASE + '/')
            pg.wait_for_timeout(1500)
            pg.evaluate('saverShow()')
            pg.wait_for_selector('#saver .sv-slide', timeout=8000)
            pg.wait_for_timeout(500)
            bg = pg.evaluate("document.querySelector('#saver .sv-bg').style.backgroundImage")
            check('Schoner zeigt ein Bild aus dem Bilderrahmen', 'x.test' in bg or '/api/x/bilderrahmen/bild' in bg, bg)
            check('Kachel ohne Text (nur Bilder) erscheint nicht als leere Kachel', pg.evaluate("[...document.querySelectorAll('#saver .sv-w')].every(e => e.textContent.trim().length > 0)"))
            check('Keine Skriptfehler', not errs, errs)
            pg.evaluate('saverHide()'); pg.wait_for_timeout(2500)
            pops = []
            pg.context.on('page', lambda q: pops.append(q))
            pg.evaluate("openManager('extensions')")
            pg.wait_for_selector('.panel button:has-text("Timer öffnen")', timeout=8000)
            pg.click('.panel button:has-text("Timer öffnen")')
            pg.wait_for_selector('.layer.gadget iframe', timeout=8000)
            check('Gadget-Seite öffnet in der App (Rahmen), kein neues Fenster', not pops and pg.locator('.layer.gadget iframe').count() == 1)
            pg.evaluate('closeTopLayer()')
            check('Schließen entfernt die Seite wieder', wait(lambda: pg.locator('.layer.gadget').count() == 0, 3))
            br.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        fake.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
