# -*- coding: utf-8 -*-
"""Frisch kopierte Addon-Module werden gefunden, auch wenn Python den Ordner schon als leer kennt (Android-Speicher).
    python tests/addon_stale_import_test.py"""
import os, sys, tempfile, importlib
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
tmp = tempfile.mkdtemp(prefix='ms_stale_')
os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = tmp
passed = failed = 0
def check(n, ok, x=''):
    global passed, failed
    if ok: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def main():
    import kodi_runtime  # noqa: F401
    from engine import addonhost as A
    lib = Path(tmp) / 'lib'; lib.mkdir()
    sys.path.insert(0, str(lib))
    try: import stale_mod_x  # noqa: F401
    except ImportError: pass
    (lib / 'stale_mod_x').mkdir(); (lib / 'stale_mod_x' / '__init__.py').write_text('v = 1')
    st = os.stat(str(lib)); f = sys.path_importer_cache.get(str(lib))
    if f is not None and hasattr(f, '_path_mtime'):
        os.utime(str(lib), ns=(st.st_atime_ns, int(f._path_mtime * 1e9)))        # Zeitstempel wie vorher: Android-Fall
    try: import stale_mod_x; before = True
    except ImportError: before = False
    print('   ohne Auffrischen gefunden:', before)
    A._fresh_imports(tmp)
    try: import stale_mod_x; after = True
    except ImportError: after = False
    check('Nach _fresh_imports wird das Modul gefunden', after)
    print('\n%d ok, %d Fehler' % (passed, failed)); return 1 if failed else 0
if __name__ == '__main__': sys.exit(main())
