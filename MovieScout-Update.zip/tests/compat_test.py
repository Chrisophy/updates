# -*- coding: utf-8 -*-
"""Test des Kompatibilitäts-Checks (engine/compat.py) ohne Server.

    python tests/compat_test.py
"""
import io
import os
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault('MOVIESCOUT_DATA', tempfile.mkdtemp(prefix='ms_compat_'))
os.environ.setdefault('MINIKODI_DATA', os.environ['MOVIESCOUT_DATA'])

from engine import addonhost as AH, compat as C  # noqa: E402

passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def scan(files, info=None):
    return C.scan_files({k: (v.encode() if isinstance(v, str) else v) for k, v in files.items()}, info or {})


def codes(rep, level=None):
    return [f['code'] for f in rep['findings'] if level is None or f['level'] == level]


def texts(rep):
    return ' | '.join(f['text'] for f in rep['findings'])


def addon_xml(aid, points, requires=()):
    req = ''.join('<import addon="%s"/>' % r for r in requires)
    return ('<addon id="%s" name="T" version="1.0.0" provider-name="x"><requires><import addon="xbmc.python" version="3.0.0"/>%s</requires>%s</addon>'
            % (aid, req, points))


def zipped(aid, files):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as z:
        for n, c in files.items():
            z.writestr(aid + '/' + n, c)
    return b.getvalue()


print('Sauberes Addon')
r = scan({'default.py': 'import sys, xbmc, xbmcgui, xbmcplugin\nxbmc.log("x")\nxbmcgui.Dialog().ok("a", "b")\nxbmcplugin.endOfDirectory(1)\n'})
check('Urteil „läuft voraussichtlich“, 100 Punkte, keine Befunde', r['verdict'] == 'ok' and r['score'] == 100 and not r['findings'], r)
check('Statistik zählt Dateien, Zeilen und genutzte Kodi-Funktionen', r['stats']['files'] == 1 and r['stats']['apis'] >= 3, r['stats'])

print('Kodi-Funktionen')
r = scan({'default.py': 'import xbmc\nxbmc.gibtEsNicht()\nxbmc.log("x")\n'})
check('Unbekannte Modulfunktion: Einschränkung mit Namen', r['verdict'] == 'limited' and 'xbmc.gibtEsNicht' in texts(r), r)
r = scan({'default.py': 'import xbmcgui\nd = xbmcgui.Dialog()\nd.ok("a")\nd.gibtEsNicht()\n'})
check('Unbekannte Methode an Variable mit Kodi-Klasse', 'xbmcgui.Dialog().gibtEsNicht' in texts(r), r)
r = scan({'default.py': 'import xbmcgui\nxbmcgui.Dialog().noch_so_eine()\n'})
check('Unbekannte Methode direkt an neuer Instanz', 'xbmcgui.Dialog().noch_so_eine' in texts(r), r)
r = scan({'default.py': 'import xbmcgui\nd = xbmcgui.Dialog()\nfor d in [1, 2]:\n    d.bit_length()\n'})
check('Variable, die auch etwas anderes bekommt, wird nicht geprüft', r['verdict'] == 'ok', r)
r = scan({'default.py': 'from xbmcgui import Dialog, ListItem\nDialog().ok("a")\nli = ListItem("x")\nli.setLabel("y")\n'})
check('from-Import und ListItem-Methoden', r['verdict'] == 'ok', r)
r = scan({'default.py': 'from xbmcgui import GibtEsNicht\n'})
check('from-Import eines unbekannten Namens', 'xbmcgui.GibtEsNicht' in texts(r), r)
r = scan({'default.py': 'import xbmcgui\nw = xbmcgui.Window(10000)\nw.irgendwas_neues()\nc = xbmcgui.ControlButton(0, 0, 1, 1, "x")\nc.noch_was()\n'})
check('Klassen mit Auffang-Methode (Control, Window-Stubs) werden nicht beanstandet', 'noch_was' not in texts(r), r)
r = scan({'default.py': 'import xbmc, xbmcvfs, xbmcgui\nxbmc.playSFX("x")\nxbmc.stopSFX()\nxbmc.getGlobalIdleTime()\nxbmcvfs.makeLegalFilename("a")\nxbmcgui.INPUT_TYPE_TEXT\nxbmc.Player().isPlayingAudio()\nxbmc.Player().getMusicInfoTag()\n'})
check('Nachgerüstete Funktionen (SFX, Leerlaufzeit, Musik-Info, Eingabetypen) sind vorhanden', r['verdict'] == 'ok', r)
r = scan({'default.py': 'import xbmcdrm\n'})
check('xbmcdrm: Kodi-Teil, den es nicht gibt', r['verdict'] == 'limited' and 'xbmcdrm' in texts(r), r)

print('Skin-Fenster (WindowXML)')
src = 'import xbmcgui\nclass W(xbmcgui.WindowXMLDialog):\n    pass\nW("a.xml", ".").doModal()\n'
SKIN = {'resources/skins/Default/720p/a.xml': '<window><controls><control type="button" id="1"/></controls></window>'}
r = scan(dict({'default.py': src}, **SKIN))
check('WindowXML: unterstützt -> Hinweis „vereinfacht“, Urteil bleibt grün', r['verdict'] == 'ok' and 'windowxml' in codes(r, 'info'), r)
import kodi_runtime.xbmcgui as G  # noqa: E402
G.WINDOWXML = False
r = scan(dict({'default.py': src}, **SKIN))
check('Ohne Unterstützung (Schalter): Urteil „läuft nicht“', r['verdict'] == 'no' and 'windowxml' in codes(r, 'error'), r)
G.WINDOWXML = True
r = scan({'default.py': src})
check('Ohne Skin-Dateien im Paket: Warnhinweis, Urteil „eingeschränkt“', r['verdict'] == 'limited' and 'windowxml_files' in codes(r, 'warn'), r)
r = scan({'default.py': src, 'resources/skins/Default/720p/a.xml': '<window><controls><control type="button" id="1"/></controls></window>'})
check('Mit Skin-Datei: nur der Hinweis „vereinfacht“', r['verdict'] == 'ok' and 'windowxml_files' not in codes(r, 'warn') and 'windowxml_parts' not in codes(r, 'info'), r)
r = scan({'default.py': src, 'resources/skins/Default/720p/a.xml': '<window><controls><control type="videowindow" id="1"/><control type="visualisation"/></controls></window>'})
check('Skin mit Videofenster/Visualisierung: Hinweis auf nicht gezeichnete Elemente', 'windowxml_parts' in codes(r, 'info') and r['verdict'] == 'ok', r)

print('Python 2')
r = scan({'default.py': 'print "hallo"\n'})
check('print-Anweisung: Python-2-Fehler, Urteil „läuft nicht“', r['verdict'] == 'no' and 'py2' in codes(r, 'error'), r)
r = scan({'default.py': 'import urllib2\n'})
check('import urllib2 ohne Absicherung: Fehler', r['verdict'] == 'no' and 'urllib2' in texts(r), r)
r = scan({'default.py': 'try:\n    import urllib.request as u\nexcept ImportError:\n    import urllib2 as u\n'})
check('urllib2 als Ausweg im except-Zweig: nur Hinweis', r['verdict'] == 'ok', r)
r = scan({'default.py': 'x = {}\nfor k, v in x.iteritems():\n    pass\ny = unicode("a")\n'})
check('Python-2-Reste (iteritems, unicode) als Einschränkung', r['verdict'] == 'limited' and 'py2rest' in codes(r), r)
r = scan({'default.py': 'def f(file):\n    return file\nunicode = str\nprint(unicode("a"))\n'})
check('Selbst definierte Namen (file, unicode) sind keine Python-2-Reste', r['verdict'] == 'ok', r)

print('Importe')
r = scan({'default.py': 'import json, os\nimport requests\n'})
check('Standardbibliothek und installierte Python-Pakete sind in Ordnung', r['verdict'] == 'ok', r)
r = scan({'default.py': 'import gibt_es_nicht_xyz\n'})
check('Fehlendes Modul oben im Code: Einschränkung', r['verdict'] == 'limited' and 'gibt_es_nicht_xyz' in texts(r), r)
r = scan({'default.py': 'try:\n    import gibt_es_nicht_xyz\nexcept ImportError:\n    gibt_es_nicht_xyz = None\n'})
check('Abgesichertes Modul: nur Hinweis', r['verdict'] == 'ok', r)
r = scan({'default.py': 'def f():\n    import gibt_es_nicht_xyz\n'})
check('Modul nur in einer Funktion: nur Hinweis', r['verdict'] == 'ok', r)
r = scan({'default.py': 'import gibt_es_nicht_xyz\n'}, {'requires': [{'id': 'script.module.irgendwas'}]})
check('Unbekanntes Modul bei verlangter, nicht installierter Bibliothek: Hinweis statt Warnung', r['verdict'] == 'ok' and 'import' in codes(r, 'info'), r)
r = scan({'default.py': 'import routing\n'}, {'requires': [{'id': 'script.module.routing'}]})
check('Modulname passt zur verlangten Bibliothek', r['verdict'] == 'ok' and not r['findings'] or 'import' not in codes(r, 'warn'), r)
r = scan({'default.py': 'import utils\nfrom helpers import x\n', 'resources/lib/utils.py': 'a = 1\n', 'helpers.py': 'x = 1\n'},
         {'library': 'default.py'})
check('Eigene Module im Addon-Ordner; resources/lib nur, wenn es das Addon selbst in den Pfad legt', 'utils' in texts(r) and 'helpers' not in texts(r), r)
r = scan({'default.py': 'import sys\nsys.path.append("resources/lib")\nimport utils\n', 'resources/lib/utils.py': 'a = 1\n'})
check('sys.path.append: Module aus Unterordnern gelten als vorhanden', r['verdict'] == 'ok', r)
r = scan({'resources/lib/default.py': 'import utils\n', 'resources/lib/utils.py': 'a = 1\n'}, {'library': 'resources/lib/default.py'})
check('Startdatei in resources/lib: Nachbarmodule sind importierbar (wie in Kodi)', r['verdict'] == 'ok', r)
r = scan({'default.py': 'from resources.lib import x\n', 'resources/lib/x.py': 'a = 1\n', 'resources/__init__.py': ''}, {'pkg': 'addon_x'})
check('Paketname des Addons (resources) gilt als eigen', r['verdict'] == 'ok', r)
r = scan({'default.py': 'import tkinter\n'})
check('Desktop-Fenster (tkinter) oben im Code: Fehler', r['verdict'] == 'no' and 'desktop' in codes(r, 'error'), r)
r = scan({'default.py': 'import sys\nif sys.platform == "win32":\n    import msvcrt\n'})
check('Windows-Modul hinter Plattformabfrage: kein Fehler', r['verdict'] == 'ok', r)

print('Befehle und Sonstiges')
r = scan({'default.py': 'import xbmc\nxbmc.executebuiltin("Notification(a, b)")\nxbmc.executebuiltin("RunScript(script.x)")\n'})
check('Bekannte Befehle (Notification, RunScript) ohne Hinweis', not r['findings'], r)
r = scan({'default.py': 'import xbmc\nxbmc.executebuiltin("PlayerControl(Stop)")\nxbmc.executebuiltin("%s" % x)\n'})
check('Unbekannter Befehl nur als Hinweis; Formatzeichen werden nicht als Befehl gelesen', r['verdict'] == 'ok' and 'playercontrol' in texts(r) and '%s' not in texts(r), r)
r = scan({'default.py': 'import xbmc\nxbmc.executeJSONRPC(\'{"jsonrpc":"2.0","method":"Player.Open","id":1}\')\n'})
check('Nicht nachgebildeter JSON-RPC-Aufruf als Hinweis', 'rpc' in codes(r, 'info') and 'Player.Open' in texts(r), r)
r = scan({'default.py': 'li.setProperty("inputstream.adaptive.license_type", "com.widevine.alpha")\n'})
check('DRM (Widevine) als Einschränkung', r['verdict'] == 'limited' and 'drm' in codes(r), r)
r = scan({'default.py': 'import subprocess\nsubprocess.Popen(["ls"])\n'})
check('subprocess nur als Hinweis', r['verdict'] == 'ok' and 'subprocess' in codes(r, 'info'), r)
r = scan({'icon.png': b'x'})
check('Addon ohne Python-Code', r['verdict'] == 'ok' and 'nopy' in codes(r), r)
r = scan({'default.py': 'x = (\n'})
check('Syntaxfehler wird als Fehler gemeldet, nicht als Absturz', r['verdict'] == 'no', r)
r = scan({'default.py': b'\xff\xfe\x00bad'})
check('Kaputt codierte Datei bringt den Check nicht zum Absturz', r['verdict'] in ('no', 'limited', 'ok'), r)

print('Reihenfolge, Wertung, Kurzfassung')
r = scan({'a.py': 'import xbmc\nxbmc.gibtEsNicht()\n', 'b.py': 'print "x"\n'})
levels = [f['level'] for f in r['findings']]
check('Fehler stehen vor Einschränkungen', levels == sorted(levels, key=lambda l: {'error': 0, 'warn': 1, 'info': 2}[l]) and levels[0] == 'error', levels)
check('Wertung sinkt mit Fehlern und Einschränkungen', r['score'] == 100 - 45 - 12, r['score'])
b = C.brief(r)
check('Kurzfassung: Urteil, Zähler und die wichtigsten Texte', b['verdict'] == 'no' and b['errors'] == 1 and b['warnings'] == 1 and len(b['top']) == 2, b)
check('Kurzfassung ohne Bericht ist None', C.brief(None) is None)
big = {('p%d.py' % i): 'import os\nx = %d\n' % i for i in range(400)}
t0 = time.time()
r = scan(big)
check('400 Dateien in unter 3 Sekunden', time.time() - t0 < 3 and r['stats']['files'] == 400, time.time() - t0)
t0 = time.time()
r = C.scan_files({('p%d.py' % i).encode().decode(): b'import os\n' * 2000 for i in range(60)}, {}, budget=0.0)
check('Zeitbudget: es wird teilweise geprüft und das gesagt', 'skipped' in codes(r), r)

print('ZIP prüfen (ohne Installation)')
good = zipped('plugin.video.zipok', {'addon.xml': addon_xml('plugin.video.zipok', '<extension point="xbmc.python.pluginsource" library="default.py"/>'),
                                     'default.py': 'import xbmc\nxbmc.log("x")\n'})
info, rep = C.scan_zip(good)
check('scan_zip liefert Addon-Daten und Bericht', info['id'] == 'plugin.video.zipok' and rep['verdict'] == 'ok', rep)
check('scan_zip installiert nichts', not AH.meta('plugin.video.zipok'))
obf = zipped('plugin.video.obf', {'addon.xml': addon_xml('plugin.video.obf', '<extension point="xbmc.python.pluginsource" library="default.py"/>'),
                                  'default.py': 'import marshal\nexec(marshal.loads(b"\\x00" * 10))\nexec("%s")\n' % ('A' * 120000)})
info, rep = C.scan_zip(obf)
check('Verschleierter Code: Urteil „läuft nicht“, Befund „obfuscated“', rep['verdict'] == 'no' and 'obfuscated' in codes(rep), rep)
skin = zipped('skin.x', {'addon.xml': addon_xml('skin.x', '<extension point="xbmc.gui.skin"/>')})
info, rep = C.scan_zip(skin)
check('Nicht unterstützter Typ: Urteil „läuft nicht“', rep['verdict'] == 'no' and 'type' in codes(rep), rep)
for bad, name in ((b'kein zip', 'Kein ZIP'), (zipped('x', {'default.py': 'pass'}), 'Ohne addon.xml')):
    try:
        C.scan_zip(bad)
        check(name + ': Fehlermeldung', False)
    except AH.AddonError:
        check(name + ': verständliche Fehlermeldung', True)

print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
sys.exit(1 if failed else 0)
