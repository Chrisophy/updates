# -*- coding: utf-8 -*-
"""Retro-Spiele in der Oberfläche: Knopf, Liste, Hinzufügen, Starten, Beenden (Zurück / Menü), Löschen.
    python tests/retro_ui_test.py"""
import os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8981
ROM = ROOT / 'tests' / 'test_game.a26'
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0', NO_PROXY='127.0.0.1,localhost')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        with sync_playwright() as p:
            b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']); pg = b.new_page(viewport={'width': 1100, 'height': 700})
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (API, API)); pg.wait_for_selector('header.top'); pg.wait_for_function('typeof providers !== "undefined" && providers.length', timeout=20000)
            check('Knopf „Retro-Spiele“ in der Kopfzeile', pg.locator('#btnRetro').is_visible())
            pg.locator('#btnRetro').click(); pg.wait_for_selector('.panel h2:has-text("Retro-Spiele")')
            check('Leere Liste erklärt, wie man Spiele hinzufügt', 'Spiel hinzufügen' in pg.locator('.panel').inner_text() and 'OK = Feuerknopf' in pg.locator('.panel').inner_text())
            pg.locator('.panel input[type=file]').set_input_files(str(ROM)); pg.wait_for_selector('.rtrow .row', timeout=10000)
            check('Hinzugefügtes Spiel steht in der Liste', 'test game' in pg.locator('.rtrow .row').first.inner_text().lower(), pg.locator('.rtrow').first.inner_text())
            pg.locator('.rtrow .row').first.click(); pg.wait_for_selector('.layer.gadget iframe[src*="retro/play.html"]')
            fr = pg.frame_locator('iframe[src*="retro/play.html"]')
            pg.wait_for_function(r'''(() => { const w = document.querySelector('iframe[src*="retro/play.html"]'); return !!(w && w.contentWindow.Javatari && w.contentWindow.Javatari.room && w.contentWindow.Javatari.room.consoleControls); })()''', timeout=20000)
            pg.wait_for_timeout(1500)
            check('Spiel läuft im Vollbild-Fenster (Emulator-Bild)', fr.locator('#javatari-screen canvas').count() >= 1)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(600)
            check('Zurück/Esc beendet das Spiel', pg.locator('iframe[src*="retro/play.html"]').count() == 0 and pg.locator('.panel h2:has-text("Retro-Spiele")').count() == 1)
            pg.locator('.rtrow .row').first.click(); pg.wait_for_selector('iframe[src*="retro/play.html"]'); pg.wait_for_timeout(1500)
            pg.go_back(); pg.wait_for_timeout(600)
            check('Android-Zurück (Verlauf) beendet das Spiel', pg.locator('iframe[src*="retro/play.html"]').count() == 0)
            pg.get_by_role('button', name='löschen').first.click(); pg.wait_for_timeout(300); pg.get_by_role('button', name='Löschen', exact=True).click(); pg.wait_for_timeout(800)
            check('Löschen (mit Rückfrage) entfernt das Spiel', pg.locator('.rtrow').count() == 0)
            b.close()
    finally:
        srv.terminate()
    check('keine Skriptfehler', not errs, errs)
    print('\n%d ok, %d Fehler' % (passed, failed)); sys.exit(1 if failed else 0)
main()
