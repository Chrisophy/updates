# -*- coding: utf-8 -*-
"""Video-Addon, das alles in einem eigenen Fenster zeigt (wie Vavoo): nach dem Schließen zurück zur vorherigen Seite (nicht „nur Einstellungen“),
beim nächsten Öffnen erscheint das Fenster wieder; Tastenblock unten nur auf Wunsch.   python tests/window_plugin_test.py"""
import os, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from kodixml_test import DEMO, INCLUDES, MAIN, PNG, PO, zipped          # noqa: E402
ROOT = Path(__file__).resolve().parent.parent
PORT = 8948
ok = bad = 0
def check(n, c, x=''):
    global ok, bad
    if c: ok += 1; print('  ok   ', n)
    else: bad += 1; print('  FEHLER', n, x)
AX = ('<addon id="plugin.video.wintest" name="Fenster-Test" version="1.0.0"><requires><import addon="xbmc.python" version="3.0.0"/></requires>'
      '<extension point="xbmc.python.pluginsource" library="default.py"><provides>video</provides></extension></addon>')
PLAYER = r'''
import xbmc, xbmcaddon, xbmcgui
class W(xbmcgui.WindowXMLDialog):
    def __init__(self, *a, **k):
        xbmcgui.WindowXMLDialog.__init__(self)
    def onClick(self, cid):
        if cid == 200:
            li = xbmcgui.ListItem('Testfilm')
            xbmc.Player().play('https://example.invalid/film.m3u8|User-Agent=Foo', li)
    def onAction(self, a):
        if a.getId() in (10, 92):
            self.close()
path = xbmcaddon.Addon().getAddonInfo('path')
w = W('Main.xml', path, 'Default', '1080i')
w.doModal()
del w
xbmc.executebuiltin('ActivateWindow(Home)')
'''
SETTINGS = '<settings><category label="A"><setting id="x" type="text" label="X" default=""/></category></settings>'
def main():
    tmp = tempfile.mkdtemp(prefix='ms_wp_')
    out = Path(tmp) / 'out.txt'
    env = dict(os.environ, MINIKODI_DATA=tmp, MOVIESCOUT_DATA=tmp, KW_OUT=str(out))
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'): env.pop(k, None)
    p = subprocess.Popen([sys.executable, 'main.py', '--local', '--port', str(PORT)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try: socket.create_connection(('127.0.0.1', PORT), timeout=.3).close(); break
            except OSError: time.sleep(.25)
        time.sleep(1)
        urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/api/admin/addon/install' % PORT, method='POST', headers={'Content-Type': 'application/zip'},
            data=zipped('plugin.video.wintest', {'addon.xml': AX, 'default.py': DEMO, 'resources/settings.xml': SETTINGS,
                'resources/skins/Default/1080i/Main.xml': MAIN, 'resources/skins/Default/1080i/Includes.xml': INCLUDES,
                'resources/skins/Default/media/bg.png': PNG, 'resources/language/resource.language.en_gb/strings.po': PO}))).read()
        urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:%d/api/admin/addon/install' % PORT, method='POST', headers={'Content-Type': 'application/zip'},
            data=zipped('plugin.video.winplay', {'addon.xml': AX.replace('plugin.video.wintest', 'plugin.video.winplay').replace('Fenster-Test', 'Fenster-Play'), 'default.py': PLAYER, 'resources/settings.xml': SETTINGS,
                'resources/skins/Default/1080i/Main.xml': MAIN, 'resources/skins/Default/1080i/Includes.xml': INCLUDES,
                'resources/skins/Default/media/bg.png': PNG, 'resources/language/resource.language.en_gb/strings.po': PO}))).read()
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch()
            ctxb = b.new_context(viewport={'width': 900, 'height': 400}, has_touch=True, is_mobile=True)
            pg = ctxb.new_page(); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/?api=http://127.0.0.1:%d' % (PORT, PORT)); pg.wait_for_timeout(1500)
            for rnd in (1, 2):
                n0 = pg.evaluate("nav.length")
                pg.evaluate("openProvider(providers.find(p=>p.addon==='plugin.video.wintest'))")
                pg.wait_for_selector('.layer.kwin .kw-stage', timeout=15000)
                check('Runde %d: Fenster des Addons öffnet sich' % rnd, True)
                check('Runde %d: kein Tastenblock unten (volles Bild)' % rnd, pg.locator('.kw-pad').count() == 0)
                check('Runde %d: kein X-Knopf oben rechts' % rnd, pg.locator('.kw-x').count() == 0)
                fs = pg.evaluate("['font12','font13','font16','font20','font30','font45','font99'].map(f => kwFont(f).px)")
                check('Runde %d: Schriftgrößen wie in Kodi (Estuary ÷ 1,5, unbekannte Namen klein)' % rnd, fs == [17, 20, 21, 27, 20, 30, 20], fs)
                if rnd == 1:
                    w = pg.evaluate("(() => { const r = document.querySelector('.kw-wrap').getBoundingClientRect(); return [Math.round(r.width), Math.round(r.height), document.querySelector('.kw-stage').offsetWidth]; })()")
                    check('Breites Handy (900x400): Fenster füllt die ganze Breite und Höhe wie in Kodi', w[0] >= 895 and w[1] >= 395 and w[2] > 1280, w)
                pg.evaluate("history.back()")
                pg.wait_for_function("!document.querySelector('.layer.kwin')", timeout=10000); pg.wait_for_timeout(1200)
                check('Runde %d: nach dem Schließen zurück (kein Einstellungs-Eintrag)' % rnd, pg.evaluate("nav.length") == n0 and pg.get_by_text('Einstellungen / Anmelden').count() == 0, pg.evaluate("nav.length"))
            # Schalter für den Tastenblock
            pg.evaluate("store.set('kwpad', true); store.set('closex', true)")
            pg.evaluate("openProvider(providers.find(p=>p.addon==='plugin.video.wintest'))")
            pg.wait_for_selector('.layer.kwin .kw-stage', timeout=15000)
            check('Mit Einstellung „Tasten-Block“: Block erscheint (Touch)', pg.locator('.kw-pad').count() == 1)
            check('Mit Einstellung „X-Knopf“: X erscheint', pg.locator('.kw-x').count() == 1)
            pg.locator('.kw-x').click(); pg.wait_for_timeout(1500)
            # Wiedergabe aus dem Fenster: Fenster schließt, die Oberfläche spielt ab (statt Liste mit „Einstellungen“)
            pg.evaluate("store.set('closex', false)")
            pg.evaluate("openProvider(providers.find(p=>p.addon==='plugin.video.winplay'))")
            pg.wait_for_selector('.layer.kwin .kw-stage', timeout=15000)
            pg.evaluate("kwinSend({ t: 'click', cid: 200 })")
            pg.wait_for_selector('#player', timeout=15000)
            check('Abspielen im Addon-Fenster startet den Player', pg.locator('#player').count() == 1)
            check('Das Addon-Fenster ist dabei geschlossen', pg.locator('.layer.kwin').count() == 0)
            check('Keine Liste mit „Einstellungen“ dahinter', pg.get_by_text('Einstellungen / Anmelden').count() == 0)
            b.close()
        check('Keine Skriptfehler', not errs, errs[:3])
    finally:
        p.terminate()
    print('\n%d ok, %d Fehler' % (ok, bad)); return 1 if bad else 0
if __name__ == '__main__': sys.exit(main())
