# -*- coding: utf-8 -*-
"""Atari 2600 im Browser: Spiel startet, OK = Feuer, Menü, Zurück; Engine-Liste/Upload/Löschen.
    python tests/retro_play_test.py"""
import hashlib, json, os, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parent.parent
API = 8980
ROM = (ROOT / 'tests' / 'test_game.a26').read_bytes()
passed = failed = 0
def check(n, c, x=''):
    global passed, failed
    if c: passed += 1; print('  ok   ', n)
    else: failed += 1; print('  FEHLER', n, x)
def call(path, data=None, method=None):
    req = urllib.request.Request('http://127.0.0.1:%d%s' % (API, path), data=data, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as r: return r.status, r.read()
    except urllib.error.HTTPError as e: return e.code, e.read()
def main():
    tmp = tempfile.mkdtemp()
    env = dict(os.environ, MOVIESCOUT_DATA=tmp, MINIKODI_DATA=tmp, MINIKODI_PROVIDERS=str(ROOT / 'tests' / 'fake_providers'), MINIKODI_ALLOW_PRIVATE='1', MOVIESCOUT_FREE='0', NO_PROXY='127.0.0.1,localhost')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN'): env.pop(k, None)
    srv = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--port', str(API)], env=env, cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try: socket.create_connection(('127.0.0.1', API), timeout=.3).close(); break
        except OSError: time.sleep(.25)
    errs = []
    try:
        s, b = call('/api/retro'); d = json.loads(b)
        check('Liste leer am Anfang', s == 200 and d['systems'][0]['id'] == 'atari2600' and d['systems'][0]['games'] == [], d)
        s, b = call('/api/retro/upload?system=atari2600&name=Test_Game_(USA).a26', ROM, 'POST')
        check('Hochladen', s == 200 and json.loads(b)['name'] == 'Test Game', b)
        s, b = call('/api/retro/upload?system=atari2600&name=virus.exe', b'MZ', 'POST')
        check('Falscher Dateityp wird abgelehnt', s == 400, s)
        s, b = call('/api/retro'); g = json.loads(b)['systems'][0]['games']
        check('Spiel erscheint mit schönem Namen', len(g) == 1 and g[0]['name'] == 'Test Game' and g[0]['own'], g)
        s, b = call('/api/retro/rom/atari2600/' + g[0]['id'])
        check('ROM wird ausgeliefert', s == 200 and b == ROM)
        s, b = call('/api/retro/rom/atari2600/..%2F..%2Fetc%2Fpasswd')
        check('Kein Zugriff außerhalb des Ordners', s == 404, s)
        with sync_playwright() as p:
            br = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
            pg = br.new_page(viewport={'width': 960, 'height': 600})
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto('http://127.0.0.1:%d/ui/retro/play.html?rom=%s' % (API, '/api/retro/rom/atari2600/' + g[0]['id']))
            pg.wait_for_function('window.Javatari && Javatari.room && Javatari.room.consoleControls', timeout=20000)
            pg.wait_for_timeout(3500)
            def shot():
                pg.evaluate("document.getElementById('javatari-screen').style.transform='none'")   # skaliertes Bild liefert im Headless-Screenshot schwankende Pixel
                h = hashlib.md5(pg.locator('#javatari-screen canvas').first.screenshot()).hexdigest()
                pg.evaluate("document.getElementById('javatari-screen').style.transform=''; window.dispatchEvent(new Event('resize'))")
                return h
            check('Emulator-Bild (Canvas) ist da', pg.locator('#javatari-screen canvas').count() >= 1)
            pg.keyboard.down('Enter'); pg.wait_for_timeout(900); a = shot(); pg.keyboard.up('Enter'); pg.wait_for_timeout(500)
            b2 = shot(); pg.wait_for_timeout(900); b3 = shot()
            check('OK (Enter) wirkt als Feuerknopf: Bild ändert sich nur, solange gedrückt', a != b2 and b2 == b3, (a, b2, b3))
            pg.keyboard.press('ContextMenu'); pg.wait_for_timeout(300)
            check('Menü-Taste öffnet das Spielmenü', pg.evaluate("__retro.isOpen()") is True)
            pg.keyboard.press('ArrowDown'); pg.wait_for_timeout(100); pg.keyboard.press('Enter'); pg.wait_for_timeout(500)
            check('Menü: Pfeile + OK wählen (Reset), danach geschlossen', pg.evaluate("__retro.isOpen()") is False)
            pg.evaluate("window.__msgs = []; addEventListener('message', e => __msgs.push(e.data))")
            pg.evaluate("window.parent.postMessage = (m) => { window.__closed = m; }")
            pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
            check('Zurück meldet „beenden“ an die Oberfläche', pg.evaluate("window.__closed && window.__closed.retro") == 'close')
            br.close()
        s, b = call('/api/retro/delete?system=atari2600&name=' + g[0]['id'], b'', 'POST')
        check('Löschen', s == 200 and json.loads(call('/api/retro')[1])['systems'][0]['games'] == [])
    finally:
        srv.terminate()
    check('keine Skriptfehler', not errs, errs)
    print('\n%d ok, %d Fehler' % (passed, failed)); sys.exit(1 if failed else 0)
main()
