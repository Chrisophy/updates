# -*- coding: utf-8 -*-
"""Test der Untertitel, Bilder-Speicher und Live-Knopf (Engine und Oberfläche) mit echter Engine und Browser.

    python tests/media_test.py
"""
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from datetime import date
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
PORT = 8902
BASE = 'http://127.0.0.1:%d' % PORT
passed = failed = 0


def check(name, cond, extra=''):
    global passed, failed
    if cond:
        passed += 1
        print('  ok   ', name)
    else:
        failed += 1
        print('  FEHLER', name, extra)


def http(path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'),
                  headers={'Content-Type': 'application/json'} if data is not None else {})
    try:
        with urlopen(req, timeout=30) as r:
            txt, code = r.read(), r.status
    except HTTPError as e:
        txt, code = e.read(), e.code
    try:
        return code, json.loads(txt)
    except Exception:                                      # noqa: BLE001
        return code, txt.decode('utf-8', 'replace')


def wait(cond, secs=8, step=0.1):
    end = time.time() + secs
    while time.time() < end:
        try:
            if cond():
                return True
        except Exception:                                  # noqa: BLE001
            pass
        time.sleep(step)
    return False


def setv(ext, **values):
    return http('/api/admin/ext/settings', {'ext': ext, 'values': values})[0]


def code_of(gid):
    from engine import examples as EXM
    return next(e for e in EXM.EXAMPLES if e['id'] == gid)['code']


SRT = "1\n00:00:00,000 --> 00:00:30,000\nHallo Welt\n\n2\n00:00:31,500 --> 00:00:33,250\n<i>Zweite</i> Zeile\n"
VTT = "WEBVTT\n\n00:00.000 --> 00:30.000\nEnglish line\n"
ASS = "[Script Info]\nTitle: x\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:00.00,0:00:30.00,Default,,0,0,0,,{\\an8}Aus ASS\\Nzweite Zeile, mit Komma\n"
JPG = b''
HITS = {}


def make_webm(path):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=160x90:rate=10:duration=20', '-c:v', 'libvpx', '-b:v', '100k', str(path)], check=True)


def serve(port, webm):
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            HITS[self.path] = HITS.get(self.path, 0) + 1
            routes = {'/de.srt': (SRT.encode('cp1252'), 'application/x-subrip'), '/en.vtt': (VTT.encode(), 'text/vtt'), '/p.jpg': (JPG, 'image/jpeg'),
                      '/notimg': (b'<html>hi</html>', 'text/html'), '/g.ass': (ASS.encode(), 'text/plain'), '/müll.srt': (b'kein untertitel', 'text/plain')}
            if self.path == '/t.webm':
                data, ct = webm.read_bytes(), 'video/webm'
            elif self.path in routes:
                data, ct = routes[self.path]
            else:
                self.send_response(404); self.end_headers(); return
            self.send_response(200); self.send_header('Content-Type', ct); self.send_header('Content-Length', str(len(data))); self.send_header('Access-Control-Allow-Origin', '*'); self.end_headers(); self.wfile.write(data)

        def log_message(self, *a):
            pass
    s = HTTPServer(('127.0.0.1', port), H)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    return s


def main():
    from engine import subs as S
    print('Untertitel-Umwandlung')
    v = S.to_vtt(SRT.encode('cp1252'))
    check('SRT -> WebVTT: Kopfzeile, Punkt statt Komma, Tags der Zeitleiste ok', v.startswith('WEBVTT') and '00:00:31.500 --> 00:00:33.250' in v and 'Hallo Welt' in v, v)
    check('VTT bleibt VTT', S.to_vtt(VTT).startswith('WEBVTT') and 'English line' in S.to_vtt(VTT))
    a = S.to_vtt(ASS)
    check('ASS: Zeiten, Zeilenumbruch \\N, Komma im Text, {\\an8} entfernt', '00:00:00.000 --> 00:00:30.000' in a and 'Aus ASS\nzweite Zeile, mit Komma' in a and '{' not in a, a)
    check('UTF-8 mit BOM, UTF-16 und Windows-1252 (Umlaute) werden gelesen', 'Grüße' in S.to_vtt('\ufeff1\n00:00:01,000 --> 00:00:02,000\nGrüße\n'.encode('utf-8')) and 'Grüße' in S.to_vtt('1\n00:00:01,000 --> 00:00:02,000\nGrüße\n'.encode('utf-16')) and 'Grüße' in S.to_vtt('1\n00:00:01,000 --> 00:00:02,000\nGrüße\n'.encode('cp1252')))
    try:
        S.to_vtt(b'nur ein bisschen Text'); ok = False
    except ValueError:
        ok = True
    check('Müll wird abgelehnt', ok)
    ns = S.norm_subtitles(['https://a.test/film.de.srt', {'url': '//b.test/x.vtt', 'lang': 'EN', 'label': 'English'}, 'ftp://x', 'C:\\lokal.srt', 'https://a.test/film.de.srt', ''])
    check('Liste: nur http(s), doppelte weg, Sprache aus Dateiname erkannt', [(x['url'], x['lang']) for x in ns] == [('https://a.test/film.de.srt', 'de'), ('https://b.test/x.vtt', 'en')], ns)
    from engine import normalize as N
    hh = N.norm_hoster({'name': 'X', 'url': 'https://v.test/a.mp4', 'subtitles': ['https://s.test/a.en.srt']})
    check('Hoster mit Untertiteln behält sie; ohne Untertitel kein Extra-Feld', hh['subtitles'][0]['lang'] == 'en' and 'subtitles' not in N.norm_hoster({'name': 'X', 'url': 'https://v.test/a.mp4'}))
    class LI:
        properties = {}
        subtitles = ['https://s.test/film.de.vtt']
        def getLabel(self): return 'Kodi'
    hr = N.hoster_from_resolved('https://v.test/a.mp4', LI(), 'v.test', 'V')
    check('Kodi: ListItem.setSubtitles kommt im Hoster an', hr and hr['subtitles'][0]['lang'] == 'de', hr)

    from engine import imgcache as IC
    tmp = Path(tempfile.mkdtemp(prefix='ms_media_'))
    IC.DIR = tmp / 'unit'
    for i in range(6):
        (IC.DIR / ('%02x' % i)).mkdir(parents=True, exist_ok=True)
        f = IC.DIR / ('%02x' % i) / ('f%d' % i)
        f.write_bytes(b'x' * 1024 * 1024)
        os.utime(str(f), (1000 + i, 1000 + i))
    check('Speicher-Aufräumen: Mindestgröße 20 MB, darunter nichts gelöscht', IC.prune(20) == 0 and IC.stats()['files'] == 6)
    IC.prune(1)   # 1 MB wird auf 20 MB angehoben -> nichts
    check('Statistik und Leeren', IC.stats()['files'] == 6 and IC.clear() == 6 and IC.stats()['files'] == 0)

    webm = tmp / 't.webm'
    make_webm(webm)
    global JPG
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=64x96:rate=1:duration=1', '-frames:v', '1', str(tmp / 'p.jpg')], check=True)
    JPG = (tmp / 'p.jpg').read_bytes()
    fport = 8903
    fake = serve(fport, webm)
    UP = 'http://127.0.0.1:%d' % fport
    env = dict(os.environ, MINIKODI_DATA=str(tmp / 'd'), MOVIESCOUT_DATA=str(tmp / 'd'), MINIKODI_ALLOW_PRIVATE='1', PYTHONUNBUFFERED='1')
    for k in ('MINIKODI_TOKEN', 'MOVIESCOUT_TOKEN', 'MOVIESCOUT_LAN_GATE', 'MOVIESCOUT_LAUNCHER'):
        env.pop(k, None)
    p = subprocess.Popen([sys.executable, str(ROOT / 'main.py'), '--local', '--port', str(PORT)], env=env, cwd=str(ROOT),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        assert wait(lambda: socket.create_connection(('127.0.0.1', PORT), timeout=0.3).close() or True, 30), 'Engine startet nicht'
        time.sleep(1)
        print('Engine: Untertitel-Route')
        from urllib.parse import quote
        def raw(path, data=None, method=None):
            req = Request(BASE + path, data=data, method=method or ('POST' if data is not None else 'GET'))
            try:
                with urlopen(req, timeout=20) as r:
                    return r.status, r.headers.get('Content-Type', ''), r.read()
            except HTTPError as e:
                return e.code, e.headers.get('Content-Type', ''), e.read()
        c, ct, b = raw('/api/subtitle?u=' + quote(UP + '/de.srt'))
        check('GET holt und wandelt um (text/vtt, Umlaute korrekt)', c == 200 and ct.startswith('text/vtt') and b.startswith(b'WEBVTT') and b'Hallo Welt' in b, (c, ct, b[:60]))
        c, ct, b = raw('/api/subtitle', ASS.encode(), 'POST')
        check('POST wandelt eine lokale Datei um', c == 200 and b'Aus ASS' in b, (c, b[:60]))
        check('Müll -> 422, 404 beim Anbieter -> Fehler, fehlende Adresse -> 400', raw('/api/subtitle?u=' + quote(UP + '/m%C3%BCll.srt'))[0] == 422 and raw('/api/subtitle?u=' + quote(UP + '/gibtsnicht'))[0] in (422, 502) and raw('/api/subtitle')[0] == 400)
        c, ct, b = raw('/api/subtitle', b'x' * (3 * 1024 * 1024 + 5), 'POST')
        check('Zu große Datei wird abgelehnt (413)', c == 413, c)

        print('Engine: Bilder-Speicher')
        c, ct, b = raw('/api/img?u=' + quote(UP + '/p.jpg'))
        check('Erster Abruf holt das Bild (Typ image/jpeg)', c == 200 and ct == 'image/jpeg' and b == JPG and HITS.get('/p.jpg') == 1, (c, ct, HITS))
        c, ct, b = raw('/api/img?u=' + quote(UP + '/p.jpg'))
        check('Zweiter Abruf kommt aus dem Speicher (Anbieter nur 1x gefragt)', c == 200 and b == JPG and HITS.get('/p.jpg') == 1, HITS)
        st = http('/api/imgcache')[1]
        check('Statistik zeigt 1 Bild', st.get('files') == 1, st)
        check('Kein Bild (HTML) -> 502 und wird nicht gespeichert', raw('/api/img?u=' + quote(UP + '/notimg'))[0] == 502 and http('/api/imgcache')[1]['files'] == 1)
        check('Keine Adresse / kein http -> 400', raw('/api/img')[0] == 400 and raw('/api/img?u=' + quote('file:///etc/passwd'))[0] == 400)
        check('Leeren löscht', http('/api/imgcache', {})[1]['cleared'] == 1 and http('/api/imgcache')[1]['files'] == 0)

        print('Engine: Abspielplan mit Untertiteln')
        hos = {'id': 0, 'name': 'W', 'url': UP + '/t.webm', 'format': 'webm', 'direct': True, 'headers': {}, 'drm': None,
               'subtitles': [{'url': UP + '/de.srt', 'lang': 'de', 'label': 'Deutsch'}, {'url': UP + '/en.vtt', 'lang': 'en', 'label': 'English'}]}
        code, plan = http('/api/play', {'hoster': hos})
        check('Plan enthält Untertitel-Pfade', code == 200 and [x['lang'] for x in plan['subtitles']] == ['de', 'en'] and plan['subtitles'][0]['path'].startswith('/api/subtitle?u='), plan)
        check('Plan ohne Untertitel hat kein Feld', 'subtitles' not in http('/api/play', {'hoster': dict(hos, subtitles=None)})[1])

        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            br = pw.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
            ctx = br.new_context(viewport={'width': 1000, 'height': 700})
            pg = ctx.new_page()
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            pg.goto(BASE + '/ui/?api=' + BASE)
            pg.wait_for_function('typeof startPlayer === "function"', timeout=20000)
            print('Oberfläche: Untertitel')
            pg.evaluate("([h]) => startPlayer({ item: { title: 'Testfilm' }, hosters: [h], index: 0 }, 0)", [hos])
            pg.wait_for_selector('video', timeout=15000)
            pg.click('#ccBtn')
            pg.wait_for_selector('.panel button:has-text("Deutsch")')
            check('Menü zeigt Aus, beide Sprachen und „Datei laden“', pg.locator('.panel button:has-text("Aus")').count() == 1 and pg.locator('.panel button:has-text("English")').count() == 1 and pg.locator('.panel button:has-text("Datei vom Gerät")').count() == 1)
            pg.click('.panel button:has-text("Deutsch")')
            pg.wait_for_selector('.subs span', timeout=8000)
            check('Deutscher Untertitel erscheint über dem Bild', 'Hallo Welt' in pg.inner_text('.subs'), pg.inner_text('.subs'))
            check('Sprache wird gemerkt', pg.evaluate("store.get('sublang','')") == 'de')
            pg.click('#ccBtn'); pg.wait_for_selector('.panel button:has-text("English")')
            pg.click('.panel button:has-text("Später")')
            pg.click('.panel button:has-text("Größe")')
            check('Größe wechselt (Variable gesetzt)', pg.evaluate("document.querySelector('.subs').style.getPropertyValue('--subsz')") in ('1.3', '1.7', '0.8'))
            pg.click('.panel button:has-text("Schließen")')
            pg.click('#ccBtn'); pg.wait_for_selector('.panel button:has-text("English")')
            pg.click('.panel button:has-text("English")')
            pg.wait_for_function("document.querySelector('.subs') && document.querySelector('.subs').innerText.includes('English line')", timeout=8000)
            check('Zweite Sprache wählbar (VTT)', True)
            pg.click('#ccBtn'); pg.wait_for_selector('.panel button:has-text("Aus")')
            pg.click('.panel button:has-text("Aus")')
            pg.wait_for_function("document.querySelector('.subs').children.length === 0", timeout=4000)
            check('„Aus“ blendet aus', pg.evaluate("store.get('sublang','')") == '-')
            pg.click('#ccBtn'); pg.wait_for_selector('.panel button:has-text("Datei vom Gerät")')
            with pg.expect_file_chooser() as fc:
                pg.click('.panel button:has-text("Datei vom Gerät")')
            ass = tmp / 'film.ass'; ass.write_text(ASS, 'utf-8')
            fc.value.set_files(str(ass))
            pg.wait_for_function("document.querySelector('.subs').innerText.includes('Aus ASS')", timeout=8000)
            check('Eigene Datei (ASS) wird geladen und angezeigt', True)
            check('Live-Knopf ist bei normalem Film verborgen', pg.evaluate("document.querySelector('#liveBtn').hidden") is True)
            pg.evaluate("history.back()"); pg.wait_for_timeout(600)
            pg.evaluate("store.set('sublang','de')")
            pg.evaluate("([h]) => startPlayer({ item: { title: 'Nochmal' }, hosters: [h], index: 0 }, 0)", [hos])
            pg.wait_for_function("document.querySelector('.subs') && document.querySelector('.subs').innerText.includes('Hallo Welt')", timeout=10000)
            check('Beim nächsten Film wird die gemerkte Sprache automatisch geladen', True)
            pg.evaluate("history.back()"); pg.wait_for_timeout(600)
            pg.evaluate("([h]) => startPlayer({ item: { title: 'Live' }, hosters: [Object.assign({}, h, { live: true, subtitles: [] })], index: 0 }, 0)", [hos])
            pg.wait_for_selector('video', timeout=10000)
            pg.wait_for_function("!document.querySelector('#liveBtn').hidden", timeout=8000)
            check('Live-Sender: „● Live“-Knopf erscheint', True)
            check('Keine Skriptfehler (Untertitel)', not errs, errs)
            ctx.close()

            print('Oberfläche: Bilder-Speicher')
            HITS.pop('/p.jpg', None)
            http('/api/imgcache', {})
            for n in range(2):
                c2 = br.new_context(viewport={'width': 800, 'height': 600})       # frischer Browser-Zwischenspeicher: nur die Engine kann helfen
                p2 = c2.new_page()
                p2.goto(BASE + '/ui/?api=' + BASE)
                p2.wait_for_function('typeof card === "function"', timeout=20000)
                p2.evaluate("(u) => { const c = card({ title: 'T', poster: u, kind: 'play' }, () => {}); c.id = 'tc'; document.body.append(c); }", UP + '/p.jpg')
                p2.wait_for_timeout(1500)
                check('Poster läuft über /api/img (Durchgang %d)' % (n + 1), '/api/img?u=' in p2.evaluate("document.querySelector('#tc img').src"), p2.evaluate("document.querySelector('#tc img').src + ' ' + cfg.api + ' ' + cfg.imgcache"))
                c2.close()
            check('Anbieter wurde über beide Browser-Sitzungen nur 1x gefragt', HITS.get('/p.jpg') == 1, HITS)
            c3 = br.new_context(viewport={'width': 800, 'height': 600})
            p3 = c3.new_page()
            p3.route('**/api/img**', lambda r: r.abort())
            p3.goto(BASE + '/ui/?api=' + BASE)
            p3.wait_for_function('typeof card === "function"', timeout=20000)
            p3.evaluate("(u) => { const c = card({ title: 'T', poster: u, kind: 'play' }, () => {}); c.id = 'tc'; document.body.append(c); }", UP + '/p.jpg')
            p3.wait_for_function("(() => { const i = document.querySelector('#tc img'); return i && i.src.startsWith('http://127.0.0.1:%d/p.jpg') })()" % fport, timeout=8000)
            check('Fällt der Bilder-Speicher aus, gilt die Original-Adresse (Rückfall)', True)
            p3.evaluate("cfg.imgcache = false")
            check('Schalter aus: Adresse bleibt unverändert', p3.evaluate("imgSrc('https://x.test/a.jpg')") == 'https://x.test/a.jpg')
            c3.close()
            br.close()
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:                                  # noqa: BLE001
            p.kill()
        fake.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d bestanden, %d fehlgeschlagen' % (passed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
