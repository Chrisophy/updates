#!/bin/sh
# Erzeugt einmalig einen eigenen Signaturschlüssel für MovieScout und zeigt die Werte für die GitHub-Secrets.
# Den Schlüssel gut aufheben: Nur damit signierte Updates lassen sich über die installierte App einspielen.
set -e
KS="${1:-moviescout.jks}"
ALIAS="${2:-moviescout}"
if [ -f "$KS" ]; then echo "$KS gibt es schon."; exit 1; fi
printf 'Passwort für den Schlüssel (mind. 6 Zeichen): '
stty -echo 2>/dev/null || true; read -r PW; stty echo 2>/dev/null || true; echo
keytool -genkeypair -v -keystore "$KS" -alias "$ALIAS" -keyalg RSA -keysize 4096 -validity 10000 \
  -storepass "$PW" -keypass "$PW" -dname "CN=MovieScout, O=IT's Possible"
echo
echo "GitHub → Repository → Settings → Secrets and variables → Actions → New repository secret:"
echo "  MS_KEYSTORE_BASE64   = (Inhalt von $KS.b64, wird jetzt erzeugt)"
echo "  MS_KEYSTORE_PASSWORD = dein Passwort"
echo "  MS_KEY_ALIAS         = $ALIAS"
echo "  MS_KEY_PASSWORD      = dein Passwort"
base64 < "$KS" | tr -d '\n' > "$KS.b64"
echo "Fertig: $KS (aufheben!) und $KS.b64 (für das Secret)."
