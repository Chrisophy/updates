package de.itspossible.moviescout;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Hintergrunddienst von MovieScout.
 *
 * Die eingebaute Engine läuft im Prozess der App. Android beendet einen Prozess im Hintergrund gern, dann
 * stoppen Downloads, das Chat-Gerät und die Erinnerungen. Ein Vordergrunddienst (mit der Dauer-Meldung
 * "MovieScout läuft") hält den Prozess am Leben. Außerdem fragt der Dienst die Engine nach neuen Meldungen und zeigt
 * daraus Android-Benachrichtigungen: Familienchat, Erinnerungen/Erweiterungen und fertige Downloads.
 *
 * - Lokal: GET /api/notify?since=…&wait=20 (Long-Poll) an die eingebaute Engine.
 * - Chat auf einem anderen Gerät (Adresse + Schlüssel): GET /api/chat?since=… alle paar Sekunden.
 * - Solange die Oberfläche sichtbar ist, gibt es keine Benachrichtigungen (man sieht ja alles direkt).
 */
public class NotifyService extends Service {

    static final String TAG = "MovieScoutService";
    static final String ACTION_STOP = "de.itspossible.moviescout.STOP";
    static final String EXTRA_OPEN = "ms_open";

    static final String CH_SERVICE = "ms_service";
    static final String CH_CHAT = "ms_chat";
    static final String CH_EXT = "ms_ext";
    static final String CH_DL = "ms_dl";

    static final String PREFS = "ms_prefs";
    static final String P_BACKGROUND = "background";      // Hintergrunddienst an (Standard: ja)
    static final String P_NOTIFY = "notify";              // Benachrichtigungen an (Standard: ja)
    static final String P_ASKED = "asked_notif";          // Erlaubnis (Android 13+) schon einmal erfragt
    static final String P_ME = "me";                      // eigener Chat-Name: eigene Nachrichten melden nichts
    static final String P_CHAT_ADDR = "chat_addr";        // Chat-Gerät eines anderen ("192.168.178.23:18765") oder leer
    static final String P_CHAT_KEY = "chat_key";

    private static final int ID_SERVICE = 4101;
    private static final AtomicInteger NEXT_ID = new AtomicInteger(5000);

    /** true, solange der Dienst läuft (Oberfläche zeigt den Zustand an). */
    static volatile boolean running;

    private volatile boolean alive;
    private Thread localThread;
    private Thread remoteThread;

    // ------------------------------------------------------------------ Starten / Stoppen von außen

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void start(Context c) {
        try {
            Intent i = new Intent(c, NotifyService.class);
            if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(i);
            } else {
                c.startService(i);
            }
        } catch (Throwable t) {
            // z. B. Start aus dem Hintergrund nicht erlaubt: dann läuft die App eben ohne Dienst weiter
            Log.w(TAG, "Dienst nicht startbar: " + t);
        }
    }

    static void stop(Context c) {
        try {
            c.stopService(new Intent(c, NotifyService.class));
        } catch (Throwable t) {
            Log.w(TAG, "Dienst nicht stoppbar: " + t);
        }
    }

    // ------------------------------------------------------------------ Lebenszyklus

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            // "Beenden" in der Dauer-Meldung: Dienst stoppen und die Oberfläche schließen
            // (beim nächsten Start der App läuft der Dienst wieder, solange er in den Einstellungen an ist)
            MainActivity.finishFromService();
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            createChannels();
            startForeground(ID_SERVICE, serviceNotification());
        } catch (Throwable t) {
            Log.w(TAG, "Vordergrunddienst nicht startbar: " + t);
            stopSelf();
            return START_NOT_STICKY;
        }
        running = true;
        if (!alive) {
            alive = true;
            localThread = new Thread(this::pollLocal, "moviescout-notify-local");
            remoteThread = new Thread(this::pollRemoteChat, "moviescout-notify-chat");
            localThread.setDaemon(true);
            remoteThread.setDaemon(true);
            localThread.start();
            remoteThread.start();
        }
        // Wird der Prozess beendet, startet Android den Dienst nicht von selbst neu: Ohne die Engine (die
        // MainActivity startet) hätte er nichts zu tun.
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        alive = false;
        running = false;
        if (localThread != null) {
            localThread.interrupt();
        }
        if (remoteThread != null) {
            remoteThread.interrupt();
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ Meldungen / Kanäle

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) {
            return;
        }
        NotificationChannel s = new NotificationChannel(CH_SERVICE, "Hintergrunddienst", NotificationManager.IMPORTANCE_LOW);
        s.setDescription("Dauer-Meldung, solange MovieScout im Hintergrund weiterläuft");
        s.setShowBadge(false);
        nm.createNotificationChannel(s);
        NotificationChannel c = new NotificationChannel(CH_CHAT, "Familienchat", NotificationManager.IMPORTANCE_HIGH);
        c.setDescription("Neue Nachrichten im Familienchat");
        nm.createNotificationChannel(c);
        NotificationChannel e = new NotificationChannel(CH_EXT, "Erinnerungen", NotificationManager.IMPORTANCE_HIGH);
        e.setDescription("Meldungen von Erweiterungen, z. B. „Heute Abend im TV“ oder neue Folgen");
        nm.createNotificationChannel(e);
        NotificationChannel d = new NotificationChannel(CH_DL, "Downloads", NotificationManager.IMPORTANCE_DEFAULT);
        d.setDescription("Fertige und fehlgeschlagene Downloads");
        nm.createNotificationChannel(d);
    }

    private PendingIntent openApp(String target, int requestCode) {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (target != null) {
            i.putExtra(EXTRA_OPEN, target);
        }
        return PendingIntent.getActivity(this, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @SuppressWarnings("deprecation")
    private Notification serviceNotification() {
        Intent stop = new Intent(this, NotifyService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = builder(CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("MovieScout läuft")
                .setContentText("Downloads, Chat und Erinnerungen bleiben aktiv")
                .setContentIntent(openApp(null, 2))
                .setOngoing(true)
                .setShowWhen(false)
                .addAction(0, "Beenden", stopPi);
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_LOW);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    /** Zeigt eine Benachrichtigung, wenn sie erwünscht ist (an, erlaubt und die Oberfläche gerade nicht sichtbar). */
    private void notifyUser(String kind, String title, String text) {
        SharedPreferences p = prefs(this);
        if (!p.getBoolean(P_NOTIFY, true) || MainActivity.visible) {
            return;
        }
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || !nm.areNotificationsEnabled()) {
                return;
            }
            String channel = "download".equals(kind) ? CH_DL : "ext".equals(kind) ? CH_EXT : CH_CHAT;
            String target = "download".equals(kind) ? "downloads" : "chat";
            int id = NEXT_ID.getAndIncrement();
            if (id > 5999) {
                NEXT_ID.set(5000);
            }
            Notification.Builder b = builder(channel)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title == null || title.isEmpty() ? "MovieScout" : title)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(openApp(target, id))
                    .setAutoCancel(true)
                    .setCategory(Notification.CATEGORY_MESSAGE);
            if (Build.VERSION.SDK_INT < 26) {
                b.setPriority("download".equals(kind) ? Notification.PRIORITY_DEFAULT : Notification.PRIORITY_HIGH);
            }
            nm.notify(id, b.build());
        } catch (Throwable t) {
            Log.w(TAG, "Benachrichtigung fehlgeschlagen: " + t);
        }
    }

    // ------------------------------------------------------------------ Abfrage der eingebauten Engine

    private static String httpGet(String url, int connectMs, int readMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(connectMs);
            c.setReadTimeout(readMs);
            if (c.getResponseCode() != 200) {
                throw new java.io.IOException("HTTP " + c.getResponseCode());
            }
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
                return out.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }

    private static void pause(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
            // Dienst wird beendet: die Schleifen prüfen "alive"
        }
    }

    private static boolean same(String a, String b) {
        return a != null && b != null && a.trim().equalsIgnoreCase(b.trim());
    }

    /** Meldungen der eigenen Engine: fertige Downloads, Erinnerungen, und Chat, wenn dieses Gerät das Chat-Gerät ist. */
    private void pollLocal() {
        long since = -1;                                   // -1 = noch nicht abgefragt: alte Meldungen überspringen
        while (alive) {
            try {
                String url = MainActivity.ENGINE_URL + "/api/notify?since=" + Math.max(since, 0) + "&wait=" + (since < 0 ? 0 : 20);
                JSONObject o = new JSONObject(httpGet(url, 1500, 35000));
                long last = o.optLong("last", 0);
                JSONArray ev = o.optJSONArray("events");
                if (since >= 0 && ev != null) {
                    SharedPreferences p = prefs(this);
                    boolean remoteChat = !p.getString(P_CHAT_ADDR, "").isEmpty();
                    for (int i = 0; i < ev.length(); i++) {
                        JSONObject e = ev.getJSONObject(i);
                        String kind = e.optString("kind");
                        if ("chat".equals(kind) && (remoteChat || same(e.optString("title"), p.getString(P_ME, "")))) {
                            continue;                      // Chat liegt woanders bzw. die eigene Nachricht
                        }
                        notifyUser(kind, e.optString("title"), e.optString("text"));
                    }
                }
                since = last;
                if (since == 0) {
                    pause(500);                            // noch nichts passiert: nicht im Kreis drehen
                }
            } catch (Throwable t) {
                if (!alive) {
                    return;
                }
                pause(3000);                               // Engine startet noch oder wird neu gestartet
            }
        }
    }

    /** Familienchat auf dem Chat-Gerät eines anderen: dort gibt es kein Long-Poll, also alle paar Sekunden nachsehen. */
    private void pollRemoteChat() {
        String watching = "";
        long lastId = -1;
        while (alive) {
            long wait = 8000;
            try {
                SharedPreferences p = prefs(this);
                String addr = p.getString(P_CHAT_ADDR, "");
                String key = p.getString(P_CHAT_KEY, "");
                if (addr.isEmpty() || key.isEmpty()) {
                    watching = "";
                    lastId = -1;
                    wait = 4000;
                } else {
                    if (!(addr + "|" + key).equals(watching)) {
                        watching = addr + "|" + key;
                        lastId = -1;                       // anderes Chat-Gerät: ab jetzt neu zählen
                    }
                    String url = "http://" + addr + "/api/chat?since=" + Math.max(lastId, 0) + "&key=" + URLEncoder.encode(key, "UTF-8");
                    JSONObject o = new JSONObject(httpGet(url, 2500, 6000));
                    JSONArray msgs = o.optJSONArray("messages");
                    long max = Math.max(lastId, 0);
                    if (msgs != null) {
                        for (int i = 0; i < msgs.length(); i++) {
                            JSONObject m = msgs.getJSONObject(i);
                            long id = m.optLong("id", 0);
                            max = Math.max(max, id);
                            if (lastId < 0 || id <= lastId) {
                                continue;                  // erste Abfrage: nur merken, nicht melden
                            }
                            if (same(m.optString("author"), p.getString(P_ME, ""))) {
                                continue;
                            }
                            String text = m.optString("text", "");
                            if (text.isEmpty()) {
                                JSONObject item = m.optJSONObject("item");
                                JSONObject file = m.optJSONObject("file");
                                text = item != null ? item.optString("title", "")
                                        : file != null ? "📎 " + file.optString("name", "Datei") : "";
                            }
                            notifyUser("chat", m.optString("author", "Jemand"), text);
                        }
                    }
                    lastId = max;
                }
            } catch (Throwable t) {
                wait = 15000;                              // Chat-Gerät aus oder nicht erreichbar
            }
            if (!alive) {
                return;
            }
            pause(wait);
        }
    }
}
