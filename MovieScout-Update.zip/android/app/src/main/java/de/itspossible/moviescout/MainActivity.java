package de.itspossible.moviescout;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.MediaDrm;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.chaquo.python.Python;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.json.JSONObject;

/**
 * MovieScout (by IT('s) Possible) – Android-Hülle für die MovieScout-Oberfläche.
 *
 * - Vollbild: Status- und Navigationsleiste sind verdeckt (wischen blendet sie kurz ein).
 * - Zurück: geht in der Oberfläche zurück; auf der Startseite fragt die App, ob sie beendet werden soll.
 * - Die Oberfläche kommt aus den App-Assets unter https://appassets.androidplatform.net/ – das ist eine
 *   sichere Herkunft, darum funktioniert DRM (Widevine). Die Engine läuft im Heimnetz (z. B. am PC) und
 *   wird über http erreicht; dafür ist "gemischter Inhalt" erlaubt.
 */
public class MainActivity extends Activity {

    static final String TAG = "MovieScout";
    static final String HOST = "appassets.androidplatform.net";
    /** Port der eingebauten Engine (bewusst ungewöhnlich, damit er nicht mit anderen Apps kollidiert). */
    static final int ENGINE_PORT = 18765;
    static final String ENGINE_URL = "http://127.0.0.1:" + ENGINE_PORT;
    /** Die Oberfläche bekommt die Adresse der eingebauten Engine als ?api=… mit. */
    static final String START_URL = "https://" + HOST + "/index.html?api=" + Uri.encode(ENGINE_URL);
    static final int BG = Color.rgb(0x0e, 0x18, 0x24);

    private FrameLayout root;
    private WebView web;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private AlertDialog exitDialog;
    /** Offene Dateiauswahl der Oberfläche (<input type=file>) – wird in onActivityResult beantwortet. */
    private ValueCallback<Uri[]> fileCallback;
    static final int REQ_FILE = 4711;
    /** Nach dem Laden der Oberfläche den Verlauf leeren, damit "Zurück" nicht auf der Start-Meldung landet. */
    private boolean clearHistoryNext;
    /** Status je laufender "In Filme speichern"-Anfrage (saveDownload/downloadMoveStatus), siehe unten. */
    private final Map<String, String> downloadMoveState = new ConcurrentHashMap<>();
    /** Nativer Player für DRM-Videos (PlayerActivity) – Ergebnis kommt in onActivityResult. */
    static final int REQ_PLAYER = 4712;
    static final UUID WIDEVINE = new UUID(0xEDEF8BA979D64ACEL, 0xA3C827DCD51D21EDL);
    private static String widevineLevel;
    private boolean playerOpen;

    /** true, solange die Oberfläche im Vordergrund ist: dann gibt es keine Benachrichtigungen (siehe NotifyService). */
    static volatile boolean visible;
    private static WeakReference<MainActivity> instance = new WeakReference<>(null);
    static final int REQ_NOTIF = 4713;
    /** Sprachbefehl über die Spracheingabe des Systems (RecognizerIntent) – Ergebnis kommt in onActivityResult. */
    static final int REQ_VOICE = 4714;
    /** Rechte zum Lesen von Medien/Dateien (eigener Dateibrowser, Mediaplayer). */
    static final int REQ_STORAGE = 4715;
    /** Von außen Übergebenes (Teilen, Link, Tipp auf eine Benachrichtigung) wartet hier, bis die Oberfläche es abholt. */
    private String pendingIntent = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        instance = new WeakReference<>(this);
        createWebView();
        hideSystemBars();
        showMessage("MovieScout startet \u2026",
                "Die Engine wird eingerichtet. Beim ersten Start kann das einen Moment dauern.");
        startEngine();
        handleIntent(getIntent());
        startBackgroundService();
        askNotificationPermission();
    }

    // ------------------------------------------------------------------ Hintergrunddienst, Benachrichtigungen, Teilen

    private SharedPreferences prefs() {
        return NotifyService.prefs(this);
    }

    /** Hält die eingebaute Engine mit einem Vordergrunddienst am Leben (Downloads, Chat, Erinnerungen). */
    private void startBackgroundService() {
        if (prefs().getBoolean(NotifyService.P_BACKGROUND, true)) {
            NotifyService.start(this);
        }
    }

    /** Android 13+: Benachrichtigungen brauchen eine Erlaubnis. Wird nur einmal von selbst erfragt. */
    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33 || !prefs().getBoolean(NotifyService.P_NOTIFY, true)) {
            return;
        }
        if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
                || prefs().getBoolean(NotifyService.P_ASKED, false)) {
            return;
        }
        prefs().edit().putBoolean(NotifyService.P_ASKED, true).apply();
        requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
    }

    /** "Beenden" in der Dauer-Meldung. */
    static void finishFromService() {
        final MainActivity a = instance.get();
        if (a != null) {
            a.runOnUiThread(a::finishAndRemoveTask);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /**
     * Merkt sich, was von außen kommt, und sagt es der Oberfläche:
     * - Teilen (Browser, andere Apps): {"kind":"share","text":…,"title":…}
     * - Link/Datei öffnen (Video, m3u8, moviescout://play?url=…&title=…, moviescout://search?q=…): {"kind":"view"|"play"|"search",…}
     * - Tipp auf eine Benachrichtigung: {"kind":"open","target":"chat"|"downloads"}
     */
    private void handleIntent(Intent i) {
        if (i == null) {
            return;
        }
        JSONObject o = null;
        try {
            String action = i.getAction();
            String open = i.getStringExtra(NotifyService.EXTRA_OPEN);
            if (open != null && !open.isEmpty()) {
                o = new JSONObject().put("kind", "open").put("target", open);
            } else if (Intent.ACTION_SEND.equals(action)) {
                String text = i.getStringExtra(Intent.EXTRA_TEXT);
                if (text != null && !text.trim().isEmpty()) {
                    String title = i.getStringExtra(Intent.EXTRA_SUBJECT);
                    if (title == null) {
                        title = i.getStringExtra(Intent.EXTRA_TITLE);
                    }
                    o = new JSONObject().put("kind", "share").put("text", clip(text, 2000)).put("title", clip(title == null ? "" : title, 200));
                }
            } else if (Intent.ACTION_VIEW.equals(action) && i.getData() != null) {
                Uri d = i.getData();
                if ("moviescout".equalsIgnoreCase(d.getScheme())) {
                    String host = d.getHost() == null ? "" : d.getHost().toLowerCase();
                    if ("search".equals(host)) {
                        String q = d.getQueryParameter("q");
                        if (q != null && !q.trim().isEmpty()) {
                            o = new JSONObject().put("kind", "search").put("q", clip(q, 200));
                        }
                    } else if ("play".equals(host)) {
                        String u = d.getQueryParameter("url");
                        if (u != null && u.matches("(?i)^https?://.+")) {
                            String t = d.getQueryParameter("title");
                            o = new JSONObject().put("kind", "play").put("url", clip(u, 4000)).put("title", clip(t == null ? "" : t, 200));
                        }
                    } else if ("chat".equals(host) || "downloads".equals(host)) {
                        o = new JSONObject().put("kind", "open").put("target", host);
                    }
                } else if ("http".equalsIgnoreCase(d.getScheme()) || "https".equalsIgnoreCase(d.getScheme())) {
                    o = new JSONObject().put("kind", "view").put("url", clip(d.toString(), 4000)).put("title", "");
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Intent nicht lesbar: " + e);
        }
        // Einmal verarbeitet: bei einem Neuaufbau der Activity nicht erneut auswerten
        setIntent(new Intent(Intent.ACTION_MAIN));
        if (o == null) {
            return;
        }
        synchronized (this) {
            pendingIntent = o.toString();
        }
        if (web != null && onUiPage()) {
            web.evaluateJavascript("window.msIntent && window.msIntent()", null);
        }
    }

    private static String clip(String t, int max) {
        t = t == null ? "" : t.trim();
        return t.length() > max ? t.substring(0, max) : t;
    }

    // ------------------------------------------------------------------ Eingebaute Engine (Python)

    /** Kopiert die Engine aus den Assets, startet sie in Python und lädt danach die Oberfläche. */
    private void startEngine() {
        new Thread(() -> {
            String problem = null;
            try {
                File appDir = prepareEngineFiles();
                File dataDir = new File(getFilesDir(), "userData");
                Python py = Python.getInstance();
                py.getModule("ms_boot").callAttr("start",
                        appDir.getAbsolutePath(), dataDir.getAbsolutePath(), ENGINE_PORT);
                long end = SystemClock.uptimeMillis() + 180000L;
                while (true) {
                    if (engineReady()) {
                        break;
                    }
                    String e = py.getModule("ms_boot").callAttr("error").toString();
                    if (e != null && !e.isEmpty()) {
                        problem = e;
                        break;
                    }
                    if (SystemClock.uptimeMillis() > end) {
                        problem = "Die Engine hat nach 3 Minuten nicht geantwortet.";
                        break;
                    }
                    Thread.sleep(300);
                }
            } catch (Throwable t) {
                Log.e(TAG, "Engine-Start fehlgeschlagen", t);
                problem = Log.getStackTraceString(t);
            }
            final String p = problem;
            runOnUiThread(() -> {
                if (web == null) {
                    return;
                }
                if (p == null) {
                    clearHistoryNext = true;
                    web.loadUrl(START_URL);
                } else {
                    showMessage("Die Engine konnte nicht starten", p);
                }
            });
        }, "moviescout-engine-start").start();
    }

    /** Fragt die Engine selbst, ob sie antwortet (nicht nur, ob der Port offen ist). */
    private static boolean engineReady() {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(ENGINE_URL + "/api/info").openConnection();
            c.setConnectTimeout(500);
            c.setReadTimeout(1500);
            if (c.getResponseCode() != 200) {
                return false;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[512];
            int n = c.getInputStream().read(buf);
            if (n > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8").contains("MovieScout");
        } catch (IOException e) {
            return false;
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
    }

    /** Legt die Engine-Dateien (aus assets/msapp) ins Dateisystem; nur bei neuer App-Version neu. */
    private File prepareEngineFiles() throws Exception {
        File dest = new File(getFilesDir(), "msapp");
        File marker = new File(dest, ".stamp");
        PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
        String stamp = versionName() + "/" + pi.lastUpdateTime;
        if (marker.exists() && stamp.equals(readText(marker))) {
            return dest;
        }
        deleteRecursive(dest);
        copyAssetDir("msapp", dest);
        try (OutputStream o = new FileOutputStream(marker)) {
            o.write(stamp.getBytes(StandardCharsets.UTF_8));
        }
        return dest;
    }

    private void copyAssetDir(String assetPath, File target) throws IOException {
        String[] names = getAssets().list(assetPath);
        if (names != null && names.length > 0) {
            if (!target.exists() && !target.mkdirs()) {
                throw new IOException("Ordner nicht anlegbar: " + target);
            }
            for (String n : names) {
                copyAssetDir(assetPath + "/" + n, new File(target, n));
            }
            return;
        }
        File parent = target.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new IOException("Ordner nicht anlegbar: " + parent);
        }
        try (InputStream in = getAssets().open(assetPath); OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
        }
    }

    private static String readText(File f) {
        try (InputStream in = new java.io.FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[512];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) {
            return;
        }
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                deleteRecursive(k);
            }
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private static String esc(String t) {
        return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /** Einfache Meldung (Start-Hinweis oder Fehlertext) statt der Oberfläche. */
    private void showMessage(String title, String text) {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='margin:0;padding:24px;background:#0e1824;color:#e8eef5;font-family:sans-serif'>"
                + "<h2 style='margin:0 0 12px'>" + esc(title) + "</h2>"
                + "<pre style='white-space:pre-wrap;font-size:13px;opacity:.85'>" + esc(text) + "</pre></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    // ------------------------------------------------------------------ WebView

    private void createWebView() {
        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);   // Engine im Heimnetz läuft über http
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);    // nötig, damit die per Dateiauswahl gewählten Dateien gelesen werden können
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " MovieScoutApp/" + versionName());

        web.addJavascriptInterface(new Bridge(), "MovieScoutApp");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.requestFocus();
    }

    /** Ein eingespieltes System-Update (Einstellungen → System) bringt eine neuere Oberfläche mit: userData/update/current/static.
     *  Die Engine nimmt das Update nur, wenn es neuer als die App ist und startet (sonst löscht/verschiebt sie es) -
     *  hier genügt also die Frage, ob die Datei dort liegt. Nicht Vorhandenes kommt weiter aus den App-Assets. */
    private File overlayFile(String name) {
        try {
            File root = new File(getFilesDir(), "userData/update/current/static");
            File f = new File(root, name);
            if (f.isFile() && f.getCanonicalPath().startsWith(root.getCanonicalPath() + File.separator)) {
                return f;
            }
        } catch (IOException ignored) {
            // dann eben aus den Assets
        }
        return null;
    }

    /** Liefert Dateien der Oberfläche aus dem Update-Ordner oder den Assets (index.html, vendor/...). */
    private WebResourceResponse asset(Uri uri) {
        String path = uri.getPath();
        if (path == null || path.isEmpty() || "/".equals(path)) {
            path = "/index.html";
        }
        String name = path.substring(1);
        if (name.contains("..")) {
            return notFound();
        }
        try {
            File over = overlayFile(name);
            InputStream in = over != null ? new FileInputStream(over) : getAssets().open(name);
            String mime = mimeOf(name);
            WebResourceResponse r = new WebResourceResponse(mime, mime.startsWith("text/")
                    || mime.endsWith("javascript") || mime.endsWith("json") ? "utf-8" : null, in);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-cache");
            h.put("Access-Control-Allow-Origin", "*");
            r.setResponseHeaders(h);
            return r;
        } catch (IOException e) {
            return notFound();
        }
    }

    private static WebResourceResponse notFound() {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h,
                new ByteArrayInputStream("Nicht in der App enthalten".getBytes(StandardCharsets.UTF_8)));
    }

    private static String mimeOf(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        if (n.endsWith(".js") || n.endsWith(".mjs")) return "application/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".woff2")) return "font/woff2";
        if (n.endsWith(".woff")) return "font/woff";
        if (n.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    private class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (u != null && "https".equals(u.getScheme()) && HOST.equals(u.getHost())) {
                return asset(u);
            }
            return null;   // alles andere (Engine, Streams, CDN) normal laden
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (!request.isForMainFrame() || u == null || HOST.equals(u.getHost())) {
                return false;
            }
            // Fremde Seiten nicht in der App öffnen, sondern im Browser des Geräts
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (ActivityNotFoundException e) {
                Log.w(TAG, "Kein Browser für " + u);
            }
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (clearHistoryNext && url != null && url.startsWith("https://" + HOST)) {
                clearHistoryNext = false;
                view.clearHistory();     // Start-Meldung aus dem Verlauf entfernen
            }
            hideSystemBars();
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // Absturz des Web-Prozesses: WebView neu aufbauen statt die App zu beenden
            Log.w(TAG, "WebView-Prozess beendet, lade neu");
            if (web != null) {
                root.removeView(web);
                web.destroy();
                web = null;
            }
            createWebView();
            clearHistoryNext = true;
            web.loadUrl(START_URL);
            return true;
        }
    }

    private class Chrome extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                Uri origin = request.getOrigin();
                boolean own = origin != null && HOST.equals(origin.getHost());
                List<String> grant = new ArrayList<>();
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) {
                        grant.add(r);     // DRM (Widevine) für die eigene Oberfläche erlauben
                    }
                }
                if (own && !grant.isEmpty()) {
                    request.grant(grant.toArray(new String[0]));
                } else {
                    request.deny();
                }
            });
        }

        /** Dateiauswahl für "Datei hinzufügen", "Sicherung wählen", Skin-/Bild-Import (ohne das tut die WebView nichts).
         *  Reihenfolge: ACTION_GET_CONTENT, dann ACTION_OPEN_DOCUMENT (manche TV-Boxen haben nur eines von beiden).
         *  Gibt es keines, meldet die App das der Oberfläche (window.msNoPicker): sie öffnet dann ihren eigenen Dateibrowser. */
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(null);
            }
            fileCallback = callback;
            boolean imagesOnly = false;
            String[] acc = params.getAcceptTypes();
            if (acc != null && acc.length > 0) {
                imagesOnly = true;
                for (String a : acc) {
                    if (a == null || !a.startsWith("image/")) {
                        imagesOnly = false;
                        break;
                    }
                }
            }
            final String type = imagesOnly ? "image/*" : "*/*";
            final boolean multiple = params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
            final String[] actions = {Intent.ACTION_GET_CONTENT, Intent.ACTION_OPEN_DOCUMENT};
            for (String action : actions) {
                try {
                    Intent i = new Intent(action);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(type);
                    if (multiple) {
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    startActivityForResult(i, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    Log.w(TAG, "Dateiauswahl " + action + " nicht verfügbar", e);
                }
            }
            fileCallback = null;
            callback.onReceiveValue(null);
            Toast.makeText(MainActivity.this,
                    "Dieses Gerät hat keine Dateiauswahl. MovieScout öffnet seinen eigenen Dateibrowser.",
                    Toast.LENGTH_LONG).show();
            if (web != null) {
                web.evaluateJavascript("window.msNoPicker && window.msNoPicker()", null);
            }
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customCallback = callback;
            view.setBackgroundColor(Color.BLACK);
            root.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            web.setVisibility(View.GONE);
            hideSystemBars();
        }

        @Override
        public void onHideCustomView() {
            leaveCustomView();
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            // statt des grauen Platzhalters ein leeres Bild
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            Log.d(TAG, m.message() + " (" + m.sourceId() + ":" + m.lineNumber() + ")");
            return true;
        }
    }

    private void leaveCustomView() {
        if (customView == null) {
            return;
        }
        root.removeView(customView);
        customView = null;
        if (customCallback != null) {
            customCallback.onCustomViewHidden();
            customCallback = null;
        }
        web.setVisibility(View.VISIBLE);
        web.requestFocus();
        hideSystemBars();
    }

    /** Für die Oberfläche: window.MovieScoutApp.* (läuft im Hintergrund-Thread der WebView). */
    private class Bridge {
        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(() -> {
                if (on) {
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } else {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            });
        }

        @JavascriptInterface
        public String version() {
            return versionName();
        }

        /** Öffnet eine Adresse im Browser des Geräts (z. B. der Scraper-Baukasten der Engine). */
        @JavascriptInterface
        public boolean openExternal(final String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
                return false;
            }
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Kein Browser gefunden", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        }

        /** Sprachbefehl: öffnet die Spracheingabe des Geräts; das Ergebnis geht an window.msVoice(text), bei Fehler an window.msVoiceFail(). */
        @JavascriptInterface
        public void startVoice() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE");
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprachbefehl");
                    i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    startActivityForResult(i, REQ_VOICE);
                } catch (Exception e) {
                    Log.w(TAG, "Keine Spracheingabe auf diesem Gerät: " + e);
                    if (web != null) {
                        web.evaluateJavascript("window.msVoiceFail && window.msVoiceFail()", null);
                    }
                }
            });
        }

        /** Startet die App komplett neu (nach einem System-Update): Python-Engine und Oberfläche laden dann den neuen Stand. */
        @JavascriptInterface
        public void restartApp() {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage(getPackageName());
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    finishAffinity();
                    System.exit(0);
                }, 350);
            });
        }

        @JavascriptInterface
        public void confirmExit() {
            runOnUiThread(MainActivity.this::askExit);
        }

        /** Holt (und löscht) das, was von außen übergeben wurde: Teilen, Link, Tipp auf eine Benachrichtigung. "" = nichts. */
        @JavascriptInterface
        public String takeIntent() {
            synchronized (MainActivity.this) {
                String r = pendingIntent;
                pendingIntent = "";
                return r;
            }
        }

        /** Läuft die Engine als Vordergrunddienst weiter, wenn die App im Hintergrund ist? (Standard: ja) */
        @JavascriptInterface
        public boolean backgroundEnabled() {
            return prefs().getBoolean(NotifyService.P_BACKGROUND, true);
        }

        @JavascriptInterface
        public void setBackground(final boolean on) {
            prefs().edit().putBoolean(NotifyService.P_BACKGROUND, on).apply();
            runOnUiThread(() -> {
                if (on) {
                    NotifyService.start(MainActivity.this);
                } else {
                    NotifyService.stop(MainActivity.this);
                }
            });
        }

        /** Zeigt die App Benachrichtigungen (Chat, Erinnerungen, Downloads), wenn sie im Hintergrund ist? (Standard: ja) */
        @JavascriptInterface
        public boolean notificationsEnabled() {
            return prefs().getBoolean(NotifyService.P_NOTIFY, true);
        }

        @JavascriptInterface
        public void setNotifications(final boolean on) {
            prefs().edit().putBoolean(NotifyService.P_NOTIFY, on).apply();
            if (on) {
                runOnUiThread(() -> {
                    prefs().edit().putBoolean(NotifyService.P_ASKED, false).apply();
                    askNotificationPermission();
                });
            }
        }

        /** Hat Android Benachrichtigungen für die App erlaubt (Systemeinstellung)? */
        @JavascriptInterface
        public boolean notificationsAllowed() {
            android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return nm != null && nm.areNotificationsEnabled();
        }

        /** Dateizugriff für den eigenen Dateibrowser: "all" (alle Dateien), "media" (nur Musik/Videos/Bilder) oder "none". */
        @JavascriptInterface
        public String storageAccess() {
            try {
                if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) {
                    return "all";
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    boolean any = checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
                            || checkSelfPermission(android.Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
                            || checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
                    return any ? "media" : "none";
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    return checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ? "media" : "none";
                }
                return checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ? "all" : "none";
            } catch (Exception e) {
                return "none";
            }
        }

        /** Fragt den Dateizugriff an: zuerst "Zugriff auf alle Dateien" (Android-Einstellungen), sonst die normalen Medien-Rechte. */
        @JavascriptInterface
        public void requestStorageAccess() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
                        return;
                    } catch (Exception e) {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                            return;
                        } catch (Exception e2) {
                            Log.w(TAG, "Einstellung \"Zugriff auf alle Dateien\" nicht verfügbar", e2);
                        }
                    }
                }
                try {
                    if (Build.VERSION.SDK_INT >= 33) {
                        requestPermissions(new String[]{android.Manifest.permission.READ_MEDIA_VIDEO,
                                android.Manifest.permission.READ_MEDIA_AUDIO, android.Manifest.permission.READ_MEDIA_IMAGES}, REQ_STORAGE);
                    } else {
                        requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Bitte in den Android-Einstellungen unter Apps \u2192 MovieScout \u2192 Berechtigungen den Dateizugriff erlauben.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        /** Öffnet die Benachrichtigungs-Einstellungen der App in Android. */
        @JavascriptInterface
        public void openNotificationSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Bitte in den Android-Einstellungen unter Apps \u2192 MovieScout \u2192 Benachrichtigungen.",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        /** {"me":"Anzeigename im Chat","addr":"ip:port des Chat-Geräts oder leer","key":"Chat-Schlüssel"}: damit der Dienst Chat-Nachrichten melden kann. */
        @JavascriptInterface
        public void setNotifyPrefs(String json) {
            try {
                JSONObject o = new JSONObject(json);
                prefs().edit()
                        .putString(NotifyService.P_ME, clip(o.optString("me", ""), 40))
                        .putString(NotifyService.P_CHAT_ADDR, clip(o.optString("addr", ""), 100))
                        .putString(NotifyService.P_CHAT_KEY, clip(o.optString("key", ""), 40))
                        .apply();
            } catch (Exception e) {
                Log.w(TAG, "setNotifyPrefs: " + e);
            }
        }

        /** Speichert eine Datei (Sicherung, Skin …) im Download-Ordner. Gibt den Ort zurück, bei Fehler "". */
        @JavascriptInterface
        public String saveFile(String name, String mime, String base64) {
            try {
                return saveToDownloads(name, mime, Base64.decode(base64, Base64.DEFAULT));
            } catch (Throwable t) {
                Log.e(TAG, "Speichern fehlgeschlagen", t);
                return "";
            }
        }

        /**
         * Verschiebt einen von der Engine fertig heruntergeladenen Film/Serien-Episode (liegt bereits im
         * Dateisystem der App, siehe ms_boot.py/MOVIESCOUT_DATA) in den öffentlichen "Filme"-Ordner des
         * Geräts. Läuft im Hintergrund (eine Kopie kann groß/langsam sein) - die Methode selbst kehrt
         * sofort mit einer Anfrage-ID zurück, der Fortschritt wird über downloadMoveStatus() abgefragt.
         */
        @JavascriptInterface
        public String saveDownload(final String enginePath, final String title, final String mime) {
            final String reqId = UUID.randomUUID().toString();
            downloadMoveState.put(reqId, "{\"state\":\"running\"}");
            new Thread(() -> runSaveDownload(reqId, enginePath, title, mime)).start();
            return reqId;
        }

        /** Status einer per saveDownload() gestarteten Anfrage: {"state":"running|done|error", ...}. */
        @JavascriptInterface
        public String downloadMoveStatus(String reqId) {
            String s = downloadMoveState.get(reqId);
            return s != null ? s : "{\"state\":\"error\",\"message\":\"Unbekannte Anfrage\"}";
        }

        /** DRM-Videos spielt die App selbst ab (Geräte-Widevine statt WebView-Widevine, die nur L3 hat). */
        @JavascriptInterface
        public boolean nativeAvailable() {
            return true;
        }

        /** Widevine-Stufe des Geräts laut Android: "L1" (Hardware), "L3" (Software) oder "NONE". */
        @JavascriptInterface
        public String nativeWidevineLevel() {
            return deviceWidevineLevel();
        }

        /** {"url":…, "format":"dash|hls|mp4", "license":…, "title":…} – Ergebnis kommt über window.msNativeDone(…). */
        @JavascriptInterface
        public boolean playNative(final String json) {
            final JSONObject o;
            try {
                o = new JSONObject(json);
            } catch (Exception e) {
                return false;
            }
            runOnUiThread(() -> openPlayer(o));
            return true;
        }
    }

    // ------------------------------------------------------------------ Nativer DRM-Player

    static synchronized String deviceWidevineLevel() {
        if (widevineLevel != null) {
            return widevineLevel;
        }
        String level = "NONE";
        MediaDrm drm = null;
        try {
            if (MediaDrm.isCryptoSchemeSupported(WIDEVINE)) {
                drm = new MediaDrm(WIDEVINE);
                String v = drm.getPropertyString("securityLevel");
                if (v != null && !v.trim().isEmpty()) {
                    level = v.trim().toUpperCase();
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Widevine-Stufe nicht lesbar: " + e);
        } finally {
            if (drm != null) {
                closeDrm(drm);
            }
        }
        widevineLevel = level;
        return level;
    }

    @SuppressWarnings("deprecation")
    private static void closeDrm(MediaDrm drm) {
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                drm.close();
            } else {
                drm.release();
            }
        } catch (Exception ignored) {
            // nichts zu tun
        }
    }

    @SuppressWarnings("deprecation")
    private void openPlayer(JSONObject o) {
        if (playerOpen) {
            return;
        }
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra(PlayerActivity.EXTRA_URL, o.optString("url", ""));
        i.putExtra(PlayerActivity.EXTRA_FORMAT, o.optString("format", "dash"));
        i.putExtra(PlayerActivity.EXTRA_LICENSE, o.optString("license", ""));
        i.putExtra(PlayerActivity.EXTRA_TITLE, o.optString("title", ""));
        playerOpen = true;
        startActivityForResult(i, REQ_PLAYER);
    }

    private void nativePlayerDone(Intent data) {
        playerOpen = false;
        String error = data != null ? data.getStringExtra(PlayerActivity.EXTRA_ERROR) : null;
        JSONObject r = new JSONObject();
        try {
            r.put("ok", error == null);
            if (error != null) {
                r.put("error", error);
            }
        } catch (Exception ignored) {
            // JSONObject.put wirft hier nicht
        }
        if (web != null) {
            web.evaluateJavascript("window.msNativeDone && window.msNativeDone(" + r + ")", null);
        }
    }

    /**
     * Kopiert die fertige Datei der Engine (enginePath, ein absoluter Pfad im App-Dateisystem) in den
     * öffentlichen Filme-Ordner (Android 10+: MediaStore.Video, "Filme/MovieScout"; davor: klassischer
     * Datei-Zugriff + Medienscanner). Löscht die Quelldatei danach, damit sie nicht doppelt belegt bleibt.
     * Ohne Schreibrecht (API 24-28 ohne WRITE_EXTERNAL_STORAGE) endet dies mit einer klaren Fehlermeldung.
     */
    private void runSaveDownload(String reqId, String enginePath, String title, String mime) {
        File src = new File(enginePath == null ? "" : enginePath);
        try {
            if (!src.isFile()) {
                throw new IOException("Datei nicht gefunden: " + enginePath);
            }
            String type = (mime == null || mime.isEmpty()) ? "video/mp4" : mime;
            String safe = (title == null || title.trim().isEmpty() ? src.getName() : title)
                    .replaceAll("[\\\\/:*?\"<>|]+", "_").trim();
            if (safe.isEmpty()) {
                safe = "Film";
            }
            String ext = src.getName().contains(".") ? src.getName().substring(src.getName().lastIndexOf('.')) : ".mp4";
            if (!safe.toLowerCase().endsWith(ext.toLowerCase())) {
                safe = safe + ext;
            }
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Video.Media.DISPLAY_NAME, safe);
                v.put(MediaStore.Video.Media.MIME_TYPE, type);
                v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/MovieScout");
                v.put(MediaStore.Video.Media.IS_PENDING, 1);
                Uri item = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
                if (item == null) {
                    throw new IOException("Filme-Ordner nicht beschreibbar");
                }
                try (InputStream in = new java.io.FileInputStream(src);
                     OutputStream out = getContentResolver().openOutputStream(item)) {
                    if (out == null) {
                        throw new IOException("Datei nicht beschreibbar");
                    }
                    copyStream(in, out);
                }
                v.clear();
                v.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContentResolver().update(item, v, null, null);
            } else {
                if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    throw new IOException("Kein Schreibrecht für den Speicher - bitte in den App-Einstellungen"
                            + " unter Berechtigungen den Speicherzugriff erlauben.");
                }
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "MovieScout");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new IOException("Ordner nicht anlegbar: " + dir);
                }
                File dst = new File(dir, safe);
                try (InputStream in = new java.io.FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
                    copyStream(in, out);
                }
                android.media.MediaScannerConnection.scanFile(this, new String[]{dst.getAbsolutePath()}, null, null);
            }
            //noinspection ResultOfMethodCallIgnored
            src.delete();
            downloadMoveState.put(reqId, "{\"state\":\"done\"}");
        } catch (Throwable t) {
            Log.e(TAG, "In Filme speichern fehlgeschlagen", t);
            String msg = t.getMessage() == null ? t.toString() : t.getMessage();
            downloadMoveState.put(reqId, "{\"state\":\"error\",\"message\":" + JSONObject.quote(msg) + "}");
        }
    }

    private static void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) {
            out.write(buf, 0, n);
        }
    }

    // ------------------------------------------------------------------ Vollbild

    private void hideSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            legacyImmersive(w.getDecorView());
        }
    }

    @SuppressWarnings("deprecation")
    private static void legacyImmersive(View decor) {
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemBars();
        }
    }

    // ------------------------------------------------------------------ Zurück / Beenden

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            leaveCustomView();
        } else if (web != null && web.canGoBack() && onUiPage()) {
            web.goBack();
        } else {
            askExit();
        }
    }

    /** true, wenn gerade die MovieScout-Oberfläche (nicht eine Start-/Fehlermeldung) angezeigt wird. */
    private boolean onUiPage() {
        String u = web == null ? null : web.getUrl();
        return u != null && u.startsWith("https://" + HOST);
    }

    private void askExit() {
        if (isFinishing() || (exitDialog != null && exitDialog.isShowing())) {
            return;
        }
        exitDialog = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.exit_title)
                .setMessage(R.string.exit_message)
                .setPositiveButton(R.string.exit_ok, (d, which) -> {
                    NotifyService.stop(MainActivity.this);       // Beenden heißt auch: keine Dauer-Meldung mehr
                    finish();
                })
                .setNegativeButton(R.string.exit_cancel, null)
                .setOnDismissListener(d -> hideSystemBars())
                .create();
        exitDialog.show();
    }

    // ------------------------------------------------------------------ Dateien (Auswahl & Speichern)

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_PLAYER) {
            nativePlayerDone(data);
            return;
        }
        if (requestCode == REQ_VOICE) {
            String said = "";
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> res = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (res != null && !res.isEmpty() && res.get(0) != null) {
                    said = res.get(0);
                }
            }
            if (web != null) {
                web.evaluateJavascript("window.msVoice && window.msVoice(" + JSONObject.quote(said) + ")", null);
            }
            return;
        }
        if (requestCode == REQ_FILE) {
            ValueCallback<Uri[]> cb = fileCallback;
            fileCallback = null;
            if (cb != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null) {
                    result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
                cb.onReceiveValue(result);
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** Legt die Datei im öffentlichen Download-Ordner ab (Android 10+: MediaStore, davor: App-Ordner "Download"). */
    private String saveToDownloads(String name, String mime, byte[] data) throws IOException {
        String safe = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|]+", "_").trim();
        if (safe.isEmpty()) {
            safe = "moviescout.dat";
        }
        String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
            v.put(MediaStore.Downloads.MIME_TYPE, type);
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            v.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (item == null) {
                throw new IOException("Download-Ordner nicht beschreibbar");
            }
            try (OutputStream o = getContentResolver().openOutputStream(item)) {
                if (o == null) {
                    throw new IOException("Datei nicht beschreibbar");
                }
                o.write(data);
            }
            v.clear();
            v.put(MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(item, v, null, null);
            return "Downloads/" + safe;
        }
        File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) {
            dir = getFilesDir();
        }
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Ordner nicht anlegbar: " + dir);
        }
        File f = new File(dir, safe);
        try (OutputStream o = new FileOutputStream(f)) {
            o.write(data);
        }
        return f.getAbsolutePath();
    }

    // ------------------------------------------------------------------ Lebenszyklus

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        if (web != null) {
            web.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})", null);
            web.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        if (web != null) {
            web.onResume();
        }
        hideSystemBars();
        startBackgroundService();         // falls Android den Dienst inzwischen beendet hat (z. B. nach "Beenden" in der Meldung)
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) {
            web.saveState(out);
        }
    }

    @Override
    protected void onDestroy() {
        visible = false;
        if (instance.get() == this) {
            instance = new WeakReference<>(null);
        }
        if (exitDialog != null) {
            exitDialog.dismiss();
        }
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    private String versionName() {
        try {
            String v = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            return v != null ? v : "1";
        } catch (Exception e) {
            return "1";
        }
    }
}
