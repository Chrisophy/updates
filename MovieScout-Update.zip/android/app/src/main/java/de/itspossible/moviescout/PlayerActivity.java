package de.itspossible.moviescout;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.HttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

/**
 * Nativer Player für DRM-Videos (Widevine über das Android-System, wie Kodi mit inputstream.adaptive).
 *
 * Die eingebettete Browser-Ansicht (WebView) bekommt auf Android nur Software-Widevine (L3). Anbieter wie
 * Rakuten TV geben Lizenzen aber nur an Hardware-Widevine (L1). Dieser Player nutzt MediaDrm direkt und damit
 * die Stufe des Geräts. Stream und Lizenz laufen über den Proxy der Engine (Kopfzeilen, Protokoll "Lizenz-Server").
 *
 * Bildformat (Knopf oben rechts, auf der Fernbedienung auch Menü-, Info-, Rot- oder Zoom-Taste):
 * "Bild füllen (Zoom)" (Standard, keine Ränder; auf breiten Handys wird oben/unten etwas abgeschnitten),
 * "Ganzes Bild" (mit Rändern) und "Gestreckt". Die Wahl wird gespeichert.
 *
 * Extras: url, format (dash|hls|mp4), license (Lizenz-URL, leer = ohne DRM), title.
 * Ergebnis: RESULT_OK; bei Fehler zusätzlich Extra "error" mit der Ursache.
 */
@SuppressLint("UnsafeOptInUsageError")
public class PlayerActivity extends Activity {

    static final String EXTRA_URL = "url";
    static final String EXTRA_FORMAT = "format";
    static final String EXTRA_LICENSE = "license";
    static final String EXTRA_TITLE = "title";
    static final String EXTRA_ERROR = "error";

    private static final int[] RESIZE_MODES = {
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
    };
    private static final String[] RESIZE_LABELS = {"Bild füllen (Zoom)", "Ganzes Bild", "Gestreckt"};

    private ExoPlayer player;
    private PlayerView view;
    private TextView formatButton;
    private int resizeIndex;
    private boolean done;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        view = new PlayerView(this);
        view.setBackgroundColor(Color.BLACK);
        view.setKeepScreenOn(true);
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        root.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        formatButton = createFormatButton();
        root.addView(formatButton, formatButtonParams());
        setContentView(root);
        resizeIndex = prefs().getInt("resize", 0);
        if (resizeIndex < 0 || resizeIndex >= RESIZE_MODES.length) {
            resizeIndex = 0;
        }
        applyResizeMode();
        // Knopf erscheint und verschwindet zusammen mit der Player-Steuerung
        view.setControllerVisibilityListener(
                (PlayerView.ControllerVisibilityListener) visibility -> formatButton.setVisibility(visibility));
        // Fernbedienung: vom Play-Knopf nach oben auf "Bildformat" und wieder zurück
        View playPause = view.findViewById(androidx.media3.ui.R.id.exo_play_pause);
        if (playPause != null) {
            playPause.setNextFocusUpId(formatButton.getId());
            formatButton.setNextFocusDownId(playPause.getId());
        }
        hideSystemBars();

        Intent in = getIntent();
        String url = in.getStringExtra(EXTRA_URL);
        String format = in.getStringExtra(EXTRA_FORMAT);
        String license = in.getStringExtra(EXTRA_LICENSE);
        String title = in.getStringExtra(EXTRA_TITLE);
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            finishWith("Ungültige Adresse");
            return;
        }

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent("MovieScoutApp")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(20000)
                .setReadTimeoutMs(30000);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http))
                .build();
        view.setPlayer(player);

        MediaItem.Builder item = new MediaItem.Builder().setUri(url).setMimeType(mimeOf(format));
        if (license != null && !license.isEmpty()) {
            item.setDrmConfiguration(new MediaItem.DrmConfiguration.Builder(C.WIDEVINE_UUID)
                    .setLicenseUri(license)
                    .build());
        }
        if (title != null) {
            item.setMediaMetadata(new MediaMetadata.Builder().setTitle(title).build());
        }
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                finishWith(describe(error));
            }

            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_ENDED) {
                    finishWith(null);
                }
            }
        });
        player.setMediaItem(item.build());
        player.prepare();
        player.setPlayWhenReady(true);
        view.requestFocus();
    }

    // ------------------------------------------------------------------ Bildformat

    private SharedPreferences prefs() {
        return getSharedPreferences("player", MODE_PRIVATE);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView createFormatButton() {
        TextView b = new TextView(this);
        b.setId(View.generateViewId());
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        b.setFocusable(true);
        b.setClickable(true);
        b.setVisibility(View.GONE);
        GradientDrawable normal = new GradientDrawable();
        normal.setColor(0x99000000);
        normal.setCornerRadius(dp(22));
        GradientDrawable focused = new GradientDrawable();
        focused.setColor(0xCC000000);
        focused.setCornerRadius(dp(22));
        focused.setStroke(dp(3), 0xFF12B2E7);
        StateListDrawable bg = new StateListDrawable();
        bg.addState(new int[]{android.R.attr.state_focused}, focused);
        bg.addState(new int[]{android.R.attr.state_pressed}, focused);
        bg.addState(new int[]{}, normal);
        b.setBackground(bg);
        b.setOnClickListener(v -> nextResizeMode());
        return b;
    }

    private FrameLayout.LayoutParams formatButtonParams() {
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = dp(20);
        lp.rightMargin = dp(24);
        return lp;
    }

    private void applyResizeMode() {
        view.setResizeMode(RESIZE_MODES[resizeIndex]);
        formatButton.setText("Bildformat: " + RESIZE_LABELS[resizeIndex]);
    }

    private void nextResizeMode() {
        resizeIndex = (resizeIndex + 1) % RESIZE_MODES.length;
        prefs().edit().putInt("resize", resizeIndex).apply();
        applyResizeMode();
        Toast.makeText(this, "Bildformat: " + RESIZE_LABELS[resizeIndex], Toast.LENGTH_SHORT).show();
        view.showController();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int k = event.getKeyCode();
        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_INFO
                || k == KeyEvent.KEYCODE_PROG_RED || k == KeyEvent.KEYCODE_TV_ZOOM_MODE) {
            if (event.getAction() == KeyEvent.ACTION_UP) {
                nextResizeMode();
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private static String mimeOf(String format) {
        if ("hls".equals(format)) return MimeTypes.APPLICATION_M3U8;
        if ("mp4".equals(format)) return MimeTypes.VIDEO_MP4;
        return MimeTypes.APPLICATION_MPD;
    }

    /** Fehlertext für die Oberfläche, mit HTTP-Status, falls der Server (z. B. der Lizenzserver) abgelehnt hat. */
    private static String describe(PlaybackException e) {
        StringBuilder sb = new StringBuilder(e.getErrorCodeName());
        Throwable t = e.getCause();
        int depth = 0;
        while (t != null && depth++ < 6) {
            if (t instanceof HttpDataSource.InvalidResponseCodeException) {
                int code = ((HttpDataSource.InvalidResponseCodeException) t).responseCode;
                sb.append(" – HTTP ").append(code);
                if (code == 403) sb.append(" (Forbidden)");
                break;
            }
            t = t.getCause();
        }
        if (e.getMessage() != null) {
            sb.append(" – ").append(e.getMessage());
        }
        return sb.toString();
    }

    private void finishWith(String error) {
        if (done) return;
        done = true;
        Intent data = new Intent();
        if (error != null) {
            data.putExtra(EXTRA_ERROR, error);
        }
        setResult(RESULT_OK, data);
        finish();
    }

    private void hideSystemBars() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            legacyImmersive(w.getDecorView());
        }
    }

    @SuppressWarnings("deprecation")
    private static void legacyImmersive(View decor) {
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemBars();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        finishWith(null);      // zurück zur Oberfläche
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.pause();
        }
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
