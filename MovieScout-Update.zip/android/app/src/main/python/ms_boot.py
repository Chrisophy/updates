# -*- coding: utf-8 -*-
"""Startet die MovieScout-Engine (Starlette/Uvicorn) im Hintergrund der Android-App.

Wird von MainActivity.java über Chaquopy aufgerufen:
    ms_boot.start(app_dir, data_dir, port)   -> kehrt sofort zurück, die Engine läuft in einem Thread
    ms_boot.error()                          -> '' solange alles gut ist, sonst der Fehlertext
"""
import os
import sys
import threading
import traceback

_lock = threading.Lock()
_started = False
_error = ''


def error():
    return _error


def start(app_dir, data_dir, port):
    global _started
    with _lock:
        if _started:
            return
        _started = True
    os.makedirs(data_dir, exist_ok=True)
    os.environ['MOVIESCOUT_DATA'] = data_dir          # Einstellungen/Cache bleiben bei App-Updates erhalten
    threading.Thread(target=_run, args=(app_dir, int(port)), name='moviescout-engine', daemon=True).start()


def _run(app_dir, port):
    global _error
    try:
        if app_dir not in sys.path:
            sys.path.insert(0, app_dir)
        os.chdir(app_dir)
        os.environ['MOVIESCOUT_EMBEDDED'] = '1'      # läuft im App-Prozess: Neustart nur über die App (siehe /api/admin/restart)
        os.environ['MOVIESCOUT_LAN_GATE'] = '1'       # im WLAN erreichbar, aber nur die Fernbedienungs-Kopplung (siehe LanGate)
        import main                                   # main.py aus dem Projekt: erzeugt main.app
        import uvicorn
        # Lauscht im WLAN, damit sich ein Handy mit dem Fernseher koppeln kann. LanGate lässt von außen nur
        # /remote und /ws/remote durch; alles andere gehört nur diesem Gerät. Uvicorn läuft hier in einem
        # Nebenthread, daher keine Signal-Handler.
        uvicorn.run(main.app, host='0.0.0.0', port=port, log_level='info')
        _error = 'Die Engine wurde beendet.'
    except BaseException:                             # auch SystemExit (z. B. Port belegt)
        _error = traceback.format_exc()
