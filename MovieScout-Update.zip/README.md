# MovieScout – by IT('s) Possible

Kodi-Scraper ohne Kodi: eine Oberfläche für Browser und Android, dazu eine kleine Python-Engine.

> MovieScout hostet keine Filme, Serien oder Streams. Es bündelt nur Links zu Angeboten, die öffentlich im Internet
> erreichbar sind. Für deren Inhalte sind allein die jeweiligen Anbieter verantwortlich. Nutzung auf eigene
> Verantwortung, ohne Gewähr und ohne Haftung für Schäden aus der Nutzung.

## Funktionen

**Korrektur (2.26.3)**
- GitHub-Abgleich: Bei „fehlgeschlagen“ nennt die Meldung jetzt die betroffene Datei und den Grund

**Korrektur (2.26.2): GitHub-Sync**
- Liegt ein Scraper im Gadget-Ordner (oder eine Erweiterung im Scraper-Ordner), wird die Datei dort eingeordnet, wo sie hingehört – statt als Fehler „nicht übernommen“ im Protokoll zu stehen
- Hilfsdateien ohne Scraper-/Erweiterungsfunktionen (z. B. `mini_player.py`) werden übersprungen und zählen nicht mehr als Fehler. Echte Fehler (Syntaxfehler) werden weiter gemeldet. Test: `python tests/sync_kind_test.py`

**Korrektur (2.26.1): Captcha-Dienst**
- Einstellungen → Konten & Inhalte: Die Felder „Captcha-Dienst“ und „API-Schlüssel“ fehlten in der Oberfläche (die Engine las sie, aber es gab keine Stelle zum Eintragen). Jetzt da: CapSolver, 2Captcha, Anti-Captcha, CapMonster, 9kw.eu, DeathByCaptcha. Gilt nach „Speichern“ sofort. Test: `python tests/captcha_ui_test.py`

**Neu (2.26.0): Gadget „Gerät“**
- Zeigt die Hardware des Geräts: Modell, Chipset, Kerne, Takt, Arbeitsspeicher (gesamt/frei), Speicherplatz, Android-Version, Sicherheits-Patch, Bildschirm (Auflösung, HDR), Akku, Netz
- Prüft, welche Video- und Tonformate das Gerät abspielt (H.264, H.265, VP9, AV1, AAC, Dolby Digital, Opus) – mit Angabe 4K/Full-HD und Hardware/Software – sowie die Widevine-Stufe
- Kachel „Gerät“ auf der Startseite und im Bildschirmschoner; Seite „Mein Gerät“ unter Erweiterungen → Gerät; Knopf „Alles kopieren“ für Fehlermeldungen
- Wird mit dem Update automatisch angelegt, keine neue APK nötig

**Korrekturen (2.25.4)**
- Android-App: Kamera und Mikrofon (Haus: „Kamera senden“) waren im Manifest nicht deklariert – Android listete die Rechte nicht und fragte nie. Jetzt eingetragen; beim ersten Start der Kamera erscheint die Freigabe-Abfrage. **Dafür muss die APK neu gebaut und installiert werden** (das Update-ZIP ändert das Manifest nicht)
- Fehlermeldung der Kamera nennt den genauen Weg in die Android-Einstellungen

**Korrekturen (2.25.3)**
- Fehler im Code von Videoquellen-Addons (auch aus Bibliotheken wie `requests`) erscheinen mit Addon-Name, Datei, Zeile **und der Codezeile selbst**
- Mit echtem `requests` (z. B. in Pydroid) nennt ein JSON-Fehler HTTP-Status, Server und Anfang der Antwort – bisher nur bei der mitgelieferten Ersatz-Bibliothek

**Korrekturen (2.25.2)**
- `xbmcvfs.File` verhält sich wie in Kodi: Eine fehlende Datei zu öffnen ist kein Fehler (Lesen liefert leer, Größe 0), Schreiben legt fehlende Ordner an, Text und Bytes werden beim Schreiben angenommen (3sat/ARD-Mediathek-Bibliotheken lesen so ihre noch nicht vorhandene Token-Datei)
- Ungültige JSON-Antworten (`requests …json()`) nennen in der Fehlermeldung HTTP-Status, Server und Anfang der Antwort – damit sieht man, ob die Website gesperrt, leer oder anders geantwortet hat

**Korrekturen (2.25.1)**
- `getAddonInfo('profile')` endet wie in Kodi auf einen Schrägstrich – Addons, die Dateinamen direkt anhängen (`profile + 'token'`, z. B. 3sat Mediathek), schrieben vorher neben den Ordner statt hinein und stürzten ab
- Fehler im Code eines Videoquellen-Addons erscheinen mit Addon-Name, Datei und Zeile (statt nacktem Python-Text); bei leerer/ungültiger JSON-Antwort mit Hinweis, woran es meist liegt

**Skin-Fenster aus Kodi-Addons – WindowXML (2.25)**
- Addons, die `xbmcgui.WindowXML` / `WindowXMLDialog` mit einer Skin-Datei (`resources/skins/Default/720p|1080i/<Name>.xml`) öffnen, laufen jetzt: MovieScout liest die XML, löst `<include>`-Bausteine samt `<param>`, `$CONSTANT`, `$EXP` und `$VAR` auf, rechnet die Lage aus (Gruppen, Gruppenlisten, `%`, `r`-Maße, `<coordinates>`, 1080i→720p) und zeichnet das Fenster auf der gewohnten 1280×720-Bühne
- **Bedingungen & Texte:** `<visible>`, `<enable>`, `<selected>` mit `Control.HasFocus/IsVisible`, `Container(n).NumItems/HasFocus`, `Window.Property(x)`, `String.*`, `Integer.*`, `Skin.*`; Beschriftungen mit `$INFO[…]`, `$LOCALIZE[n]` (aus der Sprachdatei des Addons), `$ADDON[…]`; Änderungen von Fenster-Eigenschaften zeichnen sofort neu
- **Bedienung wie in Kodi:** Pfeile folgen `<onup/down/left/right>`, sonst dem nächsten Element in der Richtung; Listen blättern; OK/Antippen ruft zuerst die `<onclick>`-Befehle, dann `onClick(id)` und `onAction`; Standard-Fokus aus `<defaultcontrol>`; `<onload>`/`<onunload>`; `onInit`, `onFocus`; Zurück schließt (Standard von Kodi, wenn das Programm `onAction` nicht selbst behandelt)
- Listen zeigen Bild, Titel und zweite Zeile (`panel` als Raster); Dialoge (`WindowXMLDialog`) liegen halbdurchsichtig über der Oberfläche; `getCurrentWindowId/DialogId` liefern die Kennung des offenen Fensters
- Fehlt die Skin-Datei, steht der Dateiname im Klartext in der Meldung, und das Programm läuft weiter. Der Kompatibilitäts-Check warnt, wenn im Paket gar keine Skin-Dateien liegen, und nennt Elemente, die nicht gezeichnet werden
- **Grenze:** Animationen, Skin-eigene Listenlayouts (`itemlayout/focusedlayout`), Videofenster, Visualisierung und Skin-Texturen fehlen; Knöpfe ohne eigene Bilder erhalten die Standarddarstellung. Das Aussehen weicht vom Original ab, Funktion und Ablauf sollen stimmen

**Kodi-Repository durchsuchen & Kompatibilitäts-Check (2.24)**
- Quellen & System → „Kodi-Repository durchsuchen …“: Suche im offiziellen Kodi-Repository (Omega). Angezeigt wird nur, was MovieScout ausführen kann – Videoquellen, Audio, Programme & Spiele, Dienste, Bibliotheken – filterbar nach Art, mit Blättern. Installiert wird mit einem Klick samt fehlenden Bibliotheken; bei neuerer Version heißt der Knopf „Aktualisieren“
- **Weitere Repositories:** im Browser unter „Weitere Repositories (optional)“ eine Ordneradresse eintragen, in der die `addons.xml` liegt (Einstellung `kodi_repos`, eine pro Zeile). Treffer erscheinen zusammen mit dem offiziellen Repository; ist eines nicht erreichbar, wird das gemeldet und der Rest funktioniert weiter
- **Kompatibilitäts-Check:** Vor der Installation aus dem Browser wird das Paket geladen und aus seinem Code beurteilt (es wird nichts ausgeführt): „Läuft voraussichtlich“ / „… eingeschränkt“ / „… nicht“ mit Befunden in Klartext – fehlende Kodi-Funktionen, Skin-Fenster (WindowXML), Python-2-Code, fehlende Module, DRM, Desktop-Fenster, ignorierte Kodi-Befehle. Dasselbe passiert bei jeder ZIP-Installation; in der Quellenliste zeigt „Prüfung: …“ das Urteil und öffnet den frisch gelesenen Bericht
- API: `GET /api/admin/repo/search?q=&group=&page=`, `GET /api/admin/repo/check?id=`, `POST /api/admin/repo/install {id}`, `POST /api/admin/addon/scan` (ZIP prüfen ohne Installation), `GET /api/admin/addon/compat?id=`
- **Wie in Kodi:** Der Ordner der Startdatei ist importierbar (liegt `default.py` in `resources/lib/`, funktioniert `import utils` für Nachbardateien)
- Nachgerüstet, weil echte Addons sie aufrufen: `xbmc.playSFX/stopSFX/getGlobalIdleTime`, `xbmc.Player().isPlayingAudio/getMusicInfoTag`, `xbmcgui.Dialog().browseSingle/browseMultiple` (liefern „abgebrochen“), `xbmcvfs.makeLegalFilename/validatePath`, `xbmcgui.INPUT_TYPE_*`
- **Grenze:** Der Check ist eine Einschätzung aus dem Code, kein Probelauf. Bei sehr großen Addons wird nach einer Zeitgrenze nur ein Teil geprüft (steht im Bericht)

**Adress-Vorlagen für Update, Scraper und Erweiterungen (2.23.1)**
- Einstellungen → System: Update-Quelle ist mit `https://github.com/Chrisophy/updates/raw/main/MovieScout-Update.zip` vorbelegt – „Jetzt prüfen“ genügt
- Einstellungen → Quellen & Listen: „GitHub Repository Ordner (Scraper)“ mit `https://github.com/Chrisophy/scraper` und neu „GitHub Repository Ordner (Erweiterungen / Gadgets)“ mit `https://github.com/Chrisophy/gadgets` vorbelegt – „Jetzt laden“ tippen
- Jeder kann die Adressen ändern; eigene Adressen (auch ein geleertes Feld = aus) werden gespeichert und haben Vorrang. Der Knopf „Vorlage“ setzt die Vorgabe wieder ein. Unberührte Vorlagen werden nicht gespeichert – geladen wird erst nach eigenem Tippen, danach beim Start automatisch
- GitHub-Datei-Links werden verstanden: `…/raw/main/datei.zip`, `…/raw/refs/heads/main/datei.zip`, `…/blob/zweig/…` und `github.com/besitzer/repo/datei.zip` (ohne Zweig = Standardzweig) werden zur Download-Adresse
- Die Vorlagen stehen zentral in `engine/app.py` (`URL_TEMPLATES`)

**Kodi-Fenster: Spiele & Programme mit eigener Oberfläche (2.23)**
- Addons, die ihr Fenster selbst zusammenbauen (`xbmcgui.Window`/`WindowDialog` + `addControl`: Bilder, Beschriftungen, Knöpfe, Listen, Textfelder, Fortschrittsbalken, Schalter), werden jetzt **angezeigt und bedient** – z. B. Vier gewinnt oder Frogger
- Die Bühne hat Kodis Koordinaten (1280×720) und wird an Handy, Tablet und Fernseher angepasst; Kodi-Textauszeichnung ([B], [I], [COLOR …], [CR]) wird übernommen, Spielfelder aus Zeichen (■ ● ◯ ▼) stehen in Kodi-Breite sauber in Spalten
- Bedienung: Pfeiltasten/Steuerkreuz → `onAction`, OK auf dem markierten Knopf oder Antippen → `onControl`, Zurück → Aktion „Zurück“ ans Programm (zweimal Zurück oder ✕ schließt das Fenster in jedem Fall). Auf Touch-Geräten erscheint ein Steuerkreuz
- Rückfragen aus dem Spiel (Auswahl, Namenseingabe für Highscores) erscheinen über dem Fenster; Spiel-Schleifen in eigenen Threads aktualisieren die Anzeige laufend
- Solange ein Spiel offen ist, laufen andere Quellen und Addons normal weiter
- Fenster aus Skin-Dateien (`WindowXML`/`WindowXMLDialog`) kamen mit 2.25 dazu (siehe oben)

**Android-Speicher & Pydroid (2.22.3)**
- Liegt MovieScout im Android-Speicher (z. B. `/storage/emulated/0/Download/…` unter Pydroid), verbietet Android oft das Umbenennen von Ordnern („Operation not permitted“). Addon-Installation, System-Update/Zurücksetzen und das Nachladen von ResolveURL kopieren dann automatisch statt umzubenennen
- Fehlt das Python-Paket `websockets` (Pydroid), versucht die Oberfläche keine Live-Verbindung mehr im Sekundentakt (kein Log-Spam „Unsupported upgrade request“); der Chat kommt per Abfrage alle 15 s. Die Engine meldet das einmal beim Start, der Support-Bericht nennt es. Live-Chat und Handy-Fernbedienung: `pip install websockets`

**Kodi-Programme & Bibliotheken – script.* (2.22)**
- Neben Videoquellen (`plugin.*`) lassen sich jetzt auch **Programme** (`script.*`, `xbmc.python.script`), **Dienste** (`xbmc.service`) und **Bibliotheken** (`script.module.*`) per ZIP installieren (Quellen & System → „Kodi-Addon / Script (ZIP) installieren …“)
- **Fehlende Abhängigkeiten** (`<requires><import addon=…>`) lädt MovieScout automatisch aus dem offiziellen Kodi-Repository (Omega; Spiegel kodi.tv und mirrors.mit.edu) nach – auch verschachtelt, mit Obergrenze von 25 Paketen. Eigene Adresse: Umgebungsvariable `MOVIESCOUT_KODI_REPO` (kommagetrennt, mit `/` am Ende). Nicht geholt wird, was die Engine selbst mitbringt (`xbmc.*`, `inputstream.*`, ResolveURL, requests) oder als Python-Paket schon da ist (six, bs4, certifi …)
- Programme erscheinen als Quelle mit „Starten“-Eintrag; in der Verwaltung gibt es unter „Kodi-Programme, Dienste & Bibliotheken“ Starten, Einstellungen, Nachladen und Entfernen. API: `POST /api/admin/addon/run {id, args}`, `POST /api/admin/addon/deps {id, fetch}`
- **RunScript(script.x, arg …)** aus anderen Addons und aus Einstellungs-Knöpfen startet das Programm (`sys.argv` wie in Kodi); Dienste starten sofort nach der Installation und beim Start der Engine
- **Verständliche Fehler (2.22.1):** Fehlende Bibliotheken, Abstürze (mit Datei und Zeile) und Programme, die ein eigenes Kodi-Fenster öffnen wollen, werden im Klartext gemeldet statt als Python-Fehler oder gar nicht
- **Support-Bericht:** Diagnose → „Support-Bericht“ zeigt Version, Quellen, installierte Kodi-Addons (mit fehlenden Bibliotheken) und letzte Warnungen als Text zum Kopieren
- **DASH-Fehler bei MultiTrailer (2.22.2):** „DASH bevorzugen“ bleibt im MovieScout immer aus – auch beim normalen Abspielen aus der Quellenliste, nicht nur beim Trailer-Knopf. DASH-Quellen des Addons werden bei Trailern gar nicht erst angeboten
- **Grenzen:** Fenster aus Skin-Dateien erscheinen vereinfacht (siehe 2.25); Bibliotheken mit nativen Binärdateien nur, wenn das Python-Paket auf dem Gerät vorhanden ist. Skins, Repositories, Sprachpakete u. ä. werden abgelehnt

**Bessere Treffer in der Suche (2.21)**
- Die Suche wertet jeden Treffer gegen deinen Suchbegriff und zeigt **genaue Treffer sofort ganz oben** (auch wenn sie von einer langsameren Quelle erst später kommen), darunter **passende** (beginnt damit, enthält die Wortgruppe, enthält alle Wörter) und zuletzt **ähnliche** (Wortanfänge, kleine Tippfehler). Gruppen mit Überschrift und Anzahl; ein gesuchtes Jahr („Matrix 1999“) bevorzugt die passende Fassung
- Verglichen wird ohne Groß-/Kleinschreibung, Jahr, Klammern, Zusätze wie „HD“, „German“, „Stream“ und mit Umlaut-Schreibweisen (ö = oe)
- Gibt es keinen genauen oder fast genauen Treffer, sucht MovieScout automatisch **bis zu zweimal mit vereinfachten Begriffen** nach (ohne Jahr/Klammern/Satzzeichen, Haupttitel vor dem Untertitel, ohne Artikel, Umlaute umgeschrieben) und sagt, wonach zusätzlich gesucht wurde

**Nachrichten & Notizen (2.20)**
- 📰 **RSS-/Atom-Feeds** (Startseite → „Nachrichten & Notizen“ → „+ Feed hinzufügen“): Adresse des Feeds oder der Webseite eintragen, MovieScout findet den Feed selbst. Jeder Feed ist eine Kachel mit der neuesten Überschrift; ein Klick zeigt alle Meldungen, ein weiterer Klick den Text (Bild, Absätze, „Im Browser öffnen“)
- 📝 **Eigene Texte**: „+ Text anlegen“ (Überschrift und Text), als Kachel mit Vorschau auf der Startseite, lesen, bearbeiten, löschen
- „Verwalten“: Reihenfolge (▲▼), Umbenennen, Entfernen. Der Bereich lässt sich wie die anderen anordnen/ausblenden (Aussehen → Anordnung) und als Menüleisten-Ziel wählen; Feeds und Texte stecken in der Sicherung
- Die Engine liest die Feeds (`GET /api/feed?url=`): RSS 2.0, RSS 1.0 (RDF) und Atom; nur öffentliche Adressen, höchstens 2 MB, Feeds mit ENTITY-Angaben werden abgelehnt, Texte kommen ohne HTML; 10 Minuten Zwischenspeicher

**Trailer (2.19)**
- 🎞 **Trailer abspielen**: Knopf „Trailer“ im Info-Fenster jedes Titels, Trailer-Symbol (🎞) auf den Karten unter „Entdecken“, Taste **T** (oder Menü-Taste) auf einer fokussierten Karte. Der Trailer läuft im eingebauten Player
- Quellen werden der Reihe nach probiert: zuerst das Kodi-Addon **MultiTrailer** (plugin.video.multitrailer, direkter Stream ohne Werbung), danach die Trailer aus TMDB (YouTube/Vimeo als eingebettetes Video, deutsche zuerst). Ohne MultiTrailer reicht der TMDB-Schlüssel, ohne Schlüssel reicht MultiTrailer
- MultiTrailer installieren wie jedes Kodi-Addon (Einstellungen → Quellen verwalten → „Kodi-Addon (ZIP) installieren“). Bei jedem Trailer schaltet MovieScout dort „DASH bevorzugen“ aus (nur die Kopie in MovieScout, nicht dein Kodi): DASH-Manifeste sind für inputstream.adaptive gebaut, der Web-Player kann sie nicht lesen („DASH-Fehler … is not available“). Adressen, die der Player nicht öffnen kann (file://, Mini-Server fremder Dienste), werden gar nicht erst angeboten
- Läuft eine Trailer-Quelle nicht, wechselt der Player von selbst zur nächsten (auch bei ausgeschaltetem Autoplay), zuletzt zur YouTube-Einbettung
- Kopfzeile passt sich schmalen Displays an (320–412 px): die Seite lässt sich nicht mehr seitlich schieben (in 2.18 war sie auf Handys zu breit)
- Engine: `POST /api/trailer {item:{title,year,tmdb,kind}}` → `{hosters:[…]}` (Quellen mit `trailer:true`)

**Looks, Menüleiste und Funktionen aus dem Kodi-Addon (2.18)**
- 🎨 **Looks**: Netflix, Disney, Sky, Joyn, Arte, ARD und ZDF als fertige Oberflächen (Einstellungen → Aussehen → Skins). Angelehnt an Farben und Anordnung der Dienste, ohne Logos; alles danach frei änderbar
- 🔘 **Menüleiste mit eigenen Buttons** (Aussehen → Buttons): Symbol, Name und Aktion frei wählbar (Quelle öffnen, Suche, Bereich anspringen, Mediaplayer, Sammlung, Erweiterungs-Seite, Entdecken, Trakt, Adresse abspielen, Look wechseln, Webadresse …), verschiebbar, als Kapseln, Reiter oder Kacheln. Jeder Look bringt eigene Buttons mit; sie gehören zum Skin und stecken im Skin-Export
- 🎞️ **Entdecken** (Startseite): TMDB-Listen für Filme und Serien (Kino, beliebt, bestbewertet, Box Office, Genres, Jahre, Titelsuche). Klick auf einen Titel sucht ihn in allen Quellen. Braucht den TMDB-Schlüssel (Konten & Inhalte)
- ❤️ **Trakt**: Anmeldung per Gerätecode, Watchlist, Verlauf, Empfehlungen, Angesagt, Beliebt. Eigene Trakt-App nötig (Client-ID und Secret unter Konten & Inhalte); Token liegen in userData/trakt.json
- 🔗 **Adresse abspielen**: Video-Link oder Hoster-Seite einfügen und im eingebauten Player starten (die letzten Adressen merkt sich MovieScout)
- 🧩 **Kodi-Addon „MovieScout“ in MovieScout**: das Addon (plugin.video.moviescout) läuft jetzt als Quelle. Sein Kodi-Format `settings-kodi19/20.xml` wird erkannt (Einstellungen mit Formular und Standardwerten), und seine Einstellungen liegen getrennt von denen der Engine

**Mediaplayer, Sammlungen & Startseite (2.17)**
- 🎵🎬🖼️ **Mediaplayer** (Startseite → „Mediaplayer“): Ordner auf dem Gerät durchsuchen, mehrere Dateien oder ganze Ordner auswählen und in die Listen Musik / Videos / Bilder einsortieren. Einträge werden gespeichert, lassen sich verschieben (▲▼, auch in eine andere Liste ⇄) und löschen (✕); die Dateien selbst bleiben unberührt. Spulen, Lautstärke, Zufall, Wiederholen, Medientasten; die Mediathek steckt in der Sicherung
- 📁 **Sammlungen** (neue Art Favoriten): Überordner wählen (Quellen-Ordner oder Ordner auf dem Gerät), ihr Inhalt wird zusammengeführt und als eine Kachel unter Favoriten gezeigt. Verwalten über „Sammlungen verwalten“ oder ★ → „Zur Sammlung“
- 🧩 **Widgets & Dash je Erweiterung**: Aus / Widget / Dash / Widget und Dash, dazu Reihenfolge per ▲▼ oder Ziehen (Startseite → ⚙ Anpassen). Dash = Knopf im Schnellzugriff, Widget = Info-Kachel im Streifen oben
- Regler (Spulen, Lautstärke) und Lupe werden jetzt fokussiert; Pfeiltasten ändern den Regler, hoch/runter verlässt ihn
- Sicherung wiederherstellen ohne System-Dateiauswahl (z. B. Homatics R 4K Plus, Android 14): „Aus Ordner wählen …“ (eigener Dateibrowser, braucht „Dateizugriff erlauben“) oder „Vom Handy (Familienchat) …“

**Untertitel & Bilder**
- Untertitel (SRT, ASS, VTT) für direkt abgespielte Videos: vom Anbieter mitgelieferte Spuren oder eigene Datei vom Gerät, Verzögerung ±0,5 s, Größe, gemerkte Sprache
- Bilder-Speicher: Poster werden einmal geladen und in der Engine gespeichert (einstellbar, Standard 300 MB, Leeren in den Einstellungen)
- Tonauswahl: Sprache und Tonart (Dolby Digital / Plus / Atmos, Surround, Stereo) pro Video wählbar, Vorliebe wird gemerkt
- Skin: optionaler Glas-Effekt (Standard aus) mit Durchsichtigkeit und Unschärfe
- Sprachsteuerung (Mikrofon in der Kopfzeile und im Player): Suchen, Starten, Quellen/Seiten öffnen, Pause/Weiter/Stopp, Vor-/Zurückspulen, Lautstärke, Untertitel/Ton. Android-App: Spracheingabe des Systems (RecognizerIntent, keine Mikrofon-Berechtigung nötig). Ohne Spracherkennung im Gerät: Eingabefeld (Tastatur-Diktat). Hilfe: „Hilfe“ sagen
- Live-Sender: Zurückspulen im Puffer und „● Live“-Knopf zum Zurückspringen

**Quellen & Suche**
- 🟢 **NEU:** Kodi-Addons (plugin.video.*, als ZIP) installieren: Einstellungen → Quellen verwalten → „Kodi-Addon (ZIP) installieren“. Das Addon läuft wie in Kodi und erscheint als eigene Quelle (Details: Abschnitt „🟢 Neu in 2.14 bis 2.16“ unten)
- Kodi-Scraper als Quellen: an- und ausschalten, hinzufügen, löschen, von URL oder GitHub laden
- Suche über alle Quellen gleichzeitig, mit Frist: Treffer erscheinen sofort, eine langsame Quelle hält die Suche nicht auf (sie wird als „noch nicht fertig“ gemeldet, ihre Treffer kommen von selbst nach). Quellen, die mehrfach hintereinander scheitern, werden kurz übersprungen
- Ordner, Staffeln, Folgen und mehrere Streams pro Titel (Hoster)
- Zustand jeder Quelle auf einen Blick
- M3U/IPTV-Listen und Stalker-Portale
- Gemeinsame EPG (Sendungsinfos „Jetzt“ und „Danach“): eine EPG-Adresse in den Einstellungen gilt für M3U und Stalker. Sendernamen werden automatisch zugeordnet, auch wenn sie leicht anders geschrieben sind

**Ansehen**
- Eingebauter Player (HLS, DASH, Widevine) mit Proxy für Header und Referer
- Info zu jedem Titel: Laufzeit, FSK, Beschreibung, Jahr, Besetzung (Live-Sender werden dabei nicht bei TMDB abgefragt)
- Verlauf („Zuletzt gesehen“): einzelne Einträge per ✕ auf dem Poster (Fernbedienung: Titel-Menü oder Entf-Taste) entfernbar; „Verlauf leeren“ und „Zwischenspeicher leeren“ fragen vorher mit Ja/Nein nach
- Favoriten nach eigenen Themen
- Downloads zum Offline-Speichern
- Cast-Modus: am Handy stöbern, auf dem gekoppelten Bildschirm abspielen

**Familie**
- Familienchat zwischen Geräten im selben WLAN (ein Gerät ist Chat-Gerät, die anderen verbinden sich mit Adresse + Schlüssel), auch mit angehängtem Titel zum direkten Abspielen
- Dateien senden und empfangen (PDF, Bilder, Musik, Video, beliebige Dateien; bis 250 MB, 30 Tage aufbewahrt), Vorschau für Bilder, Player für Musik und Video
- Die Adresse des Chat-Geräts wird auch unter neueren Android-Versionen (Android 16) im WLAN gefunden

**Erweiterungen**
- Python-Erweiterungen mit Einstellungsmaske, Zeitplan, Startseiten-Reihen, Menüpunkten, Knöpfen und Kacheln
- Mitgelieferte Beispiele: Hoster-Sortierer, Titel-Putzer, Neue-Folgen-Wächter, Heute Abend im TV (mit Erinnerung), Wetter
- Scraper-Assistent: erzeugt aus einer Webadresse einen fertigen Scraper
- Werkstatt zum Schreiben und Testen eigener Python-Skripte

**Oberfläche**
- Eigene Skins: Farben, Bilder, Anordnung, Ränder, Schrift. Standardfarbe ist Blau
- Größe von Postern und Schrift in den Einstellungen einstellbar
- Uhr und Wetter oben auf der Startseite
- Bildschirmschoner
- Bedienung per Touch, Tastatur und Fernbedienung (D-Pad)
  - Zeilenweise Navigation
  - Die Bildschirmtastatur öffnet erst nach OK auf einem Eingabefeld
  - Poster-Menü am Fernseher: ein Klick auf das Poster öffnet die Knöpfe Abspielen, Info und Favorit
  - Chat und Einstellungen lassen sich mit der Fernbedienung scrollen und bedienen

**System**
- Komplette Sicherung und Wiederherstellung
- Android-App im Vollbild, Beenden nur nach Bestätigung
- Android-App läuft auf Wunsch im Hintergrund weiter (Dauer-Meldung „MovieScout läuft“ mit Knopf „Beenden“): Downloads, Chat-Gerät, Cast-Relay und Erinnerungen werden nicht mehr von Android beendet. In den Einstellungen unter „Android-App“ ein- und ausschaltbar
- Benachrichtigungen, wenn die App nicht im Vordergrund ist: neue Chat-Nachrichten (auch vom Chat-Gerät eines anderen), Erinnerungen und Meldungen der Erweiterungen, fertige und fehlgeschlagene Downloads. Tipp auf die Meldung öffnet Chat bzw. Downloads
- Teilen: In einem Browser oder einer anderen App auf „Teilen“ tippen und „MovieScout“ wählen. MovieScout fragt dann, was damit geschehen soll: einen Titel suchen, den Link abspielen oder alles an den Familienchat schicken
- Video-Links öffnen: Ein Link zu einem Video oder einer m3u8-Liste lässt sich direkt mit MovieScout öffnen und abspielen
- Für Fortgeschrittene: Andere Apps (z. B. Tasker) können MovieScout mit einer Adresse starten, etwa `moviescout://search?q=Tatort` (Suche), `moviescout://chat` (Familienchat) oder `moviescout://downloads` (Downloads)
- Die Android-App schützt sich selbst: Von anderen Geräten im WLAN sind nur Fernbedienungs-Kopplung, Familienchat und Dateiübertragung (mit Chat-Schlüssel) erreichbar. Die Oberfläche selbst, Verwaltung und Scraper bleiben dem Gerät vorbehalten
- ResolveURL (Hoster-Auflösung) lässt sich direkt in der App aktualisieren (Verwaltung → Sicherung → „ResolveURL“), ohne neue APK.

**Gadgets (Erweiterungen zum Antippen)**

Einstellungen → Werkzeuge/Erweiterungen → „Beispiele“ → installieren. Jedes Gadget ist eine einzelne Datei (auch als
`gadgets/*.py` beigelegt, zum Importieren über die Werkstatt).

- **Statistik** – zählt die Sehzeit: Kachel „Diese Woche“ und Seite mit Monat, Jahr, Lieblingstiteln, Quellen.
- **Gesehen-Haken** – ✓ vor fertig geschauten Filmen/Folgen; Knopf zum Umschalten in der Titel-Info.
- **Jugendschutz-Filter** – blendet Titel mit Wortliste und ganze Quellen aus; Kontrollseite zeigt, was entfernt wurde.
- **Zufallsfilm** – Kachel „🎲 Zufall“ mit ein paar zufälligen Vorschlägen aus deinen Quellen.
- **Quellen-Wächter** – meldet im Familienchat, wenn eine Quelle ausfällt und wenn sie wieder läuft.
- **Feiertage** – Kachel „Nächster Feiertag“ mit Countdown für dein Bundesland.
- **Filmtipp des Tages** – täglich ein zufälliger Vorschlag im Familienchat.
- **Handy verbinden** – Kachel mit der WLAN-Adresse, zum Abtippen am Handy.
- **Notizzettel** – gemeinsame Notizen/Einkaufsliste für alle Geräte, Kachel auf der Startseite, Knopf „Auf den Notizzettel“ in der Titel-Info.
- **Countdown** – Kachel „Noch X Tage“ für Urlaub, Geburtstage (mit Alter) und Termine.
- **Himmel** – Sonnenauf-/-untergang, Tageslänge, Mondphase (offline berechnet).
- **Spruch des Tages** – ein Spruch pro Tag, mit eigenen Sprüchen erweiterbar.
- **Minispiele** – Snake, 2048 und Memory, per Fernbedienung (Pfeile + OK, Zurück = Menü) und Touch (wischen/tippen) spielbar, gemeinsame Rekorde.
- **Tetris** – mit Fernbedienung und Touch, gemeinsamer Rekord.
- **Filmquiz** – 40 Fragen, je 10 pro Runde, schnell antworten = mehr Punkte; eigene Fragen in den Einstellungen.
- **Pong** – zwei Geräte im Heimnetz gegeneinander (oder gegen den Computer), Siegerliste, Zuschauer möglich.
- **Nachrichten & Podcasts** – RSS-/Atom-Feeds: Kachel mit Schlagzeilen, Leseseite, Podcasts und Videos direkt abspielbar (Feeds in den Einstellungen).
- **Bilderrahmen** – eigene Fotos (Ordner oder Adressen) laufen im Bildschirmschoner mit.
- **Küchen-Timer** – mehrere Timer für alle Geräte, Kachel, Alarm im Familienchat.
- **Solitaire** – Klondike für Fernbedienung und Touch, Rückgängig, Auto-Ablage, 1 oder 3 Karten ziehen, Bestwerte.

Eigene Erweiterungen können im Bildschirmschoner Bilder zeigen: Ein Widget darf zusätzlich `'bilder': [Adressen]` liefern (https://… oder /api/x/<id>/…).
- Jedes Gadget lässt sich einzeln installieren und wieder entfernen (Erweiterungen → Beispiele). 🟢 **NEU:** Oben in der Beispiele-Liste gibt es „Alle installieren“ (ohne die Filter Jugendschutz, Titel-Putzer und Hoster-Sortierer, die verändern Titel/Quellen und werden einzeln gewählt).
- Schon vorher dabei: Hoster-Sortierer, Titel-Putzer, Neue-Folgen-Wächter, Heute Abend im TV, Wetter.

**Windows**

- Fertige Windows-Version: GitHub → Actions → „Windows-Version bauen“ → Run workflow → ZIP unter „Artifacts“.
  Entpacken, `MovieScout.exe` doppelklicken, fertig (eingebettetes Python, nichts zu installieren).
  Anleitung: `windows/README.md`. Daten liegen unter `%LOCALAPPDATA%\MovieScout`; das System-Update funktioniert wie in der App.
- Mac/iPhone/iPad: keine eigene App – Engine auf Mac per `python3 main.py`, oder am Handy/iPad im Browser über „Teilen im WLAN“.

**Neu in 2.1**
- **Hauptmenü beim Abspielen weg**: Läuft ein Video, sind Kopfzeile und Ansicht dahinter ausgeblendet; nur der Player ist zu sehen. Zurück bringt alles wieder
- **Einstellungen in Bereichen**: Allgemein · Konten & Inhalte · Quellen & Listen · Netzwerk · System & Update. Ein „Speichern“ gilt für alle Bereiche
- **Scraper-Baukasten fest eingebaut**: wird beim ersten Start angelegt (Einstellungen → System & Update → „Scraper-Baukasten öffnen“, öffnet im Browser des Geräts). Eine eigene Fassung in „Erweiterungen“ bleibt erhalten und wird nicht überschrieben
- **Teilen im WLAN** (Knopf oben): Der Besitzer schaltet die Freigabe ein und vergibt ein Passwort. Andere Geräte tragen Adresse und Passwort ein („Mit einem anderen Gerät verbinden“) oder öffnen die Adresse im Browser. Gäste dürfen stöbern, suchen, abspielen und chatten, aber keine Einstellungen, Scraper, Erweiterungen oder Updates ändern und sehen keine Zugangsdaten. Falsche Passwörter werden gebremst, ein neues Passwort meldet alle Gäste ab
- **System-Update ohne neue APK**: Einstellungen → System & Update. Quelle ist eine GitHub-Adresse (Repository mit `VERSION`-Datei) oder ein ZIP-Link; alternativ eine ZIP-Datei vom Gerät. Das Update ersetzt Engine, Oberfläche, mitgelieferte Scraper und Kodi-Schicht. Es wird erst geprüft (ZIP gültig, Quelltext fehlerfrei, Version neuer) und wirkt nach dem Neustart. Startet das Update nicht, fällt MovieScout selbst auf den mitgelieferten Stand zurück. „Vorigen Stand wiederherstellen“ und „Auf Stand der App zurücksetzen“ gibt es auch
- **Zwischenspeicher**: Filminfos (TMDB, 2 Wochen, überlebt Neustarts), Hoster-Links, Suchergebnisse und Menüs werden mit Ablaufzeit gemerkt (Menüs 10 Min., Hoster-Links 8 Min.); ältere Menüs werden sofort gezeigt und im Hintergrund erneuert. Übersicht und „Leeren“ unter System & Update
- **Schutz vor Sperren** (Netzwerk): Abstand und Gleichzeitigkeit je Seite, Quoten („voe.sx = 30/min“), automatische Pause bei „zu viele Anfragen“ (429), optional ein eigener Proxy für bestimmte Seiten. Adressen werden nicht gewechselt
- **DNS-Wechsler** (Netzwerk): Cloudflare, Google, Quad9, AdGuard oder eigene DoH-Adresse, mit Test. Fällt der Dienst aus, nimmt MovieScout selbstständig den normalen DNS
- **Mehr Kodi-Schnittstellen für Scraper**: DialogProgress/DialogProgressBG, Skin-Variablen und -Befehle (`Skin.SetString`, `Skin.HasSetting`, `SetProperty`, …), Bedingungen (`String.IsEqual`, `Integer.IsGreater`, `System.Platform.*`, …), Infolabels, JSON-RPC (Teilmenge), `inputstreamhelper` und `inputstream.adaptive`/`ffmpegdirect`-Eigenschaften (DRM, Header, Manifest-Typ)

**🟢 Neu in 2.14 bis 2.16 – Kodi-Addons in MovieScout** *(alles Grüne ist seit dem letzten Stand dazugekommen)*

🟢 **Installieren & Betrieb**
- 🟢 Addon-ZIP (plugin.video.*) installieren, aktualisieren und entfernen. Das Addon erscheint als eigene Quelle mit Startmenü, Ordnern, Suche und Wiedergabe, übersetzten Titeln (strings.po) und seinen Standard-Einstellungen. Es nimmt bewusst nicht an der Gesamtsuche teil
- 🟢 Addons, die `sys` ohne Import benutzen (wie in Kodi, z. B. Vodkool), laufen. Module im Addon-Ordner werden bei jedem Aufruf frisch geladen
- 🟢 Fehlt `requests` auf dem Gerät (z. B. Pydroid: „No module named 'requests'“, so bei Vodkool), springt ein eingebauter Ersatz ein (Get/Post, Session, Cookies, Weiterleitungen, Formular/JSON/Datei-Upload, `verify=False`). Ist das echte Paket da, hat es Vorrang; dasselbe gilt für die APK
- 🟢 `xbmc.Actor` (Besetzung in Film-/Serienlisten) ist vorhanden. Mit Multistream getestet: M3U- und Xtream-Anbieter anlegen (Dialoge), synchronisieren, Live TV, Filme, Serien, Suche, Abspielen
- 🟢 xStream und xShip laufen: Import-Einzeiler wie `if …: from resources.lib… import …` werden umgeleitet (bereits installierte Addons werden beim nächsten Start automatisch nachgezogen, kein Neuinstallieren nötig); `pyaes` (script.module.pyaes) ist eingebaut
- 🟢 Schalter in der `settings.xml` mit Standardwert „True“/„False“ gelten wie in Kodi (xStream zeigte deshalb zuerst keine Seiten); gleichnamige Module (z. B. `netzkino`, `internetarchive` in xStream und in MovieScout) kommen sich nicht mehr in die Quere
- 🟢 Weitere Kodi-Schnittstellen: `xbmc.Actor`, `VideoStreamDetail`/`AudioStreamDetail`/`SubtitleStreamDetail`, `LOGNOTICE`, alle `SORT_METHOD_*`-Konstanten, `InfoTag.add…`
- 🟢 Abspielen wie in Kodi: Wartet ein Addon nach `setResolvedUrl` auf seinen Player (xStream, xShip: „Bild da“, `abortRequested`-Schleifen), meldet MovieScout ihm sofort `onPlayBackStarted/onAVStarted` und beendet die Wartezeit – vorher drehte der Ladekreis endlos
- 🟢 `special://database/` mit leeren Kodi-Datenbanken (MyVideos, Addons); `os.chdir` eines Addons wirkt nicht mehr auf die ganze Engine
- 🟢 Addon-Dienste (`xbmc.service`) starten schon mit der Engine, wie beim Kodi-Start (xStream wartete sonst beim ersten Öffnen bis zu 16 s auf seinen Dienst)
- 🟢 Dienste starten beim Engine-Start ohne Fehler (Vodkool: `import service`, Multistream: Startargumente); jedes Addon findet seine eigenen Module, auch im Hintergrund. Die Scraper der Engine tragen keinen bloßen Dateinamen mehr in `sys.modules`, dadurch lädt xStream auch Netzkino und Internet Archive
- 🟢 Zeitlimits unter 8 s (z. B. die Domain-Prüfung von xShip mit `timeout=2`) werden im eingebauten `requests`-Ersatz auf 8 s angehoben: auf dem Handy meldeten sie sonst Seiten fälschlich als „dead“, und xShip schaltete deren Quellen ab. Dienste starten nacheinander (2 s Abstand); Einstellungen werden atomar gespeichert. Nach dem Update: in xShip unter Werkzeuge → „Domain Check“ einmal ausführen (das Ergebnis gilt sonst 90 Minuten)
- 🟢 xShip findet alle Quellen statt nur Vavoo: Der Domain-Check von xShip (HEAD-Anfrage) stufte viele Seiten wegen 403/405 oder Zeitüberschreitung als „dead“/„cf_blocked“ ein, und solche Scraper lädt xShip gar nicht erst. MovieScout meldet den Status `provider.<name>.health` jetzt immer als „ok“ (die Scraper selbst gehen mit Fehlern um). Außerdem fehlte `filmo` in der Liste (kein Statusfeld in der Einstellungsdatei) und ist jetzt dabei. Kein Neuinstallieren und kein Domain-Check nötig
- 🟢 xShip, zweiter Schritt: Der Domain-Check von xShip ist abgeschaltet (er schrieb Domains und Scraper-Dateien nach Zufallsantworten um; Domains kommen aus den Scraper-Dateien, gespeicherte Fremd-Domains werden ignoriert), und das Zeitlimit für die Scraper beträgt mindestens 60 s, weil jetzt alle 17 gleichzeitig laufen und auf dem Handy länger brauchen
- 🟢 Absturzschutz: Verschleierte Addons mit fremdem Bytecode (z. B. Deezer 10.25) werden beim Installieren mit klarer Meldung abgelehnt und zur Laufzeit blockiert, statt das ganze System abstürzen zu lassen. Absturz-Protokoll: `userData/crash.log`

🟢 **Speicher aufräumen** (Einstellungen → System & Update)
- 🟢 Zeigt den Gerätespeicher (belegt/frei) und was MovieScout selbst belegt, getrennt nach: Poster-Speicher, Addon-Zwischenspeicher (xStream „htmlcache“, Vavoo, resolveurl …), Temporäres (temp, cache, thumbnails), Engine-Zwischenspeicher (cache.sqlite samt -wal/-shm), Protokolle, Papierkorb der Scraper und – nur auf Wunsch – übersetzte Python-Dateien
- 🟢 „Auswahl aufräumen“ (mit Rückfrage), „Nur Altes aufräumen“ (Temporäres älter als 1 Tag, Protokolle 7, Addon-Zwischenspeicher 14, Papierkorb 30 Tage, Poster nur über der Höchstgröße) und „Neu messen“
- 🟢 Automatisch: 90 s nach dem Start und dann alle 6 Stunden räumt MovieScout Altes auf (abschaltbar). Sind weniger als 12 % Gerätespeicher frei, wird alles Aufräumbare geleert
- 🟢 Sicher: Einstellungen und Anmeldungen der Addons (settings.json), Datenbanken, Downloads, installierte Addons, eigene Scraper und Tastenbelegung werden nie angefasst. Dateien, die in den letzten 2 Minuten geändert wurden, bleiben stehen. Test: `python tests/cleanup_test.py`

🟢 **Spiele verschieben sich nicht mehr**
- 🟢 Tetris, Snake/2048/Memory, Pong und Solitaire passen jetzt in jedes Fenster (Handy hoch und quer, Tablet, TV): kein Scrollen mehr, nichts rutscht beim Tippen, bei Pfeiltasten oder bei der Bildschirmtastatur aus dem Bild. Die Seite ist so hoch wie der sichtbare Bereich (ohne Adressleiste-Trick), Tetris und Snake ordnen Bedienfelder im Querformat neben dem Spielfeld an
- 🟢 Schon installierte Spiele werden beim nächsten Start automatisch auf die neue Fassung gehoben (die alte liegt im Papierkorb). Test: `python tests/games_fit_test.py`

🟢 **ResolveURL-Update robuster**
- 🟢 Das Einspielen der neuen ResolveURL-Version scheitert nicht mehr an Dateirechten auf dem Gerät (Schreibschutz wird aufgehoben, notfalls wird kopiert statt umbenannt). Scheitert es doch, nennt die Meldung den Schritt. Die bisherige Version bleibt aktiv

🟢 **Captcha-Dienst in den Einstellungen**
- 🟢 Einstellungen → Konten: Captcha-Dienst wählen (CapSolver, 2Captcha, Anti-Captcha, CapMonster, 9kw, DeathByCaptcha) und den API-Schlüssel eintragen. Keine Dateien, keine Umgebungsvariablen nötig
- 🟢 Der Schlüssel bleibt auf dem Gerät. Vorrang haben Umgebungsvariablen, dann die Einstellungen, dann `captcha_solver.json`. Platzhalter-Schlüssel werden ignoriert

🟢 **ResolveURL-Update übernimmt die geladene Version**
- 🟢 Nach „Jetzt aktualisieren“ wird die heruntergeladene ResolveURL-Version genutzt, auch wenn ihre Nummer gleich der mitgelieferten ist. Vorher kam „Neue Version lässt sich nicht laden“, obwohl die Dateien vollständig waren

🟢 **ResolveURL-Update: Lizenzdatei stört nicht mehr**
- 🟢 Die Lizenzdatei wird nur als Bytes kopiert. Schreibgeschützte Vorlagen auf dem Gerät führen nicht mehr zum Abbruch des Updates

🟢 **Stalker Portal: Live-TV**
- 🟢 Live-Kanäle im Format MPEG-TS (`extension=ts`) laufen in der App im App-Player. Der Browser kann dieses Format nicht abspielen
- 🟢 Live-Links bekommen das Portal-Token auch als Cookie `access_token` (wie beim Stalker Hunter). Der Link wird ohne Zusatzfelder angefordert
- 🟢 Kanalliste bleibt auch dann sichtbar, wenn der Programmführer (EPG) fehlschlägt
- 🟢 Serien: Liefert das Portal keine Adresse, wird es ohne Folgennummer erneut versucht. Fehlt die Adresse ganz, steht die Portal-Antwort in der Fehlermeldung

🟢 **Nächste Folge bei Serien**
- 🟢 Läuft eine Folge aus einer Folgenliste, merkt sich MovieScout die Liste. Im Player erscheint der Knopf „Nächste Folge ▶“ (gewählt wird die Folge mit der nächsthöheren Nummer, sonst die nächste in der Liste)
- 🟢 Ist die Folge zu Ende, kommt unten rechts „Nächste Folge: … in 10 s“ mit „Jetzt starten“ und „Abbrechen“; nach 10 s startet sie von selbst (die Quelle wählt „Quelle automatisch starten“). Abschaltbar unter Einstellungen: „Nächste Folge nach dem Ende anbieten und automatisch starten“
- 🟢 Grenze: Das Ende meldet nur ein echter Videostrom. Eingebettete Hoster-Seiten melden es nicht, dort bleibt der Knopf „Nächste Folge ▶“. Filmlisten zählen nicht als Serie. Test: `python tests/features_ui_test.py`

🟢 **Einstellungen & Anmelden**
- 🟢 Knopf „⚙ Einstellungen / Anmelden“ in jeder Addon-Liste und Eintrag „Einstellungen“ im Startmenü: Formular aus der `settings.xml` (Text, Passwort, Zahl, Auswahl, Schalter, Aktions-Knöpfe wie „Anmelden“)
- 🟢 Kodi-Markup (`[COLOR]`, `[B]`, `[CR]` …) wird überall entfernt (Titel, Meldungen, Einstellungen)
- 🟢 Fragt ein Addon nach (Ja/Nein, Auswahl, Eingabe, Hinweis, Passwort, Zahl, Fortschrittsbalken), erscheint die Frage in der Oberfläche und die Antwort geht zurück an das Addon. So laufen Anmeldung, Aktionen wie „Alle Playlisten neu suchen“ (GitPlayGer) und Texte aus `textviewer` (z. B. ein Handbuch, öffnet im Lesefenster)
- 🟢 Unter „Einstellungen / Anmelden“ steht der Zustand des Hintergrunddienstes samt letzten Meldungen (Diagnose)

🟢 **Anzeige bleibt aktuell**
- 🟢 `Container.Refresh` und `Container.Update` werden befolgt: Nach Anmelden, Abmelden, Nachricht senden oder Blättern lädt die Liste neu bzw. springt auf die neue Adresse (Telegram Scraper: Eigene Nachrichten sofort sichtbar, kein Neustart nötig)
- 🟢 `ShowPicture(...)` zeigt Bilder in der Oberfläche (Telegram-Bilder)

🟢 **Abspielen**
- 🟢 Was ein Addon per `setResolvedUrl` oder `Player().play` abspielen lässt, gilt als direkter Stream (auch ohne Dateiendung) und läuft über die Engine
- 🟢 Wiedergabelisten (Deezer): Tippt man einen Titel an, wird genau dieser aufgelöst und abgespielt
- 🟢 Dateien, die ein Addon auf dem Gerät erzeugt (Deezer entschlüsselt Titel in `special://temp`), liefert die Engine selbst aus, mit Spulen (Bereichsanfragen)
- 🟢 Mini-Server auf 127.0.0.1 (NewPipe, Telegram-Stream) werden gezielt freigegeben und nur über die Engine erreicht, auch wenn man MovieScout von einem anderen Gerät benutzt
- 🟢 Hintergrunddienste (`xbmc.service`), z. B. der lokale Stream-Server des Telegram Scraper, starten beim ersten Aufruf des Addons und enden beim Entfernen oder Ersetzen

🟢 **Getestet mit echten Addons**
- 🟢 Multistream, xStream, xShip, Vodkool, NewPipe, GitPlayGer (u. a. M3U/IPTV, Playlisten), Deezer (Anmelden, Menüs, Charts, Titel abspielen), Telegram Scraper (Anmelden, Chats, Nachrichten lesen und senden, Bilder, Videos, Download), Vodkool (Hauptmenü)

🟢 **Gadgets**
- 🟢 „Alle installieren“ in Erweiterungen → Beispiele (ohne die Filter Jugendschutz, Titel-Putzer und Hoster-Sortierer, die einzeln gewählt werden)

**Grenzen (ehrlich)**
- Ein System-Update erneuert nur den Python-/Web-Teil. Der Java-Teil der Android-App (Berechtigungen, Dienst, Benachrichtigungen, Player) steckt in der APK und braucht dafür weiter eine neue APK; das Update meldet das, wenn ein Paket Android-Dateien enthält
- Der DNS-Wechsler gilt für alles, was die Engine selbst abruft (Scraper, Hoster-Abfragen, TMDB, Stream-Proxy). Das Video im Player der App nutzt den DNS des Geräts; systemweit geht das nur in Android unter Einstellungen → Netzwerk → Privates DNS
- Der Schutz vor Sperren bremst und pausiert höflich; er rotiert keine Proxys oder Adressen
- Teilen funktioniert nur im selben Netz und ohne Verschlüsselung (http). Passwort nur an Menschen weitergeben, denen du vertraust
- 🟢 Kodi-Addons: Eigene Fenster und Skins eines Addons, Kontextmenüs (Langdruck) und Hintergrunddienste außer `xbmc.service` gibt es nicht. Addons sind von der Gesamtsuche ausgenommen. Musik läuft im Video-Player, ein Titel pro Antippen (kein automatisches Weiterspielen der Liste)
- 🟢 Kodi-Addons: Verschleierte Addons mit gepacktem Bytecode laufen nicht (Absturzgefahr) – bitte die unverschleierte Fassung installieren. Ob ein Addon auf dem Gerät streamt, hängt von dessen Server ab (Telegram, Deezer-Entschlüsselung brauchen auf schwachen Handys einige Sekunden)

**Tests**: `python tests/features_test.py` (Update, Rückfall, Freigabe, Sperrschutz, Cache, Suche, Kodi-Schicht), `python tests/features_ui_test.py` (Oberfläche), dazu `run_tests.py`, `ui_tests.py`, `app_ui_test.py`, `notify_test.py`. 🟢 **NEU:** `python tests/addon_test.py` (Kodi-Addons: Installieren, Menüs, Abspielen, Dialoge, Dienste, Einstellungen), `python tests/addon_ui_test.py` (Liste lädt nach `Container.Refresh/Update` neu) und `gadgets_test.py` (inkl. „Alle installieren“). 🟢 **NEU:** `python tests/requests_compat_test.py` (Ersatz für fehlendes `requests`) und `python tests/addon_compat_test.py` (Import-Umleitung, pyaes, Schalter-Standardwerte, Namensüberschneidungen).

