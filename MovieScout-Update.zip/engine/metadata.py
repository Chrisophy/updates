# -*- coding: utf-8 -*-
"""Filminfos (Titel, Länge, FSK, Beschreibung, Jahr, Besetzung) für die Oberfläche.

Quellen, in dieser Reihenfolge:
  1. Das, was der Scraper selbst mitliefert (plot, year, duration, mpaa, cast, genre …).
  2. TMDB (themoviedb.org, deutsch) - nur wenn in den Einstellungen ein API-Schlüssel eingetragen ist.
     Unterstützt den v3-Schlüssel (32 Zeichen) und das v4-„API Read Access Token“ (beginnt mit eyJ).

Alles Fehlende bleibt einfach leer; nichts wird erfunden.
"""
import json
import logging
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from kodi_runtime import xbmcaddon

from . import cache as _cachemod

log = logging.getLogger('engine.meta')

TMDB_BASE = os.environ.get('MOVIESCOUT_TMDB_BASE', 'https://api.themoviedb.org/3').rstrip('/')
IMG_BASE = os.environ.get('MOVIESCOUT_TMDB_IMG', 'https://image.tmdb.org/t/p/w342').rstrip('/')
CACHE_TTL = 14 * 24 * 3600          # Filminfos ändern sich kaum: zwei Wochen, übersteht Neustarts (SQLite)
NEG_TTL = 12 * 3600                 # „nicht gefunden“ nur kurz merken
CACHE_MAX = 600
_C = _cachemod.Cache('tmdb', ttl=CACHE_TTL, max_mem=CACHE_MAX, persist=True)
_lock = threading.Lock()

_TV_TYPES = ('tvshow', 'season', 'episode', 'tv', 'series', 'serie')
_NOISE = re.compile(
    r'\b(?:hd|fhd|uhd|4k|1080p|720p|480p|bluray|blu-ray|webrip|web-dl|dvdrip|german|deutsch|dubbed|stream|online|'
    r'ganzer film|kostenlos|komplett|ger|de)\b', re.I)


def _int(v, default=0):
    try:
        return int(float(str(v).strip()))
    except Exception:
        return default


def clean_title(t):
    """Titel von Zusätzen wie „(2021)“, „[HD]“, „Stream“ befreien."""
    t = re.sub(r'\[[^\]]*\]|\([^)]*\)', ' ', str(t or ''))
    t = _NOISE.sub(' ', t)
    t = re.sub(r'\s+', ' ', t).strip(' -–—:|.')
    return t


def _year(v):
    m = re.search(r'(19|20)\d{2}', str(v or ''))
    return int(m.group(0)) if m else 0


def _minutes(v):
    """Laufzeit in Minuten aus Zahl (Sekunden oder Minuten) oder „1:52:00“ / „112 min“."""
    if v in (None, '', 0, '0'):
        return 0
    if isinstance(v, (int, float)):
        v = float(v)
        return int(round(v / 60)) if v > 600 else int(v)
    s = str(v).strip()
    if ':' in s:
        parts = [_int(x) for x in s.split(':')]
        if len(parts) == 3:
            return parts[0] * 60 + parts[1] + (1 if parts[2] >= 30 else 0)
        if len(parts) == 2:
            return parts[0]
    m = re.search(r'(\d+)\s*(?:h|std)\w*\.?\s*(\d+)?', s, re.I)
    if m and re.search(r'h|std', s, re.I):
        return _int(m.group(1)) * 60 + _int(m.group(2))
    n = _int(re.sub(r'[^\d.]', '', s))
    return int(round(n / 60)) if n > 600 else n


def _fsk(v):
    """„FSK 12“, „DE-12“, „ab 12“, „12“ -> „12“ (nur 0/6/12/16/18); sonst leer."""
    s = str(v or '').strip()
    if not s:
        return ''
    m = re.search(r'\b(6|12|16|18)\b', s)
    if m:
        return m.group(1)
    return '0' if re.search(r'ohne\s+alters|^0$|fsk\s*0\b|\bab\s*0\b', s, re.I) else ''


def _cast_list(v):
    out = []
    for c in (v if isinstance(v, list) else re.split(r'[,;|]', v) if isinstance(v, str) else []):
        if isinstance(c, dict):
            name = str(c.get('name') or c.get('actor') or '').strip()
            role = str(c.get('role') or c.get('character') or '').strip()
        else:
            name, role = str(c).strip(), ''
        if name:
            out.append({'name': name, 'role': role})
    return out[:15]


def _genres(v):
    if isinstance(v, list):
        return [str(g.get('name') if isinstance(g, dict) else g).strip() for g in v if g][:6]
    if isinstance(v, str):
        return [g.strip() for g in re.split(r'[,/|;]', v) if g.strip()][:6]
    return []


# ----------------------------------------------------------------------------- TMDB

def _key():
    return (xbmcaddon.all_settings().get('api.tmdb') or os.environ.get('MOVIESCOUT_TMDB_KEY') or '').strip()


def _get(path, params, key):
    q = dict(params)
    headers = {'Accept': 'application/json', 'User-Agent': 'MovieScout'}
    if key.startswith('eyJ'):
        headers['Authorization'] = 'Bearer ' + key
    else:
        q['api_key'] = key
    url = TMDB_BASE + path + '?' + urllib.parse.urlencode(q)
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=9) as r:
        return json.loads(r.read().decode('utf-8', 'replace'))


def _norm(s):
    return re.sub(r'[^a-z0-9äöüß]+', '', str(s or '').lower())


def _pick(results, title, year, tv):
    """Besten Treffer wählen: gleicher Titel + passendes Jahr vor allem anderen."""
    want = _norm(title)
    best, best_score = None, -1
    for r in results[:10]:
        names = [r.get('title'), r.get('original_title'), r.get('name'), r.get('original_name')]
        date = r.get('first_air_date') if tv else r.get('release_date')
        ry = _year(date)
        score = 0
        if any(_norm(n) == want for n in names if n):
            score += 4
        elif any(want and want in _norm(n) for n in names if n):
            score += 1
        if year and ry:
            if ry == year:
                score += 3
            elif abs(ry - year) == 1:
                score += 1
            else:
                score -= 3
        score += min(float(r.get('popularity') or 0), 50) / 100.0
        if score > best_score:
            best, best_score = r, score
    return best if best_score >= 1 else None


def _tmdb_find(key, item, title, year, want_tv):
    """-> (typ, id) oder (None, None)."""
    tid = _int(item.get('tmdb') or item.get('tmdb_id'))
    if tid:
        return ('tv' if want_tv else 'movie'), tid
    order = ['tv', 'movie'] if want_tv else ['movie', 'tv']
    cands = [title]
    for sep in (' - ', ' – ', ': '):
        if sep in title:
            cands.append(title.split(sep)[0].strip())
    for t in cands:
        if not t:
            continue
        for kind in order:
            for with_year in ((True, False) if year else (False,)):
                params = {'query': t, 'language': 'de-DE', 'include_adult': 'false'}
                if with_year:
                    params['year' if kind == 'movie' else 'first_air_date_year'] = year
                try:
                    res = _get('/search/' + kind, params, key).get('results') or []
                except urllib.error.HTTPError:
                    raise                       # z. B. ungültiger Schlüssel: dem Aufrufer melden
                except Exception as e:
                    log.warning('TMDB-Suche fehlgeschlagen: %s', e)
                    return None, None
                hit = _pick(res, t, year if with_year else 0, kind == 'tv')
                if hit:
                    return kind, hit['id']
    return None, None


def _de_cert_movie(rel):
    for c in (rel or {}).get('results') or []:
        if c.get('iso_3166_1') == 'DE':
            for r in sorted(c.get('release_dates') or [], key=lambda x: 0 if x.get('type') in (3, 4) else 1):
                f = _fsk(r.get('certification'))
                if f or str(r.get('certification') or '').strip() == '0':
                    return f or '0'
    return ''


def _de_cert_tv(rat):
    for c in (rat or {}).get('results') or []:
        if c.get('iso_3166_1') == 'DE':
            f = _fsk(c.get('rating'))
            if f:
                return f
    return ''


def _tmdb_details(key, kind, tid, season, episode):
    extra = 'credits,release_dates' if kind == 'movie' else 'credits,content_ratings'
    d = _get('/%s/%s' % (kind, tid), {'language': 'de-DE', 'append_to_response': extra}, key)
    out = {
        'title': d.get('title') or d.get('name') or '',
        'year': _year(d.get('release_date') or d.get('first_air_date')),
        'plot': (d.get('overview') or '').strip(),
        'tagline': (d.get('tagline') or '').strip(),
        'genres': _genres(d.get('genres')),
        'rating': round(float(d.get('vote_average') or 0), 1),
        'cast': _cast_list([{'name': c.get('name'), 'role': c.get('character')} for c in (d.get('credits') or {}).get('cast') or []]),
        'poster': (IMG_BASE + d['poster_path']) if d.get('poster_path') else '',
        'type': kind,
    }
    if kind == 'movie':
        out['runtime'] = _int(d.get('runtime'))
        out['fsk'] = _de_cert_movie(d.get('release_dates'))
    else:
        rt = d.get('episode_run_time') or []
        out['runtime'] = _int(rt[0]) if rt else _int(((d.get('last_episode_to_air') or {}).get('runtime')))
        out['fsk'] = _de_cert_tv(d.get('content_ratings'))
        out['seasons'] = _int(d.get('number_of_seasons'))
        if season and episode:
            try:
                e = _get('/tv/%s/season/%s/episode/%s' % (tid, season, episode), {'language': 'de-DE'}, key)
                out['episode'] = {'title': e.get('name') or '', 'plot': (e.get('overview') or '').strip(),
                                  'runtime': _int(e.get('runtime')), 'season': season, 'episode': episode}
            except Exception:
                pass
    if not out['plot']:                                # keine deutsche Beschreibung: englische als Ersatz
        try:
            en = _get('/%s/%s' % (kind, tid), {'language': 'en-US'}, key)
            out['plot'] = (en.get('overview') or '').strip()
            out['plot_lang'] = 'en' if out['plot'] else ''
        except Exception:
            pass
    return out


# ----------------------------------------------------------------------------- Zusammenführen

def _from_item(item):
    cast = _cast_list(item.get('cast') or item.get('actors'))
    return {
        'title': str(item.get('title') or '').strip(),
        'year': _year(item.get('year') or item.get('premiered') or item.get('releasedate')),
        'plot': str(item.get('plot') or item.get('description') or '').strip(),
        'runtime': _minutes(item.get('duration') or item.get('runtime')),
        'fsk': _fsk(item.get('mpaa') or item.get('fsk') or item.get('certification')),
        'genres': _genres(item.get('genre') or item.get('genres')),
        'cast': cast,
        'rating': round(float(item.get('rating') or 0), 1) if str(item.get('rating') or '').replace('.', '', 1).isdigit() else 0,
        'poster': str(item.get('poster') or ''),
    }


def lookup(item):
    """Infos zu einem Eintrag. Gibt immer ein dict zurück; 'source' sagt, woher die Daten stammen."""
    item = item if isinstance(item, dict) else {}
    base = _from_item(item)
    season, episode = _int(item.get('season')), _int(item.get('episode'))
    show = item.get('parent_title') if (season and item.get('parent_title')) else base['title']
    title = clean_title(show)
    mt = str(item.get('mediatype') or '').lower()
    want_tv = bool(season or episode or mt in _TV_TYPES or (item.get('kind') == 'folder' and not mt))
    key = _key()
    out = dict(base, source='quelle', tmdb=False, has_key=bool(key), episode=None)
    if item.get('live'):                              # Live-Sender (IPTV): die Beschreibung ist das EPG, nicht TMDB fragen
        return dict(_finish(out), missing=[])
    if not key or not title:
        return _finish(out)
    ck = '|'.join([key[:6], title.lower(), str(base['year']), str(want_tv), str(season), str(episode), str(item.get('tmdb') or '')])
    hit = _C.get(ck)
    if hit is not None:
        return _finish(dict(out, **hit))
    try:
        kind, tid = _tmdb_find(key, item, title, base['year'], want_tv)
        if not tid:
            out['not_found'] = True
            _C.put(ck, {'not_found': True}, ttl=NEG_TTL)
            return _finish(out)
        t = _tmdb_details(key, kind, tid, season, episode)
    except urllib.error.HTTPError as e:
        out['error'] = 'TMDB: ' + ('Schlüssel ungültig' if e.code in (401, 403) else 'Fehler %d' % e.code)
        return _finish(out)
    except Exception as e:
        log.warning('TMDB nicht erreichbar: %s', e)
        old, _stale = _C.get_stale(ck, max_stale=90 * 86400)       # lieber alte Infos als keine
        if old:
            return _finish(dict(out, **old))
        out['error'] = 'TMDB nicht erreichbar'
        return _finish(out)
    merged = {
        'title': base['title'] or t['title'],
        'year': t['year'] or base['year'],
        'plot': t['plot'] or base['plot'],
        'runtime': t['runtime'] or base['runtime'],
        'fsk': t['fsk'] or base['fsk'],
        'genres': t['genres'] or base['genres'],
        'cast': t['cast'] or base['cast'],
        'rating': t['rating'] or base['rating'],
        'poster': base['poster'] or t['poster'],
        'tagline': t.get('tagline', ''),
        'plot_lang': t.get('plot_lang', ''),
        'source': 'tmdb', 'tmdb': True, 'type': t['type'], 'seasons': t.get('seasons', 0),
        'episode': t.get('episode'),
    }
    _C.put(ck, merged)
    return _finish(dict(out, **merged))


def _finish(d):
    d['missing'] = [k for k, v in (('runtime', d.get('runtime')), ('fsk', d.get('fsk') != ''), ('cast', d.get('cast')), ('plot', d.get('plot'))) if not v]
    return d
