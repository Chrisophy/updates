# -*- coding: utf-8 -*-
"""Hoster-Auflösung: ResolveURL (vendor/resolveurl, ~200 Hoster) + eigene Auflöser (resources/lib/evil.py).

Reihenfolge:
  1. Hoster, die nur evil.py kennt (burningseries, meinecloud, kinoger ...)  -> evil zuerst
  2. alles, was ResolveURL erkennt                                            -> ResolveURL
  3. Rückfall auf den jeweils anderen Auflöser

ResolveURL ist unter GPL-2.0 lizenziert (siehe vendor/resolveurl/LICENSE).
"""
import io
import os
import stat
import json
import re
import time
import shutil
import sys
import threading
import zipfile
from pathlib import Path

from kodi_runtime import paths as _paths
from resources.lib import log, multiquest

_VENDOR = str(Path(__file__).resolve().parent.parent / 'vendor')
if _VENDOR not in sys.path:
    sys.path.insert(0, _VENDOR)

# Hoster, die evil.py besser (oder als Einziger) kennt
_EVIL_FIRST = ('burningseries', 'bs.to', 'meinecloud', 'kinoger', 'fsst.online', 'gupload.',
               'moflix', 'vidara', 'vidsonic', 'dr0pstream', 'playmate.', 'devideosrc.')

# Aktualisiertes ResolveURL liegt im Datenordner (bleibt bei App-Updates erhalten) und hat Vorrang vor der
# mitgelieferten Version in vendor/. Aufbau: resolveurl_update/resolveurl/... + version.txt
_UPD = _paths.DATA_DIR / 'resolveurl_update'
_SRC_FILE = _paths.DATA_DIR / 'resolveurl_quelle.json'     # eigene Adressen, falls ResolveURL umzieht
_BUNDLED_VERSION = '5.1.213'
_DEFAULT_ZIP = 'https://codeload.github.com/Gujal00/ResolveURL/zip/refs/heads/master'
_DEFAULT_ADDON = 'https://raw.githubusercontent.com/Gujal00/ResolveURL/master/script.module.resolveurl/addon.xml'

_lock = threading.Lock()
_upd_lock = threading.Lock()
_ru = None
_ru_error = ''
_override = False          # läuft gerade die nachgeladene Version?


def _vkey(v):
    return tuple(int(x) for x in re.findall(r'\d+', str(v or ''))[:4]) or (0,)


def _bundled_version():
    f = Path(_VENDOR) / 'resolveurl.version'
    try:
        return f.read_text(encoding='utf-8').strip() or _BUNDLED_VERSION
    except Exception:
        return _BUNDLED_VERSION


def _override_version():
    try:
        return (_UPD / 'version.txt').read_text(encoding='utf-8').strip()
    except Exception:
        return ''


def _purge():
    for k in list(sys.modules):
        if k == 'resolveurl' or k.startswith('resolveurl.'):
            del sys.modules[k]


def _drop_override_path():
    while str(_UPD) in sys.path:
        sys.path.remove(str(_UPD))


def _import_locked(force=False):
    """Lädt ResolveURL (Aufrufer hält _lock). Nachgeladene Version zuerst; bei Fehler Rückfall auf vendor/.
    force=True: nach einem ausdrücklichen Update die nachgeladene Version auch dann nehmen, wenn sie nicht neuer ist."""
    global _ru, _ru_error, _override
    _ru, _ru_error, _override = None, '', False
    import kodi_runtime  # noqa: F401  (Shims müssen vor ResolveURL registriert sein)
    use = (_UPD / 'resolveurl' / '__init__.py').exists() and (force or _vkey(_override_version()) > _vkey(_bundled_version()))
    if use:
        try:
            _purge()
            sys.path.insert(0, str(_UPD))
            import resolveurl
            resolveurl.relevant_resolvers()
            _ru, _override = resolveurl, True
            log.log('[resolvers] ResolveURL %s (nachgeladen) geladen: %d Auflöser' % (_override_version(), len(resolveurl.relevant_resolvers())))
            return
        except Exception as e:
            log.log('[resolvers] Nachgeladenes ResolveURL defekt, nehme die mitgelieferte Version: %s: %s' % (type(e).__name__, e))
            _purge()
            _drop_override_path()
            shutil.rmtree(str(_UPD) + '.defekt', ignore_errors=True)
            try:
                _UPD.rename(str(_UPD) + '.defekt')
            except Exception:
                pass
    try:
        _purge()
        _drop_override_path()
        import resolveurl
        _ru = resolveurl
        log.log('[resolvers] ResolveURL geladen: %d Auflöser' % len(resolveurl.relevant_resolvers()))
    except Exception as e:
        _ru_error = '%s: %s' % (type(e).__name__, e)
        log.log('[resolvers] ResolveURL nicht verfügbar: %s' % _ru_error)


def _load_resolveurl():
    if _ru is not None or _ru_error:
        return _ru
    with _lock:
        if _ru is not None or _ru_error:
            return _ru
        _import_locked()
    return _ru


def status():
    ru = _load_resolveurl()
    if ru is None:
        return {'resolveurl': False, 'error': _ru_error, 'count': 0}
    try:
        n = len(ru.relevant_resolvers())
    except Exception:
        n = 0
    return {'resolveurl': True, 'count': n, 'version': _override_version() if _override else _bundled_version(), 'updated': _override}


def resolveurl_supports(url):
    ru = _load_resolveurl()
    if ru is None:
        return False
    try:
        return bool(ru.HostedMediaFile(url).valid_url())
    except Exception:
        return False


def _via_resolveurl(url):
    ru = _load_resolveurl()
    if ru is None:
        return url, False
    try:
        hmf = ru.HostedMediaFile(url)
        if not hmf.valid_url():
            return url, False
        res = hmf.resolve()
        if res and isinstance(res, str) and res.startswith('http'):
            return res, True
        if res and not isinstance(res, str):
            return url, False
    except Exception as e:
        log.log('[resolvers] ResolveURL scheitert für %s: %s' % (url[:80], e))
    return url, False


def _via_evil(url):
    from resources.lib import evil
    try:
        res, ok = evil.resolve(url)
        return res, bool(ok)
    except Exception as e:
        log.log('[resolvers] evil scheitert für %s: %s' % (url[:80], e))
        return url, False


def resolve_embed(url):
    """-> (url, ok, via)"""
    low = url.lower()
    order = (_via_evil, _via_resolveurl) if any(k in low for k in _EVIL_FIRST) else (_via_resolveurl, _via_evil)
    for fn in order:
        res, ok = fn(url)
        if ok and res:
            return res, True, ('evil' if fn is _via_evil else 'resolveurl')
    return url, False, ''


# ---- ResolveURL aktualisieren (ohne neue APK) ----

def _xml_version(text):
    m = re.search(r'<addon[^>]*\sversion="([^"]+)"', text or '')
    return m.group(1) if m else ''


def get_source():
    """-> {zip, addon, default_zip, default_addon}: eigene Adressen aus resolveurl_quelle.json, sonst Standard."""
    own = {}
    try:
        own = json.loads(_SRC_FILE.read_text(encoding='utf-8'))
    except Exception:
        pass
    return {'zip': own.get('zip') or _DEFAULT_ZIP, 'addon': own.get('addon') or ('' if own.get('zip') else _DEFAULT_ADDON),
            'default_zip': _DEFAULT_ZIP, 'default_addon': _DEFAULT_ADDON, 'custom': bool(own.get('zip'))}


def set_source(zip_url='', addon_url=''):
    """Leer = zurück zum Standard. Adresse der ZIP-Datei (GitHub-Archiv von ResolveURL) und optional die der addon.xml."""
    zip_url, addon_url = (zip_url or '').strip(), (addon_url or '').strip()
    for u in (zip_url, addon_url):
        if u and not re.match(r'^https?://\S+$', u):
            raise RuntimeError('Ungültige Adresse: %s' % u[:80])
    if not zip_url or zip_url == _DEFAULT_ZIP:
        _SRC_FILE.unlink(missing_ok=True)
    else:
        _SRC_FILE.write_text(json.dumps({'zip': zip_url, 'addon': addon_url}, indent=1), encoding='utf-8')
    return get_source()


def check_update():
    """-> {current, latest, newer, updated}. Wirft bei Netzfehlern."""
    addon_url = get_source()['addon']
    if not addon_url:
        raise RuntimeError('Für die eigene Adresse ist keine Versions-Adresse hinterlegt – einfach „Jetzt aktualisieren“.')
    r = multiquest.get(addon_url, headers={'User-Agent': 'MovieScout'}, timeout=30)
    if r.status_code != 200:
        raise RuntimeError('GitHub nicht erreichbar (HTTP %s)' % r.status_code)
    latest = _xml_version(r.text)
    if not latest:
        raise RuntimeError('Version auf GitHub nicht lesbar')
    st = status()
    cur = st.get('version') or _bundled_version()
    return {'current': cur, 'latest': latest, 'newer': _vkey(latest) > _vkey(cur), 'updated': bool(st.get('updated'))}


def _writable(func, path, _exc):
    """Schreibschutz (z. B. nach Android-Rechten/Zwischenspeicher) aufheben und erneut versuchen."""
    try:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD | stat.S_IEXEC)
        func(path)
    except Exception:                                       # noqa: BLE001
        pass


def _rm(p):
    if Path(p).exists():
        shutil.rmtree(str(p), onerror=_writable)


def _mv(a, b):
    """Ordner verschieben; scheitert das (Rechte, anderes Dateisystem), kopieren und dann löschen."""
    from . import fsutil as FS
    FS.move_dir(a, b)


def update():
    """Lädt die neueste ResolveURL-Version von GitHub, spielt sie ein und lädt sie ohne Neustart neu.
    Bei jedem Fehler bleibt die bisherige Version aktiv."""
    global _ru, _ru_error
    if not _upd_lock.acquire(blocking=False):
        raise RuntimeError('Ein Update läuft bereits.')
    new = Path(str(_UPD) + '.neu')
    old = Path(str(_UPD) + '.alt')
    try:
        r = multiquest.get(get_source()['zip'], headers={'User-Agent': 'MovieScout'}, timeout=180)
        if r.status_code != 200 or len(r.content) < 100000:
            raise RuntimeError('Download fehlgeschlagen (HTTP %s)' % r.status_code)
        zf = zipfile.ZipFile(io.BytesIO(r.content))
        names = zf.namelist()
        # Ordner "resolveurl" mit __init__.py und plugins/ suchen (auch wenn das Archiv anders aufgebaut ist)
        cands = [n for n in names if n.endswith('/resolveurl/__init__.py') and (n[:-len('__init__.py')] + 'plugins/__init__.py') in names]
        if not cands:
            raise RuntimeError('ResolveURL im Download nicht gefunden')
        init = min(cands, key=len)
        base = init[:-len('__init__.py')]
        version, probe = '', base
        for _ in range(4):                                    # addon.xml in den übergeordneten Ordnern suchen
            probe = probe.rstrip('/').rsplit('/', 1)[0] + '/' if '/' in probe.rstrip('/') else ''
            if probe + 'addon.xml' in names:
                version = _xml_version(zf.read(probe + 'addon.xml').decode('utf-8', 'replace'))
                break
            if not probe:
                break
        if not version:
            version = '99.' + time.strftime('%y%m%d')       # keine Versionsnummer im Archiv: Datum als Ersatz
        shutil.rmtree(new, ignore_errors=True)
        target = (new / 'resolveurl')
        n_files = 0
        for n in names:
            if not n.startswith(base) or n.endswith('/') or '__pycache__' in n or n.endswith('.pyc'):
                continue
            rel = n[len(base):]
            dest = (target / rel).resolve()
            if target.resolve() not in dest.parents:
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(zf.read(n))
            n_files += 1
        if n_files < 100 or not (target / 'plugins').is_dir():
            raise RuntimeError('Download unvollständig (%d Dateien)' % n_files)
        lic = Path(_VENDOR) / 'resolveurl' / 'LICENSE'
        try:                                            # GPL-2.0 bleibt dabei; nur die Bytes kopieren (keine Rechte der Vorlage)
            if lic.exists():
                (target / 'LICENSE').write_bytes(lic.read_bytes())
        except OSError:
            pass                                        # Lizenzdatei ist Beiwerk: ihr Fehlen darf das Update nicht stoppen
        (new / 'version.txt').write_text(version + '\n', encoding='utf-8')

        with _lock:
            step = 'alte Version beiseite legen'
            try:
                _rm(old)
                had = _UPD.exists()
                if had:
                    _mv(_UPD, old)
                step = 'neue Version einspielen'
                _mv(new, _UPD)
            except OSError as e:
                raise RuntimeError('Update fehlgeschlagen beim Schritt „%s“: %s' % (step, e))
            try:
                _import_locked(force=True)
                if _ru is None or not _override:
                    raise RuntimeError(_ru_error or 'Neue Version lässt sich nicht laden')
            except Exception:
                # zurück zur bisherigen Version
                _purge()
                _drop_override_path()
                _rm(_UPD)
                _rm(str(_UPD) + '.defekt')
                if had and old.exists():
                    _mv(old, _UPD)
                _import_locked(force=had)
                raise
            _rm(old)
        log.log('[resolvers] ResolveURL auf %s aktualisiert' % version)
        return status()
    finally:
        _rm(new)
        _upd_lock.release()
