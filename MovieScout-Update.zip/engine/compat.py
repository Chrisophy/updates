# -*- coding: utf-8 -*-
"""Kompatibilitäts-Check für Kodi-Addons.

Liest den Python-Code eines Addons, ohne ihn auszuführen (ast), und vergleicht, was er braucht, mit dem, was MovieScout kann:
  * xbmc / xbmcgui / xbmcaddon / xbmcplugin / xbmcvfs: jede benutzte Funktion, Klasse und Konstante gegen die eingebaute Nachbildung
  * xbmc.executebuiltin(…) und xbmc.executeJSONRPC(…): bekannte Befehle
  * import-Anweisungen: Standardbibliothek, mitgeliefert, aus einer Bibliothek (script.module.*), als Python-Paket vorhanden – oder nicht
  * Python 2, Skin-Fenster (WindowXML), DRM, externe Programme, Desktop-Fenster (Tk)
Ergebnis: {'verdict': 'ok'|'limited'|'no', 'label', 'score', 'findings': [{'level','code','text','count','where'}], 'stats', 'needs'}.
Das ist eine Einschätzung aus dem Code, kein Probelauf – deshalb „voraussichtlich“.
"""
import ast
import importlib.util
import inspect
import io
import logging
import re
import sys
import time
import zipfile

log = logging.getLogger('engine.compat')

MAX_PY_FILES = 1500
MAX_PY_BYTES = 1536 * 1024
BUDGET_SECONDS = 12.0
KODI_MODS = ('xbmc', 'xbmcgui', 'xbmcaddon', 'xbmcplugin', 'xbmcvfs', 'inputstreamhelper')
LABELS = {'ok': 'Läuft voraussichtlich', 'limited': 'Läuft voraussichtlich eingeschränkt', 'no': 'Läuft voraussichtlich nicht'}

PY2_MODULES = {'urllib2', 'urlparse', 'cookielib', 'htmlparser', 'httplib', 'stringio', 'cpickle', 'thread', 'xmlrpclib', '__builtin__',
               'commands', 'md5', 'sha', 'htmlentitydefs', 'basehttpserver', 'simplehttpserver', 'sets', 'cgihttpserver', 'dummy_thread', 'cookie'}
PY2_NAMES = {'unicode', 'xrange', 'raw_input', 'basestring', 'unichr', 'long', 'cmp', 'execfile', 'reload', 'file'}
PY2_ATTRS = {'iteritems', 'itervalues', 'iterkeys', 'has_key'}
DESKTOP_MODULES = {'tkinter', 'pygame', 'curses', 'wx', 'gi', 'pyqt5', 'pyqt6', 'pyside2', 'pyside6', 'win32api', 'win32gui', 'msvcrt', 'winreg', '_winreg'}
UNAVAILABLE_KODI = {'xbmcdrm'}
SKIN_UNSUPPORTED = {'videowindow', 'visualisation', 'mover', 'resize', 'gamewindow', 'rss', 'epggrid', 'subtitles'}   # Skin-Elemente ohne Darstellung
# Kennung -> Modulname(n), wenn der Name nicht aus der Kennung ableitbar ist
LIB_MODULES = {
    'script.module.beautifulsoup4': ('bs4',), 'script.module.bs4': ('bs4',), 'script.module.pil': ('PIL',), 'script.module.pillow': ('PIL',),
    'script.module.pycryptodome': ('Cryptodome', 'Crypto'), 'script.module.kodi-six': ('kodi_six', 'six'), 'script.module.dnspython': ('dns',),
    'script.module.pyyaml': ('yaml',), 'script.module.dateutil': ('dateutil',), 'script.module.websocket': ('websocket',),
    'script.module.requests': ('requests',), 'script.module.resolveurl': ('resolveurl',), 'script.module.urlresolver': ('urlresolver', 'resolveurl'),
    'script.module.inputstreamhelper': ('inputstreamhelper',), 'script.module.addon.signals': ('addon_signals',),
}

_API = None


# ----------------------------------------------------------------------------- Umfang der eingebauten Kodi-Nachbildung

def _has_catchall(cls):
    return any('__getattr__' in vars(k) for k in cls.__mro__ if k is not object)


def api():
    """{modul: {'names': set, 'classes': {name: (set(members), catchall)}}} – aus kodi_runtime selbst gelesen."""
    global _API
    if _API is None:
        import kodi_runtime  # noqa: F401  (registriert die Module)
        out = {}
        for name in KODI_MODS:
            m = sys.modules.get(name)
            if m is None:
                continue
            classes = {}
            for k in dir(m):
                v = getattr(m, k, None)
                if inspect.isclass(v):
                    classes[k] = (set(dir(v)), _has_catchall(v))
            out[name] = {'names': set(dir(m)), 'classes': classes}
        _API = out
    return _API


def _skin_lists():
    try:
        from kodi_runtime import skin
        return set(getattr(skin, 'BUILTINS_OK', ())), set(getattr(skin, 'JSONRPC_OK', ()))
    except Exception:                                               # noqa: BLE001
        return set(), set()


def _windowxml_supported():
    try:
        from kodi_runtime import xbmcgui
        return bool(getattr(xbmcgui, 'WINDOWXML', False))
    except Exception:                                               # noqa: BLE001
        return False


# ----------------------------------------------------------------------------- Einzelne Datei

class _Scan:
    def __init__(self, path):
        self.path = path
        self.imports = []            # (modulname, zeile, geschützt, bedingt)
        self.missing = []            # (beschreibung, zeile)
        self.used = set()            # 'xbmc.Monitor'
        self.builtins = []           # (name, zeile)
        self.rpc = []                # (methode, zeile)
        self.py2 = []                # (text, zeile)
        self.windowxml = []          # zeilen
        self.flags = set()           # 'drm', 'subprocess', 'syspath'
        self.lines = 0
        self.syntax = False


def _guards(handlers):
    for h in handlers:
        if h.type is None:
            return True
        names = [n.id for n in ast.walk(h.type) if isinstance(n, ast.Name)]
        if any(n in ('ImportError', 'ModuleNotFoundError', 'Exception', 'BaseException') for n in names):
            return True
    return False


class _Visitor(ast.NodeVisitor):
    def __init__(self, sc, A):
        self.sc, self.A = sc, A
        self.mod_alias = {}          # lokaler Name -> xbmc-Modul
        self.cls_alias = {}          # lokaler Name -> (modul, klasse)
        self.guard = 0               # innerhalb eines try, das ImportError abfängt (Rumpf und except-Zweige)
        self.cond = 0                # innerhalb von Funktion / if / try
        self.inst = {}               # Schlüssel -> (modul, klasse) für Variablen, die nur je eine Kodi-Instanz bekommen
        self.defined = set()
        self.loaded = []

    # --- Vorlauf: Namen der Kodi-Module und -Klassen, dann Variablen mit eindeutiger Kodi-Klasse
    def prepare(self, tree):
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    if a.name in KODI_MODS:
                        self.mod_alias[a.asname or a.name] = a.name
            elif isinstance(node, ast.ImportFrom) and not node.level and node.module in KODI_MODS:
                top = node.module
                for a in node.names:
                    if a.name == '*':
                        for k in self.A.get(top, {}).get('classes', {}):
                            self.cls_alias[k] = (top, k)
                    elif a.name in self.A.get(top, {}).get('classes', {}):
                        self.cls_alias[a.asname or a.name] = (top, a.name)
        stores, kodi = {}, {}

        def bump(d, k):
            if k:
                d[k] = d.get(k, 0) + 1

        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                bump(stores, node.id)
            elif isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Store):
                bump(stores, self._key(node))
            elif isinstance(node, ast.arg):
                bump(stores, node.arg)
            elif isinstance(node, ast.ExceptHandler):
                bump(stores, node.name)
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                for a in node.names:
                    bump(stores, (a.asname or a.name).split('.')[0])
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                bump(stores, node.name)
            if isinstance(node, (ast.Assign, ast.AnnAssign)) and isinstance(node.value, ast.Call):
                kc = self._kodi_class(node.value.func)
                if kc:
                    for t in (node.targets if isinstance(node, ast.Assign) else [node.target]):
                        k = self._key(t)
                        if k:
                            bump(kodi, (k, kc))
        per = {}
        for (k, kc), n in kodi.items():
            per.setdefault(k, []).append((kc, n))
        for k, lst in per.items():
            if len(lst) == 1 and lst[0][1] == stores.get(k, 0):
                self.inst[k] = lst[0][0]

    # --- Importe
    def visit_Import(self, node):
        for a in node.names:
            top = a.name.split('.')[0]
            self.sc.imports.append((top, node.lineno, self.guard > 0, self.cond > 0))
            self.defined.add(a.asname or top)

    def visit_ImportFrom(self, node):
        if node.level:
            return
        top = (node.module or '').split('.')[0]
        self.sc.imports.append((top, node.lineno, self.guard > 0, self.cond > 0))
        for a in node.names:
            self.defined.add(a.asname or a.name)
            if top in KODI_MODS and node.module == top and a.name != '*':
                self.sc.used.add('%s.%s' % (top, a.name))
                if a.name not in self.A.get(top, {}).get('names', ()):
                    self.sc.missing.append(('%s.%s' % (top, a.name), node.lineno))

    def visit_Try(self, node):
        g = _guards(node.handlers)
        self.cond += 1
        self.guard += 1 if g else 0
        for n in node.body + node.handlers:                         # auch der except-Zweig gehört dazu: dort steht oft der Python-2-Ausweg
            self.visit(n)
        self.guard -= 1 if g else 0
        for n in node.orelse + node.finalbody:
            self.visit(n)
        self.cond -= 1

    visit_TryStar = visit_Try

    def visit_If(self, node):
        self.cond += 1
        self.generic_visit(node)
        self.cond -= 1

    # --- Definitionen
    def visit_FunctionDef(self, node):
        self.defined.add(node.name)
        self.cond += 1
        self.generic_visit(node)
        self.cond -= 1

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_arg(self, node):
        self.defined.add(node.arg)

    def visit_ClassDef(self, node):
        self.defined.add(node.name)
        for b in node.bases:
            kc = self._kodi_class(b)
            if kc and kc[1] in ('WindowXML', 'WindowXMLDialog'):
                self.sc.windowxml.append(node.lineno)
        self.generic_visit(node)

    def visit_Name(self, node):
        if isinstance(node.ctx, ast.Store):
            self.defined.add(node.id)
        elif isinstance(node.ctx, ast.Load) and node.id in PY2_NAMES:
            self.loaded.append((node.id, node.lineno))

    # --- Hilfen
    def _kodi_class(self, n):
        """Ausdruck, der eine Kodi-Klasse benennt -> (modul, klasse) oder None."""
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in self.mod_alias:
            mod = self.mod_alias[n.value.id]
            if n.attr in self.A.get(mod, {}).get('classes', {}):
                return mod, n.attr
        if isinstance(n, ast.Name) and n.id in self.cls_alias:
            return self.cls_alias[n.id]
        return None

    @staticmethod
    def _key(n):
        if isinstance(n, ast.Name):
            return n.id
        if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id in ('self', 'cls'):
            return 'self.' + n.attr
        return None

    def visit_Attribute(self, node):
        v = node.value
        if node.attr in PY2_ATTRS:
            self.sc.py2.append(('.%s()' % node.attr, node.lineno))
        if isinstance(v, ast.Name) and v.id in self.mod_alias:
            mod = self.mod_alias[v.id]
            full = '%s.%s' % (mod, node.attr)
            self.sc.used.add(full)
            if node.attr not in self.A.get(mod, {}).get('names', ()) and not node.attr.startswith('__'):
                self.sc.missing.append((full, node.lineno))
        self.generic_visit(node)

    def visit_Call(self, node):
        f = node.func
        if isinstance(f, ast.Attribute):
            # Methode direkt an einer neuen Instanz oder an einer eindeutigen Variable: xbmcgui.Dialog().ok(…), dlg.ok(…)
            kc = self._kodi_class(f.value.func) if isinstance(f.value, ast.Call) else self.inst.get(self._key(f.value))
            if kc:
                members, catch = self.A[kc[0]]['classes'][kc[1]]
                if f.attr not in members and not catch and not f.attr.startswith('__'):
                    self.sc.missing.append(('%s.%s().%s' % (kc[0], kc[1], f.attr), node.lineno))
                else:
                    self.sc.used.add('%s.%s.%s' % (kc[0], kc[1], f.attr))
            if f.attr == 'executebuiltin' and node.args:
                s = _const_str(node.args[0])
                nm = re.split(r'[(\s]', (s or '').strip(), 1)[0].lower().strip('"\'')
                if nm and re.fullmatch(r'[a-z][a-z0-9_.]*', nm):
                    self.sc.builtins.append((nm, node.lineno))
            elif f.attr == 'executeJSONRPC' and node.args:
                m = re.search(r'"method"\s*:\s*"([A-Za-z.]+)"', _const_str(node.args[0]) or '')
                if m:
                    self.sc.rpc.append((m.group(1), node.lineno))
            elif f.attr in ('append', 'insert') and isinstance(f.value, ast.Attribute) and f.value.attr == 'path' \
                    and isinstance(f.value.value, ast.Name) and f.value.value.id == 'sys':
                self.sc.flags.add('syspath')
            elif f.attr in ('Popen', 'system', 'popen', 'check_output', 'check_call', 'run') and isinstance(f.value, ast.Name) \
                    and f.value.id in ('subprocess', 'os'):
                self.sc.flags.add('subprocess')
        kc2 = self._kodi_class(f)
        if kc2 and kc2[1] in ('WindowXML', 'WindowXMLDialog'):
            self.sc.windowxml.append(node.lineno)
        self.generic_visit(node)


def _const_str(n):
    if isinstance(n, ast.Constant) and isinstance(n.value, str):
        return n.value
    if isinstance(n, ast.JoinedStr):                                # f"RunScript({x})": den festen Anfang nehmen
        for p in n.values:
            if isinstance(p, ast.Constant) and isinstance(p.value, str):
                return p.value
            break
    if isinstance(n, ast.BinOp) and isinstance(n.op, (ast.Add, ast.Mod)):
        return _const_str(n.left)
    return None


def scan_source(path, text, A=None):
    A = A or api()
    sc = _Scan(path)
    sc.lines = text.count('\n') + 1
    try:
        tree = ast.parse(text, filename=path)
    except SyntaxError as e:
        sc.py2.append(('Syntaxfehler (vermutlich Python 2): %s' % (e.msg,), e.lineno or 0))
        sc.syntax = True
        return sc
    except (ValueError, RecursionError, MemoryError):
        sc.py2.append(('Datei nicht lesbar', 0))
        sc.syntax = True
        return sc
    vis = _Visitor(sc, A)
    vis.prepare(tree)
    vis.visit(tree)
    for nm, ln in vis.loaded:
        if nm not in vis.defined:
            sc.py2.append((nm, ln))
    low = text.lower()
    if 'com.widevine.alpha' in low or 'inputstream.adaptive.license' in low or 'drm_legacy' in low:
        sc.flags.add('drm')
    return sc


# ----------------------------------------------------------------------------- Ganzes Addon

def _top_names(paths, deep):
    """Module, die der Addon-Ordner selbst bietet."""
    names = set()
    for p in paths:
        parts = p.split('/')
        if len(parts) == 1 and p.endswith('.py'):
            names.add(p[:-3])
        elif len(parts) > 1:
            names.add(parts[0])
        if deep:
            for i, s in enumerate(parts):
                names.add(s[:-3] if s.endswith('.py') else s)
    return names


def _dep_modules(requires):
    """Modulnamen, die die verlangten Bibliotheken liefern (bekannt, installiert oder aus der Kennung geraten) + ob es unbekannte gibt."""
    mods, unknown = set(), []
    try:
        from . import addonhost as AH
    except Exception:                                               # noqa: BLE001
        AH = None
    for r in requires or []:
        rid = r.get('id') or ''
        if not rid.startswith('script.module.') and not rid.startswith('script.'):
            continue
        got = set(LIB_MODULES.get(rid, ()))
        suffix = rid.split('.', 2)[-1] if rid.startswith('script.module.') else rid.split('.')[-1]
        for variant in (suffix, suffix.replace('.', '_'), suffix.replace('-', '_'), suffix.replace('.', '').replace('-', ''), suffix.split('.')[-1]):
            got.add(variant)
        if AH is not None:
            try:
                d = AH.module_lib_dir(rid)
                if d:
                    for e in d.iterdir():
                        got.add(e.stem if e.is_file() else e.name)
            except Exception:                                       # noqa: BLE001
                pass
        mods |= {g.lower() for g in got}
        if rid not in LIB_MODULES and not (AH and AH.meta(rid)):
            unknown.append(rid)
    return mods, unknown


def _importable(top):
    try:
        return importlib.util.find_spec(top) is not None
    except (ImportError, ValueError, AttributeError):
        return False


_PYC_MAGIC = {3394: '3.7', 3413: '3.8', 3425: '3.9', 3439: '3.10', 3495: '3.11', 3531: '3.12', 3571: '3.13', 3627: '3.14'}


def pyc_name(magic):
    """Die ersten 4 Bytes einer .pyc-Datei -> Python-Version als Text ('3.11') oder '?'."""
    if len(magic or b'') < 4:
        return '?'
    return _PYC_MAGIC.get(int.from_bytes(magic[:2], 'little'), '?')


def pyc_versions(files):
    """Dateien, die es nur als .pyc gibt (ohne gleichnamige .py): {'files': [Pfade], 'other': [Versionen, die nicht zu dieser Engine passen], 'current': '3.x'}."""
    import importlib.util
    cur = '%d.%d' % sys.version_info[:2]
    names = set(files)
    only, other = [], []
    for p in sorted(files):
        if not p.endswith('.pyc') or '__pycache__/' in p:          # __pycache__ ist nur Zwischenspeicher, wird nie ohne Quelltext geladen
            continue
        if p[:-1] in names:                                   # lib/api.py liegt daneben
            continue
        only.append(p)
        magic = files[p]
        if len(magic) >= 4 and magic[:4] != importlib.util.MAGIC_NUMBER:
            v = pyc_name(magic)
            v = v if v != '?' else 'anderer Version'
            if v not in other:
                other.append(v)
    return {'files': only, 'other': other, 'current': cur}


def scan_files(files, info=None, budget=BUDGET_SECONDS):
    """files: {relativer Pfad: bytes} (ohne Addon-Ordner davor); info: Ergebnis von addonhost._parse_xml (optional)."""
    t0 = time.time()
    A = api()
    info = info or {}
    paths = [p for p in files if not p.endswith('/')]
    py = sorted(p for p in paths if p.endswith('.py'))
    notes = []
    scans = []
    skipped = 0
    for p in py[:MAX_PY_FILES]:
        raw = files[p]
        if len(raw) > MAX_PY_BYTES:
            skipped += 1
            continue
        if time.time() - t0 > budget:
            skipped += len(py) - len(scans) - skipped
            break
        scans.append(scan_source(p, raw.decode('utf-8-sig', 'replace'), A))
    skipped += max(0, len(py) - MAX_PY_FILES)

    F = []                                                          # Befunde

    def add(level, code, text, where=None, count=1):
        F.append({'level': level, 'code': code, 'text': text, 'count': count, 'where': (where or [])[:3]})

    def loc(sc, ln):
        return '%s:%s' % (sc.path, ln) if ln else sc.path

    # Python 2 / unlesbar
    syn = [s for s in scans if getattr(s, 'syntax', False)]
    if syn:
        add('error', 'py2', 'Python-2-Code oder Syntaxfehler in %d Datei(en). MovieScout führt nur Python 3 aus (wie Kodi ab Version 19).' % len(syn),
            [loc(s, s.py2[0][1]) for s in syn])
    rest = [(s, t, ln) for s in scans if not getattr(s, 'syntax', False) for t, ln in s.py2]
    if rest:
        names = sorted({t for _, t, _ in rest})
        add('warn', 'py2rest', 'Reste von Python 2 im Code (%s) – das stürzt zur Laufzeit ab, sobald die Stelle drankommt.' % ', '.join(names[:6]),
            [loc(s, ln) for s, _, ln in rest], len(rest))

    # Skin-Fenster
    wx = [(s, ln) for s in scans for ln in s.windowxml]
    if wx:
        if _windowxml_supported():
            add('info', 'windowxml', 'Das Addon öffnet Fenster aus Skin-Dateien (WindowXML). MovieScout zeigt sie vereinfacht an – '
                                     'Bedienung und Aussehen können vom Original abweichen.', [loc(s, ln) for s, ln in wx], len(wx))
            skins = [p for p in paths if p.lower().endswith('.xml') and '/skins/' in '/' + p.replace('\\', '/').lower()]
            if not skins:
                add('warn', 'windowxml_files', 'Im Paket liegen keine Skin-Dateien (resources/skins/…/*.xml) – das Fenster lässt sich nur öffnen, '
                                               'wenn das Addon sie anderswo mitbringt.', [loc(s, ln) for s, ln in wx], 1)
            else:
                odd = {}
                for sp in skins[:200]:
                    raw = files[sp][:MAX_PY_BYTES]
                    for t in re.findall(rb'<control[^>]*\btype\s*=\s*["\'](\w+)', raw):
                        t = t.decode('ascii', 'ignore').lower()
                        if t in SKIN_UNSUPPORTED:
                            odd.setdefault(t, sp)
                if odd:
                    add('info', 'windowxml_parts', 'Die Skin-Dateien nutzen Elemente, die MovieScout nicht zeichnet (%s). Der Rest des Fensters erscheint trotzdem.'
                        % ', '.join(sorted(odd)), [sp for sp in list(odd.values())[:3]], len(odd))
        else:
            add('error', 'windowxml', 'Das Addon öffnet Fenster aus Skin-Dateien (WindowXML). Solche Fenster zeigt MovieScout noch nicht an.',
                [loc(s, ln) for s, ln in wx], len(wx))

    # Fehlende Kodi-Funktionen
    miss = {}
    for s in scans:
        for name, ln in s.missing:
            miss.setdefault(name, []).append(loc(s, ln))
    kodi_na = {}
    for s in scans:
        for top, ln, _g, _c in s.imports:
            if top in UNAVAILABLE_KODI:
                kodi_na.setdefault(top, []).append(loc(s, ln))
    if kodi_na:
        add('warn', 'api', 'Benötigt Kodi-Teile, die MovieScout nicht hat: %s.' % ', '.join(sorted(kodi_na)), sum(kodi_na.values(), []), len(kodi_na))
    others = sorted(miss)
    if others:
        add('warn', 'api', '%d Kodi-Funktion(en) fehlen in MovieScout: %s%s. Wird eine davon aufgerufen, bricht das Addon an der Stelle ab.'
            % (len(others), ', '.join(others[:8]), ' …' if len(others) > 8 else ''), sum((miss[n] for n in others), []), len(others))

    # Befehle und JSON-RPC
    ok_b, ok_r = _skin_lists()
    if ok_b:
        bad = {}
        for s in scans:
            for nm, ln in s.builtins:
                if nm and nm not in ok_b:
                    bad.setdefault(nm, []).append(loc(s, ln))
        if bad:
            add('info', 'builtin', 'Diese Kodi-Befehle (executebuiltin) werden ignoriert: %s.' % ', '.join(sorted(bad)[:8]), sum(bad.values(), []), len(bad))
    if ok_r:
        badr = {}
        for s in scans:
            for nm, ln in s.rpc:
                if nm not in ok_r:
                    badr.setdefault(nm, []).append(loc(s, ln))
        if badr:
            add('info', 'rpc', 'Diese JSON-RPC-Aufrufe liefern nur leere Antworten: %s.' % ', '.join(sorted(badr)[:8]), sum(badr.values(), []), len(badr))

    # Importe
    deep = any('syspath' in s.flags for s in scans)
    local = _top_names(paths, deep) | {info.get('pkg') or '-'}
    for k in ('library', 'script_lib', 'service_lib'):                  # wie Kodi: der Ordner der Startdatei ist importierbar
        e = info.get(k) or ''
        if '/' in e:
            d = e.rsplit('/', 1)[0].rstrip('/') + '/'
            local |= _top_names([p[len(d):] for p in paths if p.startswith(d)], False)
    local_l = {n.lower() for n in local}
    dep_mods, unknown_deps = _dep_modules(info.get('requires'))
    stdlib = getattr(sys, 'stdlib_module_names', frozenset())
    stdlib_l = {x.lower() for x in stdlib}
    bad_imp, guarded, desktop, py2m = {}, {}, {}, {}
    for s in scans:
        if getattr(s, 'syntax', False):
            continue
        for top, ln, g, c in s.imports:
            tl = top.lower()
            if not top or top == '__future__' or top in stdlib or top in KODI_MODS or tl in local_l:
                if tl in DESKTOP_MODULES and tl in stdlib_l and not (g or c):
                    desktop.setdefault(top, []).append(loc(s, ln))
                continue
            if tl in PY2_MODULES:
                (guarded if (g or c) else py2m).setdefault(top, []).append(loc(s, ln))
            elif tl in DESKTOP_MODULES:
                (guarded if (g or c) else desktop).setdefault(top, []).append(loc(s, ln))
            elif top in UNAVAILABLE_KODI:
                continue
            elif tl in dep_mods or _importable(top):
                continue
            else:
                (guarded if (g or c) else bad_imp).setdefault(top, []).append(loc(s, ln))
    if desktop:
        add('error', 'desktop', 'Benötigt ein Desktop-Fenster (%s) – das gibt es in MovieScout nicht.' % ', '.join(sorted(desktop)),
            sum(desktop.values(), []), len(desktop))
    if py2m:
        add('error', 'py2', 'Benutzt Python-2-Module (%s).' % ', '.join(sorted(py2m)), sum(py2m.values(), []), len(py2m))
    if bad_imp:
        if unknown_deps:
            add('info', 'import', 'Module %s kommen vermutlich aus den Bibliotheken, die das Addon braucht (%s) und werden beim Installieren nachgeladen.'
                % (', '.join(sorted(bad_imp)[:6]), ', '.join(unknown_deps[:4])), sum(bad_imp.values(), []), len(bad_imp))
        else:
            add('warn', 'import', 'Diese Python-Module fehlen: %s. Sie liegen weder im Addon noch in einer verlangten Bibliothek noch in Python.'
                % ', '.join(sorted(bad_imp)[:6]), sum(bad_imp.values(), []), len(bad_imp))
    if guarded:
        add('info', 'import-optional', 'Module nicht vorhanden, aber nur optional oder an bestimmten Stellen gebraucht (das Addon fängt das ab): %s.' % ', '.join(sorted(guarded)[:6]),
            sum(guarded.values(), []), len(guarded))

    # Nur vorkompilierter Code (.pyc ohne .py): läuft nur mit der Python-Version, für die er gebaut wurde
    pv = pyc_versions(files)
    if pv['files']:
        sample = ', '.join(pv['files'][:3])
        if pv['other']:
            add('warn', 'pyc-version', 'Teile des Addons liegen nur als vorkompilierter Code vor (%s), gebaut für Python %s. Diese Engine läuft mit Python %s – dort lässt sich der Code nicht laden.'
                % (sample, ' / '.join(pv['other']), pv['current']), pv['files'], len(pv['files']))
        else:
            add('info', 'pyc-only', 'Teile des Addons liegen nur als vorkompilierter Code vor (%s, Python %s). Sie passen zu dieser Engine, lassen sich aber nicht prüfen.'
                % (sample, pv['current']), pv['files'], len(pv['files']))

    # Weiteres
    flags = set().union(*[s.flags for s in scans]) if scans else set()
    if 'drm' in flags:
        add('warn', 'drm', 'Streams mit DRM-Schutz (Widevine) lassen sich in MovieScout nicht abspielen.')
    if 'subprocess' in flags:
        add('info', 'subprocess', 'Startet externe Programme (subprocess/os.system). Auf Android und in vielen Umgebungen geht das nicht.')
    if skipped:
        add('info', 'skipped', '%d sehr große oder überzählige Python-Dateien wurden nicht geprüft (die Einschätzung gilt für den Rest).' % skipped)
    if not py:
        add('info', 'nopy', 'Das Addon enthält keinen Python-Code (nur Daten, Bilder oder Texte).')

    # Abhängigkeiten, die noch fehlen
    needs = []
    try:
        from . import addonrepo as AR
        needs = AR.missing(info) if info.get('requires') else []
    except Exception:                                               # noqa: BLE001
        needs = []
    if needs:
        add('info', 'needs', 'Braucht noch: %s (MovieScout lädt das aus dem Kodi-Repository nach).' % ', '.join(needs[:8]), count=len(needs))

    order = {'error': 0, 'warn': 1, 'info': 2}
    F.sort(key=lambda f: order[f['level']])
    errs = sum(1 for f in F if f['level'] == 'error')
    warns = sum(1 for f in F if f['level'] == 'warn')
    verdict = 'no' if errs else ('limited' if warns else 'ok')
    apis = sorted({u for s in scans for u in s.used})
    return {'verdict': verdict, 'label': LABELS[verdict], 'score': max(0, 100 - 45 * errs - 12 * warns), 'findings': F,
            'stats': {'files': len(py), 'lines': sum(s.lines for s in scans), 'apis': len(apis)}, 'needs': needs}


def scan_zip(data):
    """ZIP (Bytes) prüfen, ohne zu installieren. -> (info, report). Wirft addonhost.AddonError bei kaputten Paketen."""
    from . import addonhost as AH
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise AH.AddonError('Das ist keine ZIP-Datei.')
    AH._safe_members(zf)
    xmls = [n for n in zf.namelist() if n.replace('\\', '/').count('/') <= 1 and n.replace('\\', '/').endswith('addon.xml')]
    if not xmls:
        raise AH.AddonError('Keine addon.xml gefunden – das ist kein Kodi-Addon.')
    xmln = sorted(xmls, key=lambda n: n.count('/'))[0].replace('\\', '/')
    base = xmln[:-len('addon.xml')]
    info = AH._parse_xml(zf.read(xmln).decode('utf-8-sig', 'replace'))
    files, obf = {}, ''
    for i in zf.infolist():
        n = i.filename.replace('\\', '/')
        if not n.startswith(base) or n.endswith('/'):
            continue
        rel = n[len(base):]
        if rel.endswith('.py') and i.file_size <= MAX_PY_BYTES and len(files) < 5000:
            raw = zf.read(i)
            if AH._obfuscated(raw):
                obf = obf or rel
            files[rel] = raw
        elif rel.endswith('.pyc') and len(files) < 5000:
            files[rel] = zf.read(i)[:4]                       # nur die Kennung der Python-Version (siehe pyc_versions)
        else:
            files[rel] = b''
    rep = scan_files(files, info)
    if info['kind'] == 'other':
        rep['findings'].insert(0, {'level': 'error', 'code': 'type', 'count': 1, 'where': [],
                                   'text': 'Dieser Addon-Typ wird nicht unterstützt (%s).' % (', '.join(p for p in info['points'] if p and p != 'xbmc.addon.metadata') or 'ohne Einstiegspunkt')})
    if obf:
        rep['findings'].insert(0, {'level': 'error', 'code': 'obfuscated', 'count': 1, 'where': [obf],
                                   'text': 'Der Code ist verschleiert (gepackter Text/Bytecode). Solche Addons bringen die Engine zum Absturz; MovieScout lehnt sie ab.'})
    if info['kind'] == 'other' or obf:
        rep.update(verdict='no', label=LABELS['no'], score=0)
    return info, rep


def scan_installed(addon_id):
    """Bereits installiertes Addon neu prüfen (liest die Dateien aus dem Addon-Ordner)."""
    from . import addonhost as AH
    d = AH.addon_path(addon_id)
    m = AH.meta(addon_id)
    if not m or not d.is_dir():
        raise AH.AddonError('Addon nicht installiert.')
    files = {}
    for p in d.rglob('*.py'):
        rel = p.relative_to(d).as_posix()
        if p.stat().st_size <= MAX_PY_BYTES and len(files) < 5000:
            files[rel] = p.read_bytes()
    for p in d.rglob('*'):
        if p.is_file() and not p.name.endswith('.py'):
            rel = p.relative_to(d).as_posix()
            if p.name.endswith('.pyc'):
                try:
                    with open(p, 'rb') as fh:
                        files.setdefault(rel, fh.read(4))
                except OSError:
                    files.setdefault(rel, b'')
            else:
                files.setdefault(rel, b'')
    return scan_files(files, m)


def brief(rep):
    """Kurzfassung für Listen und die Datei moviescout-addon.json."""
    if not rep:
        return None
    return {'verdict': rep['verdict'], 'label': rep['label'], 'score': rep['score'],
            'errors': sum(1 for f in rep['findings'] if f['level'] == 'error'),
            'warnings': sum(1 for f in rep['findings'] if f['level'] == 'warn'),
            'top': [f['text'] for f in rep['findings'] if f['level'] in ('error', 'warn')][:3]}
