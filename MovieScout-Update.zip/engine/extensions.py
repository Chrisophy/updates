# -*- coding: utf-8 -*-
"""Erweiterungen: Python-Skripte aus userData/user/extensions/*.py.

Hooks (alle optional)             Zweck
  register(api)                   einmal beim Laden: Routen, Zeitplan, Oberfläche anmelden
  on_load()                       einmal beim Laden (nach register)
  process_items(pid, items)       Einträge vor der Oberfläche ändern (Liste zurück oder None)
  process_hosters(pid, item, hs)  Streams filtern/sortieren/ergänzen (Liste zurück oder None)
  on_play(item, info)             Wiedergabe wurde gestartet
  on_stop(item, info)             Wiedergabe beendet (info: position, duration in Sekunden, finished)

Angebote im register(api):
  api.route('pfad', fn)           eigene Route  ->  /api/x/<EXT_ID>/pfad
  api.every(minuten, fn)          regelmäßige Aufgabe im Hintergrund
  api.home_row('Titel', fn)       eigene Reihe auf der Startseite (fn() -> Liste von Einträgen)
  api.menu('Titel', fn)           eigener Menüpunkt auf der Startseite (fn() -> Liste von Einträgen)
  api.item_action('Titel', fn)    eigener Knopf in der Titel-Info (fn(eintrag) -> Text oder dict)
  api.open(pid, item)             Ordner einer Quelle öffnen (Liste von Einträgen)
  api.resolve(pid, item)          Streams zu einem Eintrag holen
  api.search(pid, text)           eine Quelle durchsuchen (Liste von Einträgen)
  api.fail('Text')                Klartext-Fehler für den Nutzer (statt technischer Meldung)
  api.chat(text, item)            Nachricht in den Familienchat schreiben
  api.get / api.set               eigene Werte speichern (EXT_SETTINGS-Felder stehen dort ebenfalls)

EXT_GUEST = True                 (nur Spiele für mehrere Geräte) Mit „Teilen im WLAN“ angemeldete Gäste dürfen die Seiten und Routen dieser Erweiterung nutzen
EXT_SETTINGS = [{'key': 'x', 'label': 'Text', 'type': 'text|number|bool|select|textarea', 'default': …}]
  erzeugt in der Erweiterungsliste ein Einstellungsformular; die Werte liest die Erweiterung mit api.get('x').

Eigene Routen:  Handler fn(req) mit req.method / req.query / req.json / req.body / req.headers.
                Rückgabe: dict -> JSON, str -> HTML, bytes -> Datei, (inhalt, status) möglich.
"""
import importlib.util
import json
import logging
import re
import sys
import threading
import time
import traceback

from . import system as S

log = logging.getLogger('ext')
EXTS = {}            # ext_id -> Extension
TASKS = []           # alle angemeldeten Zeitplan-Aufgaben (aktive Erweiterungen)
_lock = threading.RLock()
CHAT_POST = None     # setzt die App: fn(text, author, item) -> Nachricht (Familienchat)
HOOK_NAMES = ('register', 'on_load', 'process_items', 'process_hosters', 'on_play', 'on_stop')
MAX_ROW_ITEMS = 120


class Request:
    def __init__(self, method='GET', query=None, body=b'', headers=None, path=''):
        self.method, self.query, self.body, self.headers, self.path = method, query or {}, body or b'', headers or {}, path
        self._json = None

    @property
    def json(self):
        if self._json is None:
            try:
                d = json.loads(self.body.decode('utf-8')) if self.body else {}
                self._json = d if isinstance(d, (dict, list)) else {}
            except Exception:
                self._json = {}
        return self._json


def _slug(text, fallback='x'):
    s = str(text or '').lower().translate(str.maketrans({'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'ß': 'ss'}))
    s = re.sub(r'[^a-z0-9]+', '_', s).strip('_')[:40]
    return s or fallback


class UserError(Exception):
    """Fehler mit Klartext, der dem Nutzer ohne technischen Vorspann angezeigt wird (api.fail)."""


class Task:
    def __init__(self, ext, name, seconds, fn, first_delay):
        self.ext, self.name, self.seconds, self.fn = ext, name, seconds, fn
        self.next_run = time.time() + max(0, first_delay)
        self.last_run = 0
        self.last_ms = 0
        self.last_error = ''
        self.running = False

    def info(self):
        return {'name': self.name, 'every_min': round(self.seconds / 60, 1), 'last_run': int(self.last_run) or None,
                'last_ms': self.last_ms, 'error': self.last_error, 'running': self.running}


class _Api:
    def __init__(self, ext):
        self._ext = ext

    # ---- Routen / Speicher / Protokoll
    def route(self, path, fn):
        self._ext.routes[str(path).strip('/')] = fn

    def log(self, msg, level='info'):
        getattr(log, level if level in ('info', 'warning', 'error', 'debug') else 'info')('[%s] %s', self._ext.id, msg)

    def get(self, key, default=None):
        d = _store_load(self._ext.id)
        key = str(key)
        if key in d:
            return d[key]
        if default is None:                       # kein eigener Standard: Vorgabe aus EXT_SETTINGS
            for f in self._ext.settings:
                if f['key'] == key:
                    return f.get('default')
        return default

    def set(self, key, value):
        with _lock:
            d = _store_load(self._ext.id)
            d[str(key)] = value
            _store_save(self._ext.id, d)

    # ---- Zeitplan
    def every(self, minutes, fn, name='', first_delay=45):
        """fn() alle <minutes> Minuten im Hintergrund (mindestens 1). Erster Lauf nach first_delay Sekunden."""
        if not callable(fn):
            raise TypeError('every(): fn muss aufrufbar sein')
        try:
            secs = max(60, int(float(minutes) * 60))
        except (TypeError, ValueError):
            secs = 3600
        t = Task(self._ext, str(name or getattr(fn, '__name__', 'aufgabe')), secs, fn, first_delay)
        with _lock:
            TASKS.append(t)
            self._ext.tasks.append(t)
        _ensure_sched()

    # ---- Oberfläche
    def home_row(self, title, fn, ttl=300, id=None):
        """Eigene Reihe auf der Startseite. fn() liefert Einträge (title, poster, url, provider_id, next_func …)."""
        self._ext.rows[str(id or _slug(title))] = {'title': str(title), 'fn': fn, 'ttl': max(0, int(ttl)), 'cache': None}

    def menu(self, title, fn, ttl=0, id=None):
        """Eigener Menüpunkt (Kachel) auf der Startseite. fn() liefert die Einträge, die darunter erscheinen."""
        self._ext.menus[str(id or _slug(title))] = {'title': str(title), 'fn': fn, 'ttl': max(0, int(ttl)), 'cache': None}

    def widget(self, title, fn, ttl=600, id=None, icon=''):
        """Kleine Kachel für den Streifen oben auf der Startseite und für den Bildschirmschoner.
        fn() gibt ein dict zurück: {'text': 'groß, kurz (z. B. 12°)', 'sub': 'Zeile darunter', 'icon': '⛅', 'lines': ['weitere', 'Zeilen']}
        oder None, wenn es gerade nichts zu zeigen gibt. Ergebnisse werden ttl Sekunden zwischengespeichert."""
        self._ext.widgets[str(id or _slug(title))] = {'title': str(title), 'fn': fn, 'ttl': max(0, int(ttl)), 'cache': None, 'icon': str(icon or '')}

    def item_action(self, title, fn, id=None, needs=None):
        """Knopf in der Titel-Info. fn(eintrag) gibt einen Text (Hinweis) oder ein dict {'message': …} zurück.
        needs='feld': Knopf nur bei Einträgen zeigen, die dieses Feld haben (z. B. ein eigenes Feld, das die Erweiterung setzt)."""
        self._ext.actions[str(id or _slug(title))] = {'title': str(title), 'fn': fn, 'needs': str(needs or '')}

    # ---- Zugriff auf Quellen und Chat
    def providers(self):
        from . import registry as R
        return [{'id': p.id, 'name': p.name} for p in R.REGISTRY.values() if p.enabled and p.module is not None]

    def open(self, provider_id, item=None, query='', fresh=True):
        """Ordner einer Quelle öffnen -> Liste von Einträgen (wie die Oberfläche sie sieht)."""
        from . import registry as R
        return R.open_item(provider_id, item or {}, query, use_cache=not fresh)['items']

    def resolve(self, provider_id, item):
        """Streams (Hoster) zu einem abspielbaren Eintrag holen."""
        from . import registry as R
        return R.resolve_item(provider_id, item or {})['hosters']

    def search(self, provider_id, query):
        """Eine Quelle durchsuchen -> Liste von Einträgen."""
        from . import registry as R
        return R.search_provider(provider_id, query)['items']

    def fail(self, text):
        """Bricht mit einer verständlichen Meldung ab (erscheint unverändert in der Oberfläche)."""
        raise UserError(str(text))

    def chat(self, text, item=None, author=None):
        """Nachricht in den Familienchat schreiben (alle Geräte sehen sie sofort)."""
        fn = CHAT_POST
        if not callable(fn):
            raise RuntimeError('Familienchat ist nicht verfügbar')
        return fn(str(text or ''), str(author or self._ext.name), item if isinstance(item, dict) else None)


def _store_path(ext_id):
    return S.USER_DIR / ('ext_%s.json' % ''.join(c for c in ext_id if c.isalnum() or c in '_-')[:40])


def _store_load(ext_id):
    try:
        return json.loads(_store_path(ext_id).read_text('utf-8'))
    except Exception:
        return {}


def _store_save(ext_id, d):
    _store_path(ext_id).write_text(json.dumps(d, ensure_ascii=False), 'utf-8')


def _clean_schema(raw):
    """EXT_SETTINGS prüfen und in eine feste Form bringen (kaputte Felder werden übersprungen)."""
    out = []
    if not isinstance(raw, (list, tuple)):
        return out
    for f in raw:
        if not isinstance(f, dict):
            continue
        key = re.sub(r'[^a-zA-Z0-9_]', '', str(f.get('key') or ''))[:40]
        typ = str(f.get('type') or 'text')
        if not key or typ not in ('text', 'textarea', 'number', 'bool', 'select'):
            continue
        row = {'key': key, 'label': str(f.get('label') or key)[:120], 'type': typ, 'hint': str(f.get('hint') or '')[:300],
               'default': f.get('default')}
        if typ == 'select':
            opts = []
            for o in f.get('options') or []:
                if isinstance(o, (list, tuple)) and len(o) == 2:
                    opts.append([str(o[0]), str(o[1])])
                else:
                    opts.append([str(o), str(o)])
            if not opts:
                continue
            row['options'] = opts
            if row['default'] is None or str(row['default']) not in [o[0] for o in opts]:
                row['default'] = opts[0][0]
        elif typ == 'number':
            for k in ('min', 'max'):
                if isinstance(f.get(k), (int, float)):
                    row[k] = f[k]
            row['default'] = row['default'] if isinstance(row['default'], (int, float)) else 0
        elif typ == 'bool':
            row['default'] = bool(row['default'])
        else:
            row['default'] = '' if row['default'] is None else str(row['default'])
        out.append(row)
    return out


class Extension:
    def __init__(self, file):
        self.file, self.id, self.name, self.description = file, file[:-3], file[:-3], ''
        self.module, self.error, self.routes, self.links, self.enabled = None, '', {}, [], True
        self.rows, self.menus, self.actions, self.tasks, self.settings = {}, {}, {}, [], []
        self.widgets = {}
        self.guest = False

    def hooks(self):
        m = self.module
        return [n for n in HOOK_NAMES if m and callable(getattr(m, n, None))]

    def info(self):
        return {'id': self.id, 'name': self.name, 'description': self.description, 'file': self.file, 'enabled': self.enabled,
                'error': self.error, 'hooks': self.hooks(), 'routes': sorted(self.routes),
                'links': [{'title': t, 'path': '/api/x/%s/%s' % (self.id, p.strip('/'))} for t, p in self.links],
                'settings': bool(self.settings),
                'tasks': [t.info() for t in self.tasks],
                'ui': {'rows': len(self.rows), 'menus': len(self.menus), 'actions': len(self.actions), 'widgets': len(self.widgets)}}


def guest_ext(ext_id):
    """Hat die Erweiterung mit EXT_GUEST = True ausdrücklich Gäste (Teilen im WLAN) zugelassen?"""
    e = EXTS.get(ext_id)
    return bool(e and e.enabled and e.module is not None and not e.error and e.guest)


def load_all():
    """(Neu-)Laden aller Erweiterungen. Kaputte werden mit Fehlertext gelistet."""
    try:
        S.seed_bundled_extensions()
        S.upgrade_games()
    except Exception:                                   # noqa: BLE001
        log.exception('Mitgelieferte Erweiterungen')
    with _lock:
        EXTS.clear()
        del TASKS[:]
        st = S.load_state()
        for row in S.list_files('extension'):
            ext = Extension(row['file'])
            ext.enabled = row['enabled']
            EXTS[ext.id] = ext          # vorläufig unter Dateiname, bei Erfolg unter EXT_ID
            if not ext.enabled:
                continue
            try:
                path = S.EXT_DIR / row['file']
                spec = importlib.util.spec_from_file_location('mk_ext_' + path.stem.replace('-', '_').replace('.', '_'), path)
                mod = importlib.util.module_from_spec(spec)
                sys.modules[spec.name] = mod
                spec.loader.exec_module(mod)
                ext.module = mod
                new_id = str(getattr(mod, 'EXT_ID', ext.id) or ext.id)
                ext.name = str(getattr(mod, 'EXT_NAME', ext.name))
                ext.description = str(getattr(mod, 'EXT_DESCRIPTION', ''))
                ext.links = [(str(a), str(b)) for a, b in (getattr(mod, 'EXT_LINKS', []) or []) if a and b]
                ext.settings = _clean_schema(getattr(mod, 'EXT_SETTINGS', []))
                ext.guest = getattr(mod, 'EXT_GUEST', False) is True
                if new_id != ext.id:
                    EXTS.pop(ext.id, None)
                    ext.id = new_id
                    EXTS[ext.id] = ext
                reg = getattr(mod, 'register', None)
                if callable(reg):
                    reg(_Api(ext))
                ol = getattr(mod, 'on_load', None)
                if callable(ol):
                    ol()
                log.info('Erweiterung geladen: %s [%s]', ext.name, ext.id)
            except BaseException as e:       # noqa: BLE001 - kaputte Skripte dürfen die Engine nicht stoppen
                if isinstance(e, KeyboardInterrupt):
                    raise
                ext.error = ('%s: %s' % (type(e).__name__, e))[:300]
                ext.module = None
                for t in ext.tasks:
                    if t in TASKS:
                        TASKS.remove(t)
                ext.tasks, ext.rows, ext.menus, ext.actions = [], {}, {}, {}
                log.error('Erweiterung %s nicht ladbar: %s', row['file'], ext.error)
        del st
    return EXTS


def infos():
    with _lock:
        return [e.info() for e in EXTS.values()]


def _each():
    with _lock:
        return [e for e in EXTS.values() if e.enabled and e.module is not None]


def apply_items(provider_id, items):
    for e in _each():
        fn = getattr(e.module, 'process_items', None)
        if not callable(fn):
            continue
        try:
            res = fn(provider_id, [dict(i) for i in items])
            if isinstance(res, list) and all(isinstance(x, dict) for x in res):
                items = res
        except Exception as ex:
            e.error = 'process_items: %s: %s' % (type(ex).__name__, ex)
            log.error('[%s] process_items: %s\n%s', e.id, ex, ''.join(traceback.format_exc().splitlines(True)[-4:]))
    return items


def apply_hosters(provider_id, item, hosters):
    for e in _each():
        fn = getattr(e.module, 'process_hosters', None)
        if not callable(fn):
            continue
        try:
            res = fn(provider_id, dict(item or {}), [dict(h) for h in hosters])
            if isinstance(res, list) and all(isinstance(x, dict) for x in res):
                hosters = res
        except Exception as ex:
            e.error = 'process_hosters: %s: %s' % (type(ex).__name__, ex)
            log.error('[%s] process_hosters: %s\n%s', e.id, ex, ''.join(traceback.format_exc().splitlines(True)[-4:]))
    for i, h in enumerate(hosters):
        h['id'] = i
    return hosters


def dispatch(ext_id, path, req):
    """Route einer Erweiterung ausführen. Gibt (Inhalt, Status) zurück oder wirft KeyError."""
    with _lock:
        e = EXTS.get(ext_id)
    if e is None or not e.enabled or e.module is None:
        raise KeyError('Erweiterung nicht aktiv: %s' % ext_id)
    fn = e.routes.get(path.strip('/'))
    if fn is None:
        raise KeyError('Route nicht gefunden: %s/%s' % (ext_id, path))
    res = fn(req)
    status = 200
    if isinstance(res, tuple) and len(res) == 2 and isinstance(res[1], int):
        res, status = res
    return res, status


# ----------------------------------------------------------------------------- Zeitplan

_sched_started = False


def _ensure_sched():
    global _sched_started
    with _lock:
        if _sched_started:
            return
        _sched_started = True
    threading.Thread(target=_sched_loop, name='ext-sched', daemon=True).start()


def _sched_loop():
    while True:
        time.sleep(10)
        try:
            now = time.time()
            with _lock:
                due = [t for t in TASKS if not t.running and t.next_run <= now and t.ext.enabled and t.ext.module is not None]
                for t in due:
                    t.running = True
            for t in due:
                threading.Thread(target=_run_task, args=(t, True), name='ext-task', daemon=True).start()
        except Exception:
            log.exception('Zeitplan')


def _run_task(t, already_marked=False):
    if not already_marked:
        with _lock:
            if t.running:
                return {'ok': False, 'error': 'läuft gerade schon'}
            t.running = True
    t0 = time.time()
    res = {'ok': True, 'error': ''}
    try:
        t.fn()
        t.last_error = ''
    except Exception as ex:
        t.last_error = ('%s: %s' % (type(ex).__name__, ex))[:300]
        t.ext.error = 'Zeitplan "%s": %s' % (t.name, t.last_error)
        log.error('[%s] Aufgabe %s: %s\n%s', t.ext.id, t.name, ex, ''.join(traceback.format_exc().splitlines(True)[-5:]))
        res = {'ok': False, 'error': t.last_error}
    finally:
        t.last_run = t0
        t.last_ms = int((time.time() - t0) * 1000)
        t.next_run = time.time() + t.seconds
        t.running = False
    res['ms'] = t.last_ms
    return res


def run_task(ext_id, name=''):
    """Aufgabe sofort ausführen (Knopf „Jetzt ausführen“). Läuft im Aufrufer-Thread."""
    with _lock:
        e = EXTS.get(ext_id)
        tasks = list(e.tasks) if e else []
    if e is None or not e.enabled or e.module is None:
        raise KeyError('Erweiterung nicht aktiv: %s' % ext_id)
    t = next((x for x in tasks if x.name == name), None) if name else (tasks[0] if tasks else None)
    if t is None:
        raise KeyError('Aufgabe nicht gefunden: %s' % (name or '(keine)'))
    return _run_task(t)


# ----------------------------------------------------------------------------- Oberfläche (Reihen, Menüs, Knöpfe)

def ui_meta():
    """Welche Erweiterungen steuern etwas zur Oberfläche bei? (nur Beschriftungen, rechnet nichts aus)"""
    rows, menus, actions = [], [], []
    for e in _each():
        for k, v in e.rows.items():
            rows.append({'ext': e.id, 'id': k, 'title': v['title']})
        for k, v in e.menus.items():
            menus.append({'ext': e.id, 'id': k, 'title': v['title']})
        for k, v in e.actions.items():
            actions.append({'ext': e.id, 'id': k, 'title': v['title'], 'needs': v.get('needs', '')})
    widgets = [{'ext': e.id, 'id': k, 'title': v['title']} for e in _each() for k, v in e.widgets.items()]
    return {'rows': rows, 'menus': menus, 'actions': actions, 'widgets': widgets}


def _norm_list(res):
    from . import normalize as N
    out = []
    if isinstance(res, (list, tuple)):
        for raw in list(res)[:MAX_ROW_ITEMS]:
            if isinstance(raw, dict):
                it = N.norm_item(raw, str(raw.get('provider_id') or ''), str(raw.get('provider') or ''), str(raw.get('parent_title') or ''))
                if it:
                    out.append(it)
    return out


def _ui_entry(ext_id, kind, key):
    with _lock:
        e = EXTS.get(ext_id)
    if e is None or not e.enabled or e.module is None:
        raise KeyError('Erweiterung nicht aktiv: %s' % ext_id)
    ent = (e.rows if kind == 'rows' else e.menus if kind == 'menus' else e.widgets if kind == 'widgets' else e.actions).get(key)
    if ent is None:
        raise KeyError('Nicht gefunden: %s/%s' % (ext_id, key))
    return e, ent


def ui_items(kind, ext_id, key, fresh=False):
    """Einträge einer Reihe/eines Menüs (kind = 'rows' | 'menus'); mit Zwischenspeicher je ttl Sekunden."""
    e, ent = _ui_entry(ext_id, kind, key)
    c = ent.get('cache')
    if c and not fresh and ent['ttl'] and time.time() - c[0] < ent['ttl']:
        return c[1], ent['title']
    try:
        items = _norm_list(ent['fn']())
    except UserError:
        raise
    except Exception as ex:
        e.error = '%s "%s": %s: %s' % ('Reihe' if kind == 'rows' else 'Menü', ent['title'], type(ex).__name__, ex)
        log.error('[%s] %s\n%s', e.id, e.error, ''.join(traceback.format_exc().splitlines(True)[-4:]))
        raise
    ent['cache'] = (time.time(), items)
    return items, ent['title']


def _clean_widget(res, ent):
    if isinstance(res, str):
        res = {'text': res}
    if not isinstance(res, dict):
        return None
    out = {'icon': str(res.get('icon') or ent.get('icon') or '')[:8], 'text': str(res.get('text') or '')[:40],
           'sub': str(res.get('sub') or '')[:120],
           'lines': [str(x)[:120] for x in (res.get('lines') or []) if x][:8] if isinstance(res.get('lines'), (list, tuple)) else []}
    b = res.get('bilder')
    out['bilder'] = [str(x)[:500] for x in b if isinstance(x, str) and re.match(r'(https?://|/api/x/)', x)][:40] if isinstance(b, (list, tuple)) else []
    return out if (out['text'] or out['sub'] or out['lines'] or out['bilder']) else None


def ui_widget(ext_id, key, fresh=False):
    """Ein Widget abrufen (mit Zwischenspeicher). Gibt dict oder None zurück."""
    e, ent = _ui_entry(ext_id, 'widgets', key)
    c = ent.get('cache')
    if c and not fresh and ent['ttl'] and time.time() - c[0] < ent['ttl']:
        return c[1]
    try:
        out = _clean_widget(ent['fn'](), ent)
    except UserError as ex:
        out = {'icon': '⚠️', 'text': '', 'sub': str(ex)[:120], 'lines': []}
    except Exception as ex:
        e.error = 'Widget "%s": %s: %s' % (ent['title'], type(ex).__name__, ex)
        log.error('[%s] %s\n%s', e.id, e.error, ''.join(traceback.format_exc().splitlines(True)[-4:]))
        raise
    ent['cache'] = (time.time(), out)
    return out


def ui_widgets(fresh=False):
    """Alle Widgets (parallel abgerufen). Kaputte oder leere werden weggelassen."""
    from concurrent.futures import ThreadPoolExecutor
    meta = ui_meta()['widgets']
    if not meta:
        return []

    def one(m):
        try:
            w = ui_widget(m['ext'], m['id'], fresh)
        except Exception:
            return None
        return dict(w, ext=m['ext'], id=m['id'], title=m['title']) if w else None
    with ThreadPoolExecutor(max_workers=min(6, len(meta))) as pool:
        return [w for w in pool.map(one, meta) if w]


def ui_action(ext_id, key, item):
    e, ent = _ui_entry(ext_id, 'actions', key)
    try:
        res = ent['fn'](dict(item or {}))
    except UserError:
        raise
    except Exception as ex:
        e.error = 'Knopf "%s": %s: %s' % (ent['title'], type(ex).__name__, ex)
        log.error('[%s] %s\n%s', e.id, e.error, ''.join(traceback.format_exc().splitlines(True)[-4:]))
        raise
    if isinstance(res, dict):
        out = {k: v for k, v in res.items() if k in ('message', 'error', 'items')}
        if 'items' in out:
            out['items'] = _norm_list(out['items'])
        return out
    return {'message': '' if res is None else str(res)}


# ----------------------------------------------------------------------------- Einstellungen

def _find(ext_id):
    with _lock:
        e = EXTS.get(ext_id)
    if e is None:
        raise KeyError('Erweiterung nicht gefunden: %s' % ext_id)
    return e


def settings_get(ext_id):
    e = _find(ext_id)
    store = _store_load(e.id)
    fields = []
    for f in e.settings:
        row = dict(f)
        row['value'] = store.get(f['key'], f['default'])
        fields.append(row)
    return {'id': e.id, 'name': e.name, 'fields': fields}


def settings_set(ext_id, values):
    e = _find(ext_id)
    values = values if isinstance(values, dict) else {}
    with _lock:
        d = _store_load(e.id)
        for f in e.settings:
            if f['key'] not in values:
                continue
            v, typ = values[f['key']], f['type']
            if typ == 'bool':
                v = bool(v)
            elif typ == 'number':
                try:
                    v = float(v)
                except (TypeError, ValueError):
                    v = f['default']
                if 'min' in f:
                    v = max(f['min'], v)
                if 'max' in f:
                    v = min(f['max'], v)
                v = int(v) if float(v).is_integer() else v
            elif typ == 'select':
                v = str(v)
                if v not in [o[0] for o in f['options']]:
                    v = f['default']
            else:
                v = str(v)[:4000]
            d[f['key']] = v
        _store_save(e.id, d)
    return settings_get(ext_id)


# ----------------------------------------------------------------------------- Ereignisse

def emit(event, item=None, info=None):
    """on_play / on_stop an alle Erweiterungen melden (jede in eigenem Thread, blockiert nichts)."""
    hook = {'play': 'on_play', 'stop': 'on_stop'}.get(event)
    if not hook:
        return 0
    n = 0
    for e in _each():
        fn = getattr(e.module, hook, None)
        if not callable(fn):
            continue
        n += 1

        def job(e=e, fn=fn):
            try:
                fn(dict(item or {}), dict(info or {}))
            except Exception as ex:
                e.error = '%s: %s: %s' % (hook, type(ex).__name__, ex)
                log.error('[%s] %s\n%s', e.id, hook, ''.join(traceback.format_exc().splitlines(True)[-4:]))
        threading.Thread(target=job, name='ext-event', daemon=True).start()
    return n
