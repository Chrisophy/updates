# -*- coding: utf-8 -*-
"""Trailer: finden und als Quellen für den eingebauten Player liefern.

Zwei Wege, beide gleichzeitig:
 1. Das Kodi-Addon „MultiTrailer“ (plugin.video.multitrailer), wenn es installiert ist. Es löst Trailer zu direkten Streams
    auf (mp4/HLS/DASH), die der Player ohne Werbung und mit Fernbedienung abspielt.
 2. TMDB-Videos (/movie|tv/<id>/videos): YouTube- und Vimeo-Trailer als Einbettung. Braucht nur den (kostenlosen) TMDB-Schlüssel.
Die Quellen kommen als normale „Hoster“ zurück; der Player probiert sie der Reihe nach.
"""
import logging
import urllib.error
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

from . import addonhost as AH
from . import cache as _cachemod
from . import metadata as MD
from . import proxy as P
from . import registry as R
from kodi_runtime import xbmcaddon

log = logging.getLogger('engine.trailer')

ADDON_ID = 'plugin.video.multitrailer'
_C = _cachemod.Cache('trailer', ttl=3600, max_mem=200, persist=False)
_AC = _cachemod.Cache('trailer_addon', ttl=1800, max_mem=100, persist=False)
_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix='trailer')
_TV = ('tv', 'series', 'serie', 'show', 'season', 'episode')


class TrailerError(Exception):
    """Meldung, die der Nutzer lesen kann."""


def _is_tv(item):
    mt = str(item.get('mediatype') or item.get('kind') or item.get('dkind') or '').lower()
    return bool(item.get('season') or item.get('episode') or mt in _TV)


def _year(item):
    return MD._year(item.get('year') or item.get('premiered') or item.get('releasedate')) or 0


def _embed(site, key):
    if site == 'YouTube':
        return 'https://www.youtube-nocookie.com/embed/%s?autoplay=1&rel=0&playsinline=1&hl=de&cc_lang_pref=de' % urllib.parse.quote(key)
    if site == 'Vimeo':
        return 'https://player.vimeo.com/video/%s?autoplay=1' % urllib.parse.quote(key)
    return ''


def _rank(v):
    typ = {'Trailer': 0, 'Teaser': 1, 'Clip': 2}.get(v.get('type'), 3)
    lang = 0 if v.get('iso_639_1') == 'de' else (1 if v.get('iso_639_1') == 'en' else 2)
    return (typ, lang, 0 if v.get('official') else 1)


def tmdb_clips(item):
    """-> (kind, tmdb_id, [hoster …]). Ohne Schlüssel oder ohne Fund: ([] bzw. TrailerError nur bei Netz-/Schlüsselfehlern)."""
    key = MD._key()
    if not key:
        return None, 0, []
    title = MD.clean_title(item.get('title') or '')
    year = _year(item)
    want_tv = _is_tv(item)
    ck = '|'.join([key[:6], title.lower(), str(year), str(want_tv), str(item.get('tmdb') or '')])
    hit = _C.get(ck)
    if hit is not None:
        return hit
    try:
        kind, tid = MD._tmdb_find(key, item, title, year, want_tv)
        if not tid:
            return None, 0, []
        res = MD._get('/%s/%s/videos' % (kind, tid), {'language': 'de-DE', 'include_video_language': 'de,en,null'}, key).get('results') or []
    except urllib.error.HTTPError as e:
        raise TrailerError('TMDB: ' + ('Schlüssel ungültig' if e.code in (401, 403) else 'Fehler %d' % e.code))
    except Exception as e:                                                  # noqa: BLE001
        raise TrailerError('TMDB nicht erreichbar (%s)' % (getattr(e, 'reason', None) or e))
    vids = [v for v in res if v.get('site') in ('YouTube', 'Vimeo') and v.get('key') and v.get('type') in ('Trailer', 'Teaser', 'Clip')]
    vids.sort(key=lambda v: str(v.get('published_at') or ''), reverse=True)     # bei gleichem Rang: neuester zuerst
    vids.sort(key=_rank)
    hosters = []
    for v in vids[:6]:
        lang = v.get('iso_639_1') or ''
        nm = '%s%s' % (v.get('name') or v.get('type') or 'Trailer', ' (%s)' % lang.upper() if lang else '')
        hosters.append({'name': nm[:70], 'url': _embed(v['site'], v['key']), 'direct': False, 'format': 'embed', 'quality': '',
                        'lang': lang, 'source': 'TMDB · ' + v['site'], 'trailer': True,
                        'watch': ('https://www.youtube.com/watch?v=' if v['site'] == 'YouTube' else 'https://vimeo.com/') + v['key']})
    out = (kind, tid, hosters)
    _C.put(ck, out, ttl=3600 if hosters else 300)
    return out


def addon_available():
    try:
        return bool(AH.meta(ADDON_ID))
    except Exception:                                                       # noqa: BLE001
        return False


def _force_no_dash():
    """Siehe addonhost.WEB_FORCED: „DASH bevorzugen“ bleibt für den Web-Player aus."""
    AH._force_settings(ADDON_ID)


def _usable(hh):
    """Nur Adressen, die die Engine/der Player wirklich holen kann: keine lokalen Dateien und keine Mini-Server fremder Geräte-Dienste."""
    u = str(hh.get('url') or '')
    if u.startswith('msfile://'):
        return True
    if u.lower().startswith('file:'):
        return False
    try:
        pu = urllib.parse.urlparse(u)
        if pu.hostname in ('127.0.0.1', 'localhost', '::1') and (pu.hostname, pu.port) not in P.LOCAL_OK:
            return False
    except ValueError:
        return False
    return True


def _is_dash(hh):
    """DASH-Manifeste (MultiTrailer baut sie lokal und lässt die Segmente von YouTube holen) kann der Web-Player nicht abspielen
    („DASH-Fehler … is not available“) - egal, wie das Addon eingestellt ist. Solche Quellen werden nicht angeboten."""
    u = str(hh.get('url') or '').lower().split('?')[0]
    return str(hh.get('format') or '').lower() == 'dash' or u.endswith('.mpd') or bool((hh.get('drm') or {}).get('manifest_type') in ('mpd', 'dash'))


def addon_hosters(item, kind=None, tid=0):
    """Trailer über das MultiTrailer-Addon: direkte Streams (oder []). Fehler des Addons sind kein Fehler der Suche."""
    m = AH.meta(ADDON_ID)
    if not m:
        return [], []
    _force_no_dash()
    ak = '|'.join([str(tid), str(kind), item.get('title') or '', str(_year(item))])
    hit = _AC.get(ak)
    if hit is not None:
        return hit
    title = MD.clean_title(item.get('title') or '')
    q = {'action': 'play', 'media_type': 'tv' if (kind == 'tv' or (kind is None and _is_tv(item))) else 'movie', 'title': title}
    if tid:
        q['tmdb_id'] = str(tid)
    if _year(item):
        q['year'] = str(_year(item))
    url = 'plugin://%s/?%s' % (ADDON_ID, urllib.parse.urlencode(q))
    try:
        out = R.resolve_item(m['provider_id'], {'url': url, 'title': title}, None, True)     # frisch: ältere Treffer könnten noch DASH enthalten
    except Exception as e:                                                  # noqa: BLE001
        log.warning('MultiTrailer fehlgeschlagen: %s', e)
        return [], ['MultiTrailer: %s' % e]
    hs = []
    dropped = 0
    for hh in out.get('hosters') or []:
        if not _usable(hh) or _is_dash(hh):
            dropped += 1
            continue
        hh = dict(hh, trailer=True, source='MultiTrailer')
        hh['name'] = ('MultiTrailer · ' + (hh.get('name') or 'Trailer'))[:70]
        hs.append(hh)
    notes = [str(n.get('message')) for n in (out.get('notes') or []) if isinstance(n, dict) and n.get('message')]
    res = (hs, ([] if hs else (notes[-1:] or (['MultiTrailer lieferte nur Adressen (z. B. DASH), die der Player nicht öffnen kann.'] if dropped else []))))
    if hs:
        _AC.put(ak, res)
    return res


def find(item):
    """-> {title, tmdb, hosters, notes}. Wirft TrailerError, wenn nichts gefunden wurde (mit lesbarer Begründung)."""
    item = item if isinstance(item, dict) else {}
    if not (item.get('title') or '').strip():
        raise TrailerError('Titel fehlt.')
    has_addon = addon_available()
    if not MD._key() and not has_addon:
        raise TrailerError('Für Trailer fehlt der TMDB-Schlüssel (kostenlos: themoviedb.org → Konto → API; eintragen unter '
                           'Einstellungen → Konten & Inhalte) – oder installiere das Addon „MultiTrailer“.')
    notes, err = [], ''
    fut = None
    kind, tid, clips = None, 0, []
    try:
        kind, tid, clips = tmdb_clips(item)
    except TrailerError as e:
        err = str(e)
    if has_addon:
        fut = _POOL.submit(addon_hosters, item, kind, tid)
    addon, an = [], []
    if fut is not None:
        addon, an = fut.result()
    notes += an
    hosters = addon + clips
    if not hosters:
        raise TrailerError(err or (an[0] if an else 'Zu „%s“ wurde kein Trailer gefunden.' % item.get('title')))
    for i, hh in enumerate(hosters):
        hh['id'] = i
    return {'title': item.get('title'), 'tmdb': tid or 0, 'kind': kind or '', 'hosters': hosters, 'notes': notes,
            'addon': has_addon}
