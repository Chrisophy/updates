# -*- coding: utf-8 -*-
"""RSS-/Atom-Feeds lesen (für den Startseiten-Bereich „Nachrichten & Notizen“).

Die Engine holt und zerlegt den Feed (die Oberfläche darf fremde Server wegen CORS meist nicht selbst fragen). Verstanden werden
RSS 2.0, RSS 1.0 (RDF) und Atom. Gibt man statt des Feeds die Webseite an, wird der Feed über <link rel="alternate"> gefunden.
Sicherheit: Ziele gehen durch proxy.fetch (keine privaten Adressen), die Antwort ist auf 2 MB begrenzt, XML mit DOCTYPE/ENTITY wird
abgelehnt (Schutz vor Entity-Bomben), Texte kommen als reiner Text zurück (kein HTML in die Oberfläche).
"""
import html
import logging
import re
import time
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from urllib.parse import urljoin

from . import cache as _cachemod
from . import proxy as P

log = logging.getLogger('engine.feeds')
MAX_BYTES = 2 * 1024 * 1024
_C = _cachemod.Cache('feeds', ttl=600, max_mem=60, persist=False)


class FeedError(Exception):
    """Meldung, die der Nutzer lesen kann."""


def _local(tag):
    return tag.rsplit('}', 1)[-1].lower() if isinstance(tag, str) else ''


def _kids(el, name):
    return [c for c in el if _local(c.tag) == name]


def _first(el, *names):
    for n in names:
        for c in el:
            if _local(c.tag) == n:
                return c
    return None


def _text(el, *names):
    c = _first(el, *names)
    return (c.text or '').strip() if c is not None and c.text else ''


_TAG = re.compile(r'<[^>]+>')
_BR = re.compile(r'<\s*(br|/li)\b[^>]*>', re.I)
_PAR = re.compile(r'<\s*/(p|div|h\d|blockquote)\b[^>]*>', re.I)
_IMG = re.compile(r'<img\b[^>]*?\bsrc\s*=\s*["\']([^"\']+)["\']', re.I)


def _plain(s, limit=1200):
    s = _PAR.sub('\n\n', _BR.sub('\n', s or ''))
    s = html.unescape(_TAG.sub('', s))
    s = re.sub(r'[ \t\r\f\v]+', ' ', s)
    s = re.sub(r'\n\s*\n+', '\n\n', s).strip()
    return s[:limit]


def _ts(s):
    s = (s or '').strip()
    if not s:
        return 0
    try:
        return int(parsedate_to_datetime(s).timestamp())
    except Exception:                                                       # noqa: BLE001
        pass
    m = re.match(r'(\d{4})-(\d\d)-(\d\d)(?:[T ](\d\d):(\d\d)(?::(\d\d))?)?', s)
    if m:
        try:
            import calendar
            y, mo, d, hh, mi, ss = (int(x or 0) for x in m.groups())
            return calendar.timegm((y, mo, d, hh, mi, ss))
        except Exception:                                                   # noqa: BLE001
            return 0
    return 0


def _link(it, base):
    for c in _kids(it, 'link'):
        href = c.get('href')
        if href and (c.get('rel') in (None, '', 'alternate')):
            return urljoin(base, href.strip())
        if c.text and c.text.strip():
            return urljoin(base, c.text.strip())
    for c in _kids(it, 'link'):                                             # Atom ohne rel
        if c.get('href'):
            return urljoin(base, c.get('href').strip())
    g = _text(it, 'guid', 'id')
    return g if g.startswith('http') else ''


def _image(it, raw_html, base):
    for c in it:
        n = _local(c.tag)
        if n in ('thumbnail', 'content') and c.get('url') and (n == 'thumbnail' or (c.get('medium') == 'image' or 'image' in (c.get('type') or ''))):
            return urljoin(base, c.get('url'))
        if n == 'enclosure' and c.get('url') and 'image' in (c.get('type') or ''):
            return urljoin(base, c.get('url'))
    m = _IMG.search(raw_html or '')
    return urljoin(base, html.unescape(m.group(1))) if m else ''


def parse(data, base=''):
    if b'<!entity' in data.lower():
        raise FeedError('Der Feed enthält ENTITY-Angaben und wird aus Sicherheitsgründen nicht gelesen.')
    try:
        root = ET.fromstring(data)
    except ET.ParseError as e:
        raise FeedError('Das ist kein gültiger Feed (%s).' % e)
    kind = _local(root.tag)
    if kind not in ('rss', 'feed', 'rdf'):
        raise FeedError('Das ist kein RSS- oder Atom-Feed.')
    chan = _first(root, 'channel') if kind in ('rss', 'rdf') else root
    if chan is None:
        raise FeedError('Der Feed hat keinen Kanal.')
    items_el = _kids(chan, 'item') + _kids(root, 'item') if kind != 'feed' else _kids(root, 'entry')
    out = []
    for it in items_el[:60]:
        title = _plain(_text(it, 'title'), 300)
        raw = ''
        for nm in ('encoded', 'content', 'description', 'summary'):
            c = _first(it, nm)
            if c is not None and (c.text or len(c)):
                raw = c.text or ''
                if len(c) and not raw.strip():
                    raw = ''.join(ET.tostring(x, encoding='unicode') for x in c)
                break
        summ = _plain(raw)
        if not title:
            title = summ.split('\n')[0][:120]
        if not title:
            continue
        ts = _ts(_text(it, 'pubdate', 'published', 'updated', 'date'))
        out.append({'title': title, 'link': _link(it, base), 'ts': ts, 'summary': summ, 'image': _image(it, raw, base)})
    return {'title': _plain(_text(chan, 'title'), 120), 'site': _link(chan, base) if kind == 'feed' else (_text(chan, 'link') or ''), 'items': out}


_ALT = re.compile(r'<link\b[^>]*>', re.I)


def _discover(page, base):
    for tag in _ALT.findall(page.decode('utf-8', 'ignore')[:200000]):
        low = tag.lower()
        if 'alternate' in low and ('rss' in low or 'atom' in low):
            m = re.search(r'href\s*=\s*["\']([^"\']+)["\']', tag, re.I)
            if m:
                return urljoin(base, html.unescape(m.group(1)))
    return ''


def _get(url):
    try:
        up = P.fetch('GET', url, {'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*;q=0.5'}, timeout=15)
    except P.Blocked as e:
        raise FeedError(str(e))
    except Exception as e:                                                  # noqa: BLE001
        raise FeedError('Nicht erreichbar (%s)' % (getattr(e, 'reason', None) or e))
    try:
        data = up.read(MAX_BYTES + 1)
    finally:
        up.close()
    if up.status >= 400:
        raise FeedError('Der Server antwortet mit HTTP %d.' % up.status)
    if len(data) > MAX_BYTES:
        raise FeedError('Der Feed ist größer als 2 MB.')
    return P._decode_body(up, data), up.final_url


def read(url, fresh=False):
    """-> {title, site, url, items:[{title, link, ts, summary, image}]}"""
    url = (url or '').strip()
    if not re.match(r'^https?://\S+$', url):
        raise FeedError('Bitte eine Adresse mit http:// oder https:// eingeben.')
    hit = None if fresh else _C.get(url)
    if hit is not None:
        return hit
    data, final = _get(url)
    try:
        res = parse(data, final)
    except FeedError:
        alt = _discover(data, final)                                        # Webseite statt Feed: verlinkten Feed suchen
        if not alt or alt == url:
            raise
        data, final = _get(alt)
        res = parse(data, final)
        url = alt
    res['url'] = url
    res['fetched'] = int(time.time())
    _C.put(url, res)
    return res
