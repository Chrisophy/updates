# -*- coding: utf-8 -*-
"""System-Update ohne neue APK.

Eine neue Programmversion (Engine, Oberfläche, Scraper, Erweiterungen) kommt als ZIP – entweder als Datei, die man
in den Einstellungen auswählt, oder von einer Quelle, die man selbst einträgt (GitHub-Repository oder ZIP-Adresse).

So läuft es ab
  1. Das ZIP wird geprüft (nur erlaubte Ordner, keine Pfad-Tricks, jede .py-Datei muss syntaktisch stimmen,
     VERSION muss dabei sein, Größenlimit).
  2. Aus dem mitgelieferten Stand der App (BASE) plus dem ZIP entsteht ein vollständiger Ordner "stage".
  3. Beim nächsten Start der Engine nimmt main.py diesen Ordner statt des mitgelieferten Codes (update/current).
  4. Startet der neue Stand nicht, fällt main.py selbstständig auf den mitgelieferten Stand zurück
     (Marker update/booting, siehe main.py). Die vorige Version bleibt unter update/previous für "zurück".
  5. Bringt später eine neue APK eine gleich neue oder neuere VERSION mit, verschwindet das Update von selbst.

Benutzerdaten (userData: Einstellungen, Favoriten, eigene Scraper …) liegen außerhalb und werden nie angefasst.
Nicht aktualisierbar ohne APK ist alles in android/ (Java, Manifest) – das wird ignoriert.
"""
import io
import json
import logging
import os
import re
import shutil
import threading
import time
import zipfile
from pathlib import Path
from urllib.parse import urlparse

from kodi_runtime import paths as _paths

from . import fsutil as FS

log = logging.getLogger('updater')

ROOT = Path(__file__).resolve().parent.parent                     # Code, der gerade läuft
BASE = Path(os.environ.get('MOVIESCOUT_BASE') or ROOT)            # mitgelieferter Code (APK / Projektordner)
UPD = _paths.DATA_DIR / 'update'
CURRENT, STAGE, PREVIOUS = UPD / 'current', UPD / 'stage', UPD / 'previous'
STATE = UPD / 'state.json'
BOOTING = UPD / 'booting'
BAD = UPD / 'bad'

CODE_DIRS = ('engine', 'kodi_runtime', 'providers', 'extensions', 'resources', 'vendor', 'static', 'system')
ROOT_FILES = ('VERSION', 'main.py')
MAX_ZIP = 60_000_000
MAX_FILES = 4000
MAX_UNPACKED = 150_000_000
SKIP_PARTS = ('__pycache__',)
SKIP_EXT = ('.pyc', '.pyo')

_lock = threading.RLock()
CHECK = {'state': 'idle', 'time': 0, 'available': False, 'version': '', 'error': '', 'source': ''}


class UpdateError(Exception):
    """Fehler mit nutzerlesbarer Meldung."""


# ----------------------------------------------------------------------------- Versionen

def read_version(folder):
    try:
        for line in (Path(folder) / 'VERSION').read_text('utf-8').splitlines():
            if line.strip():
                return line.strip()[:40]
    except Exception:                                   # noqa: BLE001
        pass
    return ''


def vkey(v):
    nums = [int(x) for x in re.findall(r'\d+', str(v or ''))][:6]
    return tuple(nums + [0] * (6 - len(nums)))


def running_version():
    return read_version(ROOT) or '0'


def base_version():
    return read_version(BASE) or '0'


# ----------------------------------------------------------------------------- Zustand

def _load():
    try:
        d = json.loads(STATE.read_text('utf-8'))
        return d if isinstance(d, dict) else {}
    except Exception:                                   # noqa: BLE001
        return {}


def _save(d):
    UPD.mkdir(parents=True, exist_ok=True)
    tmp = STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), 'utf-8')
    os.replace(tmp, STATE)


def _rm(p):
    """Ordner löschen - auch wenn Dateien/Ordner schreibgeschützt sind (Android legt die mitgelieferten Dateien so ab)."""
    def fix(func, path, _exc):
        try:
            os.chmod(os.path.dirname(path) or '.', 0o755)
            os.chmod(path, 0o755)
            func(path)
        except OSError:
            pass
    shutil.rmtree(str(p), onerror=fix)


def _copy_file(src, dst):
    """Kopieren ohne die Schreibschutz-Bits der Quelle zu übernehmen (sonst lässt sich die Kopie nicht mehr überschreiben)."""
    try:
        os.unlink(str(dst))
    except OSError:
        pass
    shutil.copyfile(str(src), str(dst))
    try:
        os.chmod(str(dst), 0o644)
    except OSError:
        pass


def mark_ok():
    """Die Engine ist sauber hochgekommen: Start-Marker löschen (sonst würde main.py zurückfallen)."""
    try:
        BOOTING.unlink()
    except FileNotFoundError:
        pass
    except Exception:                                   # noqa: BLE001
        log.exception('Marker')


def status():
    st = _load()
    cur = read_version(CURRENT) if CURRENT.is_dir() else ''
    prev = read_version(PREVIOUS) if PREVIOUS.is_dir() else ''
    run = running_version()
    return {
        'running': run,
        'base': base_version(),
        'overlay': cur,                                       # installierter Update-Stand ('' = keiner)
        'previous': prev,
        'restart_needed': bool(cur and cur != run) or bool(not cur and ROOT != BASE),
        'using_update': ROOT != BASE,
        'installed_at': st.get('installed_at', 0),
        'source_used': st.get('source', ''),
        'failed': st.get('failed', ''),                       # Meldung, wenn der letzte Start zurückgefallen ist
        'check': dict(CHECK),
    }


# ----------------------------------------------------------------------------- Prüfen und entpacken

def _norm(name):
    n = name.replace('\\', '/')
    if n.startswith('/') or re.match(r'^[A-Za-z]:', n):
        raise UpdateError('Unzulässiger Pfad im ZIP: %s' % name)
    parts = [p for p in n.split('/') if p not in ('', '.')]
    if any(p == '..' for p in parts):
        raise UpdateError('Unzulässiger Pfad im ZIP: %s' % name)
    return parts


def _read_zip(data):
    """Gibt {relativer Pfad: Bytes} der übernommenen Dateien plus Hinweise zurück."""
    if len(data) > MAX_ZIP:
        raise UpdateError('Die Datei ist zu groß (%d MB, erlaubt %d MB).' % (len(data) // 1_000_000, MAX_ZIP // 1_000_000))
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise UpdateError('Das ist keine gültige ZIP-Datei.')
    infos = [i for i in zf.infolist() if not i.is_dir()]
    if len(infos) > MAX_FILES:
        raise UpdateError('Zu viele Dateien im ZIP (%d).' % len(infos))
    if sum(i.file_size for i in infos) > MAX_UNPACKED:
        raise UpdateError('Das ZIP ist entpackt zu groß.')
    rows = [(_norm(i.filename), i) for i in infos]
    rows = [(p, i) for p, i in rows if p]
    # Ein gemeinsamer Oberordner (GitHub: "repo-main/") wird abgeschnitten, auch wenn er "MovieScout/" heißt
    def has_marker(ps):
        return any(p[:1] == ['VERSION'] or p[:2] == ['engine', 'app.py'] for p in ps)
    paths = [p for p, _ in rows]
    if paths and not has_marker(paths):
        tops = {p[0] for p in paths if len(p) > 1}
        if len(tops) == 1 and all(len(p) > 1 for p in paths):
            rows = [(p[1:], i) for p, i in rows]
        elif len(tops) >= 1:
            sub = [t for t in tops if has_marker([p[1:] for p in paths if len(p) > 1 and p[0] == t])]
            if len(sub) == 1:
                rows = [(p[1:], i) for p, i in rows if len(p) > 1 and p[0] == sub[0]]
    files, ignored = {}, set()
    for p, i in rows:
        if any(x in SKIP_PARTS for x in p) or p[-1].lower().endswith(SKIP_EXT):
            continue
        top = p[0]
        if len(p) == 1 and top in ROOT_FILES:
            files[top] = zf.read(i)
        elif len(p) > 1 and top in CODE_DIRS:
            if any(x.startswith('.') and x not in ('.gitkeep',) for x in p):
                continue
            files['/'.join(p)] = zf.read(i)
        else:
            ignored.add(top)
    return files, sorted(ignored)


def _validate(files):
    ver = files.get('VERSION', b'').decode('utf-8', 'replace').strip().splitlines()
    ver = ver[0].strip()[:40] if ver else ''
    if not ver or not re.search(r'\d', ver):
        raise UpdateError('Im ZIP fehlt die Datei VERSION – das ist kein MovieScout-Update.')
    for need in ('engine/app.py', 'kodi_runtime/__init__.py', 'static/index.html'):
        if need not in files:
            raise UpdateError('Im ZIP fehlt %s – das Paket ist unvollständig.' % need)
    for name, raw in sorted(files.items()):
        if name.endswith('.py'):
            try:
                compile(raw.decode('utf-8'), name, 'exec')
            except SyntaxError as e:
                raise UpdateError('Fehler im Quelltext %s, Zeile %s: %s – Update abgelehnt.' % (name, e.lineno, e.msg))
            except UnicodeDecodeError:
                raise UpdateError('%s ist nicht UTF-8-kodiert – Update abgelehnt.' % name)
    return ver


def _copy_tree(src, dst):
    for root, dirs, fs in os.walk(str(src)):
        dirs[:] = [d for d in dirs if d not in SKIP_PARTS]
        rel = os.path.relpath(root, str(src))
        out = Path(dst) if rel == '.' else Path(dst) / rel
        out.mkdir(parents=True, exist_ok=True)
        for f in fs:
            if f.endswith(SKIP_EXT):
                continue
            _copy_file(os.path.join(root, f), out / f)


def install_zip(data, source='Datei', force=False):
    """Prüft das ZIP und legt es als neuen Stand bereit (wirkt nach dem Neustart). Gibt eine Zusammenfassung zurück."""
    with _lock:
        files, ignored = _read_zip(data)
        ver = _validate(files)
        have = read_version(CURRENT) if CURRENT.is_dir() else base_version()
        if vkey(ver) < vkey(have) and not force:
            raise UpdateError('Das Paket (Version %s) ist älter als der aktuelle Stand (%s).' % (ver, have))
        if vkey(ver) == vkey(have) and not force and CURRENT.is_dir():
            raise UpdateError('Version %s ist schon eingespielt.' % ver)
        if vkey(ver) <= vkey(base_version()) and not force:
            raise UpdateError('Die App bringt Version %s schon mit – das Paket (%s) ist nicht neuer.' % (base_version(), ver))
        _rm(STAGE)
        UPD.mkdir(parents=True, exist_ok=True)
        # Stand der App als Grundlage; Ordner, die das Paket mitbringt, ersetzen den Ordner vollständig
        for d in CODE_DIRS:
            if (BASE / d).is_dir():
                _copy_tree(BASE / d, STAGE / d)
        for f in ROOT_FILES:
            if (BASE / f).is_file():
                STAGE.mkdir(parents=True, exist_ok=True)
                _copy_file(BASE / f, STAGE / f)
        pack_dirs = {n.split('/')[0] for n in files if '/' in n}
        for d in pack_dirs:
            keep_vendor = (STAGE / 'static' / 'vendor') if d == 'static' else None
            saved = None
            if keep_vendor is not None and keep_vendor.is_dir() and not any(n.startswith('static/vendor/') for n in files):
                saved = UPD / '_vendor_keep'
                _rm(saved)
                shutil.move(str(keep_vendor), str(saved))
            _rm(STAGE / d)
            if saved is not None:
                (STAGE / 'static').mkdir(parents=True, exist_ok=True)
                shutil.move(str(saved), str(STAGE / 'static' / 'vendor'))
        for name, raw in files.items():
            dst = STAGE / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            try:
                os.unlink(str(dst))
            except OSError:
                pass
            dst.write_bytes(raw)
        # Zweite Prüfung am fertigen Ordner (nichts Halbes übernehmen)
        for need in ('engine/app.py', 'static/index.html', 'VERSION'):
            if not (STAGE / need).is_file():
                _rm(STAGE)
                raise UpdateError('Interner Fehler beim Vorbereiten (%s fehlt).' % need)
        # Tauschen: current -> previous, stage -> current
        if CURRENT.is_dir():
            _rm(PREVIOUS)
            FS.move_dir(CURRENT, PREVIOUS)             # Android-Speicher: Ordner umbenennen oft verboten -> kopieren
        FS.move_dir(STAGE, CURRENT)
        st = _load()
        st.update(installed_at=int(time.time()), source=str(source)[:200], failed='')
        _save(st)
        _rm(BAD)
        n_changed = len(files)
        log.info('Update %s bereitgestellt (%d Dateien, Quelle %s)', ver, n_changed, source)
        return {'ok': True, 'version': ver, 'files': n_changed, 'ignored': ignored, 'restart_needed': True,
                'apk_parts': 'android' in ignored}


def rollback():
    """Vorige Version wieder einsetzen (wirkt nach Neustart)."""
    with _lock:
        if not PREVIOUS.is_dir():
            raise UpdateError('Es gibt keine vorige Version.')
        tmp = UPD / '_swap'
        _rm(tmp)
        if CURRENT.is_dir():
            FS.move_dir(CURRENT, tmp)
        FS.move_dir(PREVIOUS, CURRENT)
        if tmp.is_dir():
            FS.move_dir(tmp, PREVIOUS)
        return {'ok': True, 'version': read_version(CURRENT), 'restart_needed': True}


def reset():
    """Zurück auf den Stand, den die App mitbringt (wirkt nach Neustart)."""
    with _lock:
        if CURRENT.is_dir():
            _rm(PREVIOUS)
            FS.move_dir(CURRENT, PREVIOUS)
        st = _load()
        st['failed'] = ''
        _save(st)
        return {'ok': True, 'version': base_version(), 'restart_needed': True}


# ----------------------------------------------------------------------------- Quellen (GitHub / ZIP-Adresse)

def github_file_url(url):
    """Datei-Link auf github.com in eine Download-Adresse umwandeln:
    github.com/besitzer/repo/blob/zweig/pfad.zip und …/raw/zweig/pfad.zip -> raw.githubusercontent.com/besitzer/repo/zweig/pfad.zip,
    github.com/besitzer/repo/pfad.zip (ohne Zweig) -> …/HEAD/pfad.zip (Standardzweig). Releases/Archive und andere Adressen bleiben."""
    pu = urlparse(url)
    if (pu.hostname or '').lower() not in ('github.com', 'www.github.com'):
        return url
    parts = [p for p in pu.path.split('/') if p]
    if len(parts) < 3:
        return url
    owner, repo, rest = parts[0], parts[1], parts[2:]
    if rest[0] in ('releases', 'archive'):
        return url
    if rest[0] in ('blob', 'raw') and len(rest) >= 3:
        ref, path = rest[1], rest[2:]
    else:
        ref, path = 'HEAD', rest
    return 'https://raw.githubusercontent.com/%s/%s/%s/%s' % (owner, repo, ref, '/'.join(path))


def parse_source(text):
    """'owner/repo', 'owner/repo@zweig', GitHub-Link (auch /tree/zweig) oder ZIP-Adresse.
    Gibt ('github', owner, repo, branch) oder ('zip', url) zurück; leer -> None."""
    s = str(text or '').strip()
    if not s:
        return None
    if s.lower().startswith(('http://', 'https://')) and urlparse(s).path.lower().endswith('.zip'):
        return ('zip', github_file_url(s))
    m = re.match(r'^(?:https?://github\.com/)?([\w.\-]+)/([\w.\-]+?)(?:\.git)?(?:/tree/([^\s?#]+?))?(?:@([^\s]+))?/?$', s)
    if m and (not s.startswith('http') or 'github.com' in s):
        return ('github', m.group(1), m.group(2), (m.group(3) or m.group(4) or 'main').strip('/'))
    if s.lower().startswith(('http://', 'https://')):
        if (urlparse(s).hostname or '') == 'github.com':
            raise UpdateError('GitHub-Adresse nicht verständlich. Erlaubt: besitzer/repo oder besitzer/repo@zweig.')
        return ('zip', s)
    raise UpdateError('Quelle nicht verständlich. Erlaubt: besitzer/repo, besitzer/repo@zweig oder eine ZIP-Adresse (https://…).')


def _get(url, timeout=40):
    from resources.lib import multiquest
    r = multiquest.get(url, headers={'User-Agent': 'MovieScout-Update'}, timeout=timeout)
    if r.status_code != 200:
        raise UpdateError('Download fehlgeschlagen (HTTP %s): %s' % (r.status_code, urlparse(url).netloc))
    return r.content


def _urls(src):
    if src[0] == 'github':
        _k, o, r, b = src
        return ('https://raw.githubusercontent.com/%s/%s/%s/VERSION' % (o, r, b),
                'https://codeload.github.com/%s/%s/zip/refs/heads/%s' % (o, r, b))
    return (None, src[1])


def check(source):
    """Fragt die Quelle nach der Version. Gibt {'available','version','current'} zurück und merkt sich das Ergebnis."""
    CHECK.update(state='running', source=str(source), error='')
    try:
        src = parse_source(source)
        if not src:
            raise UpdateError('Keine Update-Quelle eingetragen.')
        have = read_version(CURRENT) if CURRENT.is_dir() else base_version()
        vurl, zurl = _urls(src)
        if vurl:
            txt = _get(vurl, 20).decode('utf-8', 'replace').strip().splitlines()
            ver = txt[0].strip()[:40] if txt else ''
            if not re.search(r'\d', ver):
                raise UpdateError('Die Quelle hat keine gültige VERSION-Datei.')
        else:                                           # ZIP-Adresse: die Version steht erst im ZIP
            files, _ig = _read_zip(_get(zurl, 90))
            ver = _validate(files)
        avail = vkey(ver) > vkey(have) and vkey(ver) > vkey(base_version())
        CHECK.update(state='done', time=int(time.time()), available=avail, version=ver, error='')
        return {'available': avail, 'version': ver, 'current': have}
    except Exception as e:                              # noqa: BLE001
        CHECK.update(state='error', time=int(time.time()), available=False, error=str(e) if isinstance(e, UpdateError)
                     else '%s: %s' % (type(e).__name__, e))
        raise


def install_from_source(source, force=False):
    src = parse_source(source)
    if not src:
        raise UpdateError('Keine Update-Quelle eingetragen.')
    _v, zurl = _urls(src)
    res = install_zip(_get(zurl, 120), source=str(source), force=force)
    CHECK.update(state='done', time=int(time.time()), available=False, version=res['version'], error='')
    return res
