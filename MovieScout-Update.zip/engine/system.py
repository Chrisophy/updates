# -*- coding: utf-8 -*-
"""Verwaltung des Systems: eigene Scraper und Erweiterungen (Python-Skripte), Aktivieren/Deaktivieren,
Papierkorb, Vorlagen, Prüfen sowie Export/Import des Gesamtsystems.

Dieses Modul braucht weder Starlette noch laufende Engine - das Kommandozeilen-Tool tools/mk.py nutzt es direkt.

Ordner (unter MOVIESCOUT_DATA, Standard ./userData):
    user/providers/*.py    eigene Scraper (überschreiben gleichnamige mitgelieferte)
    user/extensions/*.py   Erweiterungen (Hooks, eigene API-Routen)
    user/trash/            gelöschte Dateien (wiederherstellbar)
    user/state.json        deaktivierte / ausgeblendete Einträge
"""
import ast
import io
import json
import logging
import os
import re
import shutil
import threading
import time
import zipfile
from pathlib import Path

from kodi_runtime import paths as _paths

ROOT = Path(__file__).resolve().parent.parent
BUNDLED_DIR = Path(os.environ.get('MINIKODI_PROVIDERS', str(ROOT / 'providers')))
BUNDLED_EXT_DIR = ROOT / 'extensions'          # mitgelieferte Erweiterungen (z. B. der Scraper-Baukasten)
USER_DIR = _paths.DATA_DIR / 'user'
PROV_DIR = USER_DIR / 'providers'
EXT_DIR = USER_DIR / 'extensions'
TRASH_DIR = USER_DIR / 'trash'
STATE_FILE = USER_DIR / 'state.json'
FORMAT = 1
MAX_CODE = 1_500_000
MAX_ZIP = 40_000_000
log = logging.getLogger('minikodi.system')
NAME_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9_.\-]{0,60}\.py$')
KINDS = ('provider', 'extension')
_lock = threading.RLock()

for _d in (PROV_DIR, EXT_DIR, TRASH_DIR):
    _d.mkdir(parents=True, exist_ok=True)


class SystemError_(Exception):
    """Fehler mit nutzerlesbarer Meldung."""


# ----------------------------------------------------------------------------- Zustand

def load_state():
    with _lock:
        try:
            d = json.loads(STATE_FILE.read_text('utf-8'))
        except Exception:
            d = {}
    d.setdefault('disabled_provider', [])      # Dateinamen
    d.setdefault('disabled_extension', [])
    d.setdefault('removed_provider', [])       # mitgelieferte Scraper, die der Nutzer "gelöscht" hat
    return d


def save_state(d):
    with _lock:
        tmp = STATE_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), 'utf-8')
        os.replace(tmp, STATE_FILE)


def _sha(data):
    import hashlib
    return hashlib.sha256(data).hexdigest()[:16]


def seed_bundled_extensions():
    """Mitgelieferte Erweiterungen (extensions/*.py) in den Erweiterungsordner des Nutzers legen.
    - Fehlt die Datei und wurde sie noch nie angelegt: kopieren.
    - Hat der Nutzer sie gelöscht: bleibt gelöscht.
    - Hat der Nutzer sie verändert (oder selbst installiert): bleibt unangetastet.
    - Ist sie noch genau so, wie wir sie angelegt haben, und die mitgelieferte Fassung ist neuer: aktualisieren."""
    if not BUNDLED_EXT_DIR.is_dir():
        return []
    done = []
    with _lock:
        st = load_state()
        seeded = st.get('seeded_extension')
        if not isinstance(seeded, dict):
            seeded = {}
        for f in sorted(BUNDLED_EXT_DIR.glob('*.py')):
            if f.name.startswith('_') or not NAME_RE.match(f.name):
                continue
            raw = f.read_bytes()
            sha = _sha(raw)
            target = EXT_DIR / f.name
            prev = seeded.get(f.name)
            if f.name not in seeded:
                if target.exists():
                    seeded[f.name] = ''                       # vom Nutzer selbst installiert: nie anfassen
                else:
                    target.write_bytes(raw)
                    seeded[f.name] = sha
                    done.append(f.name)
            elif prev and prev != sha and target.exists() and _sha(target.read_bytes()) == prev:
                target.write_bytes(raw)                       # unverändert angelegt, jetzt gibt es eine neuere Fassung
                seeded[f.name] = sha
                done.append(f.name)
        st['seeded_extension'] = seeded
        save_state(st)
    return done


GAME_IDS = ('tetris', 'minispiele', 'pong', 'solitaire')


def upgrade_games():
    """Schon installierte Spiele-Gadgets auf die mitgelieferte Fassung heben, wenn ihnen die Marke 'ms-game' fehlt
    (ältere Fassung: Seite rutschte beim Tippen/Drehen weg, passte nicht ins Fenster). Die alte Fassung landet im Papierkorb."""
    from . import examples as EX
    done = []
    for e in EX.EXAMPLES:
        if e['id'] not in GAME_IDS or 'ms-game' not in e['code']:
            continue
        target = EXT_DIR / e['file']
        try:
            if target.is_file() and 'ms-game' not in target.read_text('utf-8', 'replace'):
                save_file('extension', e['file'], e['code'], overwrite=True)
                done.append(e['id'])
        except Exception:                                   # noqa: BLE001
            log.exception('Spiel aktualisieren: %s', e['id'])
    return done


def kind_dir(kind):
    if kind == 'provider':
        return PROV_DIR
    if kind == 'extension':
        return EXT_DIR
    raise SystemError_('Unbekannte Art: %s' % kind)


def provider_dirs():
    """[(Ordner, Herkunft)] in Ladereihenfolge - Nutzerdateien überschreiben gleichnamige mitgelieferte."""
    return [(BUNDLED_DIR, 'bundled'), (PROV_DIR, 'user')]


def clean_name(name):
    name = os.path.basename(str(name or '').strip().replace('\\', '/'))
    if not name.lower().endswith('.py'):
        name += '.py'
    if not NAME_RE.match(name) or name.startswith('_'):
        raise SystemError_('Ungültiger Dateiname „%s“ – erlaubt sind Buchstaben, Ziffern, _ - . und die Endung .py' % name)
    return name


# ----------------------------------------------------------------------------- Prüfen

def _top_names(tree):
    out = set()
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            out.add(n.name)
        elif isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name):
                    out.add(t.id)
    return out


_PROVIDER_FUNCS = {'load', 'showEntries', 'search', 'get_hosters'}
_EXT_HOOKS = {'register', 'process_items', 'process_hosters', 'on_load', 'on_play', 'on_stop'}


def check_code(kind, filename, code):
    """Statische Prüfung. Gibt {'ok', 'errors', 'warnings', 'info'} zurück - führt den Code NICHT aus."""
    errors, warnings, info = [], [], {}
    if kind not in KINDS:
        raise SystemError_('Unbekannte Art: %s' % kind)
    try:
        filename = clean_name(filename)
    except SystemError_ as e:
        errors.append(str(e))
    if not isinstance(code, str) or not code.strip():
        errors.append('Der Code ist leer.')
        return {'ok': False, 'errors': errors, 'warnings': warnings, 'info': info}
    if len(code.encode('utf-8', 'replace')) > MAX_CODE:
        errors.append('Datei ist zu groß (max. %d KB).' % (MAX_CODE // 1000))
    try:
        tree = ast.parse(code, filename or 'skript.py')
    except SyntaxError as e:
        errors.append('Syntaxfehler in Zeile %s: %s' % (e.lineno, e.msg))
        return {'ok': False, 'errors': errors, 'warnings': warnings, 'info': info}
    names = _top_names(tree)
    info['functions'] = sorted(n for n in names if n[:1].islower() and not n.startswith('_'))[:30]
    if kind == 'provider':
        if not names & _PROVIDER_FUNCS:
            errors.append('Das ist kein Scraper: es fehlt mindestens eine der Funktionen load, showEntries, search oder get_hosters.')
        if 'SITE_ID' not in names:
            warnings.append('SITE_ID fehlt – der Dateiname wird als ID benutzt.')
        if 'SITE_NAME' not in names:
            warnings.append('SITE_NAME fehlt – der Dateiname wird als Anzeigename benutzt.')
        if 'get_hosters' not in names:
            warnings.append('get_hosters fehlt – Einträge lassen sich nicht abspielen.')
    else:
        if not names & _EXT_HOOKS:
            errors.append('Keine Erweiterung: es fehlt mindestens eine der Funktionen register, process_items, process_hosters, on_load, on_play oder on_stop.')
    return {'ok': not errors, 'errors': errors, 'warnings': warnings, 'info': info}


# ----------------------------------------------------------------------------- Dateien

def _read(path):
    return Path(path).read_text('utf-8', 'replace')


def static_meta(path):
    """SITE_ID / SITE_NAME / SITE_DOMAIN aus der Datei lesen, ohne sie auszuführen (für deaktivierte Scraper)."""
    meta = {}
    try:
        tree = ast.parse(_read(path))
        for n in tree.body:
            if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ('SITE_ID', 'SITE_NAME', 'SITE_DOMAIN'):
                v = ast.literal_eval(n.value)
                if isinstance(v, str):
                    meta[n.targets[0].id] = v
    except Exception:
        pass
    return meta


def list_files(kind):
    """Alle Dateien einer Art mit Zustand: [{'file','origin','enabled','size','mtime'}]"""
    st = load_state()
    out, seen = [], {}
    if kind == 'provider':
        removed = set(st['removed_provider'])
        for d, origin in provider_dirs():
            for f in sorted(Path(d).glob('*.py')):
                if f.name.startswith('_'):
                    continue
                row = {'file': f.name, 'origin': origin, 'enabled': f.name not in st['disabled_provider'],
                       'removed': origin == 'bundled' and f.name in removed,
                       'size': f.stat().st_size, 'mtime': int(f.stat().st_mtime),
                       'overrides': origin == 'user' and f.name in seen}
                if f.name in seen:
                    seen[f.name]['shadowed'] = True
                seen[f.name] = row
                out.append(row)
        return [r for r in out if not r.get('shadowed') and not r['removed']]
    for f in sorted(EXT_DIR.glob('*.py')):
        if f.name.startswith('_'):
            continue
        out.append({'file': f.name, 'origin': 'user', 'enabled': f.name not in st['disabled_extension'],
                    'size': f.stat().st_size, 'mtime': int(f.stat().st_mtime)})
    return out


def get_source(kind, filename):
    filename = clean_name(filename)
    if kind == 'provider':
        for d, _o in reversed(provider_dirs()):
            if (Path(d) / filename).is_file():
                return _read(Path(d) / filename)
    else:
        p = EXT_DIR / filename
        if p.is_file():
            return _read(p)
    raise SystemError_('Datei nicht gefunden: %s' % filename)


def save_file(kind, filename, code, overwrite=True):
    """Prüft und speichert. Gibt das Prüfergebnis plus 'file' zurück."""
    filename = clean_name(filename)
    chk = check_code(kind, filename, code)
    if not chk['ok']:
        raise SystemError_(' '.join(chk['errors']))
    target = kind_dir(kind) / filename
    with _lock:
        if target.exists() and not overwrite:
            raise SystemError_('„%s“ gibt es schon.' % filename)
        if target.exists():
            _backup(target)
        tmp = target.with_suffix('.tmp')
        tmp.write_text(code.replace('\r\n', '\n'), 'utf-8')
        os.replace(tmp, target)
        st = load_state()
        if kind == 'provider' and filename in st['removed_provider']:
            st['removed_provider'].remove(filename)
        save_state(st)
    chk['file'] = filename
    return chk


def _backup(path):
    """Vorherige Fassung in den Papierkorb legen (Änderungen lassen sich so zurückholen)."""
    dst = TRASH_DIR / ('%s.%d.bak' % (path.name, int(time.time())))
    try:
        shutil.copy2(path, dst)
    except OSError:
        pass
    _prune_trash()


def _prune_trash(keep=60):
    files = sorted(TRASH_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    for f in files[keep:]:
        try:
            f.unlink()
        except OSError:
            pass


def set_enabled(kind, filename, enabled):
    filename = clean_name(filename)
    with _lock:
        st = load_state()
        key = 'disabled_' + kind
        lst = [x for x in st[key] if x != filename]
        if not enabled:
            lst.append(filename)
        st[key] = lst
        save_state(st)


def delete_file(kind, filename):
    """Nutzerdatei -> Papierkorb. Mitgelieferter Scraper -> ausgeblendet (Datei bleibt, wiederherstellbar)."""
    filename = clean_name(filename)
    with _lock:
        target = kind_dir(kind) / filename
        st = load_state()
        if target.is_file():
            dst = TRASH_DIR / ('%s.%s.%d.del' % (kind, filename, int(time.time())))
            shutil.move(str(target), str(dst))
            _prune_trash()
            return 'trash'            # eine darunterliegende mitgelieferte Fassung wird dadurch wieder aktiv
        if kind == 'provider' and (BUNDLED_DIR / filename).is_file():
            if filename not in st['removed_provider']:
                st['removed_provider'].append(filename)
            save_state(st)
            return 'hidden'
    raise SystemError_('Datei nicht gefunden: %s' % filename)


def list_trash():
    out = []
    st = load_state()
    for f in sorted(TRASH_DIR.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
        m = re.match(r'^(provider|extension)\.(.+\.py)\.(\d+)\.del$', f.name)
        if m:
            out.append({'id': f.name, 'kind': m.group(1), 'file': m.group(2), 'ts': int(m.group(3)), 'what': 'gelöscht'})
            continue
        m = re.match(r'^(.+\.py)\.(\d+)\.bak$', f.name)
        if m:
            out.append({'id': f.name, 'kind': '', 'file': m.group(1), 'ts': int(m.group(2)), 'what': 'frühere Fassung'})
    for name in st['removed_provider']:
        out.append({'id': 'bundled:' + name, 'kind': 'provider', 'file': name, 'ts': 0, 'what': 'ausgeblendet (mitgeliefert)'})
    return out


def restore_trash(tid):
    with _lock:
        if tid.startswith('bundled:'):
            name = clean_name(tid[8:])
            st = load_state()
            st['removed_provider'] = [x for x in st['removed_provider'] if x != name]
            save_state(st)
            return name
        src = TRASH_DIR / os.path.basename(tid)
        if not src.is_file():
            raise SystemError_('Nicht im Papierkorb: %s' % tid)
        m = re.match(r'^(provider|extension)\.(.+\.py)\.(\d+)\.del$', src.name)
        if m:
            kind, name = m.group(1), m.group(2)
        else:
            m = re.match(r'^(.+\.py)\.(\d+)\.bak$', src.name)
            if not m:
                raise SystemError_('Unbekannter Papierkorb-Eintrag')
            name = m.group(1)
            kind = 'extension' if (EXT_DIR / name).is_file() and not (PROV_DIR / name).is_file() else 'provider'
        code = _read(src)
        save_file(kind, name, code)
        src.unlink()
        return name


def purge_trash(tid=''):
    with _lock:
        for f in list(TRASH_DIR.iterdir()):
            if not tid or f.name == os.path.basename(tid):
                try:
                    f.unlink()
                except OSError:
                    pass


# ----------------------------------------------------------------------------- Vorlagen

SCRAPER_TEMPLATE = '''# -*- coding: utf-8 -*-
"""Beispiel-Scraper. Speichern, aktivieren, fertig.

Ablauf (wie bei Kodi-Addons):
  load()        liefert Einträge. Ordner haben next_func, abspielbare Einträge is_playable=True.
  search()      optional - macht die Quelle durchsuchbar.
  get_hosters() liefert die Streams zu einem abspielbaren Eintrag.
"""
import xbmcgui
from resources.lib import multiquest, log

SITE_ID = 'meinescraper'          # eindeutige ID (nur a-z, 0-9, _)
SITE_NAME = 'Mein Scraper'        # so heißt die Kachel
SITE_DOMAIN = 'example.org'       # wird als Referer/Origin für Streams genutzt
GLOBAL_SEARCH = True              # False = bei der globalen Suche nicht mitsuchen


def load(url='', params=None):
    if not url:                                    # Startmenü
        return [
            {'title': 'Beispiel-Ordner', 'url': 'ordner', 'next_func': 'load', 'is_playable': False},
            {'title': 'Suche', 'url': '', 'next_func': 'search', 'is_playable': False},
        ]
    # Beispiel: abspielbare Einträge. Hier würdest du mit multiquest.get(...) eine Seite laden.
    return [
        {'title': 'Big Buck Bunny', 'url': 'bbb', 'is_playable': True, 'next_func': 'get_hosters',
         'poster': 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Big_buck_bunny_poster_big.jpg/320px-Big_buck_bunny_poster_big.jpg',
         'year': 2008, 'plot': 'Freier Kurzfilm der Blender Foundation.'},
    ]


def search(query='', params=None):
    q = query or xbmcgui.Dialog().input('Suche')
    log.log('[MeinScraper] Suche: %s' % q)
    return [{'title': 'Treffer für ' + q, 'url': 'bbb', 'is_playable': True, 'next_func': 'get_hosters'}] if q else []


def get_hosters(title='', year='', season=0, episode=0, url='', params=None):
    # Tupel: (Name, Link, direkt?, Qualität, Sprache, Quelle)
    # Mit Kopfzeilen: 'https://…/video.mp4|Referer=https://example.org/'
    return [('Direkt (MP4)', 'https://download.blender.org/peach/bigbuckbunny_movies/BigBuckBunny_320x180.mp4', True, 'SD', 'en', 'Blender')]
'''

EXTENSION_TEMPLATE = '''# -*- coding: utf-8 -*-
"""Beispiel-Erweiterung. Alle Funktionen sind optional.

Erweiterungen laufen in der Engine und können
  * Einträge verändern, bevor die Oberfläche sie sieht      -> process_items
  * Streams filtern/umsortieren/ergänzen                    -> process_hosters
  * eigene API-Routen anbieten (/api/x/<EXT_ID>/<pfad>)     -> register(api): api.route
  * regelmäßig im Hintergrund etwas tun                     -> register(api): api.every
  * eine Reihe oder einen Menüpunkt auf der Startseite zeigen -> api.home_row / api.menu
  * einen Knopf in der Titel-Info anbieten                  -> api.item_action
  * in den Familienchat schreiben                           -> api.chat
  * auf Wiedergabe reagieren                                -> on_play / on_stop
  * ein Einstellungsformular bekommen                       -> EXT_SETTINGS
Fehler in einer Erweiterung werden protokolliert und stören nichts anderes.
"""
EXT_ID = 'beispiel'                       # eindeutige ID (a-z, 0-9, _)
EXT_NAME = 'Beispiel-Erweiterung'
EXT_DESCRIPTION = 'Zeigt, wie Hooks, Zeitplan, Startseiten-Reihe und Einstellungen funktionieren.'
EXT_LINKS = [('Hallo-Seite öffnen', 'hallo')]      # erscheint als Knopf in der Erweiterungsliste

# Einstellungsformular: erscheint in der Erweiterungsliste unter „Einstellungen“. Lesen mit api.get('schluessel').
EXT_SETTINGS = [
    {'key': 'gruss', 'label': 'Begrüßung', 'type': 'text', 'default': 'Hallo'},
    {'key': 'laut', 'label': 'LAUT schreiben', 'type': 'bool', 'default': False},
]


def register(api):
    """api.route(pfad, fn)   api.every(minuten, fn)   api.home_row(titel, fn)   api.menu(titel, fn)
    api.item_action(titel, fn)   api.chat(text)   api.open(quelle, eintrag)   api.get(k, std)   api.set(k, wert)"""
    def hallo(req):
        # req.method, req.query (dict), req.json (dict), req.body (bytes), req.headers (dict)
        n = api.get('besuche', 0) + 1
        api.set('besuche', n)
        text = '%s! Aufruf Nummer %d' % (api.get('gruss'), n)
        return '<h1>%s</h1>' % (text.upper() if api.get('laut') else text)       # str = HTML, dict = JSON, bytes = Datei

    def reihe():
        # Einträge wie bei Scrapern: title, url, poster, year, provider_id, next_func, is_playable …
        return [{'title': 'Big Buck Bunny', 'url': 'bbb', 'is_playable': False, 'plot': 'Beispiel-Eintrag aus einer Erweiterung'}]

    def knopf(item):
        api.log('Knopf gedrückt bei: %s' % item.get('title'))
        return 'Merke ich mir: %s' % item.get('title')           # erscheint als Hinweis unten

    api.route('hallo', hallo)
    api.route('status', lambda req: {'ok': True, 'besuche': api.get('besuche', 0)})
    api.home_row('Aus der Beispiel-Erweiterung', reihe)          # Reihe auf der Startseite
    api.item_action('Beispiel-Knopf', knopf)                     # Knopf in der Titel-Info
    api.log('Beispiel-Erweiterung bereit')


def process_items(provider_id, items):
    """items = Liste von Dicts (title, url, poster, year, kind, …). Zurückgeben: neue Liste (oder None = unverändert)."""
    return None


def process_hosters(provider_id, item, hosters):
    """hosters = Liste von Dicts (name, url, format, quality, lang, headers, drm, live …).
    Beispiel: Direkt-Links vor Embeds sortieren."""
    return sorted(hosters, key=lambda h: 0 if h.get('direct') else 1)


def on_play(item, info):
    """Wiedergabe gestartet. item = der Eintrag, info = {'hoster': Name}."""


def on_stop(item, info):
    """Wiedergabe beendet. info = {'position': Sekunden, 'duration': Sekunden, 'finished': True/False}."""
'''

TEMPLATES = {'provider': SCRAPER_TEMPLATE, 'extension': EXTENSION_TEMPLATE}


# ----------------------------------------------------------------------------- Export / Import

def export_zip(ui=None, full=False, settings=None):
    """Gesamtsystem als ZIP: Einstellungen, eigene Scraper + Erweiterungen, Zustand, UI-Daten (Skins, Favoriten …)."""
    from kodi_runtime import xbmcaddon
    buf = io.BytesIO()
    st = load_state()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json', json.dumps({
            'format': FORMAT, 'app': 'MovieScout', 'created': int(time.time()), 'full': bool(full),
            'providers': [f['file'] for f in list_files('provider') if f['origin'] == 'user'],
            'extensions': [f['file'] for f in list_files('extension')]}, ensure_ascii=False, indent=1))
        z.writestr('settings.json', json.dumps(settings if settings is not None else xbmcaddon.all_settings(), ensure_ascii=False, indent=1))
        z.writestr('state.json', json.dumps(st, ensure_ascii=False, indent=1))
        z.writestr('ui.json', json.dumps(ui or {}, ensure_ascii=False))
        try:
            from . import medialib
            z.writestr('medialib.json', json.dumps(medialib.export_data(), ensure_ascii=False))
        except Exception:                                  # noqa: BLE001
            pass
        for f in PROV_DIR.glob('*.py'):
            z.write(f, 'providers/' + f.name)
        for f in EXT_DIR.glob('*.py'):
            z.write(f, 'extensions/' + f.name)
        if full and BUNDLED_DIR.is_dir():
            for f in BUNDLED_DIR.glob('*.py'):
                if not (PROV_DIR / f.name).exists():
                    z.write(f, 'providers_bundled/' + f.name)
    return buf.getvalue()


def import_zip(data, mode='merge', bundled=False, apply_settings=True):
    """Spielt ein Export-ZIP ein. mode='merge' ergänzt, 'replace' ersetzt Nutzer-Scraper/-Erweiterungen/Zustand.
    Gibt {'report': [...], 'ui': {...}} zurück. Ungültige Dateien werden übersprungen und gemeldet."""
    if len(data) > MAX_ZIP:
        raise SystemError_('Datei ist zu groß.')
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise SystemError_('Das ist keine gültige MovieScout-Sicherung (ZIP).')
    with z:
        names = z.namelist()
        if 'manifest.json' not in names:
            raise SystemError_('manifest.json fehlt – das ist keine MovieScout-Sicherung.')
        try:
            man = json.loads(z.read('manifest.json').decode('utf-8'))
        except Exception:
            raise SystemError_('manifest.json ist beschädigt.')
        if man.get('app') not in ('MovieScout', 'MiniKodi') or int(man.get('format', 0)) > FORMAT:
            raise SystemError_('Die Sicherung stammt von einer neueren oder fremden Version.')
        if sum(i.file_size for i in z.infolist()) > MAX_ZIP * 3:
            raise SystemError_('Die Sicherung entpackt sich zu groß.')
        report, ui = [], {}

        def read_json(name, default):
            if name not in names:
                return default
            try:
                return json.loads(z.read(name).decode('utf-8'))
            except Exception:
                report.append('%s ist beschädigt – übersprungen' % name)
                return default

        with _lock:
            if mode == 'replace':
                for kind in KINDS:
                    for f in list_files(kind):
                        if f['origin'] == 'user':
                            try:
                                delete_file(kind, f['file'])
                            except SystemError_:
                                pass
            for folder, kind in (('providers/', 'provider'), ('extensions/', 'extension'), ('providers_bundled/', 'bundled')):
                for n in names:
                    if not n.startswith(folder) or n.endswith('/'):
                        continue
                    base = n[len(folder):]
                    if '/' in base or '\\' in base:
                        report.append('%s: Unterordner werden nicht unterstützt' % n)
                        continue
                    if kind == 'bundled' and not bundled:
                        continue
                    k = 'provider' if kind == 'bundled' else kind
                    try:
                        code = z.read(n).decode('utf-8')
                        res = save_file(k, base, code)
                        report.append('%s eingespielt%s' % (res['file'], ' (Warnung: ' + '; '.join(res['warnings']) + ')' if res['warnings'] else ''))
                    except (SystemError_, UnicodeDecodeError) as e:
                        report.append('%s übersprungen: %s' % (base, e))
            if any(n.startswith('providers_bundled/') for n in names) and not bundled:
                report.append('Original-Scraper in der Sicherung wurden nicht eingespielt (die installierte Version bleibt).')
            sts = read_json('state.json', None)
            if isinstance(sts, dict):
                cur = load_state() if mode != 'replace' else {'disabled_provider': [], 'disabled_extension': [], 'removed_provider': []}
                for k in ('disabled_provider', 'disabled_extension', 'removed_provider'):
                    vals = [x for x in sts.get(k, []) if isinstance(x, str) and NAME_RE.match(x)]
                    cur[k] = sorted(set(cur.get(k, [])) | set(vals)) if mode != 'replace' else sorted(set(vals))
                save_state(cur)
                report.append('Aktiv/Inaktiv-Zustand übernommen')
            setg = read_json('settings.json', None)
            if apply_settings and isinstance(setg, dict):
                from kodi_runtime import xbmcaddon
                xbmcaddon.save_settings({str(k): str(v) for k, v in setg.items()})
                report.append('%d Einstellungen übernommen' % len(setg))
            ui = read_json('ui.json', {})
            ml = read_json('medialib.json', None)
            if isinstance(ml, dict):
                try:
                    from . import medialib
                    n = medialib.import_data(ml, replace=(mode == 'replace'))
                    report.append('Mediathek: %d Einträge übernommen' % n)
                except Exception as e:                      # noqa: BLE001
                    report.append('Mediathek übersprungen: %s' % e)
    return {'report': report, 'ui': ui if isinstance(ui, dict) else {}}
