# -*- coding: utf-8 -*-
"""Schutz vor Sperren: höfliche Abfragen bei Hostern und Seiten (Tempo, Gleichzeitigkeit, Quoten, Abkühlzeit).

Viele Seiten sperren die Adresse, wenn zu viele Anfragen zu schnell kommen. Alle Abfragen der Scraper laufen deshalb
durch dieses Modul (multiquest ruft call() auf). Je Host (Domain) gilt:

  - höchstens N Anfragen gleichzeitig und ein kleiner Mindestabstand       (Stufe „Normal“ / „Streng“ / „Aus“)
  - optionale Quote je Host: „voe.sx = 30/min“ (Einstellung „Quoten“, eine Zeile je Host)
  - antwortet ein Host mit 429 (oder 503 + Retry-After), gilt eine Abkühlzeit: bis dahin warten Anfragen (höchstens
    MAX_WAIT Sekunden, danach gibt es eine klare Fehlermeldung statt endlosem Hängen); der Mindestabstand wächst
    selbstständig und sinkt bei guten Antworten wieder
  - ein einzelner Wiederholungsversuch bei 429 (nur GET/HEAD), wenn die Wartezeit kurz ist

Optional: ein eigener Umweg-Proxy (Einstellung „Proxy“, z. B. http://benutzer:passwort@host:port) für bestimmte Hosts
(„Proxy für Hosts“). Das ist KEIN Wechseln von Adressen, um Sperren zu umgehen – nur ein Proxy, den du selbst bestimmst.

Nicht betroffen: der Stream-Proxy (Videosegmente) und Verbindungen zu Geräten im eigenen Netz.
"""
import re
import threading
import time
from urllib.parse import urlparse

from kodi_runtime import xbmcaddon

MODES = {'off': None, 'normal': {'conc': 6, 'gap': 0.10}, 'strict': {'conc': 3, 'gap': 0.40}}
MAX_WAIT = 15.0            # länger wird nicht gewartet: lieber klar „gesperrt, später wieder“ melden
MAX_COOL = 120.0
_lock = threading.Lock()
_HOSTS = {}
_CONF = {'t': 0.0, 'v': None}


class RateLimited(Exception):
    """Der Host bremst (Abkühlzeit/Quote). Text ist für Nutzer gedacht."""


class _Host:
    def __init__(self, name):
        self.name = name
        self.cv = threading.Condition()
        self.inflight = 0
        self.last = 0.0                    # Start der letzten Anfrage
        self.extra = 0.0                   # zusätzlicher Abstand (wächst nach 429)
        self.cool_until = 0.0
        self.strikes = 0
        self.strike_t = 0.0
        self.ok_run = 0
        self.stamps = []                   # Startzeiten der letzten Minute (für Quoten)
        self.n = self.n429 = self.waited = 0.0


def _host_of(url):
    try:
        return (urlparse(url).hostname or '').lower()
    except Exception:                      # noqa: BLE001
        return ''


def _is_local(host):
    return (not host or host in ('localhost',) or host.startswith(('127.', '10.', '192.168.', '169.254.'))
            or re.match(r'^172\.(1[6-9]|2\d|3[01])\.', host) is not None or host.endswith('.local'))


def _parse_quota(text):
    out = {}
    for line in str(text or '').replace(';', '\n').splitlines():
        m = re.match(r'^\s*([A-Za-z0-9.\-*]+)\s*[=:]\s*(\d+)\s*/\s*(min|minute|sek|s|std|h)?\s*$', line, re.I)
        if not m:
            continue
        n, unit = int(m.group(2)), (m.group(3) or 'min').lower()
        per = 60.0 if unit in ('min', 'minute') else 1.0 if unit in ('sek', 's') else 3600.0
        if n > 0:
            out[m.group(1).lower()] = (n, per)
    return out


def _conf():
    now = time.time()
    with _lock:
        if _CONF['v'] is not None and now - _CONF['t'] < 3.0:
            return _CONF['v']
    try:
        s = xbmcaddon.all_settings()
    except Exception:                      # noqa: BLE001
        s = {}
    mode = str(s.get('net_protect') or 'normal').lower()
    v = {
        'mode': mode if mode in MODES else 'normal',
        'quota': _parse_quota(s.get('net_quota')),
        'proxy': str(s.get('net_proxy') or '').strip(),
        'proxy_hosts': [h.strip().lower() for h in re.split(r'[,\s;]+', str(s.get('net_proxy_hosts') or '')) if h.strip()],
    }
    with _lock:
        _CONF.update(t=now, v=v)
    return v


def invalidate():
    with _lock:
        _CONF.update(t=0.0, v=None)


def proxy_for(url):
    """Umweg-Proxy für diese Adresse oder ''."""
    c = _conf()
    if not c['proxy'] or not c['proxy_hosts']:
        return ''
    host = _host_of(url)
    if _is_local(host):
        return ''
    for pat in c['proxy_hosts']:
        if pat == '*' or host == pat or host.endswith('.' + pat.lstrip('*.')):
            return c['proxy']
    return ''


def _state(host):
    with _lock:
        st = _HOSTS.get(host)
        if st is None:
            if len(_HOSTS) > 300:
                for k in sorted(_HOSTS, key=lambda k: _HOSTS[k].last)[:100]:
                    _HOSTS.pop(k, None)
            st = _HOSTS[host] = _Host(host)
        return st


def _quota_for(c, host):
    for pat, val in c['quota'].items():
        if pat == host or host.endswith('.' + pat.lstrip('*.')):
            return val
    return None


def _acquire(st, c, mode):
    """Wartet, bis die Anfrage dran ist. Gibt die Wartezeit zurück oder wirft RateLimited."""
    t0 = time.time()
    deadline = t0 + MAX_WAIT
    quota = _quota_for(c, st.name)
    with st.cv:
        while True:
            now = time.time()
            wait = 0.0
            reason = ''
            if st.cool_until > now:
                wait, reason = st.cool_until - now, 'Der Host hat gebremst (zu viele Anfragen)'
            if mode:
                if st.inflight >= mode['conc']:
                    wait, reason = max(wait, 0.05), reason or 'Andere Anfragen laufen noch'
                gap = mode['gap'] + st.extra
                if now - st.last < gap:
                    wait = max(wait, gap - (now - st.last))
            if quota:
                n, per = quota
                st.stamps = [x for x in st.stamps if now - x < per]
                if len(st.stamps) >= n:
                    w = per - (now - st.stamps[0])
                    if w > wait:
                        wait, reason = w, 'Quote für %s erreicht (%d je %d s)' % (st.name, n, per)
            if wait <= 0:
                st.inflight += 1
                st.last = now
                st.n += 1
                if quota:
                    st.stamps.append(now)
                waited = now - t0
                st.waited += waited
                return waited
            if now + wait > deadline:
                raise RateLimited('%s – bitte in etwa %d Sekunden noch einmal versuchen.' % (reason or 'Zu viele Anfragen', int(wait) + 1))
            st.cv.wait(timeout=min(wait, 0.5))


def _release(st, status, headers, method, cooled):
    now = time.time()
    with st.cv:
        st.inflight = max(0, st.inflight - 1)
        retry_after = 0.0
        try:
            retry_after = float((headers or {}).get('Retry-After', 0) or 0)
        except (ValueError, TypeError):
            retry_after = 0.0
        throttled = status == 429 or (status == 503 and retry_after > 0)
        if throttled:
            st.n429 += 1
            if now - st.strike_t > 300:
                st.strikes = 0
            st.strikes += 1
            st.strike_t = now
            cool = retry_after if retry_after > 0 else min(MAX_COOL, 5.0 * 2 ** (st.strikes - 1))
            st.cool_until = now + min(MAX_COOL, cool)
            st.extra = min(5.0, max(0.5, st.extra * 2))
            st.ok_run = 0
        elif status and status < 400:
            st.ok_run += 1
            if st.ok_run >= 20 and st.extra > 0:
                st.extra = st.extra / 2 if st.extra > 0.2 else 0.0
                st.ok_run = 0
        st.cv.notify_all()
        return throttled, max(0.0, st.cool_until - now)


def call(url, method, fn):
    """Führt fn() (die eigentliche Anfrage, gibt eine Antwort mit status_code/headers zurück) mit Schutz aus."""
    c = _conf()
    host = _host_of(url)
    mode = MODES.get(c['mode'])
    if _is_local(host) or (mode is None and not c['quota']):
        return fn()
    st = _state(host)
    for attempt in (0, 1):
        _acquire(st, c, mode)
        resp = None
        try:
            resp = fn()
        finally:
            status = getattr(resp, 'status_code', 0) or 0
            throttled, cool = _release(st, status, getattr(resp, 'headers', None), method, False)
        if throttled and attempt == 0 and method in ('GET', 'HEAD') and cool <= 8.0:
            time.sleep(cool + 0.05)                       # einmal höflich später wiederholen
            continue
        return resp
    return resp


def snapshot():
    now = time.time()
    with _lock:
        rows = list(_HOSTS.values())
    out = []
    for st in rows:
        out.append({'host': st.name, 'requests': int(st.n), 'throttled': int(st.n429), 'waited_s': round(st.waited, 1),
                    'gap_ms': int(st.extra * 1000), 'cooling_s': int(max(0, st.cool_until - now)), 'inflight': st.inflight})
    out.sort(key=lambda r: (-r['cooling_s'], -r['requests']))
    return out[:40]


def reset():
    with _lock:
        _HOSTS.clear()
    invalidate()
