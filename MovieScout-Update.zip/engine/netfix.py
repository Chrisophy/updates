# -*- coding: utf-8 -*-
"""Robustere Verbindungen im Mobilfunknetz.

Im WLAN gibt es meist nur IPv4. Im Mobilnetz liefert der DNS oft IPv6-Adressen zuerst (teils nur über NAT64/464XLAT
erreichbar, teils ganz ohne Route). Pythons Standard-Verbindungsaufbau probiert die Adressen nacheinander mit der vollen
Wartezeit durch - eine tote IPv6-Adresse blockiert dann jede Anfrage, bis sie abläuft, und es "geht gar nichts".

Dieser Ersatz für socket.create_connection probiert IPv4 zuerst, begrenzt jeden Versuch (außer dem letzten) auf wenige
Sekunden und weicht dann auf die nächste Adresse aus. Wird beim Import der Engine automatisch aktiv."""
import socket

_ORIG = socket.create_connection
_TRY = 6.0          # Sekunden pro Versuch, solange noch andere Adressen übrig sind


def create_connection(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None, *args, **kw):
    host, port = address
    if isinstance(host, str) and host.startswith('[') and host.endswith(']'):
        host = host[1:-1]
    try:
        infos = socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM)
    except socket.gaierror:
        raise
    if not infos:
        raise OSError('getaddrinfo liefert keine Adresse')
    v4 = [i for i in infos if i[0] == socket.AF_INET]
    other = [i for i in infos if i[0] != socket.AF_INET]
    order = v4 + other
    total = timeout if timeout is not socket._GLOBAL_DEFAULT_TIMEOUT else socket.getdefaulttimeout()
    err = None
    for n, (af, socktype, proto, _canon, sa) in enumerate(order):
        sock = None
        try:
            sock = socket.socket(af, socktype, proto)
            last = n == len(order) - 1
            t = total if (last or not total) else min(total, _TRY)
            if not last and not total:
                t = _TRY
            sock.settimeout(t)
            if source_address:
                sock.bind(source_address)
            sock.connect(sa)
            sock.settimeout(total)            # ursprüngliche Wartezeit für die Daten wiederherstellen
            return sock
        except OSError as e:
            err = e
            if sock is not None:
                sock.close()
    raise err


def apply():
    socket.create_connection = create_connection
    try:                                       # requests/urllib3 nutzen ihre eigene Kopie
        import urllib3.util.connection as _c
        _orig = _c.create_connection

        def _u3(address, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None, socket_options=None):
            sock = create_connection(address, timeout, source_address)
            for opt in socket_options or ():
                sock.setsockopt(*opt)
            return sock
        _c.create_connection = _u3
    except Exception:
        pass


apply()
