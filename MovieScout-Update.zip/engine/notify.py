# -*- coding: utf-8 -*-
"""Meldungen der Engine für die Android-App (Benachrichtigungen).

Die Engine legt hier ab, was der Nutzer mitbekommen soll, auch wenn die Oberfläche gerade nicht offen ist:
neue Chat-Nachrichten, Meldungen von Erweiterungen (z. B. die Erinnerung "Heute Abend im TV") und fertige
Downloads. Der Hintergrunddienst der App fragt /api/notify ab und zeigt daraus Android-Benachrichtigungen.

Nur ein kleiner Ringspeicher im Arbeitsspeicher: nach einem Neustart der Engine ist er leer, die IDs zählen
dann wieder bei 1 los (die App merkt das an "last" und fängt neu an).
"""
import threading
import time

_LOCK = threading.Lock()
_EVENTS = []              # [{id, ts, kind, title, text, ...}]
_NEXT = 1
_MAX = 200
_KINDS = ('chat', 'ext', 'download')


def push(kind, title, text='', **extra):
    """Meldung ablegen. kind: chat | ext | download. Gibt die Meldung zurück."""
    global _NEXT
    if kind not in _KINDS:
        raise ValueError('Unbekannte Art: %s' % kind)
    ev = {'kind': kind, 'title': str(title or '')[:120], 'text': str(text or '')[:400], 'ts': int(time.time())}
    for k, v in extra.items():
        if isinstance(v, (str, int, float, bool)) or v is None:
            ev[k] = v
    with _LOCK:
        ev['id'] = _NEXT
        _NEXT += 1
        _EVENTS.append(ev)
        del _EVENTS[:-_MAX]
    return ev


def last_id():
    with _LOCK:
        return _NEXT - 1


def since(after):
    """Alle Meldungen mit einer ID größer als after."""
    with _LOCK:
        return [dict(e) for e in _EVENTS if e['id'] > after]


def reset():
    """Nur für Tests."""
    global _NEXT
    with _LOCK:
        _EVENTS.clear()
        _NEXT = 1
