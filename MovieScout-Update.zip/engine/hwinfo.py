# -*- coding: utf-8 -*-
"""Geräte-Info für die Einstellungen: Hardware, System, Speicher. Läuft auf Android (Chaquopy), Linux, Windows, macOS.
Alles ist freiwillig: Was sich nicht lesen lässt (Android sperrt manches), fehlt einfach - nichts davon wirft einen Fehler."""
import glob
import os
import platform
import re
import shutil
import subprocess
import sys
import time

_NA = ('', 'unknown', 'Nicht verfügbar')


def prop(name):
    """Android-Systemeigenschaft (getprop); ohne Android leer."""
    try:
        out = subprocess.check_output(['getprop', name], stderr=subprocess.DEVNULL, timeout=3).decode('utf-8', 'replace').strip()
        return '' if out in _NA else out
    except Exception:                                    # noqa: BLE001
        return ''


def _read(path, limit=200000):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            return f.read(limit)
    except Exception:                                    # noqa: BLE001
        return ''


def is_android():
    return bool(os.environ.get('ANDROID_ROOT') or os.environ.get('ANDROID_DATA')) or 'android' in sys.platform or os.path.exists('/system/build.prop')


def cpu_cores():
    n = len(glob.glob('/sys/devices/system/cpu/cpu[0-9]*'))
    return n or os.cpu_count() or 0


def cpu_max_ghz():
    best = 0
    for p in glob.glob('/sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq'):
        try:
            best = max(best, int(_read(p).strip() or 0))
        except ValueError:
            pass
    return round(best / 1_000_000, 2) if best else 0


def _cpuinfo_name():
    txt = _read('/proc/cpuinfo')
    for key in ('model name', 'Hardware', 'Processor', 'cpu model'):
        m = re.search(r'^%s\s*:\s*(.+)$' % re.escape(key), txt, re.M | re.I)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return ''


def memory():
    """(gesamt, frei) in Bytes; frei = verfügbar ohne Auslagern."""
    txt = _read('/proc/meminfo', 8000)
    tot = av = 0
    for line in txt.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[1].isdigit():
            if parts[0] == 'MemTotal:':
                tot = int(parts[1]) * 1024
            elif parts[0] == 'MemAvailable:':
                av = int(parts[1]) * 1024
    if not tot and os.name == 'nt':
        try:
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [('l', ctypes.c_ulong), ('load', ctypes.c_ulong), ('tot', ctypes.c_ulonglong), ('av', ctypes.c_ulonglong),
                            ('a', ctypes.c_ulonglong), ('b', ctypes.c_ulonglong), ('c', ctypes.c_ulonglong), ('d', ctypes.c_ulonglong), ('e', ctypes.c_ulonglong)]
            ms = MS()
            ms.l = ctypes.sizeof(ms)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms))
            tot, av = int(ms.tot), int(ms.av)
        except Exception:                                # noqa: BLE001
            pass
    return tot, av


def disk(path):
    try:
        u = shutil.disk_usage(path)
        return {'total': int(u.total), 'free': int(u.free)}
    except Exception:                                    # noqa: BLE001
        return None


def battery():
    """Akku aus dem Kernel, falls Android das erlaubt (sonst liefert die Oberfläche den Wert aus dem Browser)."""
    for d in glob.glob('/sys/class/power_supply/*'):
        if _read(d + '/type', 50).strip().lower() != 'battery':
            continue
        cap = _read(d + '/capacity', 20).strip()
        if cap.isdigit():
            st = _read(d + '/status', 40).strip().lower()
            return {'percent': int(cap), 'charging': st in ('charging', 'full')}
    return None


def uptime_s():
    try:
        return int(float(_read('/proc/uptime', 80).split()[0]))
    except Exception:                                    # noqa: BLE001
        return 0


def collect(version='', data_dir=None):
    android = is_android()
    p = prop if android else (lambda n: '')
    tot, av = memory()
    out = {'android': android, 'time': int(time.time())}
    brand = p('ro.product.brand') or p('ro.product.manufacturer')
    out['device'] = {
        'brand': brand, 'manufacturer': p('ro.product.manufacturer'), 'model': p('ro.product.model') or (platform.node() if not android else ''),
        'name': p('ro.product.device'), 'board': p('ro.board.platform') or p('ro.product.board'),
        'android': p('ro.build.version.release'), 'sdk': p('ro.build.version.sdk'), 'patch': p('ro.build.version.security_patch'),
        'build': p('ro.build.display.id'), 'tv': 'tv' in (p('ro.build.characteristics') or '').lower() or p('ro.build.characteristics') == 'tv',
    }
    soc = p('ro.soc.model') or p('ro.hardware.chipname') or p('ro.hardware') or _cpuinfo_name()
    maker = p('ro.soc.manufacturer')
    if soc and maker and maker.lower() not in soc.lower():
        soc = maker + ' ' + soc
    abis = p('ro.product.cpu.abilist')
    out['cpu'] = {'chipset': soc, 'arch': platform.machine() or '', 'cores': cpu_cores(), 'ghz': cpu_max_ghz(),
                  'abis': [a for a in abis.split(',') if a] if abis else []}
    out['gpu'] = {'egl': p('ro.hardware.egl'), 'vulkan': p('ro.hardware.vulkan')}
    out['ram'] = {'total': tot, 'free': av}
    st = {}
    d = disk(str(data_dir)) if data_dir else None
    if d:
        st['app'] = d
    sh = disk('/storage/emulated/0') if android else None
    if sh:
        st['shared'] = sh
    out['storage'] = st
    out['os'] = {'kernel': platform.release(), 'system': platform.system(), 'python': platform.python_version(),
                 'platform': platform.platform() if not android else ''}
    out['battery'] = battery()
    out['uptime'] = uptime_s()
    out['app'] = {'version': version}
    return out
