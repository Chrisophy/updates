# -*- coding: utf-8 -*-
"""Mitgelieferte Beispiel-Erweiterungen: in der Erweiterungsliste mit einem Tipp installieren, in der Werkstatt ansehen und anpassen."""

# Greifen in Titel, Quellen oder Reihenfolge ein: werden bei „Alle installieren“ nicht mitgenommen, nur einzeln
NOT_IN_BULK = {'jugendschutz', 'titel_putzer', 'hoster_sortierer'}

EXAMPLES = [
    {'id': 'hoster_sortierer', 'file': 'hoster_sortierer.py', 'title': 'Hoster-Sortierer',
     'description': 'Streams nach deinem Geschmack ordnen: Wunsch-Sprache, Lieblings-Hoster, hohe Qualität zuerst; unerwünschte Hoster ausblenden.',
     'code': r'''# -*- coding: utf-8 -*-
"""Hoster-Sortierer: ordnet die Streams so, wie du sie am liebsten hast.

Reihenfolge der Kriterien: Wunsch-Sprache, bevorzugte Hoster (in deiner Reihenfolge), direkte Streams, hohe Qualität.
Ausgeblendete Hoster verschwinden. Bleibt dadurch gar nichts übrig, zeigt die App trotzdem alle Streams.
Alle Einstellungen findest du in der Erweiterungsliste unter „Einstellungen“.
"""
import re

EXT_ID = 'hoster_sortierer'
EXT_NAME = 'Hoster-Sortierer'
EXT_DESCRIPTION = 'Streams nach deinem Geschmack ordnen: Sprache, Lieblings-Hoster, Qualität; unerwünschte Hoster ausblenden.'
EXT_SETTINGS = [
    {'key': 'sprache', 'label': 'Sprache zuerst', 'type': 'select', 'default': 'de',
     'options': [['egal', 'egal'], ['de', 'Deutsch'], ['en', 'Englisch']]},
    {'key': 'bevorzugt', 'label': 'Bevorzugte Hoster (in dieser Reihenfolge)', 'type': 'text', 'default': '',
     'hint': 'Komma-getrennt, ein Teil des Namens genügt – z. B.  voe, streamtape, doodstream'},
    {'key': 'ausblenden', 'label': 'Diese Hoster nie anzeigen', 'type': 'text', 'default': '',
     'hint': 'Komma-getrennt – z. B.  mixdrop, upstream'},
    {'key': 'qualitaet', 'label': 'Qualität', 'type': 'select', 'default': 'hoch',
     'options': [['egal', 'egal'], ['hoch', 'hohe Qualität zuerst']]},
    {'key': 'direkt', 'label': 'Direkte Streams vor Embeds', 'type': 'bool', 'default': True,
     'hint': 'Direkte Streams starten schneller und brauchen kein Auflösen.'},
]

_api = None
_DEFAULTS = {f['key']: f['default'] for f in EXT_SETTINGS}


def register(api):
    global _api
    _api = api


def _s(key):
    if _api is not None:
        v = _api.get(key)
        if v is not None:
            return v
    return _DEFAULTS.get(key)


def _words(text):
    return [w.strip().lower() for w in str(text or '').replace(';', ',').split(',') if w.strip()]


def _label(h):
    return ('%s %s' % (h.get('name') or '', h.get('source') or '')).lower()


def _quality(h):
    q = ('%s %s' % (h.get('quality') or '', h.get('name') or '')).lower()
    if re.search(r'\b(cam|hdcam|telesync|ts)\b', q):
        return 0
    if re.search(r'2160|\b4k\b|\buhd\b', q):
        return 4
    if re.search(r'1080|\bfhd\b|full ?hd', q):
        return 3
    if re.search(r'720|\bhd\b', q):
        return 2
    if re.search(r'480|360|\bsd\b', q):
        return 1
    return 1.5                                      # unbekannt: zwischen SD und HD


def _lang(h):
    s = str(h.get('lang') or '').lower()
    if s.startswith('de') or 'german' in s or 'deutsch' in s:
        return 'de'
    if s.startswith('en') or 'engl' in s:
        return 'en'
    return ''


def process_hosters(provider_id, item, hosters):
    block = _words(_s('ausblenden'))
    if block:
        keep = [h for h in hosters if not any(b in _label(h) for b in block)]
        if keep:
            hosters = keep
    pref = _words(_s('bevorzugt'))
    want = str(_s('sprache') or 'egal')
    by_quality = _s('qualitaet') == 'hoch'
    direct_first = bool(_s('direkt'))

    def key(h):
        lab = _label(h)
        rank = next((i for i, p in enumerate(pref) if p in lab), len(pref))
        lang_miss = 0 if want == 'egal' or _lang(h) == want else 1
        return (lang_miss, rank, 0 if (h.get('direct') or not direct_first) else 1, -_quality(h) if by_quality else 0)

    return sorted(hosters, key=key)
'''},
    {'id': 'titel_putzer', 'file': 'titel_putzer.py', 'title': 'Titel-Putzer',
     'description': 'Entfernt [HD], (German), „- Stream“ & Co. aus Titeln und fasst doppelte Einträge zusammen.',
     'code': r'''# -*- coding: utf-8 -*-
"""Titel-Putzer: räumt Titel in den Listen auf.

* Zusätze wie [HD], (German), *4K* hinter dem Titel verschwinden
* Anhänge wie „ - Stream“, „ online sehen“, „ kostenlos“ verschwinden
* doppelte Einträge (gleicher Titel, gleiches Jahr) werden zu einem zusammengefasst
* auf Wunsch werden GROSSGESCHRIEBENE Titel normal geschrieben
Nur die Anzeige ändert sich, Links und Quellen bleiben unberührt.
"""
import re

EXT_ID = 'titel_putzer'
EXT_NAME = 'Titel-Putzer'
EXT_DESCRIPTION = 'Entfernt [HD]/(German)/„- Stream“ aus Titeln und fasst doppelte Einträge zusammen.'
EXT_SETTINGS = [
    {'key': 'klammern', 'label': 'Zusätze in Klammern entfernen', 'type': 'bool', 'default': True,
     'hint': 'z. B. [HD], (German), [DE], *4K* – Jahreszahlen wie (2019) bleiben stehen.'},
    {'key': 'anhang', 'label': 'Anhänge wie „- Stream“ oder „online sehen“ entfernen', 'type': 'bool', 'default': True},
    {'key': 'extra', 'label': 'Eigene Wörter entfernen', 'type': 'text', 'default': '',
     'hint': 'Komma-getrennt, ganze Wörter – z. B.  Kinofassung, Extended'},
    {'key': 'doppelte', 'label': 'Doppelte Einträge zusammenfassen', 'type': 'bool', 'default': True},
    {'key': 'gross', 'label': 'GROSSGESCHRIEBENE Titel normal schreiben', 'type': 'bool', 'default': False},
]

_api = None
_DEFAULTS = {f['key']: f['default'] for f in EXT_SETTINGS}
_TAGS = {'hd', 'fhd', 'full', 'fullhd', 'uhd', '4k', 'sd', 'hq', 'de', 'ger', 'german', 'deutsch', 'dt', 'dub', 'dubbed',
         'sub', 'subbed', 'en', 'engl', 'english', 'ac3', 'cam', 'ts', 'hdrip', 'bluray', 'webrip', 'web', 'dl', 'stream', 'online'}
_BRACKETS = re.compile(r'\s*(\[[^\[\]]{1,30}\]|\([^()]{1,30}\)|\{[^{}]{1,30}\}|\*[^*]{1,20}\*)\s*')
_TAIL = re.compile(r'\s*[-–—|:]\s*(?:stream|streamen|online|kostenlos|gratis|ganzer film|ansehen|anschauen|sehen|hd|german|deutsch)'
                   r'(?:\s+(?:stream|streamen|online|kostenlos|gratis|ansehen|anschauen|sehen|hd|german|deutsch))*\s*$', re.I)
_TAIL2 = re.compile(r'\s+(?:online\s+(?:sehen|ansehen|anschauen|streamen)|kostenlos\s+(?:sehen|anschauen|streamen)?|stream\s+deutsch)\s*$', re.I)


def register(api):
    global _api
    _api = api


def _s(key):
    if _api is not None:
        v = _api.get(key)
        if v is not None:
            return v
    return _DEFAULTS.get(key)


def _drop_bracket(m):
    inner = m.group(1)[1:-1].strip().lower()
    toks = [t for t in re.split(r'[\s,/+|&.\-]+', inner) if t]
    return ' ' if toks and all(t in _TAGS for t in toks) else m.group(0)


def _shout(m):
    w = m.group(0)
    return w if len(w) <= 4 and set(w) <= set('IVXLCDM') else w[0] + w[1:].lower()


def clean_title(title):
    t = str(title or '')
    if _s('klammern'):
        t = _BRACKETS.sub(_drop_bracket, t)
    if _s('anhang'):
        for _ in range(4):
            n = _TAIL2.sub('', _TAIL.sub('', t))
            if n == t:
                break
            t = n
    for w in [x.strip() for x in str(_s('extra') or '').split(',') if x.strip()]:
        t = re.sub(r'(?<!\w)%s(?!\w)' % re.escape(w), ' ', t, flags=re.I)
    t = re.sub(r'\s{2,}', ' ', t).strip(' -–—|:')
    if _s('gross') and sum(c.isalpha() for c in t) >= 5 and t == t.upper():
        t = re.sub(r"[A-ZÄÖÜ][A-ZÄÖÜ']*", _shout, t)
    return t


def _key(it):
    return (re.sub(r'[\W_]+', '', str(it.get('title') or '').lower()), str(it.get('year') or ''), str(it.get('kind') or ''))


def process_items(provider_id, items):
    out = []
    for it in items:
        old = str(it.get('title') or '')
        new = clean_title(old)
        if new and new != old:
            it['title'] = new
        out.append(it)
    if _s('doppelte') and len(out) >= 3:
        seen, merged = {}, []
        for it in out:
            if not it.get('poster'):                  # nur Poster-Listen (Filme/Serien), nie Menüs oder Folgenlisten
                merged.append(it)
                continue
            k = _key(it)
            first = seen.get(k)
            if first is None:
                seen[k] = it
                merged.append(it)
                continue
            for f in ('plot', 'year', 'fanart', 'imdb', 'tmdb', 'rating'):
                if not first.get(f) and it.get(f):
                    first[f] = it[f]
        out = merged
    return out
'''},
    {'id': 'neue_folgen', 'file': 'neue_folgen.py', 'title': 'Neue-Folgen-Wächter',
     'description': 'Beobachtet Serien (Knopf „🔔 Neue Folgen melden“ in der Titel-Info) und meldet neue Folgen im Familienchat.',
     'code': r'''# -*- coding: utf-8 -*-
"""Neue-Folgen-Wächter: meldet neue Folgen deiner Serien im Familienchat.

So geht es: In der Info eines Titels auf „🔔 Neue Folgen melden“ tippen. Der Wächter merkt sich, welche Folgen es
schon gibt, schaut dann regelmäßig im Hintergrund nach und schreibt eine Nachricht in den Familienchat, sobald etwas
Neues dazukommt. Tippt jemand auf die Nachricht, öffnet sich die Folge (bei mehreren neuen: die Serie).
Die beobachteten Serien stehen auch als Reihe auf der Startseite. Nochmal auf den Knopf tippen beendet die Beobachtung.
"""
import json
import re
import time
from html import escape

EXT_ID = 'neue_folgen'
EXT_NAME = 'Neue-Folgen-Wächter'
EXT_DESCRIPTION = 'Beobachtet Serien und meldet neue Folgen im Familienchat.'
EXT_LINKS = [('Beobachtete Serien', 'liste')]
EXT_SETTINGS = [
    {'key': 'intervall', 'label': 'Nachsehen alle … Minuten', 'type': 'number', 'default': 180, 'min': 30, 'max': 2880,
     'hint': 'Änderungen gelten sofort. Nicht zu oft, sonst werden die Quellen belastet.'},
    {'key': 'chat', 'label': 'Neue Folgen im Familienchat melden', 'type': 'bool', 'default': True},
    {'key': 'absender', 'label': 'Absender im Chat', 'type': 'text', 'default': '🔔 Folgen-Wächter'},
]

_PAGER = re.compile(r'seite|weiter|next|zurück|zurueck|back|mehr|suche|search|a-z|genre|jahr', re.I)
_api = None


def _watch():
    d = _api.get('watch', {})
    return d if isinstance(d, dict) else {}


def _key(item):
    return '%s|%s' % (item.get('provider_id') or '', (item.get('url') or item.get('title') or '').strip().lower())


def _mini(item):
    """Eintrag schlank speichern (alles, was zum späteren Öffnen nötig ist)."""
    out = {}
    for k, v in item.items():
        if k in ('fanart', 'plot'):
            continue
        try:
            if len(json.dumps(v, ensure_ascii=False)) <= 500:
                out[k] = v
        except (TypeError, ValueError):
            pass
    if item.get('plot'):
        out['plot'] = str(item['plot'])[:200]
    return out


def _leaves(item, depth=0, budget=None):
    """Alle abspielbaren Einträge unterhalb eines Serien-Ordners (höchstens 3 Ebenen, begrenzte Zahl Abrufe)."""
    budget = budget if budget is not None else [14]
    if budget[0] <= 0:
        return []
    budget[0] -= 1
    try:
        items = _api.open(item.get('provider_id') or '', item)
    except Exception:
        if depth == 0:
            raise
        return []
    plays = [i for i in items if i.get('kind') == 'play']
    if plays:
        return plays
    out = []
    if depth < 2:
        for f in items:
            if f.get('kind') == 'folder' and not _PAGER.search(f.get('title') or ''):
                out += _leaves(f, depth + 1, budget)
    return out


def _leaf_key(it):
    return (it.get('url') or it.get('title') or '').strip()


def _check_one(ent):
    """Eine Serie prüfen. Gibt die Zahl neuer Folgen zurück (meldet sie im Chat)."""
    leaves = _leaves(ent['item'])
    ent['checked'] = int(time.time())
    if not leaves:
        return 0                                     # nichts erkannt: Stand nicht anfassen
    keys = {}
    for it in leaves:
        keys.setdefault(_leaf_key(it), it)
    if ent.get('seen') is None:                      # erste Prüfung: nur Stand merken
        ent['seen'] = list(keys)[:3000]
        return 0
    known = set(ent['seen'])
    new = [(k, it) for k, it in keys.items() if k not in known]
    if not new:
        return 0
    ent['seen'] = (ent['seen'] + [k for k, _ in new])[-3000:]
    ent['last_new'] = int(time.time())
    if _api.get('chat'):
        titles = [it.get('title') or '?' for _, it in new]
        if len(new) == 1:
            text = 'Neue Folge bei „%s“: %s' % (ent['title'], titles[0])
            att = _mini(new[0][1])
        else:
            text = 'Neue Folgen bei „%s“: %s%s' % (ent['title'], ', '.join(titles[:4]), ' … (+%d)' % (len(new) - 4) if len(new) > 4 else '')
            att = ent['item']
        _api.chat(text, item=att, author=_api.get('absender') or None)
    return len(new)


def check_all():
    watch = _watch()
    total = 0
    for k, ent in list(watch.items()):
        try:
            total += _check_one(ent)
        except Exception as e:
            _api.log('Prüfen fehlgeschlagen (%s): %s' % (ent.get('title'), e), 'warning')
        time.sleep(1)
    _api.set('watch', watch)
    return total


def _toggle(item):
    if item.get('kind') == 'play':
        return 'Das ist ein einzelner Film oder eine einzelne Folge – beobachten kann ich Serien (Ordner mit Folgen).'
    watch = _watch()
    k = _key(item)
    title = item.get('title') or 'Serie'
    if k in watch:
        del watch[k]
        _api.set('watch', watch)
        return 'Wird nicht mehr beobachtet: %s' % title
    ent = {'key': k, 'title': title, 'item': _mini(item), 'seen': None, 'added': int(time.time()), 'checked': 0, 'last_new': 0}
    try:
        _check_one(ent)
        known = len(ent['seen'] or [])
        msg = 'Ich beobachte „%s“ (%d Folgen bekannt). Neue melde ich im Familienchat.' % (title, known) if known else \
            'Ich beobachte „%s“. Folgen konnte ich noch nicht lesen – ich versuche es später nochmal.' % title
    except Exception as e:
        msg = 'Ich beobachte „%s“. Erste Prüfung klappte nicht (%s), ich versuche es später nochmal.' % (title, e)
    watch[k] = ent
    _api.set('watch', watch)
    return msg


def register(api):
    global _api
    _api = api

    def row():
        return [dict(e['item'], title=e['title']) for e in _watch().values()]

    def liste(req):
        rem = req.query.get('weg')
        watch = _watch()
        if rem and rem in watch:
            del watch[rem]
            api.set('watch', watch)
        rows = ''.join(
            '<li><b>%s</b> – %d Folgen bekannt%s <a href="liste?weg=%s">entfernen</a></li>' % (
                escape(e['title']), len(e.get('seen') or []),
                (', zuletzt neu: ' + time.strftime('%d.%m. %H:%M', time.localtime(e['last_new']))) if e.get('last_new') else '',
                escape(k, quote=True)) for k, e in watch.items())
        return ('<meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;max-width:640px;margin:20px auto;padding:0 14px">'
                '<h2>Beobachtete Serien</h2><ul>%s</ul>%s<p><a href="pruefen">Jetzt alle prüfen</a></p>' % (
                    rows, '' if rows else '<p>Noch keine. In der Titel-Info auf „🔔 Neue Folgen melden“ tippen.</p>'))

    api.route('liste', liste)
    api.route('pruefen', lambda req: {'neu': check_all()})
    api.home_row('Beobachtete Serien', row, ttl=60)
    api.item_action('🔔 Neue Folgen melden', _toggle)
    try:
        minutes = int(api.get('intervall') or 180)
    except (TypeError, ValueError):
        minutes = 180
    api.every(max(30, minutes), check_all, name='Serien prüfen', first_delay=120)
'''},
    {'id': 'tv_heute', 'file': 'tv_heute.py', 'title': 'Heute Abend im TV',
     'description': 'Die Spielfilme des Abends auf deinen Sendern (aus der EPG), per Tipp live ansehen; Erinnerung und Programm im Familienchat.',
     'code': r'''# -*- coding: utf-8 -*-
"""Heute Abend im TV: die Spielfilme des Abends auf deinen Sendern.

Quelle ist eine EPG-Datei im XMLTV-Format. Ist hier keine Adresse eingetragen, wird die EPG-Adresse aus den
Engine-Einstellungen genommen, die auch „M3U / IPTV“ benutzt (die Playlist wird nur gebraucht, damit ein Tipp
auf einen Eintrag den Sender live startet).

Du bekommst
  * eine Kachel für den Streifen oben auf der Startseite und den Bildschirmschoner
  * in der Titel-Info jedes Eintrags den Knopf „⏰ Erinnere uns“: kurz vor Beginn meldet sich der Familienchat
  * eine Reihe „Heute Abend im TV“ auf der Startseite und einen gleichnamigen Menüpunkt
  * auf Wunsch jeden Tag um eine feste Uhrzeit eine Nachricht im Familienchat
Ist der Abend schon vorbei, zeigt die Erweiterung den Abend von morgen.
"""
import gzip
import io
import re
import threading
import time
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone
from html import escape

EXT_ID = 'tv_heute'
EXT_NAME = 'Heute Abend im TV'
EXT_DESCRIPTION = 'Spielfilme des Abends auf deinen Sendern, per Tipp live ansehen; Erinnerung im Familienchat; auf Wunsch täglich das Programm im Chat.'
EXT_LINKS = [('Programm ansehen', 'heute'), ('Jetzt in den Familienchat senden', 'chat'), ('Gesetzte Erinnerungen', 'erinnerungen')]
EXT_SETTINGS = [
    {'key': 'epg_url', 'label': 'EPG-Adresse (XMLTV, auch .xml.gz)', 'type': 'text', 'default': '',
     'hint': 'Leer lassen = die EPG-Adresse aus den Engine-Einstellungen („M3U / IPTV“) wird benutzt.'},
    {'key': 'sender', 'label': 'Sender', 'type': 'textarea', 'default': 'Das Erste, ZDF, RTL, RTL2, SAT.1, ProSieben, VOX, kabel eins, Tele 5, arte',
     'hint': 'Komma-getrennt, so wie die Sender in deiner EPG und Playlist heißen (Zusätze wie „HD“ stören nicht).'},
    {'key': 'ab', 'label': 'Anfang des Abends (Stunde)', 'type': 'number', 'default': 20, 'min': 0, 'max': 23},
    {'key': 'bis', 'label': 'Ende des Abends (Stunde, 24 = Mitternacht)', 'type': 'number', 'default': 24, 'min': 1, 'max': 24},
    {'key': 'nur_filme', 'label': 'Nur Spielfilme zeigen', 'type': 'bool', 'default': True,
     'hint': 'Erkannt an der Kategorie in der EPG. Hat die EPG keine Kategorien, zählen Sendungen ab 80 Minuten.'},
    {'key': 'zone', 'label': 'Zeitzone', 'type': 'select', 'default': 'berlin',
     'options': [['berlin', 'Deutschland (Sommer-/Winterzeit automatisch)'], ['system', 'Uhrzeit des Geräts']]},
    {'key': 'chat', 'label': 'Jeden Tag in den Familienchat schreiben', 'type': 'bool', 'default': False},
    {'key': 'chat_uhr', 'label': '… um (Stunde)', 'type': 'number', 'default': 17, 'min': 0, 'max': 23},
    {'key': 'vorlauf', 'label': 'Erinnerung: so viele Minuten vor Beginn melden', 'type': 'number', 'default': 10, 'min': 0, 'max': 120,
     'hint': 'Gilt für den Knopf „⏰ Erinnere uns“ in der Titel-Info eines Eintrags.'},
]

_api = None
_LOCK = threading.Lock()
_CACHE = {}                                   # Schlüssel -> (geladen_um, Zeilen)
_CACHE_TTL = 3600
_XMLTV_TIME = re.compile(r'^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4}|[+-]\d{2}:?\d{2})?$')
_DROP = ('hd', 'deutschland', 'germany', 'de', 'television', 'fernsehen', 'tv')


# ----------------------------------------------------------------------------- Zeit

def _parse_time(s):
    m = _XMLTV_TIME.match((s or '').strip())
    if not m:
        return None
    y, mo, d, h, mi, se, off = m.groups()
    try:
        dt = datetime(int(y), int(mo), int(d), int(h), int(mi), int(se))
    except ValueError:
        return None
    if off:
        off = off.replace(':', '')
        sign = 1 if off[0] == '+' else -1
        dt = dt - sign * timedelta(hours=int(off[1:3]), minutes=int(off[3:5]))
    return dt.replace(tzinfo=timezone.utc)


def _last_sunday(year, month):
    d = datetime(year, month, 31)
    return d - timedelta(days=(d.weekday() + 1) % 7)


def _local(dt_utc):
    """UTC -> Ortszeit (ohne Zeitzonen-Angabe). „berlin“ rechnet Sommer-/Winterzeit selbst, ohne Zeitzonen-Datenbank."""
    if _api.get('zone') == 'system':
        return dt_utc.astimezone().replace(tzinfo=None)
    y = dt_utc.year
    start = _last_sunday(y, 3).replace(hour=1, tzinfo=timezone.utc)
    end = _last_sunday(y, 10).replace(hour=1, tzinfo=timezone.utc)
    return (dt_utc + timedelta(hours=2 if start <= dt_utc < end else 1)).replace(tzinfo=None)


def _num(key, default):
    """Zahl aus den Einstellungen; 0 ist ein gültiger Wert (z. B. Mitternacht)."""
    try:
        v = _api.get(key)
        return default if v is None or v == '' else int(float(v))
    except (TypeError, ValueError):
        return default


def _hours():
    ab = max(0, min(23, _num('ab', 20)))
    bis = max(ab + 1, min(24, _num('bis', 24)))
    return ab, bis


def _window():
    """(Tag, von, bis) in Ortszeit. Ist der Abend vorbei, gilt der nächste."""
    ab, bis = _hours()
    now = _local(datetime.now(timezone.utc))
    day = now.date()
    end = datetime.combine(day, datetime.min.time()) + timedelta(hours=bis)
    if now >= end:
        day = day + timedelta(days=1)
    start = datetime.combine(day, datetime.min.time()) + timedelta(hours=ab)
    return day, start, datetime.combine(day, datetime.min.time()) + timedelta(hours=bis)


# ----------------------------------------------------------------------------- Sender

def _norm(name):
    n = re.sub(r'[^a-z0-9äöüß]+', ' ', str(name or '').lower()).split()
    while n and n[-1] in _DROP:
        n.pop()
    return ''.join(n)


def _wanted():
    return [(w.strip(), _norm(w)) for w in re.split(r'[,;\n]+', str(_api.get('sender') or '')) if w.strip()]


def _same(a, b):
    return bool(a) and a == b


# ----------------------------------------------------------------------------- EPG lesen

def _epg_url():
    url = str(_api.get('epg_url') or '').strip()
    if url:
        return url
    try:
        import xbmcaddon
        return str(xbmcaddon.all_settings().get('epg_url') or '').strip()
    except Exception:
        return ''


def _read_epg(url, day, start, end):
    """Alle Sendungen im Zeitfenster, für die Sender aus den Einstellungen -> Liste von Zeilen (sortiert)."""
    from resources.lib import multiquest
    r = multiquest.get(url, headers={'User-Agent': 'MovieScout'}, timeout=60)
    if r.status_code != 200:
        _api.fail('Die EPG-Adresse antwortet mit HTTP %s.' % r.status_code)
    data = r.content
    if url.lower().split('?')[0].endswith('.gz') or data[:2] == b'\x1f\x8b':
        data = gzip.decompress(data)
    wanted = _wanted()
    chan_names, rows = {}, []
    for _, el in ET.iterparse(io.BytesIO(data), events=('end',)):
        if el.tag == 'channel':
            cid = el.get('id') or ''
            chan_names[cid] = [(d.text or '').strip() for d in el.findall('display-name') if (d.text or '').strip()]
            el.clear()
        elif el.tag == 'programme':
            try:
                t0, t1 = _parse_time(el.get('start')), _parse_time(el.get('stop'))
                if not t0 or not t1:
                    continue
                l0, l1 = _local(t0), _local(t1)
                if not (start <= l0 < end):
                    continue
                title_el = el.find('title')
                desc_el = el.find('desc')
                icon_el = el.find('icon')
                date_el = el.find('date')
                rows.append({
                    'cid': el.get('channel') or '', 'start': l0, 'stop': l1,
                    'title': (title_el.text or '').strip() if title_el is not None else '',
                    'desc': (desc_el.text or '').strip() if desc_el is not None else '',
                    'poster': (icon_el.get('src') or '') if icon_el is not None else '',
                    'year': ((date_el.text or '').strip()[:4] if date_el is not None else ''),
                    'cats': [(c.text or '').strip().lower() for c in el.findall('category')],
                })
            finally:
                el.clear()
    out = []
    for row in rows:
        names = chan_names.get(row['cid']) or [row['cid']]
        hit = next(((label, n) for label, w in wanted for n in names if _same(w, _norm(n))), None)
        if not hit:
            continue
        row['sender'] = hit[1]
        row['label'] = hit[0]
        out.append(row)
    out.sort(key=lambda r: (r['start'], r['sender']))
    return out


def _is_film(row, has_cats):
    if has_cats:
        cats = ' '.join(row['cats'])
        return ('film' in cats or 'movie' in cats) and 'doku' not in cats and 'serie' not in cats
    return (row['stop'] - row['start']).total_seconds() >= 80 * 60


def _program(force=False):
    """Zeilen des Abends (gefiltert), mit Zwischenspeicher."""
    url = _epg_url()
    if not url:
        _api.fail('Es ist keine EPG-Adresse eingetragen. Trage sie in den Einstellungen dieser Erweiterung ein '
                  'oder unter Einstellungen → M3U / IPTV (EPG-Adresse).')
    if not _wanted():
        _api.fail('In den Einstellungen dieser Erweiterung sind keine Sender eingetragen.')
    day, start, end = _window()
    key = (url, str(day), start.hour, end.hour, str(_api.get('sender')), _api.get('zone'))
    with _LOCK:
        hit = _CACHE.get(key)
        if hit and not force and time.time() - hit[0] < _CACHE_TTL:
            rows = hit[1]
        else:
            rows = None
    if rows is None:
        try:
            rows = _read_epg(url, day, start, end)
        except Exception as e:
            if type(e).__name__ == 'UserError':
                raise
            _api.fail('Die EPG konnte nicht gelesen werden: %s' % e)
        with _LOCK:
            _CACHE.clear()
            _CACHE[key] = (time.time(), rows)
    has_cats = any(r['cats'] for r in rows)
    if _api.get('nur_filme'):
        rows = [r for r in rows if _is_film(r, has_cats)]
    return day, rows


# ----------------------------------------------------------------------------- Einträge

def _channel_items(rows):
    """Zu jedem Sender den passenden Playlist-Eintrag suchen (damit ein Tipp live startet)."""
    found = {}
    for sender, label in sorted({(r['sender'], r.get('label') or r['sender']) for r in rows}):
        want = _norm(sender)
        found[sender] = None
        for q in dict.fromkeys([label, sender]):          # erst dein Name („ZDF“), dann der EPG-Name („ZDF HD“)
            try:
                hits = [c for c in _api.search('m3u_iptv', q) if c.get('kind') == 'play']
            except Exception:
                hits = []
            found[sender] = next((c for c in hits if _same(want, _norm(c.get('title')))), None)
            if found[sender]:
                break
    return found


def _item(row, chans):
    hhmm = row['start'].strftime('%H:%M')
    plot = '%s – %s Uhr, %s' % (hhmm, row['stop'].strftime('%H:%M'), row['sender'])
    if row['desc']:
        plot += '\n' + row['desc'][:500]
    base = chans.get(row['sender'])
    it = dict(base) if base else {'provider_id': 'm3u_iptv', 'url': '', 'next_func': 'load', 'is_playable': False}
    it.update({'title': '%s · %s – %s' % (hhmm, row['sender'], row['title']), 'plot': plot,
               'year': row['year'] or '', 'parent_title': '',
               'tv_start': row['start'].strftime('%Y-%m-%dT%H:%M'), 'tv_sender': row['sender'], 'tv_title': row['title']})
    if row['poster']:
        it['poster'] = row['poster']
    return it


def _items():
    day, rows = _program()
    chans = _channel_items(rows)
    return [_item(r, chans) for r in rows]


def _chat_text(day, rows):
    today = day == _local(datetime.now(timezone.utc)).date()
    lines = ['📺 %s im TV:' % ('Heute Abend' if today else 'Morgen Abend')]
    for r in rows[:10]:
        lines.append('%s  %s – %s' % (r['start'].strftime('%H:%M'), r['sender'], r['title']))
    if len(rows) > 10:
        lines.append('… und %d weitere' % (len(rows) - 10))
    return '\n'.join(lines)


def _post():
    day, rows = _program()
    if not rows:
        return 0
    chans = _channel_items(rows)
    first = next((_item(r, chans) for r in rows if chans.get(r['sender'])), None)      # erster Eintrag, der live startet
    _api.chat(_chat_text(day, rows), item=first, author='📺 TV-Programm')
    return len(rows)


_KEEP = ('title', 'url', 'poster', 'year', 'kind', 'provider_id', 'provider', 'next_func', 'plot', 'live', 'params', 'is_playable',
         'tv_start', 'tv_sender', 'tv_title')


def _remind(item):
    """Knopf „Erinnere uns“: setzt oder entfernt die Erinnerung für diese Sendung."""
    try:
        start = datetime.strptime(str(item.get('tv_start') or ''), '%Y-%m-%dT%H:%M')
    except ValueError:
        _api.fail('Dieser Eintrag hat keine Sendezeit. Den Knopf gibt es nur bei Einträgen aus „Heute Abend im TV“.')
    now = _local(datetime.now(timezone.utc))
    key = '%s|%s' % (item.get('tv_start'), item.get('tv_sender'))
    with _LOCK:
        rem = dict(_api.get('erinnerungen') or {})
        if key in rem:
            del rem[key]
            _api.set('erinnerungen', rem)
            return 'Erinnerung für „%s“ entfernt.' % item.get('tv_title')
        if start + timedelta(minutes=5) < now:
            _api.fail('„%s“ läuft schon oder ist vorbei.' % item.get('tv_title'))
        rem[key] = {k: item[k] for k in _KEEP if item.get(k) not in (None, '')}
        _api.set('erinnerungen', rem)
    vor = _lead()
    when = ('%d Minuten vor Beginn' % vor) if vor else 'zu Beginn'
    return 'Erinnerung gesetzt: „%s“ (%s, %s Uhr). Der Familienchat meldet sich %s.' % (
        item.get('tv_title'), item.get('tv_sender'), start.strftime('%H:%M'), when)


def _lead():
    try:
        return max(0, min(120, int(_api.get('vorlauf') if _api.get('vorlauf') is not None else 10)))
    except (TypeError, ValueError):
        return 10


def _remind_tick():
    """Jede Minute: fällige Erinnerungen in den Chat schreiben, abgelaufene wegräumen."""
    rem = _api.get('erinnerungen') or {}
    if not rem:
        return
    now = _local(datetime.now(timezone.utc))
    lead = timedelta(minutes=_lead())
    due, keep = [], {}
    for key, it in rem.items():
        try:
            start = datetime.strptime(str(it.get('tv_start')), '%Y-%m-%dT%H:%M')
        except ValueError:
            continue
        if now > start + timedelta(minutes=15):
            continue                                           # verpasst (z. B. App war aus): nicht mehr melden
        if now >= start - lead:
            due.append((start, it))
        else:
            keep[key] = it
    if len(keep) != len(rem):
        with _LOCK:
            cur = dict(_api.get('erinnerungen') or {})
            for key in list(cur):
                if key not in keep:
                    del cur[key]
            for key, it in keep.items():
                cur.setdefault(key, it)
            _api.set('erinnerungen', cur)
    for start, it in sorted(due, key=lambda x: x[0]):
        mins = int((start - now).total_seconds() // 60) + 1
        when = 'in %d Minuten' % mins if mins > 1 else ('gleich' if start >= now else 'jetzt')
        text = '⏰ %s: %s auf %s (%s Uhr)' % (when[0].upper() + when[1:], it.get('tv_title'), it.get('tv_sender'), start.strftime('%H:%M'))
        item = {k: v for k, v in it.items() if k in _KEEP} if it.get('url') else None
        _api.chat(text, item=item, author='📺 TV-Programm')


def _tick():
    """Alle 10 Minuten: zur eingestellten Uhrzeit einmal pro Tag in den Chat schreiben."""
    if not _api.get('chat'):
        return
    now = _local(datetime.now(timezone.utc))
    if now.hour < max(0, min(23, _num('chat_uhr', 17))):
        return
    stamp = str(now.date())
    if _api.get('last_post') == stamp:
        return
    try:
        _post()
    except Exception as e:
        if type(e).__name__ != 'UserError':
            raise
        _api.log('TV-Programm für den Chat nicht möglich: %s' % e, 'warning')
        return
    _api.set('last_post', stamp)


def _widget():
    """Kachel für Startseite/Bildschirmschoner: die ersten Filme des Abends (nichts, wenn keine EPG eingerichtet ist)."""
    try:
        day, rows = _program()
    except Exception as e:
        if type(e).__name__ == 'UserError':
            return None
        raise
    if not rows:
        return None
    today = day == _local(datetime.now(timezone.utc)).date()
    return {'icon': '📺', 'text': '%d %s' % (len(rows), 'Film' if len(rows) == 1 else 'Filme'),
            'sub': 'Heute Abend im TV' if today else 'Morgen Abend im TV',
            'lines': ['%s  %s – %s' % (r['start'].strftime('%H:%M'), r['sender'], r['title']) for r in rows[:5]]}


def register(api):
    global _api
    _api = api

    def page(req):
        try:
            day, rows = _program(force=req.query.get('neu') == '1')
        except Exception as e:
            return '<meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;padding:16px"><h2>Heute Abend im TV</h2><p>%s</p>' % escape(str(e))
        li = ''.join('<li><b>%s</b> %s – %s <small>(bis %s%s)</small></li>' % (
            r['start'].strftime('%H:%M'), escape(r['sender']), escape(r['title']), r['stop'].strftime('%H:%M'),
            ', ' + escape(r['year']) if r['year'] else '') for r in rows)
        return ('<meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;max-width:680px;margin:20px auto;padding:0 14px">'
                '<h2>Fernsehprogramm %s</h2><ul>%s</ul>%s<p><a href="heute?neu=1">Neu laden</a></p>' % (
                    day.strftime('%d.%m.%Y'), li, '' if li else '<p>Nichts gefunden (Sender oder Zeitraum in den Einstellungen prüfen).</p>'))

    def chat_now(req):
        return {'ok': True, 'sendungen': _post()}

    def reminders(req):
        rem = _api.get('erinnerungen') or {}
        return {'erinnerungen': sorted(({'start': v.get('tv_start'), 'sender': v.get('tv_sender'), 'titel': v.get('tv_title')} for v in rem.values()),
                                       key=lambda x: str(x['start']))}

    api.route('heute', page)
    api.route('chat', chat_now)
    api.route('erinnerungen', reminders)
    api.item_action('⏰ Erinnere uns', _remind, id='erinnern', needs='tv_start')
    api.home_row('Heute Abend im TV', _items, ttl=900)
    api.menu('Heute Abend im TV', _items, ttl=300)
    api.widget('Heute Abend im TV', _widget, ttl=900, id='tv', icon='📺')
    api.every(10, _tick, name='Chat-Meldung', first_delay=90)
    api.every(1, _remind_tick, name='Erinnerungen', first_delay=30)
'''},
    {'id': 'wetter', 'file': 'wetter.py', 'title': 'Wetter',
     'description': 'Aktuelles Wetter und Vorhersage für deinen Ort (Open-Meteo, ohne Schlüssel) als Kachel auf der Startseite und im Bildschirmschoner.',
     'code': r'''# -*- coding: utf-8 -*-
"""Wetter: aktuelles Wetter und Vorhersage für deinen Ort als Kachel auf der Startseite und im Bildschirmschoner.

Die Daten kommen von Open-Meteo (open-meteo.com): kostenlos, ohne Anmeldung und ohne Schlüssel.
Du gibst nur den Ort ein (Einstellungen dieser Erweiterung), die Koordinaten werden einmal gesucht und gemerkt.
"""
import json
from datetime import date, datetime
from html import escape

EXT_ID = 'wetter'
EXT_NAME = 'Wetter'
EXT_DESCRIPTION = 'Aktuelles Wetter und Vorhersage für deinen Ort (Open-Meteo, ohne Schlüssel) als Kachel und im Bildschirmschoner.'
EXT_LINKS = [('Wetter ansehen', 'wetter')]
EXT_SETTINGS = [
    {'key': 'ort', 'label': 'Ort', 'type': 'text', 'default': 'Düsseldorf',
     'hint': 'Stadt oder Gemeinde, zum Beispiel Düsseldorf. Bei gleichnamigen Orten hilft die Postleitzahl oder der Zusatz, z. B. Neuss.'},
    {'key': 'tage', 'label': 'Vorhersage-Tage', 'type': 'number', 'default': 4, 'min': 1, 'max': 7},
]

_api = None
_GEO = 'https://geocoding-api.open-meteo.com/v1/search'
_FC = 'https://api.open-meteo.com/v1/forecast'
_DAYS = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So']

# WMO-Wettercode -> (Symbol, Text)
_WMO = {0: ('☀️', 'Klar'), 1: ('🌤️', 'Überwiegend klar'), 2: ('⛅', 'Teils bewölkt'), 3: ('☁️', 'Bedeckt'),
        45: ('🌫️', 'Nebel'), 48: ('🌫️', 'Raureifnebel'),
        51: ('🌦️', 'Leichter Nieselregen'), 53: ('🌦️', 'Nieselregen'), 55: ('🌧️', 'Starker Nieselregen'),
        56: ('🌧️', 'Gefrierender Nieselregen'), 57: ('🌧️', 'Gefrierender Nieselregen'),
        61: ('🌧️', 'Leichter Regen'), 63: ('🌧️', 'Regen'), 65: ('🌧️', 'Starker Regen'),
        66: ('🌧️', 'Gefrierender Regen'), 67: ('🌧️', 'Gefrierender Regen'),
        71: ('🌨️', 'Leichter Schneefall'), 73: ('🌨️', 'Schneefall'), 75: ('❄️', 'Starker Schneefall'), 77: ('🌨️', 'Schneegriesel'),
        80: ('🌦️', 'Leichte Schauer'), 81: ('🌧️', 'Schauer'), 82: ('⛈️', 'Heftige Schauer'),
        85: ('🌨️', 'Schneeschauer'), 86: ('🌨️', 'Starke Schneeschauer'),
        95: ('⛈️', 'Gewitter'), 96: ('⛈️', 'Gewitter mit Hagel'), 99: ('⛈️', 'Gewitter mit starkem Hagel')}


def _wmo(code, day=True):
    sym, text = _WMO.get(int(code or 0), ('🌡️', 'Wetter'))
    if not day and int(code or 0) in (0, 1):
        sym = '🌙'
    return sym, text


def _get_json(url, params):
    from resources.lib import multiquest
    try:
        r = multiquest.get(url, params=params, headers={'User-Agent': 'MovieScout'}, timeout=15)
    except Exception:
        _api.fail('Wetter: keine Verbindung zu Open-Meteo.')
    if r.status_code != 200:
        _api.fail('Wetter: Open-Meteo antwortet mit HTTP %s.' % r.status_code)
    try:
        return json.loads(r.text)
    except ValueError:
        _api.fail('Wetter: unerwartete Antwort von Open-Meteo.')


def _place():
    ort = str(_api.get('ort') or '').strip()
    if not ort:
        _api.fail('Wetter: kein Ort eingetragen (Einstellungen der Erweiterung).')
    geo = _api.get('geo') or {}
    if geo.get('ort') == ort and geo.get('lat') is not None:
        return geo
    d = _get_json(_GEO, {'name': ort, 'count': 1, 'language': 'de', 'format': 'json'})
    res = (d.get('results') or [])
    if not res:
        _api.fail('Wetter: Ort „%s“ nicht gefunden.' % ort)
    r = res[0]
    geo = {'ort': ort, 'lat': r.get('latitude'), 'lon': r.get('longitude'), 'name': r.get('name') or ort}
    _api.set('geo', geo)
    return geo


def _forecast():
    geo = _place()
    try:
        tage = max(1, min(7, int(_api.get('tage') or 4)))
    except (TypeError, ValueError):
        tage = 4
    d = _get_json(_FC, {
        'latitude': geo['lat'], 'longitude': geo['lon'], 'timezone': 'auto', 'forecast_days': tage,
        'current': 'temperature_2m,apparent_temperature,weather_code,wind_speed_10m,is_day',
        'daily': 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max'})
    cur = d.get('current') or {}
    if cur.get('temperature_2m') is None:
        _api.fail('Wetter: Open-Meteo lieferte keine aktuellen Werte.')
    daily = d.get('daily') or {}
    days = []
    for i, ds in enumerate(daily.get('time') or []):
        try:
            dt = datetime.strptime(ds, '%Y-%m-%d').date()
        except ValueError:
            continue
        g = lambda k: (daily.get(k) or [None] * (i + 1))[i]
        days.append({'datum': dt, 'code': g('weather_code'), 'max': g('temperature_2m_max'), 'min': g('temperature_2m_min'),
                     'regen': g('precipitation_probability_max')})
    return geo, cur, days


def _deg(v):
    return '–' if v is None else '%d°' % round(float(v))


def _day_label(dt, i):
    return 'Heute' if i == 0 else 'Morgen' if i == 1 else _DAYS[dt.weekday()]


def _day_line(d, i):
    sym, _ = _wmo(d['code'])
    regen = (' · %d %%' % round(d['regen'])) if d['regen'] else ''
    return '%s  %s %s / %s%s' % (_day_label(d['datum'], i), sym, _deg(d['max']), _deg(d['min']), regen)


def _widget():
    geo, cur, days = _forecast()
    sym, text = _wmo(cur.get('weather_code'), bool(cur.get('is_day', 1)))
    sub = '%s · %s' % (geo['name'], text)
    if cur.get('apparent_temperature') is not None:
        sub += ' · gefühlt %s' % _deg(cur['apparent_temperature'])
    return {'icon': sym, 'text': _deg(cur['temperature_2m']), 'sub': sub, 'lines': [_day_line(d, i) for i, d in enumerate(days)]}


def register(api):
    global _api
    _api = api

    def page(req):
        try:
            geo, cur, days = _forecast()
        except Exception as e:
            return '<meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;padding:16px"><h2>Wetter</h2><p>%s</p>' % escape(str(e))
        sym, text = _wmo(cur.get('weather_code'), bool(cur.get('is_day', 1)))
        li = ''.join('<li>%s</li>' % escape(_day_line(d, i)) for i, d in enumerate(days))
        return ('<meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;max-width:520px;margin:20px auto;padding:0 14px">'
                '<h2>Wetter in %s</h2><p style="font-size:2.2em;margin:.2em 0">%s %s</p><p>%s, Wind %s km/h</p><ul style="list-style:none;padding:0;line-height:1.9">%s</ul>'
                '<p><small>Daten: Open-Meteo.com</small></p>' % (
                    escape(geo['name']), sym, _deg(cur['temperature_2m']), escape(text), round(cur.get('wind_speed_10m') or 0), li))

    api.route('wetter', page)
    api.widget('Wetter', _widget, ttl=900, id='wetter', icon='⛅')
'''},

    # --- Gadgets (generiert) ---
    {'id': 'statistik', 'file': 'statistik.py', 'title': 'Statistik',
     'description': 'Zählt die Sehzeit: Kachel „Diese Woche“ und Seite mit Monat, Jahr, Lieblingstiteln und Quellen.',
     'code': r'''# -*- coding: utf-8 -*-
"""Statistik: wie viel wurde geschaut? (Woche, Monat, Jahr, Lieblingstitel und -quellen)

Die Erweiterung zählt mit, wenn eine Wiedergabe endet, und rechnet daraus die ungefähre Sehzeit aus.
Zu sehen ist das Ergebnis als Kachel „Diese Woche“ auf der Startseite (und im Bildschirmschoner) und auf der
Seite „Meine Statistik“ (Erweiterungsliste -> Statistik -> Meine Statistik).
Hinweis: Die Zahlen gelten für die ganze Engine, also für alle Geräte, die sie benutzen. Gespeichert wird nur Titel,
Quelle, Zeitpunkt und Dauer - nichts verlässt dein Gerät.
"""
import threading
import time
from datetime import datetime, timedelta
from html import escape

EXT_ID = 'statistik'
EXT_NAME = 'Statistik'
EXT_DESCRIPTION = 'Zählt die Sehzeit: Kachel „Diese Woche“ und Seite mit Monat, Jahr, Lieblingstiteln und Quellen.'
EXT_LINKS = [('Meine Statistik', 'index')]
EXT_SETTINGS = [
    {'key': 'aktiv', 'label': 'Wiedergaben mitzählen', 'type': 'bool', 'default': True},
    {'key': 'min_sek', 'label': 'Erst ab … Sekunden zählen', 'type': 'number', 'default': 60, 'min': 0, 'max': 3600,
     'hint': 'Kurzes Reinschauen (Vorschau, Probieren) soll die Zahlen nicht verfälschen.'},
    {'key': 'ziel', 'label': 'Wochenziel in Stunden (0 = keins)', 'type': 'number', 'default': 0, 'min': 0, 'max': 200},
]

MAX_LOG = 5000
_api = None
_starts = {}
_lock = threading.Lock()


def _key(item):
    return '%s|%s|%s|%s' % (item.get('provider_id') or '', item.get('url') or item.get('title') or '',
                            item.get('season') or '', item.get('episode') or '')


def _clean_title(t):
    t = str(t or '').strip()
    return t[2:].strip() if t.startswith('✓ ') else t


def on_play(item, info):
    if _api is None:
        return
    with _lock:
        now = time.time()
        for k in [k for k, v in _starts.items() if now - v > 43200]:
            _starts.pop(k, None)
        _starts[_key(item)] = now


def on_stop(item, info):
    if _api is None or not _api.get('aktiv'):
        return
    now = time.time()
    with _lock:
        start = _starts.pop(_key(item), None)
    try:
        pos = float(info.get('position') or 0)
        dur = float(info.get('duration') or 0)
    except (TypeError, ValueError):
        pos = dur = 0
    sec = (now - start) if start else pos          # lief die Engine neu, bleibt nur die Position
    if dur > 0:
        sec = min(sec, dur)
    sec = int(min(sec, 43200))
    if sec < max(1, int(_api.get('min_sek') or 0)):
        return
    parent = _clean_title(item.get('parent_title'))
    title = _clean_title(item.get('title')) or 'Unbekannt'
    entry = {'t': int(now), 'sec': sec, 'title': parent or title,
             'ep': title if parent else '', 'p': item.get('provider') or item.get('provider_id') or '?',
             'k': 'serie' if (parent or item.get('season') or item.get('episode')) else 'film'}
    with _lock:
        log = _api.get('log', [])
        if not isinstance(log, list):
            log = []
        log.append(entry)
        _api.set('log', log[-MAX_LOG:])


def _fmt(sec):
    sec = int(sec)
    h, m = divmod(sec // 60, 60)
    if h:
        return '%d h %02d min' % (h, m)
    return '%d min' % m


def _sums(log, now=None):
    now = now or datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week0 = (today - timedelta(days=today.weekday())).timestamp()
    month0 = today.replace(day=1).timestamp()
    year0 = today.replace(month=1, day=1).timestamp()
    out = {'week': 0, 'month': 0, 'year': 0, 'all': 0, 'n_week': 0, 'n_all': len(log)}
    for e in log:
        t, s = e.get('t', 0), e.get('sec', 0)
        out['all'] += s
        if t >= year0:
            out['year'] += s
        if t >= month0:
            out['month'] += s
        if t >= week0:
            out['week'] += s
            out['n_week'] += 1
    return out


def _days(log, n=14, now=None):
    now = now or datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    names = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So']
    rows = []
    for i in range(n - 1, -1, -1):
        d0 = today - timedelta(days=i)
        a, b = d0.timestamp(), (d0 + timedelta(days=1)).timestamp()
        rows.append({'label': '%s %d.%d.' % (names[d0.weekday()], d0.day, d0.month),
                     'sec': sum(e['sec'] for e in log if a <= e.get('t', 0) < b)})
    return rows


def _top(log, field, n=5):
    acc = {}
    for e in log:
        k = e.get(field) or '?'
        a = acc.setdefault(k, [0, 0])
        a[0] += e.get('sec', 0)
        a[1] += 1
    return [{'name': k, 'sec': v[0], 'n': v[1]} for k, v in sorted(acc.items(), key=lambda kv: -kv[1][0])[:n]]


def _data():
    log = _api.get('log', [])
    log = log if isinstance(log, list) else []
    kinds = {'film': 0, 'serie': 0}
    for e in log:
        kinds[e.get('k') if e.get('k') in kinds else 'film'] += e.get('sec', 0)
    return {'sums': _sums(log), 'days': _days(log), 'titles': _top(log, 'title'), 'sources': _top(log, 'p'), 'kinds': kinds,
            'count': len(log)}


def _page(req):
    d = _data()
    s = d['sums']
    peak = max([x['sec'] for x in d['days']] + [1])
    ziel = float(_api.get('ziel') or 0)

    def card(label, sec, sub=''):
        return '<div class="c"><b>%s</b><span>%s</span><i>%s</i></div>' % (escape(_fmt(sec)), escape(label), escape(sub))

    bars = ''.join('<div class="d"><div class="b" style="height:%d%%" title="%s"></div><span>%s</span></div>'
                   % (max(2, round(100 * x['sec'] / peak)) if x['sec'] else 0, escape(_fmt(x['sec'])), escape(x['label'].split(' ')[0]))
                   for x in d['days'])

    def lst(rows):
        if not rows:
            return '<p class="m">Noch nichts gezählt.</p>'
        return '<ol>' + ''.join('<li>%s <small>%s · %d×</small></li>' % (escape(str(r['name'])), escape(_fmt(r['sec'])), r['n']) for r in rows) + '</ol>'

    goal = ''
    if ziel > 0:
        pct = min(100, round(100 * s['week'] / (ziel * 3600)))
        goal = '<p class="m">Wochenziel %g h: %d %% erreicht.</p><div class="g"><div style="width:%d%%"></div></div>' % (ziel, pct, pct)
    total = d['kinds']['film'] + d['kinds']['serie']
    share = ('Filme %d %% · Serien %d %%' % (round(100 * d['kinds']['film'] / total), round(100 * d['kinds']['serie'] / total))) if total else ''
    return ('<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>Meine Statistik</title><style>'
            ':root{--bg:#0f141b;--fg:#e8edf3;--mut:#93a1b3;--card:#18202b;--acc:#4da3ff}'
            '@media(prefers-color-scheme:light){:root{--bg:#f4f6f9;--fg:#18202b;--mut:#5d6b7c;--card:#fff;--acc:#1b6fd1}}'
            'body{margin:0;padding:18px 16px 60px;background:var(--bg);color:var(--fg);font:16px/1.45 system-ui,sans-serif;max-width:760px;margin-inline:auto}'
            'h1{font-size:1.4rem;margin:.2em 0 .6em}h2{font-size:1.05rem;margin:1.6em 0 .4em}'
            '.row{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}'
            '.c{background:var(--card);border-radius:12px;padding:12px 14px;display:flex;flex-direction:column}'
            '.c b{font-size:1.35rem;color:var(--acc)}.c span{font-weight:600}.c i{color:var(--mut);font-style:normal;font-size:.85rem}'
            '.chart{display:flex;gap:4px;align-items:flex-end;height:120px;background:var(--card);border-radius:12px;padding:10px 8px 6px}'
            '.d{flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;gap:4px}'
            '.b{width:100%;background:var(--acc);border-radius:4px 4px 0 0;min-height:0}.d span{font-size:.7rem;color:var(--mut)}'
            'ol{padding-left:1.3em;margin:.2em 0}li{margin:.25em 0}small,.m{color:var(--mut)}'
            '.g{height:10px;background:var(--card);border-radius:5px;overflow:hidden}.g div{height:100%;background:var(--acc)}'
            'button{font:inherit;padding:8px 14px;border-radius:10px;border:1px solid var(--mut);background:transparent;color:var(--fg);margin-top:22px}'
            '</style><h1>📊 Meine Statistik</h1>'
            '<div class="row">' + card('Diese Woche', s['week'], '%d Wiedergaben' % s['n_week']) + card('Dieser Monat', s['month'])
            + card('Dieses Jahr', s['year']) + card('Insgesamt', s['all'], '%d Wiedergaben' % s['n_all']) + '</div>' + goal +
            '<h2>Letzte 14 Tage</h2><div class="chart">' + bars + '</div>'
            '<h2>Lieblingstitel</h2>' + lst(d['titles']) + '<h2>Quellen</h2>' + lst(d['sources'])
            + ('<p class="m">' + escape(share) + '</p>' if share else '') +
            '<p class="m">Die Sehzeit ist eine Schätzung (Pausen zählen mit). Gezählt wird für alle Geräte, die diese Engine benutzen.</p>'
            '<button onclick="if(confirm(\'Alle gezählten Wiedergaben löschen?\'))fetch(\'reset\',{method:\'POST\'}).then(()=>location.reload())">Statistik zurücksetzen</button>'
            '</html>')


def register(api):
    global _api
    _api = api

    def widget():
        s = _sums(api.get('log', []) if isinstance(api.get('log', []), list) else [])
        ziel = float(api.get('ziel') or 0)
        lines = []
        if ziel > 0:
            lines.append('Ziel %g h: %d %%' % (ziel, min(100, round(100 * s['week'] / (ziel * 3600)))))
        return {'text': _fmt(s['week']), 'sub': 'geschaut diese Woche · %d Wiedergaben' % s['n_week'],
                'lines': lines + ['Monat: ' + _fmt(s['month']), 'Jahr: ' + _fmt(s['year'])]}

    def reset(req):
        if req.method != 'POST':
            return ({'error': 'Nur per POST'}, 405)
        api.set('log', [])
        return {'ok': True}

    api.route('index', _page)
    api.route('daten', lambda req: _data())
    api.route('reset', reset)
    api.widget('Diese Woche', widget, ttl=300, icon='📊')
'''},
    {'id': 'gesehen', 'file': 'gesehen.py', 'title': 'Gesehen-Haken',
     'description': 'Setzt vor fertig geschaute Filme und Folgen ein ✓; Knopf zum Umschalten in der Titel-Info.',
     'code': r'''# -*- coding: utf-8 -*-
"""Gesehen-Haken: Filme und Folgen, die du fertig geschaut hast, bekommen vorn ein ✓.

So geht es: Wird eine Wiedergabe bis fast zum Ende geschaut (Standard: 90 %), merkt sich die Erweiterung den Titel.
In allen Listen steht dann vor dem Titel ein ✓. In der Titel-Info gibt es außerdem den Knopf „✓ Gesehen / Ungesehen“,
um von Hand umzuschalten. Die Haken gelten für alle Geräte, die diese Engine benutzen.
Neue Haken erscheinen sofort (die Zwischenspeicher der Listen werden dafür geleert).
"""
import threading
import time

EXT_ID = 'gesehen'
EXT_NAME = 'Gesehen-Haken'
EXT_DESCRIPTION = 'Setzt vor fertig geschaute Filme und Folgen ein ✓; Knopf zum Umschalten in der Titel-Info.'
EXT_LINKS = [('Gesehen-Liste', 'liste')]
EXT_SETTINGS = [
    {'key': 'schwelle', 'label': 'Als gesehen zählt ab … % der Laufzeit', 'type': 'number', 'default': 90, 'min': 50, 'max': 100},
    {'key': 'zeichen', 'label': 'Zeichen vor dem Titel', 'type': 'text', 'default': '✓'},
]

MAX_SEEN = 20000
_api = None
_lock = threading.Lock()


def _mark():
    return (str(_api.get('zeichen') or '✓').strip() or '✓') + ' ' if _api else '✓ '


def _key(pid, item):
    return '%s|%s|%s|%s' % (pid or item.get('provider_id') or '', item.get('url') or str(item.get('title') or '').lstrip('✓ ').strip(),
                            item.get('season') or '', item.get('episode') or '')


def _seen():
    d = _api.get('seen', {})
    return d if isinstance(d, dict) else {}


def _forget_lists():
    """Zwischenspeicher der Listen leeren, damit die Haken sofort sichtbar werden."""
    try:
        from engine import registry as R
        R._LIST_C.clear()
    except Exception:                                  # noqa: BLE001 - nur Komfort
        pass


def _set(item, value, title=None):
    with _lock:
        d = _seen()
        k = _key('', item)
        if value:
            d[k] = {'t': int(time.time()), 'title': (title or item.get('parent_title') or item.get('title') or '')[:120]}
            if len(d) > MAX_SEEN:
                for old in sorted(d, key=lambda x: d[x].get('t', 0))[:len(d) - MAX_SEEN]:
                    d.pop(old, None)
        else:
            d.pop(k, None)
        _api.set('seen', d)
    _forget_lists()


def on_stop(item, info):
    if _api is None:
        return
    try:
        pos, dur = float(info.get('position') or 0), float(info.get('duration') or 0)
    except (TypeError, ValueError):
        return
    schwelle = float(_api.get('schwelle') or 90) / 100.0
    if info.get('finished') or (dur > 0 and pos / dur >= schwelle):
        _set(item, True)


def process_items(provider_id, items):
    if _api is None:
        return None
    d = _seen()
    if not d:
        return None
    mark = _mark()
    out = []
    for it in items:
        if it.get('kind') == 'play' and _key(provider_id, it) in d and not str(it.get('title') or '').startswith(mark):
            it = dict(it, title=mark + str(it.get('title') or ''))
        out.append(it)
    return out


def register(api):
    global _api
    _api = api

    def toggle(item):
        item = dict(item)
        k = _key('', item)
        if k in _seen():
            _set(item, False)
            return 'Wieder ungesehen: %s' % item.get('title')
        _set(item, True)
        return 'Als gesehen markiert: %s' % item.get('title')

    def liste(req):
        from html import escape
        rows = sorted(_seen().values(), key=lambda v: -v.get('t', 0))[:300]
        lis = ''.join('<li>%s <small>%s</small></li>' % (escape(r.get('title', '')), time.strftime('%d.%m.%Y', time.localtime(r.get('t', 0)))) for r in rows)
        return ('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Gesehen</title>'
                '<style>body{font:16px/1.5 system-ui;margin:0;padding:18px;max-width:700px;margin-inline:auto;background:#0f141b;color:#e8edf3}small{color:#93a1b3}</style>'
                '<h1>✓ Gesehen (%d)</h1><ol>%s</ol>' % (len(_seen()), lis or '<p>Noch nichts.</p>'))

    api.route('liste', liste)
    api.route('status', lambda req: {'count': len(_seen())})
    api.item_action('✓ Gesehen / Ungesehen', toggle, needs='url')
'''},
    {'id': 'jugendschutz', 'file': 'jugendschutz.py', 'title': 'Jugendschutz-Filter',
     'description': 'Blendet Titel mit unerwünschten Wörtern und ausgewählte Quellen aus; Kontrollseite zeigt, was entfernt wurde.',
     'code': r'''# -*- coding: utf-8 -*-
"""Jugendschutz-Filter: blendet Einträge mit unerwünschten Wörtern im Titel aus - und auf Wunsch ganze Quellen.

So geht es: In den Einstellungen der Erweiterung stehen die Wörter (komma-getrennt). Es zählen ganze Wörter,
„Sex“ blendet also „Essex“ nicht aus. Ein * am Ende passt auf jedes Wortende: „erotik*“ trifft „Erotik“ und „Erotikfilme“.
Ganze Quellen blendest du über „Diese Quellen ausblenden“ aus (Teil des Namens genügt, z. B. „tube8“).
Die Seite „Was wurde ausgeblendet?“ zeigt zur Kontrolle, was der Filter zuletzt entfernt hat.
Wichtig: Der Filter gilt für alle Geräte, die diese Engine benutzen, und ist ein Hilfsmittel, kein Kopierschutz:
Wer Zugriff auf die Einstellungen hat, kann ihn ausschalten. Bereits zwischengespeicherte Listen (bis 10 Minuten)
zeigen nach einer Änderung noch den alten Stand - „Zwischenspeicher leeren“ hilft.
"""
import re
import threading
import time
from html import escape

EXT_ID = 'jugendschutz'
EXT_NAME = 'Jugendschutz-Filter'
EXT_DESCRIPTION = 'Blendet Titel mit unerwünschten Wörtern und ausgewählte Quellen aus; Kontrollseite zeigt, was entfernt wurde.'
EXT_LINKS = [('Was wurde ausgeblendet?', 'index')]
EXT_SETTINGS = [
    {'key': 'aktiv', 'label': 'Filter einschalten', 'type': 'bool', 'default': True},
    {'key': 'woerter', 'label': 'Unerwünschte Wörter', 'type': 'textarea',
     'default': 'erotik*, porn*, xxx, hentai, sexfilm*, fsk 18, ab 18, 18+, adult, nackt*',
     'hint': 'Komma-getrennt, Groß-/Kleinschreibung egal. Ganze Wörter; * am Ende = beliebige Fortsetzung.'},
    {'key': 'quellen', 'label': 'Diese Quellen ausblenden', 'type': 'text', 'default': '',
     'hint': 'Komma-getrennt, ein Teil des Namens genügt - z. B.  tube8, xvideos'},
    {'key': 'beschreibung', 'label': 'Auch die Beschreibung prüfen', 'type': 'bool', 'default': False,
     'hint': 'Strenger, blendet aber auch harmlose Filme aus, deren Inhaltsangabe ein Wort enthält.'},
]

MAX_HITS = 60
_api = None
_lock = threading.Lock()
_cache = {'raw': None, 'rx': None}


def _words(text):
    return [w.strip().lower() for w in str(text or '').replace(';', ',').replace('\n', ',').split(',') if w.strip()]


def _regex(raw):
    """Wörterliste -> ein Muster (zwischengemerkt, solange sich der Text nicht ändert)."""
    if _cache['raw'] == raw:
        return _cache['rx']
    parts = []
    for w in _words(raw):
        star = w.endswith('*')
        core = re.escape(w.rstrip('*').strip())
        if not core:
            continue
        parts.append(core + (r'\w*' if star else ''))
    rx = re.compile(r'(?<!\w)(?:' + '|'.join(parts) + r')(?!\w)', re.I) if parts else None
    _cache['raw'], _cache['rx'] = raw, rx
    return rx


def _log_hits(provider, rows):
    """rows = [(titel, grund)] - gesammelt in einem Zug gespeichert."""
    if not rows:
        return
    with _lock:
        hits = _api.get('hits', [])
        hits = hits if isinstance(hits, list) else []
        now = int(time.time())
        hits += [{'t': now, 'p': provider, 'title': str(t)[:120], 'why': w} for t, w in rows]
        _api.set('hits', hits[-MAX_HITS:])
        _api.set('count', int(_api.get('count', 0) or 0) + len(rows))


def process_items(provider_id, items):
    if _api is None or not _api.get('aktiv'):
        return None
    blocked_src = _words(_api.get('quellen'))
    if blocked_src:
        low = str(provider_id).lower()
        names = [low] + [str(p.get('name') or '').lower() for p in _api.providers() if p.get('id') == provider_id]
        if any(b in n for b in blocked_src for n in names):
            if items:
                _log_hits(provider_id, [('(%d Einträge)' % len(items), 'Quelle ausgeblendet')])
            return []
    rx = _regex(_api.get('woerter'))
    if rx is None:
        return None
    plot = bool(_api.get('beschreibung'))
    out, hits = [], []
    for it in items:
        text = str(it.get('title') or '')
        m = rx.search(text)
        if not m and plot:
            m = rx.search(str(it.get('plot') or ''))
        if m:
            hits.append((text, 'Wort: ' + m.group(0)))
            continue
        out.append(it)
    _log_hits(provider_id, hits)
    return out if hits else None


def register(api):
    global _api
    _api = api

    def page(req):
        hits = list(reversed(api.get('hits', []) or []))
        rows = ''.join('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (
            time.strftime('%d.%m. %H:%M', time.localtime(h.get('t', 0))), escape(str(h.get('p', ''))), escape(h.get('title', '')), escape(h.get('why', '')))
            for h in hits)
        return ('<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                '<title>Jugendschutz</title><style>body{font:15px/1.45 system-ui;margin:0;padding:18px;max-width:900px;margin-inline:auto;background:#0f141b;color:#e8edf3}'
                'td,th{padding:6px 8px;border-bottom:1px solid #2a3442;text-align:left;vertical-align:top}small{color:#93a1b3}'
                'button{font:inherit;padding:8px 14px;border-radius:10px;border:1px solid #93a1b3;background:transparent;color:inherit;margin-top:16px}</style>'
                '<h1>🛡 Jugendschutz-Filter</h1><p>Filter: <b>%s</b> · bisher ausgeblendet: <b>%d</b> Einträge</p>'
                '<p><small>Zuletzt entfernt (höchstens %d, neueste oben):</small></p>'
                '<table><tr><th>Wann</th><th>Quelle</th><th>Titel</th><th>Grund</th></tr>%s</table>%s'
                '<button onclick="fetch(\'leeren\',{method:\'POST\'}).then(()=>location.reload())">Liste leeren</button></html>'
                % ('an' if api.get('aktiv') else 'aus', int(api.get('count', 0) or 0), MAX_HITS, rows, '' if rows else '<p>Noch nichts ausgeblendet.</p>'))

    def clear(req):
        if req.method != 'POST':
            return ({'error': 'Nur per POST'}, 405)
        api.set('hits', [])
        return {'ok': True}

    api.route('index', page)
    api.route('leeren', clear)
    api.route('status', lambda req: {'aktiv': bool(api.get('aktiv')), 'count': int(api.get('count', 0) or 0)})
'''},
    {'id': 'zufall', 'file': 'zufall.py', 'title': 'Zufallsfilm',
     'description': 'Kachel „🎲 Zufall“: ein paar zufällige Titel aus deinen Quellen - gegen das ewige Suchen.',
     'code': r'''# -*- coding: utf-8 -*-
"""Zufallsfilm: „Was schauen wir heute?“ - ein Menüpunkt, der ein paar zufällige Filme aus deinen Quellen vorschlägt.

So geht es: Auf der Startseite die Kachel „🎲 Zufall“ öffnen. Die Erweiterung wählt eine Quelle, geht einen Ordner
tiefer (Filme, Kategorien …) und zeigt dir ein paar abspielbare Titel. Nochmal öffnen = neue Auswahl.
Mit „Nur diese Quellen“ legst du fest, woher die Vorschläge kommen (Teil des Namens genügt, leer = alle aktiven).
Ordner, die nach Suche, Seitenwechsel oder Serien aussehen, werden übersprungen.
"""
import random
import re
import time

EXT_ID = 'zufall'
EXT_NAME = 'Zufallsfilm'
EXT_DESCRIPTION = 'Kachel „🎲 Zufall“: ein paar zufällige Titel aus deinen Quellen - gegen das ewige Suchen.'
EXT_SETTINGS = [
    {'key': 'anzahl', 'label': 'Wie viele Vorschläge', 'type': 'number', 'default': 6, 'min': 1, 'max': 30},
    {'key': 'quellen', 'label': 'Nur diese Quellen', 'type': 'text', 'default': '',
     'hint': 'Komma-getrennt, Teil des Namens genügt. Leer = alle aktiven Quellen.'},
    {'key': 'serien', 'label': 'Serien-Ordner auch erlauben', 'type': 'bool', 'default': False},
    {'key': 'tiefe', 'label': 'Wie tief in die Ordner schauen (1-3)', 'type': 'number', 'default': 2, 'min': 1, 'max': 3},
]

_SKIP = re.compile(r'such|search|seite|weiter|next|zur(ü|ue)ck|back|a-z|^[a-z0-9#]$|cache|einstellung|login|anmeld|\b(?:tv|live|radio)\b', re.I)
_SERIES = re.compile(r'serie|staffel|season|folge|episod|anime|doku', re.I)
_api = None


def _words(text):
    return [w.strip().lower() for w in str(text or '').replace(';', ',').split(',') if w.strip()]


def _sources():
    want = _words(_api.get('quellen'))
    provs = _api.providers()
    if want:
        provs = [p for p in provs if any(w in (p['id'] + ' ' + p['name']).lower() for w in want)]
    random.shuffle(provs)
    return provs


def _plays(pid, folder, depth, budget, serien):
    """Abspielbare Einträge unterhalb eines Ordners einsammeln (höchstens `budget[0]` Abrufe)."""
    if budget[0] <= 0:
        return []
    budget[0] -= 1
    try:
        items = _api.open(pid, folder, fresh=False)
    except Exception:                                  # noqa: BLE001 - eine kaputte Quelle darf den Rest nicht stoppen
        return []
    plays = [i for i in items if i.get('kind') == 'play' and not i.get('episode')]
    if len(plays) >= 3:
        return plays
    if depth <= 0:
        return plays
    folders = [i for i in items if i.get('kind') == 'folder' and not _SKIP.search(i.get('title') or '')
               and (serien or not _SERIES.search(i.get('title') or '') and i.get('next_func') not in ('get_seasons', 'get_episodes'))]
    random.shuffle(folders)
    out = list(plays)
    for f in folders[:3]:
        out += _plays(pid, f, depth - 1, budget, serien)
        if len(out) >= 12 or budget[0] <= 0:
            break
    return out


def vorschlaege():
    n = max(1, int(_api.get('anzahl') or 6))
    depth = max(1, min(3, int(_api.get('tiefe') or 2)))
    serien = bool(_api.get('serien'))
    t0, found, seen = time.time(), [], set()
    for p in _sources()[:6]:
        pool = _plays(p['id'], {}, depth, [8], serien)
        random.shuffle(pool)
        for it in pool:
            k = (it.get('provider_id'), it.get('url'), it.get('title'))
            if k in seen:
                continue
            seen.add(k)
            found.append(it)
            if len(found) >= n * 2:
                break
        if len(found) >= n * 2 or time.time() - t0 > 25:
            break
    random.shuffle(found)
    return found[:n]


def register(api):
    global _api
    _api = api

    def menu():
        res = vorschlaege()
        if not res:
            api.fail('Keine Vorschläge gefunden. Prüfe, ob Quellen aktiv sind (oder die Einstellung „Nur diese Quellen“).')
        return res

    api.menu('🎲 Zufall', menu, ttl=0)
    api.route('probe', lambda req: {'n': len(vorschlaege())})
'''},
    {'id': 'quellen_waechter', 'file': 'quellen_waechter.py', 'title': 'Quellen-Wächter',
     'description': 'Meldet im Familienchat, wenn eine Quelle länger ausfällt - und wenn sie wieder läuft.',
     'code': r'''# -*- coding: utf-8 -*-
"""Quellen-Wächter: sagt im Familienchat Bescheid, wenn eine Quelle ausfällt - und wenn sie wieder läuft.

Die Engine prüft ihre Quellen ohnehin regelmäßig im Hintergrund (Diagnose). Der Wächter schaut dort nur nach und
belastet die Seiten nicht zusätzlich. Eine Quelle gilt als ausgefallen, wenn sie länger als die eingestellte Zeit
durchgehend leer oder fehlerhaft ist. Pro Ausfall kommt genau eine Meldung, nach der Erholung eine zweite.
"""
import threading
import time
from html import escape

EXT_ID = 'quellen_waechter'
EXT_NAME = 'Quellen-Wächter'
EXT_DESCRIPTION = 'Meldet im Familienchat, wenn eine Quelle länger ausfällt - und wenn sie wieder läuft.'
EXT_LINKS = [('Zustand der Quellen', 'index')]
EXT_SETTINGS = [
    {'key': 'ab_minuten', 'label': 'Als ausgefallen melden nach … Minuten', 'type': 'number', 'default': 60, 'min': 0, 'max': 1440},
    {'key': 'chat', 'label': 'Meldungen in den Familienchat schreiben', 'type': 'bool', 'default': True},
    {'key': 'erholung', 'label': 'Auch melden, wenn eine Quelle wieder läuft', 'type': 'bool', 'default': True},
    {'key': 'absender', 'label': 'Absender im Chat', 'type': 'text', 'default': '🩺 Quellen-Wächter'},
]

_api = None
_lock = threading.Lock()


def _snapshot():
    from engine import registry as R
    out = []
    for pid, p in list(R.REGISTRY.items()):
        if not getattr(p, 'enabled', False):
            continue
        h = R.HEALTH.get(pid) or {}
        out.append({'id': pid, 'name': getattr(p, 'name', pid), 'status': h.get('status') or 'unknown',
                    'since': h.get('bad_since'), 'error': h.get('error') or '', 'checked': h.get('checked') or 0})
    return out


def pruefen():
    """Gesundheitsstand lesen, Meldungen schreiben. Gibt die Zahl der gesendeten Meldungen zurück."""
    now = time.time()
    limit = float(_api.get('ab_minuten') or 0) * 60
    sent = 0
    with _lock:
        known = _api.get('known', {})
        known = known if isinstance(known, dict) else {}
        for s in _snapshot():
            was_down = bool(known.get(s['id']))
            bad = s['status'] in ('error', 'empty') and s['since'] and now - s['since'] >= limit
            if bad and not was_down:
                known[s['id']] = int(now)
                sent += _say('⚠️ %s ist ausgefallen: %s' % (s['name'], s['error'] or 'keine Antwort'))
            elif was_down and s['status'] == 'ok':
                known.pop(s['id'], None)
                if _api.get('erholung'):
                    sent += _say('✅ %s läuft wieder.' % s['name'])
        _api.set('known', known)
        _api.set('last', int(now))
    return sent


def _say(text):
    _api.set('log', (_api.get('log', []) or [])[-49:] + [{'t': int(time.time()), 'text': text}])
    if not _api.get('chat'):
        return 1
    try:
        _api.chat(text, author=_api.get('absender') or None)
    except Exception as e:                           # noqa: BLE001 - Chat nicht bereit: später erneut versuchen reicht nicht, aber nichts kaputt machen
        _api.log('Chat nicht erreichbar: %s' % e, 'warning')
    return 1


def register(api):
    global _api
    _api = api

    def page(req):
        rows = ''
        icons = {'ok': '✅', 'empty': '⚠️', 'error': '❌', 'unknown': '❔'}
        for s in sorted(_snapshot(), key=lambda x: (x['status'] == 'ok', x['name'].lower())):
            since = time.strftime('%d.%m. %H:%M', time.localtime(s['since'])) if s['since'] else ''
            rows += '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>' % (icons.get(s['status'], '❔'), escape(s['name']), escape(since), escape(s['error']))
        log = ''.join('<li>%s - %s</li>' % (time.strftime('%d.%m. %H:%M', time.localtime(e['t'])), escape(e['text'])) for e in reversed(api.get('log', []) or []))
        return ('<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Quellen</title>'
                '<style>body{font:15px/1.45 system-ui;margin:0;padding:18px;max-width:900px;margin-inline:auto;background:#0f141b;color:#e8edf3}'
                'td,th{padding:6px 8px;border-bottom:1px solid #2a3442;text-align:left}small{color:#93a1b3}</style>'
                '<h1>🩺 Zustand der Quellen</h1><table><tr><th></th><th>Quelle</th><th>Gestört seit</th><th>Grund</th></tr>%s</table>'
                '<h2>Letzte Meldungen</h2><ul>%s</ul></html>' % (rows, log or '<li><small>Noch keine.</small></li>'))

    api.route('index', page)
    api.route('jetzt', lambda req: {'gesendet': pruefen()} if req.method == 'POST' else ({'error': 'Nur per POST'}, 405))
    api.every(15, pruefen, name='Quellen ansehen', first_delay=120)
'''},
    {'id': 'feiertage', 'file': 'feiertage.py', 'title': 'Feiertage',
     'description': 'Kachel „Nächster Feiertag“ mit Countdown für dein Bundesland (offline berechnet).',
     'code': r'''# -*- coding: utf-8 -*-
"""Feiertage: Kachel „Nächster Feiertag“ mit Countdown (gesetzliche Feiertage in Deutschland, ohne Internet).

Das Bundesland stellst du in den Einstellungen ein. Die Kachel zeigt auch die zwei Feiertage danach.
Praktisch für den Bildschirmschoner und für die Frage „Ist morgen frei?“.
"""
from datetime import date, timedelta

EXT_ID = 'feiertage'
EXT_NAME = 'Feiertage'
EXT_DESCRIPTION = 'Kachel „Nächster Feiertag“ mit Countdown für dein Bundesland (offline berechnet).'
LAENDER = [('BW', 'Baden-Württemberg'), ('BY', 'Bayern'), ('BE', 'Berlin'), ('BB', 'Brandenburg'), ('HB', 'Bremen'), ('HH', 'Hamburg'),
           ('HE', 'Hessen'), ('MV', 'Mecklenburg-Vorpommern'), ('NI', 'Niedersachsen'), ('NW', 'Nordrhein-Westfalen'),
           ('RP', 'Rheinland-Pfalz'), ('SL', 'Saarland'), ('SN', 'Sachsen'), ('ST', 'Sachsen-Anhalt'), ('SH', 'Schleswig-Holstein'), ('TH', 'Thüringen')]
EXT_SETTINGS = [{'key': 'land', 'label': 'Bundesland', 'type': 'select', 'default': 'NW', 'options': [[k, v] for k, v in LAENDER]}]
_api = None


def ostern(jahr):
    """Ostersonntag (Gauß-Algorithmus)."""
    a, b, c = jahr % 19, jahr // 100, jahr % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    monat, tag = divmod(h + l - 7 * m + 114, 31)
    return date(jahr, monat, tag + 1)


def feiertage(jahr, land):
    """{Datum: Name} der gesetzlichen Feiertage im Bundesland."""
    o = ostern(jahr)
    t = {date(jahr, 1, 1): 'Neujahr', o - timedelta(days=2): 'Karfreitag', o + timedelta(days=1): 'Ostermontag',
         date(jahr, 5, 1): 'Tag der Arbeit', o + timedelta(days=39): 'Christi Himmelfahrt', o + timedelta(days=50): 'Pfingstmontag',
         date(jahr, 10, 3): 'Tag der Deutschen Einheit', date(jahr, 12, 25): '1. Weihnachtstag', date(jahr, 12, 26): '2. Weihnachtstag'}
    if land in ('BW', 'BY', 'ST'):
        t[date(jahr, 1, 6)] = 'Heilige Drei Könige'
    if land in ('BE', 'MV'):
        t[date(jahr, 3, 8)] = 'Internationaler Frauentag'
    if land == 'BB':
        t[o] = 'Ostersonntag'
        t[o + timedelta(days=49)] = 'Pfingstsonntag'
    if land in ('BW', 'BY', 'HE', 'NW', 'RP', 'SL'):
        t[o + timedelta(days=60)] = 'Fronleichnam'
    if land == 'SL':
        t[date(jahr, 8, 15)] = 'Mariä Himmelfahrt'
    if land == 'TH':
        t[date(jahr, 9, 20)] = 'Weltkindertag'
    if land in ('BB', 'HB', 'HH', 'MV', 'NI', 'SN', 'ST', 'SH', 'TH'):
        t[date(jahr, 10, 31)] = 'Reformationstag'
    if land in ('BW', 'BY', 'NW', 'RP', 'SL'):
        t[date(jahr, 11, 1)] = 'Allerheiligen'
    if land == 'SN':
        d = date(jahr, 11, 22)
        while d.weekday() != 2:
            d -= timedelta(days=1)
        t[d] = 'Buß- und Bettag'
    return t


def naechste(heute, land, n=3):
    out = []
    for jahr in (heute.year, heute.year + 1):
        out += [(d, name) for d, name in feiertage(jahr, land).items() if d >= heute]
    return sorted(out)[:n]


def _tage(d, heute):
    n = (d - heute).days
    return 'heute' if n == 0 else 'morgen' if n == 1 else 'in %d Tagen' % n


WOCHE = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So']


def widget():
    heute = date.today()
    land = (_api.get('land') if _api else None) or 'NW'
    liste = naechste(heute, land, 3)
    d, name = liste[0]
    return {'text': _tage(d, heute), 'sub': '%s, %s' % (name, '%s %d.%d.' % (WOCHE[d.weekday()], d.day, d.month)),
            'lines': ['%s: %s %d.%d.' % (n2, WOCHE[d2.weekday()], d2.day, d2.month) for d2, n2 in liste[1:]]}


def register(api):
    global _api
    _api = api
    api.widget('Nächster Feiertag', widget, ttl=3600, icon='🎉')
    api.route('liste', lambda req: {'land': api.get('land'), 'feiertage': [{'datum': d.isoformat(), 'name': n}
                                                                         for d, n in sorted(feiertage(date.today().year, api.get('land') or 'NW').items())]})
'''},
    {'id': 'filmtipp', 'file': 'filmtipp.py', 'title': 'Filmtipp des Tages',
     'description': 'Postet täglich einen zufälligen Filmvorschlag aus deinen Quellen in den Familienchat.',
     'code': r'''# -*- coding: utf-8 -*-
"""Filmtipp des Tages: schreibt einmal am Tag einen zufälligen Filmvorschlag in den Familienchat.

Tippen auf die Nachricht öffnet den Titel. Die Uhrzeit stellst du ein; verpasst die Engine sie (z. B. aus),
kommt der Tipp beim nächsten Start danach. „Jetzt posten“ löst sofort einen Tipp aus (POST an .../jetzt).
Ordner, die nach Suche, Seitenwechsel, Serien oder Live-TV aussehen, werden übersprungen.
"""
import random
import re
import time

EXT_ID = 'filmtipp'
EXT_NAME = 'Filmtipp des Tages'
EXT_DESCRIPTION = 'Postet täglich einen zufälligen Filmvorschlag aus deinen Quellen in den Familienchat.'
EXT_SETTINGS = [
    {'key': 'an', 'label': 'Täglichen Tipp posten', 'type': 'bool', 'default': True},
    {'key': 'stunde', 'label': 'Frühestens um … Uhr', 'type': 'number', 'default': 17, 'min': 0, 'max': 23},
    {'key': 'quellen', 'label': 'Nur diese Quellen', 'type': 'text', 'default': '', 'hint': 'Komma-getrennt, Teil des Namens genügt. Leer = alle.'},
    {'key': 'absender', 'label': 'Absender im Chat', 'type': 'text', 'default': '🎬 Filmtipp'},
]
_SKIP = re.compile(r'such|search|seite|weiter|next|zur(ü|ue)ck|back|a-z|^[a-z0-9#]$|cache|einstellung|login|anmeld|serie|staffel|season|folge|anime|\b(?:tv|live|radio)\b', re.I)
_api = None


def _words(text):
    return [w.strip().lower() for w in str(text or '').replace(';', ',').split(',') if w.strip()]


def _plays(pid, folder, depth, budget):
    if budget[0] <= 0:
        return []
    budget[0] -= 1
    try:
        items = _api.open(pid, folder, fresh=False)
    except Exception:                                  # noqa: BLE001
        return []
    plays = [i for i in items if i.get('kind') == 'play' and not i.get('episode')]
    if len(plays) >= 3 or depth <= 0:
        return plays
    folders = [i for i in items if i.get('kind') == 'folder' and not _SKIP.search(i.get('title') or '')]
    random.shuffle(folders)
    out = list(plays)
    for f in folders[:3]:
        out += _plays(pid, f, depth - 1, budget)
        if len(out) >= 10 or budget[0] <= 0:
            break
    return out


def tipp():
    want = _words(_api.get('quellen'))
    provs = _api.providers()
    if want:
        provs = [p for p in provs if any(w in (p['id'] + ' ' + p['name']).lower() for w in want)]
    random.shuffle(provs)
    for p in provs[:5]:
        pool = _plays(p['id'], {}, 2, [8])
        if pool:
            return random.choice(pool)
    return None


def jetzt(force=False):
    it = tipp()
    if not it:
        return 0
    _api.chat('Filmtipp des Tages: %s%s' % (it.get('title', '?'), (' (%s)' % it['year']) if it.get('year') else ''),
              item=it, author=_api.get('absender') or None)
    _api.set('letzter', time.strftime('%Y-%m-%d'))
    return 1


def pruefen():
    if not _api.get('an'):
        return
    heute = time.strftime('%Y-%m-%d')
    if _api.get('letzter') == heute or time.localtime().tm_hour < int(_api.get('stunde') or 0):
        return
    jetzt()


def register(api):
    global _api
    _api = api
    api.route('jetzt', lambda req: {'gepostet': jetzt(True)} if req.method == 'POST' else ({'error': 'Nur per POST'}, 405))
    api.every(30, pruefen, name='Tipp prüfen', first_delay=90)
'''},
    {'id': 'handy_verbinden', 'file': 'handy_verbinden.py', 'title': 'Handy verbinden',
     'description': 'Kachel mit der WLAN-Adresse von MovieScout - zum Abtippen am Handy.',
     'code': r'''# -*- coding: utf-8 -*-
"""Handy verbinden: Kachel mit der Adresse, unter der MovieScout im Heimnetz erreichbar ist.

Gedacht für den Fernseher oder PC: Die Adresse steht groß in der Kachel (und im Bildschirmschoner), das Handy muss im
selben WLAN sein und sie im Browser öffnen. Mit „Teilen im WLAN“ (Einstellungen) legst du zusätzlich ein Passwort fest.
"""
import socket
import sys

EXT_ID = 'handy_verbinden'
EXT_NAME = 'Handy verbinden'
EXT_DESCRIPTION = 'Kachel mit der WLAN-Adresse von MovieScout - zum Abtippen am Handy.'
EXT_LINKS = [('Adresse anzeigen', 'adresse')]
_api = None


def _port():
    a = sys.argv
    for i, x in enumerate(a):
        if x == '--port' and i + 1 < len(a) and a[i + 1].isdigit():
            return int(a[i + 1])
        if x.startswith('--port=') and x[7:].isdigit():
            return int(x[7:])
    return 8000


def _ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(1)
        s.connect(('10.255.255.255', 1))          # sendet nichts, wählt nur die passende Netzwerkkarte
        ip = s.getsockname()[0]
    except OSError:
        ip = ''
    finally:
        s.close()
    return '' if ip.startswith('127.') else ip


def adresse():
    ip = _ip()
    return 'http://%s:%d/ui/' % (ip, _port()) if ip else ''


def widget():
    url = adresse()
    if not url:
        return {'icon': '📵', 'text': 'kein WLAN', 'sub': 'Keine Heimnetz-Adresse gefunden'}
    return {'text': url.replace('http://', '').replace('/ui/', ''), 'sub': 'Am Handy im selben WLAN im Browser öffnen',
            'lines': [url]}


def register(api):
    global _api
    _api = api
    api.widget('Handy verbinden', widget, ttl=120, icon='📱')
    api.route('adresse', lambda req: {'url': adresse(), 'port': _port()})
'''},
    {'id': 'notizen', 'file': 'notizen.py', 'title': 'Notizzettel',
     'description': 'Gemeinsame Notizen/Einkaufsliste mit Kachel auf der Startseite und Knopf „Auf den Notizzettel“ in der Titel-Info.',
     'code': r'''# -*- coding: utf-8 -*-
"""Notizzettel: gemeinsame Notizen und Einkaufsliste für alle Geräte im Haus.

Öffnen: Erweiterungsliste -> Notizen -> „Notizzettel öffnen“ (oder als Lesezeichen am Handy). Dort Notiz eintippen,
abhaken, anheften (📌) oder löschen. Die Kachel „Notizen“ auf der Startseite (und im Bildschirmschoner) zeigt die
angehefteten und offenen Notizen. In der Titel-Info gibt es den Knopf „📝 Auf den Notizzettel“ (z. B. „Film am Samstag“).
Alles liegt in der Engine, nichts geht ins Internet.
"""
import threading
import time
import uuid

EXT_ID = 'notizen'
EXT_NAME = 'Notizzettel'
EXT_DESCRIPTION = 'Gemeinsame Notizen/Einkaufsliste mit Kachel auf der Startseite und Knopf „Auf den Notizzettel“ in der Titel-Info.'
EXT_LINKS = [('Notizzettel öffnen', 'index')]
EXT_SETTINGS = [
    {'key': 'zeilen', 'label': 'Zeilen in der Kachel', 'type': 'number', 'default': 4, 'min': 1, 'max': 8},
]

MAX_NOTES = 300
MAX_LEN = 500
_api = None
_lock = threading.Lock()


def _all():
    d = _api.get('notizen', [])
    return d if isinstance(d, list) else []


def _save(rows):
    _api.set('notizen', rows[-MAX_NOTES:])


def hinzu(text, pinned=False):
    text = str(text or '').strip()[:MAX_LEN]
    if not text:
        _api.fail('Die Notiz ist leer.')
    with _lock:
        rows = _all()
        n = {'id': uuid.uuid4().hex[:8], 'text': text, 'done': False, 'pinned': bool(pinned), 't': int(time.time())}
        rows.append(n)
        _save(rows)
    return n


def _find(rows, nid):
    return next((r for r in rows if r.get('id') == nid), None)


def _sorted(rows):
    return sorted(rows, key=lambda r: (r.get('done', False), not r.get('pinned', False), -r.get('t', 0)))


def _page(req):
    return """<!doctype html><html lang="de"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Notizzettel</title><style>
:root{--bg:#0f141b;--fg:#e8edf3;--mut:#93a1b3;--card:#18202b;--acc:#4da3ff}
@media(prefers-color-scheme:light){:root{--bg:#f4f6f9;--fg:#18202b;--mut:#5d6b7c;--card:#fff;--acc:#1b6fd1}}
body{margin:0;padding:18px 16px 60px;background:var(--bg);color:var(--fg);font:17px/1.45 system-ui,sans-serif;max-width:640px;margin-inline:auto}
h1{font-size:1.4rem;margin:.2em 0 .6em}form{display:flex;gap:8px}input[type=text]{flex:1;font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--mut);background:var(--card);color:var(--fg)}
button{font:inherit;padding:8px 14px;border-radius:10px;border:0;background:var(--acc);color:#fff;cursor:pointer}
button.l{background:transparent;color:var(--mut);padding:6px 8px}ul{list-style:none;padding:0;margin:14px 0}
li{display:flex;align-items:center;gap:8px;background:var(--card);border-radius:12px;padding:8px 10px;margin:6px 0}
li span{flex:1;word-break:break-word}li.d span{text-decoration:line-through;color:var(--mut)}li.p{outline:2px solid var(--acc)}
input[type=checkbox]{width:22px;height:22px}.m{color:var(--mut);font-size:.9rem}
</style><h1>📝 Notizzettel</h1>
<form id="f"><input type="text" id="t" maxlength="500" placeholder="Neue Notiz …" autocomplete="off"><button>Hinzufügen</button></form>
<ul id="l"></ul><p class="m" id="m"></p><button class="l" id="c">Erledigte entfernen</button>
<script>
const $=(i)=>document.getElementById(i);
async function call(p,b){const r=await fetch(p,{method:b?'POST':'GET',headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});if(!r.ok){let e='Fehler';try{e=(await r.json()).error||e}catch(_){}alert(e);throw new Error(e)}return r.json()}
function el(tag,cls,txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e}
async function draw(){
  const d=await call('liste');const ul=$('l');ul.textContent='';
  d.notizen.forEach(n=>{
    const li=el('li',(n.done?'d ':'')+(n.pinned?'p':''));
    const cb=el('input');cb.type='checkbox';cb.checked=n.done;cb.onchange=async()=>{await call('aendern',{id:n.id,done:cb.checked});draw()};
    const sp=el('span','',n.text);
    const pin=el('button','l',n.pinned?'📌':'📍');pin.title='Anheften';pin.onclick=async()=>{await call('aendern',{id:n.id,pinned:!n.pinned});draw()};
    const del=el('button','l','✕');del.title='Löschen';del.onclick=async()=>{await call('loeschen',{id:n.id});draw()};
    li.append(cb,sp,pin,del);ul.append(li)});
  $('m').textContent=d.notizen.length?d.offen+' offen von '+d.notizen.length:'Noch keine Notizen.';
}
$('f').onsubmit=async(e)=>{e.preventDefault();const v=$('t').value.trim();if(!v)return;await call('neu',{text:v});$('t').value='';draw()};
$('c').onclick=async()=>{await call('aufraeumen',{});draw()};
draw();setInterval(draw,15000);
</script></html>"""


def register(api):
    global _api
    _api = api

    def post_only(fn):
        def wrap(req):
            if req.method != 'POST':
                return ({'error': 'Nur per POST'}, 405)
            return fn(req.json if isinstance(req.json, dict) else {})
        return wrap

    def liste(req):
        rows = _sorted(_all())
        return {'notizen': rows, 'offen': sum(1 for r in rows if not r.get('done'))}

    def neu(d):
        if not str(d.get('text') or '').strip():
            return ({'error': 'Die Notiz ist leer.'}, 400)
        return {'ok': True, 'notiz': hinzu(d.get('text'), d.get('pinned'))}

    def aendern(d):
        with _lock:
            rows = _all()
            r = _find(rows, d.get('id'))
            if r is None:
                return ({'error': 'Notiz nicht gefunden'}, 404)
            if 'done' in d:
                r['done'] = bool(d['done'])
            if 'pinned' in d:
                r['pinned'] = bool(d['pinned'])
            if 'text' in d and str(d['text']).strip():
                r['text'] = str(d['text']).strip()[:MAX_LEN]
            _save(rows)
        return {'ok': True}

    def loeschen(d):
        with _lock:
            rows = [r for r in _all() if r.get('id') != d.get('id')]
            _save(rows)
        return {'ok': True}

    def aufraeumen(d):
        with _lock:
            rows = [r for r in _all() if not r.get('done')]
            n = len(_all()) - len(rows)
            _save(rows)
        return {'ok': True, 'entfernt': n}

    def widget():
        rows = [r for r in _sorted(_all()) if not r.get('done')]
        if not rows:
            return {'icon': '📝', 'text': 'Notizzettel leer', 'sub': 'Erweiterungsliste -> Notizen -> Notizzettel öffnen'}
        n = max(1, int(api.get('zeilen') or 4))
        top = rows[0]
        return {'icon': '📌' if top.get('pinned') else '📝', 'text': top['text'][:40], 'sub': ('%d offen' % len(rows)),
                'lines': [r['text'] for r in rows[1:n]]}

    def knopf(item):
        t = str(item.get('title') or '').strip()
        if item.get('parent_title'):
            t = '%s - %s' % (item['parent_title'], t)
        src = item.get('provider') or ''
        hinzu('🎬 %s%s' % (t, ' (%s)' % src if src else ''))
        return 'Auf den Notizzettel gesetzt: %s' % t

    api.route('index', _page)
    api.route('liste', liste)
    api.route('neu', post_only(neu))
    api.route('aendern', post_only(aendern))
    api.route('loeschen', post_only(loeschen))
    api.route('aufraeumen', post_only(aufraeumen))
    api.widget('Notizen', widget, ttl=30, icon='📝')
    api.item_action('📝 Auf den Notizzettel', knopf, needs='title')
'''},
    {'id': 'countdown', 'file': 'countdown.py', 'title': 'Countdown',
     'description': 'Kachel „Noch X Tage“ für Urlaub, Geburtstage und Termine (einmalig oder jährlich, mit Alter).',
     'code': r'''# -*- coding: utf-8 -*-
"""Countdown: Tage bis zu Urlaub, Geburtstagen und anderen Terminen - als Kachel auf der Startseite.

Die Termine stehen in den Einstellungen, einer pro Zeile:
    Urlaub am Meer; 2027-07-12            einmaliger Termin (JJJJ-MM-TT oder TT.MM.JJJJ)
    Hochzeitstag; 14.06.                  jedes Jahr am 14.6.
    Anna; 03.05.1990; j                   jährlich, mit Alter („wird 36“)
Die Kachel zeigt den nächsten Termin groß und die zwei danach darunter.
"""
import re
from datetime import date

EXT_ID = 'countdown'
EXT_NAME = 'Countdown'
EXT_DESCRIPTION = 'Kachel „Noch X Tage“ für Urlaub, Geburtstage und Termine (einmalig oder jährlich, mit Alter).'
EXT_SETTINGS = [
    {'key': 'termine', 'label': 'Termine (einer pro Zeile)', 'type': 'textarea', 'default': '',
     'hint': 'Name; Datum   - z. B.  Urlaub; 2027-07-12   |   Hochzeitstag; 14.06.   |   Anna; 03.05.1990; j  (jährlich mit Alter)'},
]
_api = None
_RX = re.compile(r'^\s*(?:(\d{4})-(\d{1,2})-(\d{1,2})|(\d{1,2})\.(\d{1,2})\.(\d{4})?)\s*$')


def parse(text):
    """Zeilen -> Liste von {'name', 'm', 'd', 'y' (oder None), 'jaehrlich', 'alter'}; kaputte Zeilen werden übersprungen."""
    out = []
    for line in str(text or '').splitlines():
        parts = [p.strip() for p in line.split(';')]
        if len(parts) < 2 or not parts[0]:
            continue
        m = _RX.match(parts[1])
        if not m:
            continue
        if m.group(1):
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        else:
            d, mo = int(m.group(4)), int(m.group(5))
            y = int(m.group(6)) if m.group(6) else None
        flag = (parts[2].lower() if len(parts) > 2 else '')
        yearly = y is None or flag in ('j', 'jaehrlich', 'jährlich', 'ja')
        try:
            date(y or 2000, mo, d)                       # 2000 ist ein Schaltjahr: 29.2. bleibt erlaubt
        except ValueError:
            continue
        out.append({'name': parts[0][:60], 'm': mo, 'd': d, 'y': y, 'jaehrlich': yearly, 'alter': y is not None and yearly})
    return out


def _on(year, e):
    try:
        return date(year, e['m'], e['d'])
    except ValueError:                                   # 29.2. in Nicht-Schaltjahren -> 28.2.
        return date(year, 2, 28)


def kommende(termine, heute):
    """Sortierte Liste (Datum, Eintrag, Alter oder None) ab heute; vergangene einmalige Termine entfallen."""
    out = []
    for e in termine:
        if e['jaehrlich']:
            d = _on(heute.year, e)
            if d < heute:
                d = _on(heute.year + 1, e)
            out.append((d, e, (d.year - e['y']) if e['alter'] else None))
        else:
            d = date(e['y'], e['m'], e['d'])
            if d >= heute:
                out.append((d, e, None))
    return sorted(out, key=lambda x: (x[0], x[1]['name']))


def wann(d, heute):
    n = (d - heute).days
    return 'heute!' if n == 0 else 'morgen' if n == 1 else '%d Tage' % n


def zeile(x, heute):
    d, e, alter = x
    return '%s: %s, %d.%d.%s' % (e['name'], wann(d, heute), d.day, d.month, (' (wird %d)' % alter) if alter else '')


def widget():
    heute = date.today()
    k = kommende(parse(_api.get('termine')), heute)
    if not k:
        return {'icon': '⏳', 'text': 'Keine Termine', 'sub': 'Einstellungen der Erweiterung „Countdown“'}
    d, e, alter = k[0]
    return {'icon': '🎂' if alter else '⏳', 'text': wann(d, heute), 'sub': e['name'] + ((' wird %d' % alter) if alter else ''),
            'lines': [zeile(x, heute) for x in k[1:3]]}


def register(api):
    global _api
    _api = api
    api.widget('Countdown', widget, ttl=600, icon='⏳')
    api.route('liste', lambda req: {'termine': [{'name': e['name'], 'datum': d.isoformat(), 'tage': (d - date.today()).days, 'alter': a}
                                                for d, e, a in kommende(parse(api.get('termine')), date.today())]})
'''},
    {'id': 'himmel', 'file': 'himmel.py', 'title': 'Himmel',
     'description': 'Kachel mit Sonnenauf-/-untergang, Tageslänge und Mondphase (offline berechnet).',
     'code': r'''# -*- coding: utf-8 -*-
"""Himmel: Sonnenauf- und -untergang, Tageslänge und Mondphase - offline berechnet, als Kachel.

Stelle in den Einstellungen deinen Ort ein (Breiten-/Längengrad, z. B. aus Google Maps: Rechtsklick auf den Ort).
Die Zeiten gelten in der Zeitzone des Geräts, auf dem die Engine läuft. Genauigkeit: wenige Minuten.
"""
import math
from datetime import date, datetime, timedelta, timezone

EXT_ID = 'himmel'
EXT_NAME = 'Himmel'
EXT_DESCRIPTION = 'Kachel mit Sonnenauf-/-untergang, Tageslänge und Mondphase (offline berechnet).'
EXT_SETTINGS = [
    {'key': 'breite', 'label': 'Breitengrad', 'type': 'number', 'default': 51.2277, 'min': -66, 'max': 66, 'hint': 'Nord positiv. Standard: Düsseldorf.'},
    {'key': 'laenge', 'label': 'Längengrad', 'type': 'number', 'default': 6.7735, 'min': -180, 'max': 180, 'hint': 'Ost positiv.'},
]
_api = None
SYNODISCH = 29.530588853
NEUMOND_0 = datetime(2000, 1, 6, 18, 14, tzinfo=timezone.utc)
PHASEN = [('🌑', 'Neumond'), ('🌒', 'zunehmende Sichel'), ('🌓', 'erstes Viertel'), ('🌔', 'zunehmender Mond'),
          ('🌕', 'Vollmond'), ('🌖', 'abnehmender Mond'), ('🌗', 'letztes Viertel'), ('🌘', 'abnehmende Sichel')]


def sonne_ut(tag, breite, laenge, aufgang=True):
    """Aufgang/Untergang als UTC-Stunden (0-24) oder None (Polartag/-nacht). Almanac-Algorithmus, Zenit 90,833°."""
    n = tag.timetuple().tm_yday
    lh = laenge / 15.0
    t = n + ((6 if aufgang else 18) - lh) / 24.0
    m = 0.9856 * t - 3.289
    rad = math.radians
    l = (m + 1.916 * math.sin(rad(m)) + 0.020 * math.sin(rad(2 * m)) + 282.634) % 360
    ra = math.degrees(math.atan(0.91764 * math.tan(rad(l)))) % 360
    ra += math.floor(l / 90) * 90 - math.floor(ra / 90) * 90
    ra /= 15.0
    sin_dec = 0.39782 * math.sin(rad(l))
    cos_dec = math.cos(math.asin(sin_dec))
    cos_h = (math.cos(rad(90.833)) - sin_dec * math.sin(rad(breite))) / (cos_dec * math.cos(rad(breite)))
    if cos_h > 1 or cos_h < -1:
        return None
    h = (360 - math.degrees(math.acos(cos_h))) if aufgang else math.degrees(math.acos(cos_h))
    h /= 15.0
    tt = h + ra - 0.06571 * t - 6.622
    return (tt - lh) % 24


def lokal(tag, ut):
    """UTC-Stunden -> lokale Uhrzeit (Zeitzone des Rechners, inkl. Sommerzeit)."""
    if ut is None:
        return None
    base = datetime(tag.year, tag.month, tag.day, tzinfo=timezone.utc)
    return (base + timedelta(hours=ut)).astimezone()


def mond(zeit):
    """(Phase 0..1, Beleuchtung in Prozent, Emoji, Name) für einen Zeitpunkt (aware datetime)."""
    f = (((zeit - NEUMOND_0).total_seconds() / 86400.0) % SYNODISCH) / SYNODISCH
    hell = round((1 - math.cos(2 * math.pi * f)) / 2 * 100)
    emoji, name = PHASEN[int(f * 8 + 0.5) % 8]
    return f, hell, emoji, name


def naechster(zeit, ziel):
    """Nächster Zeitpunkt (aware) mit Phase `ziel` (0 = Neumond, 0.5 = Vollmond)."""
    k = math.floor((zeit - NEUMOND_0).total_seconds() / 86400.0 / SYNODISCH)
    for i in (0, 1, 2):
        t = NEUMOND_0 + timedelta(days=(k + i + ziel) * SYNODISCH)
        if t > zeit:
            return t
    return zeit


def widget():
    breite, laenge = float(_api.get('breite')), float(_api.get('laenge'))
    heute = date.today()
    auf, unter = lokal(heute, sonne_ut(heute, breite, laenge, True)), lokal(heute, sonne_ut(heute, breite, laenge, False))
    jetzt = datetime.now(timezone.utc)
    _, hell, emoji, name = mond(jetzt)
    voll = naechster(jetzt, 0.5).astimezone()
    neu = naechster(jetzt, 0.0).astimezone()
    if auf is None or unter is None:
        return {'icon': '🌌', 'text': 'Polartag/-nacht', 'sub': '%s %s · %d %%' % (emoji, name, hell)}
    laenge_min = int((unter - auf).total_seconds() // 60)
    return {'icon': '🌅', 'text': '↑ %s  ↓ %s' % (auf.strftime('%H:%M'), unter.strftime('%H:%M')),
            'sub': '%s %s · %d %% beleuchtet' % (emoji, name, hell),
            'lines': ['Tageslänge: %d h %02d min' % divmod(laenge_min, 60),
                      'Nächster Vollmond: %s' % voll.strftime('%d.%m.'), 'Nächster Neumond: %s' % neu.strftime('%d.%m.')]}


def register(api):
    global _api
    _api = api
    api.widget('Himmel', widget, ttl=900, icon='🌅')
    api.route('heute', lambda req: {'mond': dict(zip(('phase', 'hell', 'emoji', 'name'), mond(datetime.now(timezone.utc)))),
                                    'sonne_ut': [sonne_ut(date.today(), float(api.get('breite')), float(api.get('laenge')), a) for a in (True, False)]})
'''},
    {'id': 'spruch', 'file': 'spruch.py', 'title': 'Spruch des Tages',
     'description': 'Kachel mit einem Spruch pro Tag (Klassiker und Sprichwörter) - mit eigenen Sprüchen erweiterbar.',
     'code': r'''# -*- coding: utf-8 -*-
"""Spruch des Tages: ein Gedanke zum Tag als Kachel (jeden Tag ein anderer) - mit eigenen Sprüchen erweiterbar.

Die mitgelieferten Sprüche sind Klassiker und Sprichwörter. Eigene Sprüche trägst du in den Einstellungen ein
(einer pro Zeile, am Ende gern „ - Name“). Mit „Nur eigene Sprüche“ kommen nur deine dran, z. B. Familiensprüche.
"""
from datetime import date

EXT_ID = 'spruch'
EXT_NAME = 'Spruch des Tages'
EXT_DESCRIPTION = 'Kachel mit einem Spruch pro Tag (Klassiker und Sprichwörter) - mit eigenen Sprüchen erweiterbar.'
EXT_SETTINGS = [
    {'key': 'eigene', 'label': 'Eigene Sprüche (einer pro Zeile)', 'type': 'textarea', 'default': '',
     'hint': 'z. B.  Wer rastet, der rostet. - Oma Gerda'},
    {'key': 'nur_eigene', 'label': 'Nur eigene Sprüche', 'type': 'bool', 'default': False},
]
SPRUECHE = [
    ('Habe Mut, dich deines eigenen Verstandes zu bedienen!', 'Immanuel Kant'),
    ('Der Mensch ist nur da ganz Mensch, wo er spielt.', 'Friedrich Schiller'),
    ('Es ist nicht genug zu wissen, man muss auch anwenden; es ist nicht genug zu wollen, man muss auch tun.', 'Johann Wolfgang von Goethe'),
    ('Man sieht nur mit dem Herzen gut. Das Wesentliche ist für die Augen unsichtbar.', 'Antoine de Saint-Exupéry'),
    ('Ohne Musik wäre das Leben ein Irrtum.', 'Friedrich Nietzsche'),
    ('Es gibt nichts Gutes, außer man tut es.', 'Erich Kästner'),
    ('Nichts ist so beständig wie der Wandel.', 'Heraklit'),
    ('Der Klügere gibt nach - eine traurige Wahrheit.', 'Marie von Ebner-Eschenbach'),
    ('Ein Buch ist ein Spiegel: Wenn ein Affe hineinschaut, kann kein Apostel heraussehen.', 'Georg Christoph Lichtenberg'),
    ('Es ist ein Brauch von alters her: Wer Sorgen hat, hat auch Likör.', 'Wilhelm Busch'),
    ('Wer kämpft, kann verlieren. Wer nicht kämpft, hat schon verloren.', 'Bertolt Brecht'),
    ('Wo man singt, da lass dich ruhig nieder, böse Menschen haben keine Lieder.', 'Johann Gottfried Seume'),
    ('Ich weiß, dass ich nichts weiß.', 'Sokrates'),
    ('Alles Gescheite ist schon gedacht worden; man muss nur versuchen, es noch einmal zu denken.', 'Johann Wolfgang von Goethe'),
    ('Morgenstund hat Gold im Mund.', 'Sprichwort'),
    ('Ohne Fleiß kein Preis.', 'Sprichwort'),
    ('Aller Anfang ist schwer.', 'Sprichwort'),
    ('Gut Ding will Weile haben.', 'Sprichwort'),
    ('Übung macht den Meister.', 'Sprichwort'),
    ('Lachen ist die beste Medizin.', 'Sprichwort'),
    ('Wer rastet, der rostet.', 'Sprichwort'),
    ('Aufgeschoben ist nicht aufgehoben.', 'Sprichwort'),
    ('In der Ruhe liegt die Kraft.', 'Sprichwort'),
    ('Ende gut, alles gut.', 'Sprichwort'),
    ('Wer wagt, gewinnt.', 'Sprichwort'),
    ('Geteilte Freude ist doppelte Freude.', 'Sprichwort'),
    ('Kleinvieh macht auch Mist.', 'Sprichwort'),
    ('Ein Lächeln kostet nichts und bringt viel.', 'Sprichwort'),
]
_api = None


def eigene(text):
    out = []
    for line in str(text or '').splitlines():
        line = line.strip()
        if not line:
            continue
        if ' - ' in line:
            s, a = line.rsplit(' - ', 1)
            out.append((s.strip(), a.strip()))
        else:
            out.append((line, ''))
    return out


def waehle(heute, eig, nur_eigene):
    pool = (eig if (eig and nur_eigene) else SPRUECHE + eig)
    return pool[heute.toordinal() % len(pool)]


def widget():
    s, a = waehle(date.today(), eigene(_api.get('eigene')), bool(_api.get('nur_eigene')))
    return {'icon': '💬', 'text': (a or 'Spruch des Tages')[:40], 'sub': s[:120]}


def register(api):
    global _api
    _api = api
    api.widget('Spruch des Tages', widget, ttl=1800, icon='💬')
    api.route('heute', lambda req: dict(zip(('spruch', 'autor'), waehle(date.today(), eigene(api.get('eigene')), bool(api.get('nur_eigene'))))))
'''},
    {'id': 'minispiele', 'file': 'minispiele.py', 'title': 'Minispiele',
     'description': 'Snake, 2048 und Memory für Fernbedienung (Pfeile + OK) und Touch - mit gemeinsamen Rekorden und Kachel.',
     'code': r'''# -*- coding: utf-8 -*-
"""Minispiele: Snake, 2048 und Memory - mit Fernbedienung (Pfeiltasten + OK) und per Touch (Wischen/Tippen) spielbar.

Öffnen: Erweiterungsliste -> Minispiele -> „Minispiele öffnen“ (im Browser des Geräts; am Fernseher mit der Fernbedienung).
Bedienung:  Pfeiltasten / D-Pad = steuern · OK/Enter = auswählen, pausieren, neu starten · Zurück/Esc = ins Menü.
            Touch: wischen (Snake, 2048), tippen (Memory, Knöpfe).
Die Rekorde werden in der Engine gespeichert und gelten für alle Geräte im Haus. Die Kachel „Minispiele“ zeigt sie an.
"""
import threading

EXT_ID = 'minispiele'
EXT_NAME = 'Minispiele'
EXT_DESCRIPTION = 'Snake, 2048 und Memory für Fernbedienung und Touch - mit gemeinsamen Rekorden und Kachel.'
EXT_LINKS = [('Minispiele öffnen', 'index')]

SPIELE = {'snake': 'hoch', '2048': 'hoch', 'memory': 'niedrig'}      # hoch = mehr ist besser, niedrig = weniger (Züge)
_api = None
_lock = threading.Lock()

PAGE = r"""<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="ms-game"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>Minispiele</title>
<style>
:root{--bg:#0f141b;--fg:#e8edf3;--mut:#93a1b3;--card:#18202b;--acc:#4da3ff;--bad:#ff6b6b;--ok:#4cd08a}
*{box-sizing:border-box}html,body{height:100%}
body{--chrome:4.6em;margin:0;height:100dvh;overflow:hidden;background:var(--bg);color:var(--fg);font:clamp(13px,2.4vmin,26px)/1.3 system-ui,sans-serif;display:flex;flex-direction:column;align-items:center;-webkit-user-select:none;user-select:none;overscroll-behavior:none}
body[data-m=snake]{--chrome:10.6em}
header{width:min(94vw,92vh,640px);display:flex;align-items:center;gap:12px;padding:6px 0}
header h1{font-size:1.2em;margin:0;flex:1}header .s{color:var(--mut);white-space:nowrap}
button{font:inherit;color:var(--fg);background:var(--card);border:3px solid transparent;border-radius:14px;padding:.5em 1em;cursor:pointer}
button:focus,button.f{outline:none;border-color:var(--acc)}
#menu{display:grid;gap:14px;width:min(80vw,70vh);margin-top:6vh}#menu button{padding:.9em 1em;font-size:1.3em;text-align:left}#menu small{display:block;color:var(--mut);font-size:.65em}
#stage{width:min(94vw,calc(100dvh - var(--chrome)));aspect-ratio:1;position:relative;touch-action:none}
canvas{width:100%;height:100%;background:var(--card);border-radius:14px;display:block}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:2.2%;height:100%;background:#0b1016;padding:2.2%;border-radius:14px}
.t{display:grid;place-items:center;border-radius:10px;background:var(--card);font-weight:700;font-size:clamp(20px,6vmin,56px);transition:transform .08s}
.t[data-v="2"]{background:#2b3a4f}.t[data-v="4"]{background:#34506f}.t[data-v="8"]{background:#d98a3d}.t[data-v="16"]{background:#e2702f}
.t[data-v="32"]{background:#e2552f}.t[data-v="64"]{background:#e0322f}.t[data-v="128"]{background:#cdb24a}.t[data-v="256"]{background:#c7b02a}
.t[data-v="512"]{background:#bfae12}.t[data-v="1024"]{background:#b6a500}.t[data-v="2048"]{background:#4cd08a;color:#052}
.c{cursor:pointer;font-size:clamp(24px,8vmin,72px)}.c.o,.c.d{background:#27415f}.c.d{opacity:.45}.c.cur{outline:4px solid var(--acc)}
#msg{position:absolute;inset:0;display:none;place-items:center;text-align:center;background:rgba(5,8,13,.78);border-radius:14px;padding:16px;font-size:1.3em}
#msg.on{display:grid}#msg small{display:block;color:var(--mut);margin-top:.4em}
#pad{display:none;grid-template-columns:repeat(3,1fr);gap:6px;width:min(60vw,15em);margin:6px 0}#pad button{padding:.35em}
@media (pointer:coarse){#pad.snake{display:grid}}
@media (orientation:landscape){
 body{display:grid;grid-template-columns:1fr auto;grid-template-rows:auto 1fr;justify-items:center;align-items:start;column-gap:12px;--chrome:4.4em}
 body[data-m=snake]{--chrome:4.4em}
 header{grid-column:1/-1}
 #menu{grid-column:1/-1;grid-template-columns:repeat(3,1fr);width:min(94vw,900px);margin-top:2vh}#menu small[style]{grid-column:1/-1}
 #stage{grid-column:1}#pad{grid-column:2;align-self:center;width:14em;margin:0 8px}
 #stage,#pad{grid-row:2}
}
</style></head><body>
<header><h1 id="ti">🎮 Minispiele</h1><span class="s" id="sc"></span><button id="bm" style="display:none">☰ Menü</button></header>
<div id="menu">
  <button data-g="snake">🐍 Snake<small id="r-snake"></small></button>
  <button data-g="2048">🔢 2048<small id="r-2048"></small></button>
  <button data-g="memory">🃏 Memory<small id="r-memory"></small></button>
  <small style="color:var(--mut)">Fernbedienung: Pfeile + OK · Touch: tippen und wischen</small>
</div>
<div id="stage" style="display:none"><canvas id="cv" width="540" height="540"></canvas><div class="g4" id="grid" style="display:none"></div><div id="msg"></div></div>
<div id="pad"><span></span><button data-d="up">▲</button><span></span><button data-d="left">◀</button><button data-d="down">▼</button><button data-d="right">▶</button></div>
<script>
"use strict";
const $=(s)=>document.querySelector(s);
const DIRS={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]};
const KEYDIR={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',w:'up',s:'down',a:'left',d:'right'};
const BACK=['Escape','Backspace','GoBack','BrowserBack'];
let mode='menu',cur=null,timer=null,best={},menuIdx=0;

/* ---------- Rekorde (in der Engine gespeichert) ---------- */
async function loadBest(){try{const r=await fetch('punkte');best=await r.json()}catch(e){best={}}drawBest()}
function bestText(g){const b=best[g];if(b==null)return 'Noch kein Rekord';return g==='memory'?'Rekord: '+b+' Züge':'Rekord: '+b}
function drawBest(){['snake','2048','memory'].forEach(g=>{const e=$('#r-'+g);if(e)e.textContent=bestText(g)})}
async function report(g,v){try{const r=await fetch('punkte',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({spiel:g,wert:v})});best=await r.json();drawBest()}catch(e){}}

/* ---------- Snake ---------- */
function snakePlace(s,rnd){const free=[];const o=new Set(s.body.map(c=>c[0]+','+c[1]));for(let y=0;y<s.n;y++)for(let x=0;x<s.n;x++)if(!o.has(x+','+y))free.push([x,y]);return free.length?free[Math.floor((rnd||Math.random)()*free.length)]:null}
function snakeNew(rnd){const n=18,m=n>>1;const s={n,body:[[m,m],[m-1,m],[m-2,m]],dir:[1,0],queue:[],food:null,score:0,over:false,paused:false};s.food=snakePlace(s,rnd);return s}
function snakeTurn(s,name){const d=DIRS[name];if(!d)return;const last=s.queue.length?s.queue[s.queue.length-1]:s.dir;if(d[0]===-last[0]&&d[1]===-last[1])return;if(d[0]===last[0]&&d[1]===last[1])return;if(s.queue.length<2)s.queue.push(d)}
function snakeStep(s,rnd){if(s.over)return s;if(s.queue.length)s.dir=s.queue.shift();const h=s.body[0],n=s.n;const nx=(h[0]+s.dir[0]+n)%n,ny=(h[1]+s.dir[1]+n)%n;const eat=!!s.food&&nx===s.food[0]&&ny===s.food[1];const tail=eat?s.body:s.body.slice(0,-1);if(tail.some(c=>c[0]===nx&&c[1]===ny)){s.over=true;return s}s.body.unshift([nx,ny]);if(eat){s.score++;s.food=snakePlace(s,rnd)}else s.body.pop();return s}
function snakeDraw(s){const cv=$('#cv'),x=cv.getContext('2d'),c=cv.width/s.n;x.clearRect(0,0,cv.width,cv.height);x.fillStyle='#18202b';x.fillRect(0,0,cv.width,cv.height);
  if(s.food){x.fillStyle='#ff6b6b';x.beginPath();x.arc((s.food[0]+.5)*c,(s.food[1]+.5)*c,c*.38,0,7);x.fill()}
  s.body.forEach((p,i)=>{x.fillStyle=i?'#4cd08a':'#9dffc8';x.fillRect(p[0]*c+1,p[1]*c+1,c-2,c-2)})}
function snakeLoop(){clearTimeout(timer);if(mode!=='snake')return;const s=cur;if(!s.over&&!s.paused){snakeStep(s);snakeDraw(s);setScore('Punkte: '+s.score);if(s.over){report('snake',s.score);msg('Game Over<small>'+s.score+' Punkte · OK = nochmal · Zurück = Menü</small>')}}
  timer=setTimeout(snakeLoop,Math.max(70,160-s.score*4))}
function snakeStart(){cur=snakeNew();msg('');snakeDraw(cur);setScore('Punkte: 0');snakeLoop()}

/* ---------- 2048 ---------- */
function slide(line){const a=line.filter(v=>v);let gained=0;const out=[];for(let i=0;i<a.length;i++){if(a[i+1]===a[i]){out.push(a[i]*2);gained+=a[i]*2;i++}else out.push(a[i])}while(out.length<line.length)out.push(0);return{line:out,gained}}
function lines4(dir){const L=[];for(let i=0;i<4;i++){const idx=[];for(let j=0;j<4;j++){const k=dir==='left'?[i,j]:dir==='right'?[i,3-j]:dir==='up'?[j,i]:[3-j,i];idx.push(k[0]*4+k[1])}L.push(idx)}return L}
function move2048(g,dir){let moved=false,gain=0;for(const idx of lines4(dir)){const r=slide(idx.map(i=>g.b[i]));r.line.forEach((v,j)=>{if(g.b[idx[j]]!==v){moved=true;g.b[idx[j]]=v}});gain+=r.gained}g.score+=gain;return moved}
function can2048(g){return['left','right','up','down'].some(d=>move2048({b:g.b.slice(),score:0},d))}
function add2048(g,rnd){const free=[];g.b.forEach((v,i)=>{if(!v)free.push(i)});if(!free.length)return;g.b[free[Math.floor((rnd||Math.random)()*free.length)]]=(rnd||Math.random)()<.9?2:4}
function new2048(rnd){const g={b:Array(16).fill(0),score:0,over:false};add2048(g,rnd);add2048(g,rnd);return g}
function draw2048(g){const el=$('#grid');el.textContent='';g.b.forEach(v=>{const t=document.createElement('div');t.className='t';t.dataset.v=v;t.textContent=v||'';el.appendChild(t)});setScore('Punkte: '+g.score)}
function turn2048(name){const g=cur;if(g.over||!DIRS[name])return;if(move2048(g,name)){add2048(g);draw2048(g);if(!can2048(g)){g.over=true;report('2048',g.score);msg('Keine Züge mehr<small>'+g.score+' Punkte · OK = nochmal · Zurück = Menü</small>')}}}
function start2048(){cur=new2048();msg('');draw2048(cur)}

/* ---------- Memory ---------- */
const EMOJI=['🎬','🍿','🎭','📺','🎞️','⭐','🎥','🎟️'];
function memNew(rnd){const r=rnd||Math.random;const a=EMOJI.concat(EMOJI).map(e=>({e,open:false,done:false}));for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return{cards:a,first:null,lock:false,moves:0,cursor:0,t0:Date.now(),won:false}}
function memFlip(m,i,after){const c=m.cards[i];if(m.lock||m.won||!c||c.open||c.done)return false;c.open=true;if(m.first===null){m.first=i;return true}
  m.moves++;const f=m.cards[m.first];if(f.e===c.e){f.done=c.done=true;m.first=null;m.won=m.cards.every(x=>x.done)}else{m.lock=true;const a=m.first;m.first=null;const back=()=>{f.open=false;c.open=false;m.lock=false;if(after)after()};if(after===false)back();else setTimeout(back,750)}return true}
function memDraw(m){const el=$('#grid');el.textContent='';m.cards.forEach((c,i)=>{const t=document.createElement('div');t.className='t c'+(c.open?' o':'')+(c.done?' d':'')+(i===m.cursor?' cur':'');t.textContent=(c.open||c.done)?c.e:'❓';t.onclick=()=>{m.cursor=i;memAct()};el.appendChild(t)});setScore('Züge: '+m.moves)}
function memAct(){const m=cur;if(m.won){memStart();return}memFlip(m,m.cursor,()=>memDraw(m));memDraw(m);if(m.won){report('memory',m.moves);msg('Geschafft!<small>'+m.moves+' Züge in '+Math.round((Date.now()-m.t0)/1000)+' s · OK = nochmal · Zurück = Menü</small>')}}
function memMove(name){const m=cur,d=DIRS[name];if(!d)return;let x=m.cursor%4+d[0],y=Math.floor(m.cursor/4)+d[1];x=(x+4)%4;y=(y+4)%4;m.cursor=y*4+x;memDraw(m)}
function memStart(){cur=memNew();msg('');memDraw(cur)}

/* ---------- Gemeinsames ---------- */
function setScore(t){$('#sc').textContent=t}
function msg(html){const m=$('#msg');m.innerHTML=html;m.classList.toggle('on',!!html)}
function show(g){mode=g;document.body.dataset.m=g;clearTimeout(timer);const game=g!=='menu';$('#menu').style.display=game?'none':'grid';$('#stage').style.display=game?'block':'none';$('#bm').style.display=game?'':'none';
  $('#cv').style.display=g==='snake'?'block':'none';$('#grid').style.display=(g==='2048'||g==='memory')?'grid':'none';$('#pad').className=g==='snake'?'snake':'';
  $('#ti').textContent=g==='snake'?'🐍 Snake':g==='2048'?'🔢 2048':g==='memory'?'🃏 Memory':'🎮 Minispiele';setScore('');msg('');
  if(g==='snake')snakeStart();else if(g==='2048')start2048();else if(g==='memory')memStart();else{markMenu();loadBest()}}
function markMenu(){document.querySelectorAll('#menu button').forEach((b,i)=>b.classList.toggle('f',i===menuIdx));const b=document.querySelectorAll('#menu button')[menuIdx];if(b)b.focus()}
function over(){return cur&&(cur.over||cur.won)}
function direction(name){if(mode==='snake'){if(!cur.over)snakeTurn(cur,name)}else if(mode==='2048')turn2048(name);else if(mode==='memory')memMove(name);else if(mode==='menu'){menuIdx=(menuIdx+(name==='down'||name==='right'?1:-1)+3)%3;markMenu()}}
function ok(){if(mode==='menu'){show(['snake','2048','memory'][menuIdx]);return}
  if(mode==='snake'){if(cur.over)snakeStart();else{cur.paused=!cur.paused;msg(cur.paused?'Pause<small>OK = weiter</small>':'')}}
  else if(mode==='2048'){if(cur.over)start2048()}else if(mode==='memory')memAct()}
document.addEventListener('keydown',e=>{const k=e.key.length===1?e.key.toLowerCase():e.key;
  if(KEYDIR[k]){e.preventDefault();direction(KEYDIR[k])}
  else if(k==='Enter'||k===' '||k==='Select'){e.preventDefault();ok()}
  else if(BACK.includes(k)||e.keyCode===4){if(mode!=='menu'){e.preventDefault();show('menu')}}});
/* Touch: wischen */
let tx=0,ty=0;const st=$('#stage');
st.addEventListener('touchstart',e=>{tx=e.touches[0].clientX;ty=e.touches[0].clientY},{passive:true});
st.addEventListener('touchend',e=>{const t=e.changedTouches[0],dx=t.clientX-tx,dy=t.clientY-ty;if(Math.max(Math.abs(dx),Math.abs(dy))<24){if(mode!=='memory'&&over())ok();else if(mode==='snake'&&cur.paused)ok();return}
  if(mode==='memory')return;direction(Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up'))},{passive:true});
st.addEventListener('touchmove',e=>e.preventDefault(),{passive:false});
document.querySelectorAll('#menu button').forEach((b,i)=>b.onclick=()=>{menuIdx=i;ok()});
document.querySelectorAll('#pad button').forEach(b=>b.onclick=()=>direction(b.dataset.d));
$('#bm').onclick=()=>show('menu');
window.MS={slide,move2048,can2048,snakeNew,snakeStep,snakeTurn,memNew,memFlip,state:()=>({mode,cur})};
show('menu');
</script></body></html>"""


def _vergleich(spiel, neu, alt):
    return alt is None or (neu > alt if SPIELE[spiel] == 'hoch' else neu < alt)


def register(api):
    global _api
    _api = api

    def punkte(req):
        if req.method == 'POST':
            d = req.json if isinstance(req.json, dict) else {}
            spiel = str(d.get('spiel') or '')
            try:
                wert = int(d.get('wert'))
            except (TypeError, ValueError):
                return ({'error': 'Wert fehlt'}, 400)
            if spiel not in SPIELE or wert < 0 or wert > 10_000_000:
                return ({'error': 'Unbekanntes Spiel oder ungültiger Wert'}, 400)
            with _lock:
                best = api.get('rekorde', {})
                best = best if isinstance(best, dict) else {}
                if _vergleich(spiel, wert, best.get(spiel)) and not (spiel == 'memory' and wert < 8):
                    best[spiel] = wert
                    api.set('rekorde', best)
                return best
        b = api.get('rekorde', {})
        return b if isinstance(b, dict) else {}

    def widget():
        b = punkte(type('R', (), {'method': 'GET', 'json': {}})())
        if not b:
            return {'icon': '🎮', 'text': 'Minispiele', 'sub': 'Snake · 2048 · Memory - noch keine Rekorde'}
        teile = []
        if 'snake' in b:
            teile.append('🐍 %d' % b['snake'])
        if '2048' in b:
            teile.append('🔢 %d' % b['2048'])
        if 'memory' in b:
            teile.append('🃏 %d Züge' % b['memory'])
        return {'icon': '🎮', 'text': 'Rekorde', 'sub': ' · '.join(teile)}

    api.route('index', lambda req: PAGE)
    api.route('punkte', punkte)
    api.widget('Minispiele', widget, ttl=60, icon='🎮')
'''},
    {'id': 'tetris', 'file': 'tetris.py', 'title': 'Tetris',
     'description': 'Tetris für Fernbedienung und Touch mit gemeinsamem Rekord und Kachel.',
     'code': r'''# -*- coding: utf-8 -*-
"""Tetris: Steine stapeln, Reihen füllen - mit Fernbedienung und Touch spielbar, Rekord gilt für alle Geräte.

Öffnen: Erweiterungsliste -> Tetris -> „Tetris öffnen“.
Fernbedienung:  links/rechts = bewegen · runter = schneller · hoch = drehen · OK = Stein fallen lassen · Zurück = Pause
Touch:          nach links/rechts ziehen = bewegen · tippen = drehen · nach unten wischen = fallen lassen · Knöpfe unten
"""
import threading

EXT_ID = 'tetris'
EXT_NAME = 'Tetris'
EXT_DESCRIPTION = 'Tetris für Fernbedienung und Touch mit gemeinsamem Rekord und Kachel.'
EXT_LINKS = [('Tetris öffnen', 'index')]
_api = None
_lock = threading.Lock()

PAGE = r"""<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="ms-game"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>Tetris</title>
<style>
:root{--bg:#0f141b;--fg:#e8edf3;--mut:#93a1b3;--card:#18202b;--acc:#4da3ff}
*{box-sizing:border-box}html,body{height:100%}
body{margin:0;background:var(--bg);color:var(--fg);font:clamp(12px,2.3vmin,24px)/1.3 system-ui,sans-serif;display:flex;justify-content:center;align-items:center;gap:12px;flex-wrap:nowrap;-webkit-user-select:none;user-select:none;overscroll-behavior:none;padding:6px;overflow:hidden}
#wrap{position:relative;flex:none;height:min(calc(100dvh - 12px),calc((100vw - 12em - 24px)*2));aspect-ratio:1/2;touch-action:none}
canvas{display:block;width:100%;height:100%;background:var(--card);border-radius:12px}
#side{display:grid;grid-template-columns:1fr 1fr;gap:6px;width:11em;flex:none}
#side div{background:var(--card);border-radius:10px;padding:.3em .6em}#side b{display:block;font-size:1.3em;color:var(--acc)}
#side div:nth-child(5),#pad{grid-column:1/-1}
#nx{display:block;width:3.6em;height:3.6em;background:transparent;margin:0 auto}
#msg{position:absolute;inset:0;display:none;place-items:center;text-align:center;background:rgba(5,8,13,.8);border-radius:12px;padding:12px;font-size:1.2em}
#msg.on{display:grid}#msg small{display:block;color:var(--mut);margin-top:.4em}
#pad{display:none;gap:6px;justify-content:center}#pad button{flex:1;font:inherit;font-size:1.3em;color:var(--fg);background:var(--card);border:0;border-radius:10px;padding:.45em 0}
@media (pointer:coarse){#pad{display:flex}}
@media (orientation:portrait){
 body{flex-direction:column;gap:6px}
 #wrap{height:min(calc(100dvh - 11em),calc((100vw - 12px)*2))}
 #side{grid-template-columns:repeat(5,1fr);width:min(100%,calc(100vw - 12px))}
 #side div:nth-child(5){grid-column:auto}#side div{padding:.25em .4em}#side b{font-size:1.2em}
 #nx{width:2.6em;height:2.6em}
}
</style></head><body>
<div id="wrap"><canvas id="cv" width="300" height="600"></canvas><div id="msg"></div></div>
<div id="side"><div>Punkte<b id="sc">0</b></div><div>Reihen<b id="ln">0</b></div><div>Stufe<b id="lv">1</b></div><div>Rekord<b id="bs">-</b></div>
<div>Nächster<canvas id="nx" width="120" height="120"></canvas></div><div id="pad"><button data-k="left">◀</button><button data-k="rot">⟳</button><button data-k="down">▼</button><button data-k="drop">⏬</button><button data-k="right">▶</button></div></div>
<script>
"use strict";
const $=(s)=>document.querySelector(s);
const W=10,H=20,COL=['#000','#4dd0e1','#ffd54f','#ba68c8','#81c784','#e57373','#64b5f6','#ffb74d'];
const SHAPES=[null,[[1,1,1,1]],[[1,1],[1,1]],[[0,1,0],[1,1,1]],[[0,1,1],[1,1,0]],[[1,1,0],[0,1,1]],[[1,0,0],[1,1,1]],[[0,0,1],[1,1,1]]];
function rotate(m){return m[0].map((_,i)=>m.map(r=>r[i]).reverse())}
function collide(b,m,x,y){for(let j=0;j<m.length;j++)for(let i=0;i<m[j].length;i++)if(m[j][i]){const bx=x+i,by=y+j;if(bx<0||bx>=W||by>=H)return true;if(by>=0&&b[by][bx])return true}return false}
function bag(rnd){const a=[1,2,3,4,5,6,7];for(let i=6;i>0;i--){const j=Math.floor((rnd||Math.random)()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function spawn(g){const k=g.queue.length<2?g.queue.push(...bag(g.rnd)):0;const t=g.queue.shift();g.p={k:t,m:SHAPES[t].map(r=>r.slice()),x:Math.floor((W-SHAPES[t][0].length)/2),y:0};
  if(collide(g.b,g.p.m,g.p.x,g.p.y))g.over=true}
function newGame(rnd){const g={b:Array.from({length:H},()=>Array(W).fill(0)),queue:[],p:null,score:0,lines:0,level:1,over:false,paused:false,rnd:rnd};g.queue.push(...bag(rnd));spawn(g);return g}
function tryMove(g,dx,dy){if(g.over||g.paused)return false;if(!collide(g.b,g.p.m,g.p.x+dx,g.p.y+dy)){g.p.x+=dx;g.p.y+=dy;return true}return false}
function tryRotate(g){if(g.over||g.paused||g.p.k===2)return false;const m=rotate(g.p.m);for(const dx of [0,-1,1,-2,2])if(!collide(g.b,m,g.p.x+dx,g.p.y)){g.p.m=m;g.p.x+=dx;return true}return false}
function lock(g){g.p.m.forEach((r,j)=>r.forEach((v,i)=>{if(v&&g.p.y+j>=0)g.b[g.p.y+j][g.p.x+i]=g.p.k}));let n=0;for(let y=H-1;y>=0;y--){if(g.b[y].every(v=>v)){g.b.splice(y,1);g.b.unshift(Array(W).fill(0));n++;y++}}
  g.score+=[0,100,300,500,800][n]*g.level;g.lines+=n;g.level=1+Math.floor(g.lines/10);spawn(g);return n}
function tick(g){if(g.over||g.paused)return;if(!tryMove(g,0,1))lock(g)}
function softDrop(g){if(tryMove(g,0,1))g.score+=1;else tick(g)}
function hardDrop(g){if(g.over||g.paused)return;let n=0;while(tryMove(g,0,1))n++;g.score+=2*n;lock(g)}
function speed(g){return Math.max(90,800-(g.level-1)*70)}

let g=null,timer=null,best=null;
function cell(x,c,px,py,s){x.fillStyle=COL[c];x.fillRect(px+1,py+1,s-2,s-2)}
function draw(){const cv=$('#cv'),x=cv.getContext('2d'),s=cv.width/W;x.clearRect(0,0,cv.width,cv.height);
  for(let y=0;y<H;y++)for(let i=0;i<W;i++){if(g.b[y][i])cell(x,g.b[y][i],i*s,y*s,s);else{x.fillStyle='rgba(255,255,255,.04)';x.fillRect(i*s+s/2-1,y*s+s/2-1,2,2)}}
  if(!g.over){let gy=g.p.y;while(!collide(g.b,g.p.m,g.p.x,gy+1))gy++;x.globalAlpha=.25;g.p.m.forEach((r,j)=>r.forEach((v,i)=>{if(v)cell(x,g.p.k,(g.p.x+i)*s,(gy+j)*s,s)}));x.globalAlpha=1;
    g.p.m.forEach((r,j)=>r.forEach((v,i)=>{if(v)cell(x,g.p.k,(g.p.x+i)*s,(g.p.y+j)*s,s)}))}
  const nx=$('#nx').getContext('2d');nx.clearRect(0,0,120,120);const nm=SHAPES[g.queue[0]];const ns=24,ox=(120-nm[0].length*ns)/2,oy=(120-nm.length*ns)/2;nm.forEach((r,j)=>r.forEach((v,i)=>{if(v)cell(nx,g.queue[0],ox+i*ns,oy+j*ns,ns)}));
  $('#sc').textContent=g.score;$('#ln').textContent=g.lines;$('#lv').textContent=g.level}
function msg(h){const m=$('#msg');m.innerHTML=h;m.classList.toggle('on',!!h)}
async function loadBest(){try{const r=await (await fetch('punkte')).json();best=r.tetris==null?null:r.tetris}catch(e){}$('#bs').textContent=best==null?'-':best}
async function report(v){try{const r=await (await fetch('punkte',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({wert:v})})).json();best=r.tetris;$('#bs').textContent=best}catch(e){}}
function loop(){clearTimeout(timer);if(g.over)return;if(!g.paused){tick(g);after()}timer=setTimeout(loop,speed(g))}
function after(){draw();if(g.over){report(g.score);msg('Game Over<small>'+g.score+' Punkte · OK = nochmal</small>')}}
function start(){g=newGame();msg('');draw();loop()}
function act(k){if(!g)return;if(g.over){if(k==='drop')start();return}
  if(k==='pause'){g.paused=!g.paused;msg(g.paused?'Pause<small>Zurück oder OK = weiter</small>':'');return}
  if(g.paused){if(k==='drop'){g.paused=false;msg('')}return}
  if(k==='left')tryMove(g,-1,0);else if(k==='right')tryMove(g,1,0);else if(k==='down')softDrop(g);else if(k==='rot')tryRotate(g);else if(k==='drop')hardDrop(g);
  after()}
const KEYS={ArrowLeft:'left',ArrowRight:'right',ArrowDown:'down',ArrowUp:'rot',Enter:'drop',' ':'drop',Select:'drop',Escape:'pause',Backspace:'pause',GoBack:'pause',BrowserBack:'pause',p:'pause'};
document.addEventListener('keydown',e=>{const a=KEYS[e.key]||(e.keyCode===4?'pause':null);if(a){e.preventDefault();act(a)}});
document.querySelectorAll('#pad button').forEach(b=>b.addEventListener('click',()=>act(b.dataset.k)));
let sx=0,sy=0,lx=0,moved=false;const w=$('#wrap');
w.addEventListener('touchstart',e=>{sx=lx=e.touches[0].clientX;sy=e.touches[0].clientY;moved=false},{passive:true});
w.addEventListener('touchmove',e=>{e.preventDefault();const x=e.touches[0].clientX,step=w.clientWidth/W*1.2;while(x-lx>step){act('right');lx+=step;moved=true}while(lx-x>step){act('left');lx-=step;moved=true}},{passive:false});
w.addEventListener('touchend',e=>{const t=e.changedTouches[0],dx=t.clientX-sx,dy=t.clientY-sy;if(!moved&&Math.abs(dx)<14&&Math.abs(dy)<14){if(g.over||g.paused)act('drop');else act('rot')}else if(dy>70&&dy>Math.abs(dx)*1.5)act('drop')},{passive:true});
window.TT={newGame,collide,rotate,tryMove,tryRotate,lock,tick,hardDrop,softDrop,speed,state:()=>g,SHAPES};
loadBest();start();
</script></body></html>"""


def register(api):
    global _api
    _api = api

    def punkte(req):
        if req.method == 'POST':
            d = req.json if isinstance(req.json, dict) else {}
            try:
                wert = int(d.get('wert'))
            except (TypeError, ValueError):
                return ({'error': 'Wert fehlt'}, 400)
            if wert < 0 or wert > 100_000_000:
                return ({'error': 'Ungültiger Wert'}, 400)
            with _lock:
                b = api.get('rekorde', {})
                b = b if isinstance(b, dict) else {}
                if wert > b.get('tetris', -1):
                    b['tetris'] = wert
                    api.set('rekorde', b)
                return b
        b = api.get('rekorde', {})
        return b if isinstance(b, dict) else {}

    def widget():
        b = punkte(type('R', (), {'method': 'GET', 'json': {}})())
        return {'icon': '🧱', 'text': 'Tetris', 'sub': ('Rekord: %d Punkte' % b['tetris']) if 'tetris' in b else 'Noch kein Rekord - los geht’s!'}

    api.route('index', lambda req: PAGE)
    api.route('punkte', punkte)
    api.widget('Tetris', widget, ttl=60, icon='🧱')
'''},
    {'id': 'quiz', 'file': 'quiz.py', 'title': 'Filmquiz',
     'description': 'Filmquiz mit 40 Fragen für Fernbedienung und Touch, eigene Fragen möglich, gemeinsamer Rekord.',
     'code': r'''# -*- coding: utf-8 -*-
"""Filmquiz: zehn Fragen rund ums Kino - mit Fernbedienung und Touch spielbar, Rekord gilt für alle Geräte.

Öffnen: Erweiterungsliste -> Filmquiz -> „Quiz starten“.
Fernbedienung: Pfeiltasten wählen die Antwort, OK bestätigt (oder Zifferntasten 1-4) · Touch: Antwort antippen.
Je schneller die richtige Antwort, desto mehr Punkte (100 bis 150). Eigene Fragen trägst du in den Einstellungen ein:
    Frage; richtige Antwort; falsch 1; falsch 2; falsch 3        (eine Frage pro Zeile)
"""
import random
import threading

EXT_ID = 'quiz'
EXT_NAME = 'Filmquiz'
EXT_DESCRIPTION = 'Filmquiz mit 40 Fragen für Fernbedienung und Touch, eigene Fragen möglich, gemeinsamer Rekord.'
EXT_LINKS = [('Quiz starten', 'index')]
EXT_SETTINGS = [
    {'key': 'anzahl', 'label': 'Fragen pro Runde', 'type': 'number', 'default': 10, 'min': 3, 'max': 30},
    {'key': 'zeit', 'label': 'Sekunden pro Frage', 'type': 'number', 'default': 15, 'min': 5, 'max': 60},
    {'key': 'eigene', 'label': 'Eigene Fragen (eine pro Zeile)', 'type': 'textarea', 'default': '',
     'hint': 'Frage; richtige Antwort; falsch 1; falsch 2; falsch 3   - mindestens eine falsche Antwort.'},
    {'key': 'nur_eigene', 'label': 'Nur eigene Fragen', 'type': 'bool', 'default': False},
]

FRAGEN = [
    ('Wer führte Regie bei „Der Pate“ (1972)?', 'Francis Ford Coppola', 'Martin Scorsese', 'Steven Spielberg', 'Brian De Palma'),
    ('In welchem Film sagt Darth Vader „Ich bin dein Vater“?', 'Das Imperium schlägt zurück', 'Eine neue Hoffnung', 'Die dunkle Bedrohung', 'Das Erwachen der Macht'),
    ('Wer führte Regie bei „Der weiße Hai“?', 'Steven Spielberg', 'George Lucas', 'James Cameron', 'Ridley Scott'),
    ('Wie viele Oscars gewann „Titanic“ (1997)?', '11', '7', '14', '5'),
    ('Wer spielt Captain Jack Sparrow in „Fluch der Karibik“?', 'Johnny Depp', 'Orlando Bloom', 'Brad Pitt', 'Geoffrey Rush'),
    ('Wie heißt der Junge mit der Blitznarbe?', 'Harry Potter', 'Percy Jackson', 'Frodo Beutlin', 'Peter Parker'),
    ('Welches Studio hat „Toy Story“ produziert?', 'Pixar', 'DreamWorks', 'Illumination', 'Studio Ghibli'),
    ('Wie viele Filme hat die Original-Trilogie „Der Herr der Ringe“?', '3', '2', '4', '5'),
    ('Wer spielt die Titelrolle in „Forrest Gump“?', 'Tom Hanks', 'Tom Cruise', 'Kevin Costner', 'Bill Murray'),
    ('Wer führte Regie bei „Pulp Fiction“?', 'Quentin Tarantino', 'Guy Ritchie', 'David Fincher', 'Robert Rodriguez'),
    ('Wie heißt die vergessliche blaue Fischdame in „Findet Nemo“?', 'Dorie', 'Marlin', 'Bruce', 'Gill'),
    ('Wer führte Regie bei „Inception“?', 'Christopher Nolan', 'Denis Villeneuve', 'Ridley Scott', 'Peter Jackson'),
    ('Welcher Schauspieler verkörpert Iron Man im Marvel-Universum?', 'Robert Downey Jr.', 'Chris Evans', 'Chris Hemsworth', 'Mark Ruffalo'),
    ('Wie heißt der graue Zauberer in „Der Herr der Ringe“?', 'Gandalf', 'Saruman', 'Dumbledore', 'Merlin'),
    ('Welches Tier ist Simba im „König der Löwen“?', 'Ein Löwe', 'Ein Tiger', 'Ein Gepard', 'Ein Leopard'),
    ('In welchem Film erlebt Bill Murray jeden Tag denselben Tag?', 'Und täglich grüßt das Murmeltier', 'Zurück in die Zukunft', 'Die Truman Show', 'Edge of Tomorrow'),
    ('In welchem Jahr kam der erste „Star Wars“-Film ins Kino?', '1977', '1969', '1983', '1991'),
    ('Welche Pille nimmt Neo in „Matrix“?', 'Die rote', 'Die blaue', 'Die grüne', 'Die weiße'),
    ('Wer führte Regie bei „Jurassic Park“ (1993)?', 'Steven Spielberg', 'Michael Crichton', 'Robert Zemeckis', 'Tim Burton'),
    ('Wie heißt der beste Freund von Harry Potter mit den roten Haaren?', 'Ron Weasley', 'Draco Malfoy', 'Neville Longbottom', 'Cedric Diggory'),
    ('Was will „E.T.“ am Ende?', 'Nach Hause telefonieren', 'Auf der Erde bleiben', 'Pizza essen', 'Den Präsidenten treffen'),
    ('In welchem Film singt Elsa „Lass jetzt los“?', 'Die Eiskönigin', 'Vaiana', 'Rapunzel', 'Die Schöne und das Biest'),
    ('Wer spielt die Hauptrolle in „Gladiator“ (2000)?', 'Russell Crowe', 'Mel Gibson', 'Brad Pitt', 'Gerard Butler'),
    ('Wer führte Regie bei „Psycho“?', 'Alfred Hitchcock', 'Stanley Kubrick', 'Orson Welles', 'Billy Wilder'),
    ('Wer führte Regie bei „Lola rennt“?', 'Tom Tykwer', 'Wim Wenders', 'Wolfgang Becker', 'Fatih Akin'),
    ('Wer führte Regie bei „Das Boot“?', 'Wolfgang Petersen', 'Roland Emmerich', 'Bernd Eichinger', 'Werner Herzog'),
    ('Wer führte Regie bei „Good Bye, Lenin!“?', 'Wolfgang Becker', 'Tom Tykwer', 'Dominik Graf', 'Caroline Link'),
    ('Welcher deutsche Film gewann 2007 den Auslands-Oscar?', 'Das Leben der Anderen', 'Die Fälscher', 'Nirgendwo in Afrika', 'Der Untergang'),
    ('Welches Auto ist die Zeitmaschine in „Zurück in die Zukunft“?', 'Ein DeLorean', 'Ein Ford Mustang', 'Ein Chevrolet Camaro', 'Ein Porsche 911'),
    ('Wer spielt Kevin in „Kevin - Allein zu Haus“?', 'Macaulay Culkin', 'Haley Joel Osment', 'Elijah Wood', 'Daniel Radcliffe'),
    ('Welchen Don spielt Marlon Brando in „Der Pate“?', 'Vito Corleone', 'Michael Corleone', 'Carlo Rizzi', 'Tom Hagen'),
    ('Wie heißt der Planet in „Avatar“ (2009)?', 'Pandora', 'Tatooine', 'Krypton', 'Arrakis'),
    ('Wie heißt die Heldin in „Die Schöne und das Biest“?', 'Belle', 'Aurora', 'Jasmin', 'Ariel'),
    ('Welche Sportart betreibt „Rocky“?', 'Boxen', 'Ringen', 'Eishockey', 'Football'),
    ('Wer drehte „Chihiros Reise ins Zauberland“?', 'Hayao Miyazaki', 'Makoto Shinkai', 'Mamoru Hosoda', 'Katsuhiro Otomo'),
    ('Wer spielte James Bond in „Casino Royale“ (2006)?', 'Daniel Craig', 'Pierce Brosnan', 'Roger Moore', 'Sean Connery'),
    ('Wer spielte in „Der Schuh des Manitu“ Abahachi und führte Regie?', 'Michael „Bully“ Herbig', 'Til Schweiger', 'Matthias Schweighöfer', 'Christian Ulmen'),
    ('Welches Ereignis steht im Mittelpunkt von „Das Wunder von Bern“?', 'Die Fußball-WM 1954', 'Der Mauerfall', 'Die Olympischen Spiele 1972', 'Die Wiedervereinigung'),
    ('Wer ist Schulleiter von Hogwarts in den ersten Harry-Potter-Filmen?', 'Albus Dumbledore', 'Gandalf', 'Severus Snape', 'Sirius Black'),
    ('Welcher Detektiv wohnt in der Baker Street 221B?', 'Sherlock Holmes', 'Hercule Poirot', 'Miss Marple', 'Philip Marlowe'),
]
_api = None
_lock = threading.Lock()


def eigene(text):
    """Zeilen 'Frage; richtig; falsch 1; ...' -> Liste von Tupeln. Kaputte Zeilen (zu wenig Felder, leer) werden übersprungen."""
    out = []
    for line in str(text or '').splitlines():
        teile = [t.strip() for t in line.split(';')]
        if len(teile) < 3 or not all(teile[:3]):
            continue
        out.append(tuple(t[:160] for t in teile[:5] if t))
    return out


def runde(n, eig=(), nur_eigene=False, rnd=random):
    """n zufällige Fragen mit gemischten Antworten: [{'f', 'a': [...], 'r': Index der richtigen}]."""
    pool = list(eig) if (eig and nur_eigene) else list(FRAGEN) + list(eig)
    rnd.shuffle(pool)
    out = []
    for q in pool[:max(1, n)]:
        a = list(q[1:])
        richtig = a[0]
        rnd.shuffle(a)
        out.append({'f': q[0], 'a': a, 'r': a.index(richtig)})
    return out


PAGE = r"""<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>Filmquiz</title>
<style>
:root{--bg:#0f141b;--fg:#e8edf3;--mut:#93a1b3;--card:#18202b;--acc:#4da3ff;--ok:#2e9d62;--bad:#d9534f}
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:var(--bg);color:var(--fg);font:clamp(17px,2.8vmin,30px)/1.4 system-ui,sans-serif;display:flex;justify-content:center;padding:14px;-webkit-user-select:none;user-select:none}
main{width:min(96vw,960px)}header{display:flex;gap:14px;align-items:center;color:var(--mut)}header b{color:var(--fg)}header span:first-child{flex:1}
#bar{height:8px;background:var(--card);border-radius:4px;margin:10px 0;overflow:hidden}#bar i{display:block;height:100%;background:var(--acc);width:100%;transition:width .2s linear}
h1{font-size:1.35em;margin:.6em 0 .8em;min-height:2.6em}
#ans{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:560px){#ans{grid-template-columns:1fr}}
button{font:inherit;color:var(--fg);background:var(--card);border:4px solid transparent;border-radius:16px;padding:.9em 1em;text-align:left;cursor:pointer;min-height:3.2em}
button.f{border-color:var(--acc)}button.r{background:var(--ok)}button.w{background:var(--bad)}
#end{display:none;text-align:center;margin-top:8vh}#end b{display:block;font-size:2.4em;color:var(--acc)}#end button{text-align:center;margin-top:1em}
small{color:var(--mut)}
</style></head><body><main>
<header><span id="pr">Frage 0/0</span><span>Punkte: <b id="sc">0</b></span><span id="bs"></span></header>
<div id="bar"><i id="bi"></i></div>
<div id="q"><h1 id="fr"></h1><div id="ans"></div><p><small id="hint">Pfeiltasten + OK, Zifferntasten 1-4 oder antippen</small></p></div>
<div id="end"><h1 id="et"></h1><b id="es"></b><p id="er"></p><button id="again">Nochmal (OK)</button></div>
</main><script>
"use strict";
const $=(s)=>document.querySelector(s);
let Q=[],i=0,score=0,right=0,sel=0,locked=false,t0=0,TIME=15,timer=null,best=null,finished=false;
async function boot(){try{const r=await (await fetch('fragen')).json();Q=r.fragen;TIME=r.zeit||15}catch(e){$('#fr').textContent='Fragen konnten nicht geladen werden.';return}
  try{const b=await (await fetch('punkte')).json();best=b.quiz==null?null:b.quiz}catch(e){}
  $('#bs').textContent=best==null?'':'Rekord: '+best;i=0;score=0;right=0;finished=false;$('#end').style.display='none';$('#q').style.display='block';ask()}
function ask(){if(i>=Q.length)return done();const q=Q[i];locked=false;sel=0;$('#pr').textContent='Frage '+(i+1)+'/'+Q.length;$('#sc').textContent=score;$('#fr').textContent=q.f;
  const a=$('#ans');a.textContent='';q.a.forEach((t,k)=>{const b=document.createElement('button');b.textContent=(k+1)+'  '+t;b.onclick=()=>{sel=k;pick()};a.appendChild(b)});mark();
  t0=Date.now();clearInterval(timer);timer=setInterval(tickBar,100);tickBar()}
function left(){return Math.max(0,TIME-(Date.now()-t0)/1000)}
function tickBar(){const l=left();$('#bi').style.width=(100*l/TIME)+'%';if(l<=0&&!locked){locked=true;clearInterval(timer);reveal(-1)}}
function mark(){document.querySelectorAll('#ans button').forEach((b,k)=>b.classList.toggle('f',k===sel))}
function pick(){if(locked)return;locked=true;clearInterval(timer);const q=Q[i];const ok=sel===q.r;if(ok){score+=100+Math.round(50*left()/TIME);right++}reveal(sel)}
function reveal(k){const q=Q[i],bs=document.querySelectorAll('#ans button');bs[q.r].classList.add('r');if(k>=0&&k!==q.r)bs[k].classList.add('w');$('#sc').textContent=score;
  $('#hint').textContent=k===-1?'Zeit abgelaufen - OK für die nächste Frage':(k===q.r?'Richtig! OK für die nächste Frage':'Leider falsch - OK für die nächste Frage');setTimeout(()=>{if(locked&&!finished&&Q[i]===q)next()},1600)}
function next(){i++;$('#hint').textContent='Pfeiltasten + OK, Zifferntasten 1-4 oder antippen';ask()}
async function done(){finished=true;clearInterval(timer);$('#q').style.display='none';$('#end').style.display='block';$('#et').textContent=right+' von '+Q.length+' richtig';$('#es').textContent=score+' Punkte';
  try{const b=await (await fetch('punkte',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({wert:score})})).json();const neu=best==null||score>best;best=b.quiz;$('#er').textContent=neu?'🏆 Neuer Rekord!':'Rekord: '+best}catch(e){}
  $('#again').classList.add('f')}
document.addEventListener('keydown',e=>{const k=e.key;
  if(finished){if(k==='Enter'||k===' '){e.preventDefault();boot()}return}
  if(k>='1'&&k<='4'&&!locked&&Q[i]&&+k<=Q[i].a.length){sel=+k-1;mark();pick();return}
  if(k==='Enter'||k===' '||k==='Select'){e.preventDefault();if(locked){next_();}else pick();return}
  if(locked)return;const n=Q[i].a.length;
  if(k==='ArrowRight'||k==='ArrowLeft'){e.preventDefault();const t=sel^1;if(t<n)sel=t;mark()}
  else if(k==='ArrowDown'||k==='ArrowUp'){e.preventDefault();const t=(sel+2)%4;if(t<n)sel=t;else sel=(sel+1)%n;mark()}});
function next_(){if(locked&&!finished)next()}
$('#again').onclick=boot;
window.QZ={state:()=>({i,score,right,sel,locked,finished,n:Q.length})};
boot();
</script></body></html>"""


def register(api):
    global _api
    _api = api

    def fragen(req):
        n = int(api.get('anzahl') or 10)
        return {'fragen': runde(n, eigene(api.get('eigene')), bool(api.get('nur_eigene'))), 'zeit': int(api.get('zeit') or 15)}

    def punkte(req):
        if req.method == 'POST':
            d = req.json if isinstance(req.json, dict) else {}
            try:
                wert = int(d.get('wert'))
            except (TypeError, ValueError):
                return ({'error': 'Wert fehlt'}, 400)
            if wert < 0 or wert > 1_000_000:
                return ({'error': 'Ungültiger Wert'}, 400)
            with _lock:
                b = api.get('rekorde', {})
                b = b if isinstance(b, dict) else {}
                if wert > b.get('quiz', -1):
                    b['quiz'] = wert
                    api.set('rekorde', b)
                return b
        b = api.get('rekorde', {})
        return b if isinstance(b, dict) else {}

    def widget():
        b = punkte(type('R', (), {'method': 'GET', 'json': {}})())
        return {'icon': '🎬', 'text': 'Filmquiz', 'sub': ('Rekord: %d Punkte' % b['quiz']) if 'quiz' in b else 'Teste dein Kinowissen'}

    api.route('index', lambda req: PAGE)
    api.route('fragen', fragen)
    api.route('punkte', punkte)
    api.widget('Filmquiz', widget, ttl=60, icon='🎬')
'''},
    {'id': 'nachrichten', 'file': 'nachrichten.py', 'title': 'Nachrichten & Podcasts',
     'description': 'RSS-Reader: Kachel mit Schlagzeilen, Leseseite und abspielbare Podcasts/Videos aus beliebigen Feeds.',
     'code': r'''# -*- coding: utf-8 -*-
"""Nachrichten & Podcasts: liest RSS-/Atom-Feeds (Nachrichten, Blogs, Podcasts, Video-Podcasts).

So geht es: In den Einstellungen unter „Feeds“ pro Zeile  Name; Adresse  eintragen. Beispiel:
    Tagesschau; https://www.tagesschau.de/index~rss2.xml
Dann gibt es
  - eine Kachel „Schlagzeile“ auf der Startseite (und im Bildschirmschoner) mit den neuesten Meldungen,
  - die Seite „Nachrichten lesen“ (Erweiterungsliste -> Nachrichten) mit allen Meldungen zum Lesen,
  - den Menüpunkt „📰 Nachrichten“: Feeds mit Audio/Video (Podcasts, Videos der Tagesschau …) lassen sich direkt abspielen.
Es werden nur Adressen mit http:// oder https:// gelesen; pro Feed höchstens 2 MB.
"""
import html
import re
import time
import urllib.request
import xml.etree.ElementTree as ET

EXT_ID = 'nachrichten'
EXT_NAME = 'Nachrichten & Podcasts'
EXT_DESCRIPTION = 'RSS-Reader: Kachel mit Schlagzeilen, Leseseite und abspielbare Podcasts/Videos aus beliebigen Feeds.'
EXT_LINKS = [('Nachrichten lesen', 'index')]
EXT_SETTINGS = [
    {'key': 'feeds', 'label': 'Feeds (einer pro Zeile)', 'type': 'textarea',
     'default': 'Tagesschau; https://www.tagesschau.de/index~rss2.xml',
     'hint': 'Name; Adresse   - Nachrichten, Blogs oder Podcasts. Podcasts mit Audio/Video sind direkt abspielbar.'},
    {'key': 'anzahl', 'label': 'Meldungen pro Feed', 'type': 'number', 'default': 15, 'min': 3, 'max': 50},
    {'key': 'zeilen', 'label': 'Zeilen in der Kachel', 'type': 'number', 'default': 4, 'min': 1, 'max': 8},
]

MAX_BYTES = 2 * 1024 * 1024
_api = None
_cache = {}                       # url -> (zeit, [eintraege])
_TTL = 600
_TAG = re.compile(r'<[^>]+>')


def feeds(text):
    """'Name; URL' je Zeile -> [(name, url)]; Zeilen ohne http(s)-Adresse werden ignoriert."""
    out = []
    for line in str(text or '').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        name, _, url = line.rpartition(';')
        url = url.strip()
        if not re.match(r'https?://', url, re.I):
            continue
        out.append((name.strip() or re.sub(r'^https?://(www\.)?', '', url).split('/')[0], url))
    return out


def _clean(t, n=400):
    t = html.unescape(_TAG.sub(' ', str(t or '')))
    return re.sub(r'\s+', ' ', t).strip()[:n]


def _local(tag):
    return tag.rsplit('}', 1)[-1].lower()


def parse(data):
    """RSS 2.0 / Atom -> Liste von {title, link, desc, date, media, mtype, image}."""
    root = ET.fromstring(data)
    out = []
    for el in root.iter():
        if _local(el.tag) not in ('item', 'entry'):
            continue
        e = {'title': '', 'link': '', 'desc': '', 'date': '', 'media': '', 'mtype': '', 'image': ''}
        for c in el:
            t = _local(c.tag)
            txt = (c.text or '').strip()
            if t == 'title':
                e['title'] = _clean(txt, 200)
            elif t == 'link':
                e['link'] = c.get('href') or txt if not e['link'] else e['link']
                if c.get('rel') == 'enclosure' and c.get('href') and not e['media']:
                    e['media'], e['mtype'] = c.get('href'), (c.get('type') or '')
            elif t in ('description', 'summary', 'encoded') and (not e['desc'] or t == 'summary'):
                e['desc'] = _clean(txt)
            elif t in ('pubdate', 'updated', 'published', 'date'):
                e['date'] = e['date'] or txt
            elif t in ('enclosure', 'content') and c.get('url') and not e['media']:
                ty = c.get('type') or ''
                if t == 'enclosure' or ty.startswith(('audio', 'video')) or c.get('medium') in ('audio', 'video'):
                    e['media'], e['mtype'] = c.get('url'), ty
                elif ty.startswith('image') and not e['image']:
                    e['image'] = c.get('url')
            elif t == 'thumbnail' and c.get('url') and not e['image']:
                e['image'] = c.get('url')
        if e['media'] and not e['mtype'].startswith(('audio', 'video')):
            if not re.search(r'\.(mp3|m4a|aac|ogg|opus|mp4|m4v|webm|mov)(\?|$)', e['media'], re.I):
                if e['mtype'].startswith('image') and not e['image']:
                    e['image'] = e['media']
                e['media'], e['mtype'] = '', ''
        if e['title']:
            out.append(e)
    return out


def _fetch(url):
    c = _cache.get(url)
    if c and time.time() - c[0] < _TTL:
        return c[1]
    req = urllib.request.Request(url, headers={'User-Agent': 'MovieScout/1.0 (RSS)', 'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml, */*'})
    with urllib.request.urlopen(req, timeout=15) as r:
        data = r.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('Feed zu groß')
    items = parse(data)
    _cache[url] = (time.time(), items)
    return items


def alle():
    """[(feedname, eintrag)] - neueste Feeds zuerst in Reihenfolge der Einstellung; Fehler pro Feed als eintrag mit 'fehler'."""
    n = max(1, int(_api.get('anzahl') or 15))
    res, errs = [], []
    for name, url in feeds(_api.get('feeds')):
        try:
            res.extend((name, e) for e in _fetch(url)[:n])
        except Exception as ex:                       # noqa: BLE001 - ein toter Feed darf die anderen nicht stoppen
            errs.append('%s: %s' % (name, str(ex)[:80]))
    return res, errs


def playable(name, e):
    return {'title': e['title'], 'provider_id': 'm3u_iptv', 'url': e['media'], 'next_func': 'get_hosters', 'is_playable': True,
            'kind': 'play', 'plot': (e['desc'] + '\n' if e['desc'] else '') + name, 'poster': e['image'], 'parent_title': name}


def register(api):
    global _api
    _api = api

    def menu():
        res, errs = alle()
        items = [playable(n, e) for n, e in res if e['media']]
        if not items:
            api.fail('Keine abspielbaren Beiträge. ' + ('; '.join(errs) if errs else
                     'Trage in den Einstellungen Podcast- oder Video-Feeds ein (Seite „Nachrichten lesen“ zeigt Textmeldungen).'))
        return items

    def widget():
        res, errs = alle()
        if not res:
            return {'icon': '📰', 'text': '', 'sub': errs[0] if errs else 'Keine Feeds eingetragen'} if (errs or not feeds(api.get('feeds'))) else None
        n = max(1, int(api.get('zeilen') or 4))
        return {'icon': '📰', 'text': res[0][1]['title'][:40], 'sub': res[0][0], 'lines': [e['title'] for _, e in res[1:n]]}

    def seite(req):
        res, errs = alle()
        rows = ''.join('<li><small>%s%s</small><br>%s%s</li>' % (
            html.escape(n), ' · ' + html.escape(e['date'][:25]) if e['date'] else '',
            ('<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>' % (html.escape(e['link'], quote=True), html.escape(e['title']))
             if re.match(r'https?://', e['link'] or '') else html.escape(e['title'])),
            ('<p>%s</p>' % html.escape(e['desc'])) if e['desc'] else '') for n, e in res)
        er = ''.join('<p class="e">⚠ %s</p>' % html.escape(x) for x in errs)
        return ('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                '<title>Nachrichten</title><style>body{font:18px system-ui;background:#10131a;color:#eee;max-width:760px;margin:auto;padding:16px}'
                'a{color:#8ab4ff}li{margin:0 0 18px;list-style:none}small{color:#9aa}p{margin:4px 0;color:#bbb}.e{color:#f99}ul{padding:0}</style>'
                '<h1>📰 Nachrichten</h1>%s<ul>%s</ul>%s' % (er, rows, '' if res else '<p>Keine Meldungen. Feeds in den Einstellungen eintragen.</p>'))

    api.menu('📰 Nachrichten', menu, ttl=300)
    api.widget('Schlagzeile', widget, ttl=900, id='schlagzeile', icon='📰')
    api.route('index', seite)
    api.route('probe', lambda req: {'n': len(alle()[0])})
'''},
    {'id': 'bilderrahmen', 'file': 'bilderrahmen.py', 'title': 'Bilderrahmen',
     'description': 'Eigene Fotos (Ordner oder Adressen) laufen im Bildschirmschoner mit.',
     'code': r'''# -*- coding: utf-8 -*-
"""Bilderrahmen: eigene Fotos im Bildschirmschoner (statt oder zusätzlich zu den Titelbildern).

So geht es: In den Einstellungen einen Ordner mit Fotos eintragen (Ordner auf dem Gerät, auf dem MovieScout läuft, z. B.
/home/ich/Bilder/Urlaub oder D:\\Fotos) und/oder Bildadressen (https://…), eine pro Zeile. Der Bildschirmschoner mischt diese
Bilder unter die Titelbilder.
Die Seite „Alle Bilder ansehen“ zeigt eine Übersicht. Nur Dateien .jpg .jpeg .png .gif .webp bis 15 MB aus genau diesem Ordner werden ausgeliefert.
"""
import html
import os
import random
import re

EXT_ID = 'bilderrahmen'
EXT_NAME = 'Bilderrahmen'
EXT_DESCRIPTION = 'Eigene Fotos (Ordner oder Adressen) laufen im Bildschirmschoner mit.'
EXT_LINKS = [('Alle Bilder ansehen', 'index')]
EXT_SETTINGS = [
    {'key': 'ordner', 'label': 'Foto-Ordner', 'type': 'text', 'default': '', 'hint': 'Ordner auf dem Gerät mit der Engine (Unterordner werden mitgelesen).'},
    {'key': 'adressen', 'label': 'Bildadressen (eine pro Zeile)', 'type': 'textarea', 'default': ''},
    {'key': 'anzahl', 'label': 'Bilder pro Durchgang', 'type': 'number', 'default': 25, 'min': 5, 'max': 40},
]

EXT = ('.jpg', '.jpeg', '.png', '.gif', '.webp')
MAX_FILE = 15 * 1024 * 1024
_api = None


def dateien():
    root = str(_api.get('ordner') or '').strip()
    out = []
    if root and os.path.isdir(root):
        root = os.path.realpath(root)
        for d, _dirs, files in os.walk(root):
            for f in files:
                if f.lower().endswith(EXT):
                    out.append(os.path.relpath(os.path.join(d, f), root).replace(os.sep, '/'))
            if len(out) > 5000:
                break
    return sorted(out)


def adressen():
    return [u.strip() for u in str(_api.get('adressen') or '').splitlines() if re.match(r'https?://', u.strip(), re.I)]


def lesen(rel):
    """Datei aus dem Foto-Ordner lesen; None, wenn nicht erlaubt (Pfad außerhalb, falscher Typ, zu groß)."""
    root = str(_api.get('ordner') or '').strip()
    if not root or not rel or not rel.lower().endswith(EXT):
        return None
    root = os.path.realpath(root)
    p = os.path.realpath(os.path.join(root, rel))
    if os.path.commonpath([root, p]) != root or not os.path.isfile(p) or os.path.getsize(p) > MAX_FILE:
        return None
    with open(p, 'rb') as fh:
        return fh.read()


def register(api):
    global _api
    _api = api

    def widget():
        n = max(5, int(api.get('anzahl') or 25))
        pool = ['/api/x/%s/bild?f=%s' % (EXT_ID, __import__('urllib.parse').parse.quote(f)) for f in dateien()] + adressen()
        if not pool:
            return None
        random.shuffle(pool)
        return {'bilder': pool[:n]}

    def bild(req):
        data = lesen(req.query.get('f', ''))
        if data is None:
            return ({'error': 'Bild nicht gefunden'}, 404)
        return data

    def seite(req):
        from urllib.parse import quote
        fs = dateien()
        imgs = ['/api/x/%s/bild?f=%s' % (EXT_ID, quote(f)) for f in fs[:300]] + adressen()
        tok = req.query.get('token', '')
        suffix = ('&token=' + quote(tok)) if tok else ''
        cells = ''.join('<img loading="lazy" src="%s%s">' % (html.escape(u, quote=True), suffix if u.startswith('/api/') else '') for u in imgs)
        return ('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                '<title>Bilder</title><style>body{background:#10131a;color:#eee;font:18px system-ui;margin:0;padding:12px}'
                'div{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px}img{width:100%%;height:140px;object-fit:cover;border-radius:6px}</style>'
                '<h1>🖼️ Bilderrahmen</h1><p>%d Bilder</p><div>%s</div>' % (len(imgs), cells))

    api.widget('Bilder', widget, ttl=600, id='bilder', icon='🖼️')
    api.route('bild', bild)
    api.route('index', seite)
    api.route('probe', lambda req: {'n': len(dateien()) + len(adressen())})
'''},
    {'id': 'kuechentimer', 'file': 'kuechentimer.py', 'title': 'Küchen-Timer',
     'description': 'Mehrere Timer mit Kachel und Alarm im Familienchat - von jedem Gerät bedienbar.',
     'code': r'''# -*- coding: utf-8 -*-
"""Küchen-Timer: mehrere Timer für alle Geräte im Haus, mit Alarm im Familienchat.

So geht es: Erweiterungsliste -> Küchen-Timer -> „Timer öffnen“. Dort ein Preset antippen (Ei, Nudeln, Tee …) oder eigene Minuten
eintippen. Laufende Timer erscheinen als Kachel auf der Startseite (und im Bildschirmschoner). Ist ein Timer abgelaufen,
schreibt MovieScout eine Nachricht in den Familienchat und die geöffnete Seite piept. Timer überleben einen Neustart.
"""
import html
import threading
import time
import uuid

EXT_ID = 'kuechentimer'
EXT_NAME = 'Küchen-Timer'
EXT_DESCRIPTION = 'Mehrere Timer mit Kachel und Alarm im Familienchat - von jedem Gerät bedienbar.'
EXT_LINKS = [('Timer öffnen', 'index')]
EXT_SETTINGS = [
    {'key': 'chat', 'label': 'Alarm in den Familienchat schreiben', 'type': 'bool', 'default': True},
    {'key': 'presets', 'label': 'Presets (Name; Minuten, eine pro Zeile)', 'type': 'textarea',
     'default': 'Ei weich; 5\nEi hart; 9\nNudeln; 10\nTee; 4\nPizza; 12'},
]

MAX_MIN = 24 * 60
_api = None
_lock = threading.Lock()
_timers = {}                      # id -> threading.Timer


def presets(text):
    out = []
    for line in str(text or '').splitlines():
        name, _, m = line.rpartition(';')
        try:
            m = float(m.strip().replace(',', '.'))
        except ValueError:
            continue
        if 0 < m <= MAX_MIN:
            out.append((name.strip() or '%g min' % m, m))
    return out


def liste():
    rows = _api.get('timer', [])
    return rows if isinstance(rows, list) else []


def _speichern(rows):
    _api.set('timer', rows)


def _fertig(tid):
    with _lock:
        rows = liste()
        hit = next((r for r in rows if r['id'] == tid and not r.get('fertig')), None)
        if not hit:
            return
        hit['fertig'] = True
        _speichern(rows)
        _timers.pop(tid, None)
    if _api.get('chat') is not False:
        try:
            _api.chat('⏰ %s ist fertig!' % hit['name'])
        except Exception:                             # noqa: BLE001 - Chat darf den Timer nicht kaputtmachen
            pass


def _plane(r):
    rest = r['ende'] - time.time()
    t = threading.Timer(max(0, rest), _fertig, args=(r['id'],))
    t.daemon = True
    _timers[r['id']] = t
    t.start()


def starten(name, minuten):
    try:
        m = float(str(minuten).replace(',', '.'))
    except ValueError:
        return None
    if not 0 < m <= MAX_MIN:
        return None
    r = {'id': uuid.uuid4().hex[:8], 'name': str(name or '').strip()[:40] or '%g min' % m, 'ende': time.time() + m * 60, 'fertig': False}
    with _lock:
        rows = [x for x in liste() if not x.get('fertig') or time.time() - x['ende'] < 3600][-19:]
        rows.append(r)
        _speichern(rows)
        _plane(r)
    return r


def stoppen(tid):
    with _lock:
        rows = liste()
        keep = [r for r in rows if r['id'] != tid]
        t = _timers.pop(tid, None)
        if t:
            t.cancel()
        _speichern(keep)
        return len(keep) != len(rows)


def fmt(sek):
    sek = max(0, int(sek))
    return '%d:%02d:%02d' % (sek // 3600, sek % 3600 // 60, sek % 60) if sek >= 3600 else '%d:%02d' % (sek // 60, sek % 60)


_PAGE = """<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Küchen-Timer</title>
<style>body{font:20px system-ui;background:#10131a;color:#eee;max-width:640px;margin:auto;padding:16px}
button{font:inherit;padding:14px 18px;margin:4px;border:0;border-radius:10px;background:#2a3350;color:#fff}button:focus,button:hover{outline:3px solid #8ab4ff}
.t{display:flex;justify-content:space-between;align-items:center;background:#1b2133;border-radius:10px;padding:10px 14px;margin:8px 0}
.t b{font-size:1.6em}.f{background:#5a2330}input{font:inherit;padding:12px;width:5em;border-radius:8px;border:0}</style>
<h1>⏲️ Küchen-Timer</h1><div id="p">__PRESETS__</div>
<p><input id="n" type="number" min="1" step="any" placeholder="Min"> <button onclick="go('',n.value)">Starten</button></p><div id="l"></div>
<script>
const B=location.pathname.replace(/\\/index$/,'/')+'';const Q=location.search;let T=[],off=0,piep={};
function url(p){return B+p+Q+(Q?'&':'?')+'_=1'}
function go(name,m){if(!(+m>0))return;fetch(url('start'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,minuten:+m})}).then(load)}
function stop(id){fetch(url('stop'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})}).then(load)}
function f(s){s=Math.max(0,s|0);const h=s/3600|0,m=s%3600/60|0,x=s%60;return(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(x).padStart(2,'0')}
function beep(){try{const c=new AudioContext();[0,.3,.6].forEach(t=>{const o=c.createOscillator();o.connect(c.destination);o.frequency.value=880;o.start(c.currentTime+t);o.stop(c.currentTime+t+.2)})}catch(e){}}
function load(){fetch(url('liste')).then(r=>r.json()).then(j=>{T=j.timer;off=j.jetzt-Date.now()/1000;draw()})}
function draw(){const now=Date.now()/1000+off;l.innerHTML='';T.forEach(t=>{const r=t.ende-now,d=r<=0;if(d&&!piep[t.id]){piep[t.id]=1;beep()}
const e=document.createElement('div');e.className='t'+(d?' f':'');e.innerHTML='<span></span><b></b><button>✕</button>';e.children[0].textContent=t.name;e.children[1].textContent=d?'Fertig!':f(r);e.children[2].onclick=()=>stop(t.id);l.append(e)})}
load();setInterval(draw,1000);setInterval(load,15000);
</script>"""


def register(api):
    global _api
    _api = api
    for r in liste():                                 # nach einem Neustart weiterlaufen lassen
        if not r.get('fertig'):
            _plane(r)

    def seite(req):
        btn = ''.join('<button onclick="go(%s,%g)">%s · %g min</button>' % (
            html.escape(repr(n), quote=True), m, html.escape(n), m) for n, m in presets(api.get('presets')))
        return _PAGE.replace('__PRESETS__', btn)

    def _post(req):
        try:
            return req.json or {}
        except Exception:                             # noqa: BLE001
            return {}

    def start(req):
        j = _post(req)
        r = starten(j.get('name'), j.get('minuten'))
        return ({'ok': True, 'timer': r}, 200) if r else ({'error': 'Ungültige Minuten'}, 400)

    def stop(req):
        return {'ok': stoppen(str(_post(req).get('id') or ''))}

    def liste_route(req):
        return {'timer': liste(), 'jetzt': time.time()}

    def widget():
        run = sorted((r for r in liste() if not r.get('fertig') and r['ende'] > time.time()), key=lambda r: r['ende'])
        if not run:
            return None
        return {'icon': '⏲️', 'text': '%s %s' % (run[0]['name'][:20], fmt(run[0]['ende'] - time.time())),
                'sub': '%d Timer läuft' % len(run) if len(run) == 1 else '%d Timer laufen' % len(run),
                'lines': ['%s %s' % (r['name'], fmt(r['ende'] - time.time())) for r in run[1:5]]}

    api.route('index', seite)
    api.route('start', start)
    api.route('stop', stop)
    api.route('liste', liste_route)
    api.widget('Timer', widget, ttl=20, id='timer', icon='⏲️')
'''},
    {'id': 'solitaire', 'file': 'solitaire.py', 'title': 'Solitaire',
     'description': 'Klondike-Solitaire für Fernbedienung und Touch, mit Rückgängig und Bestwerten.',
     'code': r'''# -*- coding: utf-8 -*-
"""Solitaire (Klondike): Karten-Patience für Fernbedienung und Touch - mit Rückgängig, Auto-Ablage und Bestwerten.

Öffnen: Erweiterungsliste -> Solitaire -> „Solitaire öffnen“.
Touch:          Stapel antippen = ziehen · Karte antippen = aufnehmen, dann Ziel antippen · dieselbe Karte nochmal = auf die Ablage
Fernbedienung:  Pfeile = Cursor · OK = ziehen / aufnehmen / ablegen · Hoch/Runter in einer Spalte = mehrere Karten wählen
                Zurück = Aufnahme abbrechen · Knopfzeile ganz oben: Rückgängig, Auto, Neu
Tastatur:       Z = rückgängig · A = Auto-Ablage · N = neues Spiel
In den Einstellungen: 1 oder 3 Karten ziehen. Nicht jedes Blatt ist lösbar - dafür gibt es „Neu“.
"""
import threading

EXT_ID = 'solitaire'
EXT_NAME = 'Solitaire'
EXT_DESCRIPTION = 'Klondike-Solitaire für Fernbedienung und Touch, mit Rückgängig und Bestwerten.'
EXT_LINKS = [('Solitaire öffnen', 'index')]
EXT_SETTINGS = [
    {'key': 'ziehen', 'label': 'Karten pro Zug vom Stapel', 'type': 'select', 'default': '1', 'options': [['1', 'Eine Karte (leichter)'], ['3', 'Drei Karten (klassisch)']]},
]
_api = None
_lock = threading.Lock()

PAGE = r"""<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="ms-game"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>Solitaire</title>
<style>
:root{--bg:#0d2a1f;--fg:#e8f3ec;--mut:#8fb5a1;--card:#143a2b;--acc:#ffd54f}
*{box-sizing:border-box}html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--fg);font:clamp(14px,2.4vmin,22px)/1.3 system-ui,sans-serif;display:flex;flex-direction:column;overflow:hidden;-webkit-user-select:none;user-select:none;overscroll-behavior:none}
#bar{display:flex;gap:8px;align-items:center;padding:6px 10px;flex:none;padding-right:64px}
#bar button{font:inherit;color:var(--fg);background:var(--card);border:3px solid transparent;border-radius:12px;padding:.35em .8em;cursor:pointer}
#bar button.f,#bar button:focus{outline:none;border-color:var(--acc)}
#info{margin-left:auto;color:var(--mut)}
#bar button{white-space:nowrap}@media (max-width:480px){#bar{gap:5px;padding-left:6px}#bar button{padding:.3em .5em}#info{font-size:.8em;white-space:nowrap}}
#cvw{position:relative;flex:1;min-height:0;touch-action:none}
canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
#msg{position:absolute;inset:0;display:none;place-items:center;text-align:center;background:rgba(3,15,10,.82);padding:14px;font-size:1.3em}
#msg.on{display:grid}#msg small{display:block;color:var(--mut);margin-top:.5em}
#msg button{font:inherit;margin-top:1em;color:#0d2a1f;background:var(--acc);border:0;border-radius:12px;padding:.5em 1.2em}
</style></head><body>
<div id="bar"><button id="bu" data-a="undo">↶ Zurück</button><button id="ba" data-a="auto">⚡ Auto</button><button id="bn" data-a="new">🔄 Neu</button><span id="info"></span></div>
<div id="cvw"><canvas id="cv"></canvas><div id="msg"></div></div>
<script>
"use strict";
const $=(s)=>document.querySelector(s);
const SUIT='♠♣♥♦',RANK=['','A','2','3','4','5','6','7','8','9','10','J','Q','K'];
const red=(c)=>c.s>=2;
/* ---------- Spiellogik (rein, ohne Oberfläche) ---------- */
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function deck(){const d=[];for(let s=0;s<4;s++)for(let r=1;r<=13;r++)d.push({r,s,up:false});return d}
function shuffle(d,rnd){for(let i=d.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[d[i],d[j]]=[d[j],d[i]]}return d}
function deal(rnd,draw){const d=shuffle(deck(),rnd);const g={tab:[],found:[[],[],[],[]],stock:[],waste:[],draw:draw===3?3:1,moves:0,won:false};
  for(let i=0;i<7;i++){const p=[];for(let j=0;j<=i;j++){const c=d.pop();c.up=j===i;p.push(c)}g.tab.push(p)}g.stock=d;return g}
function canTab(c,p){if(!p.length)return c.r===13;const t=p[p.length-1];return t.up&&t.r===c.r+1&&red(t)!==red(c)}
function canFound(g,c){return g.found[c.s].length===c.r-1}
function cardsFrom(g,f){
  if(f.t==='waste')return g.waste.length?[g.waste[g.waste.length-1]]:null;
  if(f.t==='found'){const p=g.found[f.i];return p.length?[p[p.length-1]]:null}
  if(f.t==='tab'){const p=g.tab[f.i],k=f.k||1;if(!p||k<1||k>p.length)return null;const cs=p.slice(p.length-k);return cs.every((c)=>c.up)?cs:null}
  return null}
function legal(g,f,to){const cs=cardsFrom(g,f);if(!cs)return false;
  if(to.t==='found')return cs.length===1&&f.t!=='found'&&canFound(g,cs[0]);
  if(to.t==='tab'){if(f.t==='tab'&&f.i===to.i)return false;return canTab(cs[0],g.tab[to.i])}
  return false}
function doMove(g,f,to){if(!legal(g,f,to))return false;const cs=cardsFrom(g,f);
  if(f.t==='waste')g.waste.pop();else if(f.t==='found')g.found[f.i].pop();
  else{const p=g.tab[f.i];p.splice(p.length-cs.length,cs.length);if(p.length&&!p[p.length-1].up)p[p.length-1].up=true}
  if(to.t==='found')g.found[cs[0].s].push(cs[0]);else g.tab[to.i].push(...cs);
  g.moves++;g.won=g.found.every((p)=>p.length===13);return true}
function drawStock(g){
  if(g.stock.length){for(let n=0;n<g.draw&&g.stock.length;n++){const c=g.stock.pop();c.up=true;g.waste.push(c)}}
  else if(g.waste.length){while(g.waste.length){const c=g.waste.pop();c.up=false;g.stock.push(c)}}
  else return false;
  g.moves++;return true}
function autoOne(g){const src=[{t:'waste'}];for(let i=0;i<7;i++)src.push({t:'tab',i,k:1});
  for(const f of src){const cs=cardsFrom(g,f);if(cs&&canFound(g,cs[0])){doMove(g,f,{t:'found',i:cs[0].s});return true}}return false}
/* ---------- Oberfläche ---------- */
let g=null,hist=[],held=null,cur={row:1,col:0,k:1},t0=0,tEnd=0,cfgDraw=1,reported=false,seed=null,flash=0;
const cv=$('#cv'),x=cv.getContext('2d');let L={};
function maxK(i){const p=g.tab[i];let k=0;for(let j=p.length-1;j>=0&&p[j].up;j--)k++;return k}
function snap(){hist.push(JSON.stringify(g));if(hist.length>300)hist.shift()}
function newGame(sd,draw){seed=sd==null?Math.floor(Math.random()*4294967296):sd;g=deal(mulberry(seed),draw||cfgDraw);hist=[];held=null;cur={row:1,col:0,k:1};t0=0;tEnd=0;reported=false;$('#msg').classList.remove('on');layout();paint()}
function started(){if(!t0)t0=Date.now()}
function act(fn){snap();started();if(!fn()){hist.pop();flash=Date.now();paint();return false}held=null;after();return true}
function after(){if(g.won&&!tEnd){tEnd=Date.now();win()}paint()}
function undo(){if(!hist.length||g.won)return;const s=JSON.parse(hist.pop());g=s;held=null;paint()}
function autoAll(){snap();started();let n=0;while(autoOne(g)&&!g.won)n++;if(g.won)n++;if(!n){hist.pop();flash=Date.now()}held=null;after()}
function secs(){return t0?Math.floor(((tEnd||Date.now())-t0)/1000):0}
function fmt(s){return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
async function win(){const s=secs();$('#msg').innerHTML='🎉 Gewonnen!<small>'+g.moves+' Züge · '+fmt(s)+'</small><button id="bw">Neues Spiel</button>';$('#msg').classList.add('on');$('#bw').onclick=()=>newGame();
  if(!reported){reported=true;try{await fetch('punkte',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({zuege:g.moves,sekunden:s})})}catch(e){}}}
/* Layout: alle Maße aus der Fensterbreite/-höhe */
function layout(){const r=$('#cvw').getBoundingClientRect(),dpr=window.devicePixelRatio||1;cv.width=Math.round(r.width*dpr);cv.height=Math.round(r.height*dpr);x.setTransform(dpr,0,0,dpr,0,0);
  const W=r.width,H=r.height;let ch=Math.min(W/7.9*1.4,H/3.9),cw=ch/1.4;const gap=cw*.12,tw=7*cw+6*gap,ox=(W-tw)/2,oy=Math.max(4,cw*.08);
  L={W,H,cw,ch,gap,ox,oy,ty:oy+ch+gap*1.5,colX:(i)=>ox+i*(cw+gap)}}
function offsets(p){const avail=L.H-L.ty-L.ch-4;let d=0,u=0;for(let i=0;i<p.length-1;i++)p[i].up?u++:d++;
  let dd=L.ch*.16,du=L.ch*.3;const need=d*dd+u*du;if(need>avail&&need>0){const f=Math.max(.35,avail/need);dd*=f;du*=f}
  const o=[];let y=0;for(let i=0;i<p.length;i++){o.push(y);y+=p[i].up?du:dd}return o}
/* Rechtecke aller Stellen, zum Zeichnen und für Berührungen */
function rects(){const R=[];R.push({t:'stock',x:L.colX(0),y:L.oy,w:L.cw,h:L.ch});R.push({t:'waste',x:L.colX(1),y:L.oy,w:L.cw,h:L.ch});
  for(let i=0;i<4;i++)R.push({t:'found',i,x:L.colX(3+i),y:L.oy,w:L.cw,h:L.ch});
  for(let i=0;i<7;i++){const p=g.tab[i],o=offsets(p);R.push({t:'tab',i,x:L.colX(i),y:L.ty,w:L.cw,h:p.length?o[p.length-1]+L.ch:L.ch,o});}
  return R}
function rr(px,py,w,h,r){x.beginPath();x.moveTo(px+r,py);x.arcTo(px+w,py,px+w,py+h,r);x.arcTo(px+w,py+h,px,py+h,r);x.arcTo(px,py+h,px,py,r);x.arcTo(px,py,px+w,py,r);x.closePath()}
function drawCard(c,px,py,sel){const w=L.cw,h=L.ch,r=w*.1;
  if(!c.up){rr(px,py,w,h,r);x.fillStyle='#1d4f8f';x.fill();x.strokeStyle='#0c2a52';x.lineWidth=2;x.stroke();rr(px+w*.1,py+w*.1,w*.8,h-w*.2,r*.6);x.strokeStyle='rgba(255,255,255,.35)';x.lineWidth=1.5;x.stroke();return}
  rr(px,py,w,h,r);x.fillStyle=sel?'#fff6c8':'#f6f4ee';x.fill();x.strokeStyle='#222';x.lineWidth=1.5;x.stroke();
  x.fillStyle=red(c)?'#c62828':'#1b1b1b';x.textBaseline='top';x.textAlign='left';x.font='bold '+Math.round(w*.3)+'px system-ui,sans-serif';
  x.fillText(RANK[c.r]+SUIT[c.s],px+w*.07,py+w*.05);
  x.textAlign='center';x.textBaseline='middle';x.font=Math.round(w*.55)+'px system-ui,sans-serif';x.fillText(SUIT[c.s],px+w/2,py+h*.62)}
function slot(px,py,label){rr(px,py,L.cw,L.ch,L.cw*.1);x.strokeStyle='rgba(255,255,255,.25)';x.lineWidth=2;x.stroke();if(label){x.fillStyle='rgba(255,255,255,.3)';x.textAlign='center';x.textBaseline='middle';x.font=Math.round(L.cw*.5)+'px system-ui,sans-serif';x.fillText(label,px+L.cw/2,py+L.ch/2)}}
function isHeld(f){return held&&held.t===f.t&&(held.i===undefined||held.i===f.i)}
function paint(){if(!g)return;x.clearRect(0,0,L.W,L.H);
  slot(L.colX(0),L.oy,g.waste.length?'↻':'');if(g.stock.length)drawCard({up:false},L.colX(0),L.oy);
  slot(L.colX(1),L.oy);if(g.waste.length){const n=Math.min(g.draw,g.waste.length);for(let j=0;j<n;j++){const c=g.waste[g.waste.length-n+j];const sh=(n>1?j*L.cw*.22:0);drawCard(c,L.colX(1)+sh,L.oy,held&&held.t==='waste'&&j===n-1)}}
  for(let i=0;i<4;i++){slot(L.colX(3+i),L.oy,SUIT[i]);const p=g.found[i];if(p.length)drawCard(p[p.length-1],L.colX(3+i),L.oy,held&&held.t==='found'&&held.i===i)}
  for(let i=0;i<7;i++){const p=g.tab[i],o=offsets(p);if(!p.length)slot(L.colX(i),L.ty,'K');
    p.forEach((c,j)=>{const sel=held&&held.t==='tab'&&held.i===i&&j>=p.length-held.k;drawCard(c,L.colX(i),L.ty+o[j]-(sel?L.ch*.06:0),sel)})}
  cursorBox();if(Date.now()-flash<400)setTimeout(paint,420);$('#info').textContent='Züge '+g.moves+' · '+fmt(secs())+(g.draw===3?' · 3er':'');
  document.querySelectorAll('#bar button').forEach((b)=>b.classList.remove('f'));if(cur.row===-1)document.querySelectorAll('#bar button')[cur.col].classList.add('f')}
function cursorBox(){if(cur.row===-1)return;let px,py,w=L.cw,h=L.ch;
  if(cur.row===0){px=L.colX(cur.col);py=L.oy}
  else{const p=g.tab[cur.col],o=offsets(p);px=L.colX(cur.col);const k=Math.min(cur.k,Math.max(1,p.length));if(p.length){const j=p.length-k;py=L.ty+o[j];h=o[p.length-1]-o[j]+L.ch}else py=L.ty}
  x.strokeStyle=Date.now()-flash<400?'#ff5252':'#ffd54f';x.lineWidth=4;rr(px-3,py-3,w+6,h+6,L.cw*.12);x.stroke()}
/* Bedienung */
function whereCursor(){if(cur.row===0){if(cur.col===0)return{t:'stock'};if(cur.col===1)return{t:'waste'};if(cur.col>=3)return{t:'found',i:cur.col-3};return null}return{t:'tab',i:cur.col}}
function okAt(pos,k){
  if(pos.t==='stock'){held=null;act(()=>drawStock(g));return}
  if(!held){
    if(pos.t==='waste'&&g.waste.length)held={t:'waste'};
    else if(pos.t==='found'&&g.found[pos.i].length)held={t:'found',i:pos.i};
    else if(pos.t==='tab'){const p=g.tab[pos.i];if(p.length){const kk=Math.min(k||1,maxK(pos.i));if(kk>=1)held={t:'tab',i:pos.i,k:kk}}}
    if(!held)flash=Date.now();paint();return}
  const f=held;const same=(f.t===pos.t&&(pos.i===undefined||f.i===pos.i));
  if(same){const cs=cardsFrom(g,f);if(cs&&cs.length===1&&f.t!=='found'&&canFound(g,cs[0])){act(()=>doMove(g,f,{t:'found',i:cs[0].s}));return}held=null;paint();return}
  if(pos.t==='waste'){held=null;paint();return}
  if(!act(()=>doMove(g,f,pos))){held=null;paint()}}
function key(e){const k=e.key;
  if(k==='z'||k==='Z'){undo();e.preventDefault();return}if(k==='a'||k==='A'){autoAll();e.preventDefault();return}if(k==='n'||k==='N'){newGame();e.preventDefault();return}
  if(k==='Escape'||k==='Backspace'){if(held){held=null;paint();e.preventDefault()}return}
  if(!g||(g.won&&$('#msg').classList.contains('on'))){if(k==='Enter'||k===' '){newGame();e.preventDefault()}return}
  if(k==='ArrowLeft'||k==='ArrowRight'){const d=k==='ArrowLeft'?-1:1;const n=cur.row===-1?3:7;let c=cur.col+d;if(cur.row===0&&c===2)c+=d;if(c<0||c>=n)return;cur.col=c;cur.k=1;paint();e.preventDefault();return}
  if(k==='ArrowUp'){if(cur.row===1){const m=maxK(cur.col);if(cur.k<m)cur.k++;else{cur.row=0;if(cur.col===2)cur.col=1}}else if(cur.row===0){cur.row=-1;cur.col=Math.min(cur.col,2)}paint();e.preventDefault();return}
  if(k==='ArrowDown'){if(cur.row===-1){cur.row=0;cur.col=Math.min(cur.col,6);if(cur.col===2)cur.col=3}else if(cur.row===0){cur.row=1;cur.k=1}else if(cur.k>1)cur.k--;paint();e.preventDefault();return}
  if(k==='Enter'||k===' '){e.preventDefault();if(cur.row===-1){press(['undo','auto','new'][cur.col]);return}okAt(whereCursor(),cur.k)}}
function press(a){if(a==='undo')undo();else if(a==='auto')autoAll();else if(a==='new')newGame()}
document.addEventListener('keydown',key);
document.querySelectorAll('#bar button').forEach((b)=>b.addEventListener('click',()=>press(b.dataset.a)));
cv.addEventListener('pointerdown',(e)=>{if(!g||(g.won&&$('#msg').classList.contains('on')))return;const r=cv.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top;
  const R=rects();for(let n=R.length-1;n>=0;n--){const s=R[n];if(px<s.x||px>s.x+s.w||py<s.y||py>s.y+s.h)continue;
    if(s.t==='tab'){const p=g.tab[s.i];let idx=-1;for(let j=p.length-1;j>=0;j--){const top=L.ty+s.o[j];const h=j===p.length-1?L.ch:s.o[j+1]-s.o[j];if(py>=top&&py<=top+h){idx=j;break}}
      const k=idx>=0&&p[idx].up?p.length-idx:0;
      if(held&&held.t==='tab'&&held.i===s.i&&k>=1&&k!==held.k){held.k=k;cur={row:1,col:s.i,k};paint()}
      else if(held){cur={row:1,col:s.i,k:1};okAt({t:'tab',i:s.i})}
      else if(k>=1){cur={row:1,col:s.i,k};okAt({t:'tab',i:s.i},k)}}
    else{cur=s.t==='stock'?{row:0,col:0,k:1}:s.t==='waste'?{row:0,col:1,k:1}:{row:0,col:3+s.i,k:1};okAt(s.t==='found'?{t:'found',i:s.i}:{t:s.t},1)}
    e.preventDefault();return}});
window.addEventListener('resize',()=>{layout();paint()});
setInterval(()=>{if(g&&t0&&!tEnd)$('#info').textContent='Züge '+g.moves+' · '+fmt(secs())+(g.draw===3?' · 3er':'')},1000);
async function boot(){try{const c=await (await fetch('konfig')).json();cfgDraw=c.ziehen===3?3:1}catch(e){}
  const q=new URLSearchParams(location.search);const sd=q.get('seed');layout();newGame(sd!==null&&sd!==''?+sd:null,q.get('draw')==='3'?3:cfgDraw)}
window.SOL={state:()=>g,cursor:()=>cur,held:()=>held,seed:()=>seed,deal,mulberry,canTab,canFound,legal,doMove,drawStock,autoOne,cardsFrom,newGame,rects:()=>rects(),layout:()=>L,hist:()=>hist.length};
boot();
</script></body></html>"""


def register(api):
    global _api
    _api = api

    def draw_n():
        return 3 if str(api.get('ziehen') or '1') == '3' else 1

    def punkte(req):
        if req.method == 'POST':
            d = req.json if isinstance(req.json, dict) else {}
            try:
                zuege, sek = int(d.get('zuege')), int(d.get('sekunden'))
            except (TypeError, ValueError):
                return ({'error': 'Werte fehlen'}, 400)
            if not (0 < zuege < 100000 and 0 <= sek < 10_000_000):
                return ({'error': 'Ungültige Werte'}, 400)
            with _lock:
                b = api.get('rekorde', {})
                b = b if isinstance(b, dict) else {}
                b['siege'] = int(b.get('siege', 0)) + 1
                if zuege < b.get('zuege', 10 ** 9):
                    b['zuege'] = zuege
                if sek < b.get('sekunden', 10 ** 9):
                    b['sekunden'] = sek
                api.set('rekorde', b)
                return b
        b = api.get('rekorde', {})
        return b if isinstance(b, dict) else {}

    def widget():
        b = punkte(type('R', (), {'method': 'GET', 'json': {}})())
        if not b.get('siege'):
            return {'icon': '🃏', 'text': 'Solitaire', 'sub': 'Noch kein Spiel gewonnen - los geht’s!'}
        s = b['sekunden']
        return {'icon': '🃏', 'text': 'Solitaire', 'sub': '%d gewonnen · Best: %d Züge, %d:%02d' % (b['siege'], b['zuege'], s // 60, s % 60)}

    api.route('index', lambda req: PAGE)
    api.route('konfig', lambda req: {'ziehen': draw_n()})
    api.route('punkte', punkte)
    api.widget('Solitaire', widget, ttl=60, icon='🃏')
'''},
    {'id': 'pong', 'file': 'pong.py', 'title': 'Pong',
     'description': 'Pong für zwei Geräte im Heimnetz (oder gegen den Computer) - Fernbedienung und Touch, Siegerliste.',
     'code': r'''# -*- coding: utf-8 -*-
"""Pong im Netzwerk: zwei Geräte im Haus spielen gegeneinander - oder einer gegen den Computer.

Öffnen: Erweiterungsliste -> Pong -> „Pong öffnen“ (auf beiden Geräten). Name eingeben, „Mitspielen“ wählen.
Wer zuerst da ist, bekommt links, der Zweite rechts. Ist noch niemand da: „Gegen Computer“. Weitere Geräte können zuschauen.
Fernbedienung: hoch/runter bewegt den Schläger · Touch/Maus: Finger bzw. Zeiger auf dem Spielfeld verschieben.
Wer zuerst die eingestellte Punktzahl erreicht (Standard 7), gewinnt; die Siege werden pro Name gezählt.
Das Spiel läuft in der Engine (60 Bilder pro Sekunde); die Geräte fragen den Stand ab und melden ihren Schläger.
"""
import random
import threading
import time

EXT_ID = 'pong'
EXT_GUEST = True               # Gäste aus „Teilen im WLAN“ dürfen mitspielen
EXT_NAME = 'Pong'
EXT_DESCRIPTION = 'Pong für zwei Geräte im Heimnetz (oder gegen den Computer) - Fernbedienung und Touch, Siegerliste.'
EXT_LINKS = [('Pong öffnen', 'index')]
EXT_SETTINGS = [
    {'key': 'ziel', 'label': 'Gewonnen hat, wer … Punkte erreicht', 'type': 'number', 'default': 7, 'min': 1, 'max': 21},
    {'key': 'tempo', 'label': 'Spieltempo (1 = normal)', 'type': 'number', 'default': 1, 'min': 0.5, 'max': 3},
]

B, H = 800.0, 500.0            # Spielfeld
PH, BALL = 90.0, 10.0          # Schlägerhöhe, Ballradius
PX = 30.0                      # Abstand der Schläger vom Rand
TIMEOUT = 10.0                 # so lange darf ein Gerät schweigen, bevor sein Platz frei wird
GRUND = 340.0                  # Ballgeschwindigkeit (px/s)
MAX_V = 900.0
_api = None
_lock = threading.RLock()
_thread = None
S = {}


def neu():
    return {'status': 'wartet', 'seats': {'links': None, 'rechts': None}, 'score': [0, 0], 'ball': [B / 2, H / 2], 'v': [0.0, 0.0],
            'pad': [0.5, 0.5], 'start': 0.0, 'sieger': '', 'letzte_aktion': time.time(), 'serve': 1, 'gezaehlt': False}


S.update(neu())


def aufschlag(s, richtung):
    """Ball in die Mitte, Richtung +1 (nach rechts) oder -1 (nach links), leicht schräg."""
    s['ball'] = [B / 2, H / 2]
    w = random.uniform(-0.45, 0.45)
    v = GRUND * float(_tempo())
    s['v'] = [richtung * v, w * v]


def _tempo():
    try:
        return max(0.5, min(3.0, float(_api.get('tempo') or 1))) if _api else 1.0
    except (TypeError, ValueError):
        return 1.0


def _ziel():
    try:
        return max(1, min(21, int(_api.get('ziel') or 7))) if _api else 7
    except (TypeError, ValueError):
        return 7


def schritt(s, dt, ziel=7):
    """Ein Physikschritt. Gibt 'punkt', 'ende' oder None zurück. Reine Funktion auf dem Zustand (testbar)."""
    x, y = s['ball']
    vx, vy = s['v']
    x += vx * dt
    y += vy * dt
    if y < BALL:
        y, vy = BALL, abs(vy)
    elif y > H - BALL:
        y, vy = H - BALL, -abs(vy)
    for seite, face in ((0, PX + 12), (1, B - PX - 12)):
        py = s['pad'][seite] * H
        trifft = abs(y - py) <= PH / 2 + BALL
        if seite == 0 and vx < 0 and x - BALL <= face and x + BALL > PX and trifft:
            x = face + BALL
            vx = min(MAX_V, abs(vx) * 1.07)
            vy += (y - py) / (PH / 2) * 260
        elif seite == 1 and vx > 0 and x + BALL >= face and x - BALL < B - PX and trifft:
            x = face - BALL
            vx = -min(MAX_V, abs(vx) * 1.07)
            vy += (y - py) / (PH / 2) * 260
    vy = max(-MAX_V, min(MAX_V, vy))
    s['ball'], s['v'] = [x, y], [vx, vy]
    if x < -BALL * 2 or x > B + BALL * 2:
        gewinner = 1 if x < 0 else 0
        s['score'][gewinner] += 1
        s['serve'] = 1 if gewinner == 0 else -1                # Aufschlag zum Verlierer hin
        if s['score'][gewinner] >= ziel:
            return 'ende'
        return 'punkt'
    return None


def _namen(s):
    return [(s['seats'][k] or {}).get('name', '') for k in ('links', 'rechts')]


def _bewege_computer(s, dt):
    for i, k in enumerate(('links', 'rechts')):
        seat = s['seats'][k]
        if seat and seat.get('bot'):
            ziel_y = s['ball'][1] / H if ((i == 1 and s['v'][0] > 0) or (i == 0 and s['v'][0] < 0)) else 0.5
            d = ziel_y - s['pad'][i]
            gr = 0.62 * _tempo() * dt                          # etwas langsamer als der Ball: schlagbar
            s['pad'][i] += max(-gr, min(gr, d))
            s['pad'][i] = max(PH / 2 / H, min(1 - PH / 2 / H, s['pad'][i]))


def _aufraeumen(s, jetzt):
    for k in ('links', 'rechts'):
        seat = s['seats'][k]
        if seat and not seat.get('bot') and jetzt - seat['last'] > TIMEOUT:
            s['seats'][k] = None
    menschen = [k for k in ('links', 'rechts') if s['seats'][k] and not s['seats'][k].get('bot')]
    if not menschen:                                           # Computer ohne Mensch spielt nicht weiter
        for k in ('links', 'rechts'):
            s['seats'][k] = None
    if s['status'] in ('start', 'laeuft') and not (s['seats']['links'] and s['seats']['rechts']):
        s['status'] = 'wartet'
        s['score'] = [0, 0]


def _loop():
    global _thread
    letzte = time.time()
    leer_seit = None
    while True:
        time.sleep(1 / 60.0)
        jetzt = time.time()
        dt = min(0.05, jetzt - letzte)
        letzte = jetzt
        with _lock:
            s = S
            _aufraeumen(s, jetzt)
            if s['status'] == 'wartet' and s['seats']['links'] and s['seats']['rechts']:
                s['status'], s['start'], s['score'] = 'start', jetzt + 3.0, [0, 0]
            if s['status'] == 'start' and jetzt >= s['start']:
                s['status'] = 'laeuft'
                aufschlag(s, random.choice((-1, 1)))
            if s['status'] == 'laeuft':
                _bewege_computer(s, dt)
                r = schritt(s, dt, _ziel())
                if r == 'punkt':
                    aufschlag(s, s['serve'])
                elif r == 'ende':
                    s['status'] = 'ende'
                    i = 0 if s['score'][0] > s['score'][1] else 1
                    seat = s['seats']['links' if i == 0 else 'rechts']
                    s['sieger'] = (seat or {}).get('name', '?')
                    if seat and not seat.get('bot'):
                        _sieg(seat['name'])
            if not any(S['seats'].values()):
                leer_seit = leer_seit or jetzt
                if jetzt - leer_seit > 20:
                    _thread = None
                    S.update(neu())
                    return
            else:
                leer_seit = None


def _sieg(name):
    try:
        d = _api.get('siege', {})
        d = d if isinstance(d, dict) else {}
        d[name] = int(d.get(name, 0)) + 1
        _api.set('siege', d)
    except Exception:                                          # noqa: BLE001
        pass


def _sicherstellen():
    global _thread
    with _lock:
        if _thread is None or not _thread.is_alive():
            _thread = threading.Thread(target=_loop, name='pong', daemon=True)
            _thread.start()


def _sicht(s):
    k = 0.0
    if s['status'] == 'start':
        k = max(0.0, s['start'] - time.time())
    return {'status': s['status'], 'ball': [s['ball'][0] / B, s['ball'][1] / H], 'pad': list(s['pad']), 'score': list(s['score']),
            'namen': _namen(s), 'ziel': _ziel(), 'sieger': s['sieger'], 'countdown': round(k, 1), 'ph': PH / H, 'bd': BALL / B,
            'frei': [k2 for k2 in ('links', 'rechts') if not s['seats'][k2]]}


PAGE = r"""<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="ms-game"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title>Pong</title>
<style>
:root{--bg:#0f141b;--fg:#e8edf3;--mut:#93a1b3;--card:#18202b;--acc:#4da3ff}
*{box-sizing:border-box}body{margin:0;height:100vh;height:100dvh;overflow:hidden;background:var(--bg);color:var(--fg);font:clamp(16px,2.6vmin,28px)/1.4 system-ui,sans-serif;display:flex;flex-direction:column;align-items:center;gap:10px;padding:10px;-webkit-user-select:none;user-select:none;overscroll-behavior:none}
#top{width:min(96vw,calc((100vh - 11em)*1.6));width:min(96vw,calc((100dvh - 11em)*1.6));display:flex;justify-content:space-between;gap:10px;color:var(--mut)}#top b{color:var(--fg);font-size:1.4em}
#cvw{position:relative;width:min(96vw,calc((100vh - 11em)*1.6));width:min(96vw,calc((100dvh - 11em)*1.6));aspect-ratio:8/5;touch-action:none}canvas{display:block;width:100%;height:100%;background:var(--card);border-radius:12px}
#msg{position:absolute;inset:0;display:grid;place-items:center;text-align:center;background:rgba(5,8,13,.72);border-radius:12px;padding:14px}
#msg small{display:block;color:var(--mut)}
#lobby{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;align-items:center}
input{font:inherit;padding:.5em .8em;border-radius:12px;border:2px solid var(--mut);background:var(--card);color:var(--fg);width:11em}
button{font:inherit;color:var(--fg);background:var(--card);border:4px solid transparent;border-radius:14px;padding:.55em 1em;cursor:pointer}button.f,button:focus{outline:none;border-color:var(--acc)}
</style></head><body>
<div id="top"><span><b id="n0">-</b> <b id="s0">0</b></span><span id="info"></span><span><b id="s1">0</b> <b id="n1">-</b></span></div>
<div id="cvw"><canvas id="cv" width="800" height="500"></canvas><div id="msg"></div></div>
<div id="lobby"><input id="nm" maxlength="16" placeholder="Dein Name" autocomplete="off"><button id="bj">Mitspielen</button><button id="bc" style="display:none">Gegen Computer</button><button id="bl" style="display:none">Aufhören</button></div>
<script>
"use strict";
const $=(s)=>document.querySelector(s);
let me=null,st=null,y=0.5,vy=0,sending=false,lastT=performance.now(),btn=0;
try{$('#nm').value=localStorage.getItem('pong.name')||''}catch(e){}
async function post(p,b){const r=await fetch(p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b||{})});return r.json()}
async function join(){const name=($('#nm').value||'Spieler').trim().slice(0,16);try{localStorage.setItem('pong.name',name)}catch(e){}const r=await post('beitreten',{name});if(r.error){$('#msg').innerHTML=r.error;return}me=r;y=0.5}
async function leave(){if(me){await post('verlassen',{platz:me.platz,token:me.token});me=null}}
$('#bj').onclick=join;$('#bl').onclick=leave;$('#bc').onclick=async()=>{if(me)await post('computer',{platz:me.platz,token:me.token})};
function sheet(){const L=['bj','bc','bl'].map(i=>$('#'+i)).filter(b=>b.style.display!=='none');return L}
document.addEventListener('keydown',e=>{const k=e.key;
  if(k==='ArrowUp'||k==='ArrowDown'){if(me){e.preventDefault();vy=k==='ArrowUp'?-1.1:1.1}}
  else if(k==='ArrowLeft'||k==='ArrowRight'){if(!me){const L=sheet();btn=(btn+(k==='ArrowRight'?1:-1)+L.length)%L.length;L.forEach((b,i)=>b.classList.toggle('f',i===btn))}}
  else if((k==='Enter'||k==='Select')&&document.activeElement.tagName!=='INPUT'){e.preventDefault();if(me&&st&&st.status==='ende')post('nochmal',{platz:me.platz,token:me.token});else{const L=sheet();const b=L[Math.min(btn,L.length-1)]||$('#bj');b.click()}}
  else if(k==='Escape'||k==='Backspace'&&document.activeElement.tagName!=='INPUT'){if(me){e.preventDefault();leave()}}});
document.addEventListener('keyup',e=>{if(e.key==='ArrowUp'||e.key==='ArrowDown')vy=0});
const cvw=$('#cvw');
function pointer(cy){const r=cvw.getBoundingClientRect();y=Math.max(0,Math.min(1,(cy-r.top)/r.height))}
cvw.addEventListener('touchstart',e=>{pointer(e.touches[0].clientY)},{passive:true});
cvw.addEventListener('touchmove',e=>{e.preventDefault();pointer(e.touches[0].clientY)},{passive:false});
cvw.addEventListener('mousemove',e=>{if(me)pointer(e.clientY)});
cvw.addEventListener('click',()=>{if(me&&st&&st.status==='ende')post('nochmal',{platz:me.platz,token:me.token})});
function draw(){const cv=$('#cv'),x=cv.getContext('2d');x.clearRect(0,0,800,500);x.fillStyle='#18202b';x.fillRect(0,0,800,500);
  x.strokeStyle='rgba(255,255,255,.18)';x.setLineDash([10,14]);x.lineWidth=3;x.beginPath();x.moveTo(400,0);x.lineTo(400,500);x.stroke();x.setLineDash([]);
  if(!st)return;const ph=st.ph*500;x.fillStyle='#e8edf3';
  [[30,st.pad[0]],[800-30-12,st.pad[1]]].forEach((p,i)=>{x.fillStyle=(me&&me.platz===(i?'rechts':'links'))?'#4da3ff':'#e8edf3';x.fillRect(p[0],p[1]*500-ph/2,12,ph)});
  if(st.status==='laeuft'){x.fillStyle='#ffd54f';x.beginPath();x.arc(st.ball[0]*800,st.ball[1]*500,10,0,7);x.fill()}}
function ui(){if(!st)return;$('#n0').textContent=st.namen[0]||'-';$('#n1').textContent=st.namen[1]||'-';$('#s0').textContent=st.score[0];$('#s1').textContent=st.score[1];
  $('#info').textContent='bis '+st.ziel+' Punkte';const m=$('#msg');let t='';
  if(!me){t=st.frei.length?'Frei: '+st.frei.join(' / ')+'<small>Name eingeben und „Mitspielen“</small>':(st.status==='laeuft'?'':'Beide Plätze besetzt<small>Du schaust zu</small>')}
  else if(st.status==='wartet')t='Warte auf Mitspieler …<small>oder „Gegen Computer“ wählen</small>';
  else if(st.status==='start')t='Gleich geht’s los: '+Math.ceil(st.countdown)+'<small>Du bist '+(me.platz==='links'?'links':'rechts')+' (blau)</small>';
  else if(st.status==='ende')t='🏆 '+st.sieger+' gewinnt!<small>OK oder tippen = Revanche</small>';
  m.innerHTML=t;m.style.display=t?'grid':'none';
  $('#bj').style.display=me?'none':'';$('#nm').style.display=me?'none':'';$('#bl').style.display=me?'':'none';$('#bc').style.display=(me&&st.status==='wartet')?'':'none'}
async function poll(){const now=performance.now(),dt=(now-lastT)/1000;lastT=now;if(me&&vy)y=Math.max(0,Math.min(1,y+vy*dt));
  try{const r=me?await post('tick',{platz:me.platz,token:me.token,y}):await (await fetch('zustand')).json();
    if(r.error==='weg'){me=null}else if(r.status){st=r}}catch(e){}
  draw();ui();setTimeout(poll,me?33:120)}
window.PG={state:()=>({me,st,y}),setY:(v)=>{y=v}};
poll();
</script></body></html>"""


def register(api):
    global _api
    _api = api

    def post_only(fn):
        def wrap(req):
            if req.method != 'POST':
                return ({'error': 'Nur per POST'}, 405)
            return fn(req.json if isinstance(req.json, dict) else {})
        return wrap

    def platz_pruefen(d):
        k = d.get('platz')
        seat = S['seats'].get(k) if k in ('links', 'rechts') else None
        if seat is None or seat.get('bot') or seat['token'] != d.get('token'):
            return None, None
        return k, seat

    def beitreten(d):
        name = str(d.get('name') or 'Spieler').strip()[:16] or 'Spieler'
        with _lock:
            frei = [k for k in ('links', 'rechts') if S['seats'][k] is None]
            if not frei:
                return ({'error': 'Beide Plätze sind besetzt - du kannst zuschauen.'}, 409)
            k = frei[0]
            tok = '%016x' % random.getrandbits(64)
            if any(S['seats'][o] and S['seats'][o].get('name') == name and not S['seats'][o].get('bot') for o in ('links', 'rechts')):
                name = name[:13] + ' 2'
            S['seats'][k] = {'name': name, 'token': tok, 'last': time.time(), 'bot': False}
            S['pad'][0 if k == 'links' else 1] = 0.5
        _sicherstellen()
        return {'platz': k, 'token': tok, 'name': name}

    def tick(d):
        with _lock:
            k, seat = platz_pruefen(d)
            if seat is None:
                return {'error': 'weg'}
            seat['last'] = time.time()
            try:
                y = float(d.get('y'))
            except (TypeError, ValueError):
                y = 0.5
            lo = PH / 2 / H
            S['pad'][0 if k == 'links' else 1] = max(lo, min(1 - lo, y))
            return _sicht(S)

    def computer(d):
        with _lock:
            k, seat = platz_pruefen(d)
            if seat is None:
                return ({'error': 'weg'}, 403)
            andere = 'rechts' if k == 'links' else 'links'
            if S['seats'][andere] is None:
                S['seats'][andere] = {'name': 'Computer', 'token': '', 'last': time.time(), 'bot': True}
        return {'ok': True}

    def verlassen(d):
        with _lock:
            k, seat = platz_pruefen(d)
            if seat is not None:
                S['seats'][k] = None
                if S['status'] != 'wartet':
                    S['status'], S['score'], S['sieger'] = 'wartet', [0, 0], ''
        return {'ok': True}

    def nochmal(d):
        with _lock:
            k, seat = platz_pruefen(d)
            if seat is None:
                return ({'error': 'weg'}, 403)
            if S['status'] == 'ende':
                S['status'], S['score'], S['sieger'] = 'wartet', [0, 0], ''
        return {'ok': True}

    def zustand(req):
        with _lock:
            return _sicht(S)

    def widget():
        with _lock:
            s = S
            n = [x for x in _namen(s) if x]
            if s['status'] == 'laeuft' or s['status'] == 'start':
                return {'icon': '🏓', 'text': 'Pong läuft', 'sub': '%s %d : %d %s' % (_namen(s)[0], s['score'][0], s['score'][1], _namen(s)[1])}
            if n:
                return {'icon': '🏓', 'text': 'Pong: %s wartet' % n[0][:20], 'sub': 'Mitspielen: Erweiterungsliste -> Pong öffnen'}
        siege = _api.get('siege', {}) or {}
        if siege:
            top = max(siege.items(), key=lambda kv: kv[1])
            return {'icon': '🏓', 'text': 'Pong', 'sub': 'Meiste Siege: %s (%d)' % top}
        return {'icon': '🏓', 'text': 'Pong', 'sub': 'Zwei Geräte, ein Spiel - jetzt starten'}

    api.route('index', lambda req: PAGE)
    api.route('beitreten', post_only(beitreten))
    api.route('tick', post_only(tick))
    api.route('computer', post_only(computer))
    api.route('verlassen', post_only(verlassen))
    api.route('nochmal', post_only(nochmal))
    api.route('zustand', zustand)
    api.route('siege', lambda req: _api.get('siege', {}) or {})
    api.widget('Pong', widget, ttl=5, icon='🏓')
'''},
]
