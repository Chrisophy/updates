# -*- coding: utf-8 -*-

import os as _os

# Umgebungsvariablen: MOVIESCOUT_* (neu) gelten auch unter dem alten Namen MINIKODI_*.
for _k, _v in list(_os.environ.items()):
    if _k.startswith('MOVIESCOUT_'):
        _os.environ.setdefault('MINIKODI_' + _k[len('MOVIESCOUT_'):], _v)
