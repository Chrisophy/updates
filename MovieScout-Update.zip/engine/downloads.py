# -*- coding: utf-8 -*-
"""Filme/Serien offline speichern.

Lädt eine aufgelöste Quelle herunter - eine einzelne Datei oder einen HLS-Stream (m3u8), dessen
Segmente zu einer Datei zusammengefügt werden (mit ffmpeg, wenn vorhanden, sonst durch einfaches
Aneinanderhängen, was bei normalen, unverschlüsselten HLS-Quellen ebenfalls eine abspielbare Datei
ergibt). Verschlüsselte HLS-Streams (EXT-X-KEY, METHOD ungleich NONE) werden nicht unterstützt und
brechen mit einer klaren Fehlermeldung ab, statt eine kaputte Datei abzuliefern.

Fertige Downloads werden dauerhaft gemerkt (userData/downloads/library.json), laufende/kürzlich
beendete Jobs nur im Speicher (für den Fortschrittsbalken der Oberfläche).
"""
import json
import logging
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import urljoin, urlparse

from kodi_runtime import paths as _paths

from . import registry as R
from . import notify as NF

log = logging.getLogger('engine')

ROOT_DIR = _paths.DATA_DIR / 'downloads'
STAGE_DIR = ROOT_DIR / 'stage'
READY_DIR = ROOT_DIR / 'ready'
LIB_FILE = ROOT_DIR / 'library.json'
for _d in (STAGE_DIR, READY_DIR):
    _d.mkdir(parents=True, exist_ok=True)

_UA = 'Mozilla/5.0 (MovieScout)'
_CHUNK = 256 * 1024
_HLS_WORKERS = 4
_FFMPEG = shutil.which('ffmpeg')
_EXT_BY_MIME = {
    'video/mp4': '.mp4', 'video/x-matroska': '.mkv', 'video/webm': '.webm', 'video/mp2t': '.ts',
    'video/quicktime': '.mov', 'video/x-msvideo': '.avi',
}

_LOCK = threading.Lock()
_JOBS = {}             # id -> dict (nur im Speicher)
_CANCEL = {}           # id -> threading.Event


def _safe_name(s):
    s = re.sub(r'[\\/:*?"<>|]+', '_', str(s or 'Download')).strip(' .') or 'Download'
    return s[:120]


def _load_library():
    try:
        data = json.loads(LIB_FILE.read_text('utf-8'))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_library(items):
    tmp = LIB_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=1), 'utf-8')
    os.replace(tmp, LIB_FILE)


def library():
    return _load_library()


def jobs():
    with _LOCK:
        return [dict(j) for j in _JOBS.values()]


def job(jid):
    with _LOCK:
        j = _JOBS.get(jid)
        return dict(j) if j else None


def library_item(jid):
    for it in _load_library():
        if it.get('id') == jid:
            return it
    return None


def _set(jid, **kw):
    with _LOCK:
        if jid in _JOBS:
            _JOBS[jid].update(kw)


def start(provider_id, item, title=None, poster=None, hoster_url=None, headers=None, fmt=None):
    """Startet einen Download im Hintergrund, gibt sofort die Job-ID zurück."""
    title = (title or (item or {}).get('title') or 'Download').strip() or 'Download'
    poster = poster or (item or {}).get('poster') or ''
    jid = '%d%03d' % (int(time.time() * 1000), threading.get_ident() % 1000)
    with _LOCK:
        while jid in _JOBS:
            jid += 'x'
        _JOBS[jid] = {
            'id': jid, 'title': title, 'poster': poster, 'provider': provider_id,
            'state': 'queued', 'progress': 0, 'bytes_done': 0, 'bytes_total': 0,
            'method': '', 'error': '', 'created': time.time(),
        }
        ev = threading.Event()
        _CANCEL[jid] = ev
    threading.Thread(target=_run, name='download-%s' % jid, daemon=True,
                     args=(jid, provider_id, item, title, poster, hoster_url, headers, fmt, ev)).start()
    return jid


def cancel(jid):
    with _LOCK:
        ev = _CANCEL.get(jid)
    if not ev:
        return False
    ev.set()
    return True


def remove(jid):
    """Entfernt einen Eintrag (Bibliothek + Datei). Läuft der Job noch, wird er zuerst abgebrochen."""
    cancel(jid)
    with _LOCK:
        _JOBS.pop(jid, None)
    items, keep, removed = _load_library(), [], False
    for it in items:
        if it.get('id') == jid:
            removed = True
            try:
                p = Path(it.get('path') or '')
                if p.exists():
                    p.unlink()
            except Exception:
                pass
        else:
            keep.append(it)
    if removed:
        _save_library(keep)
    return removed


def mark_moved(jid):
    """Die App hat die Datei nach Filme/Movies verschoben: aus der Bibliothek (engine-seitig) entfernen,
    die Datei selbst ist schon weg (von der App verschoben)."""
    items = _load_library()
    keep = [it for it in items if it.get('id') != jid]
    if len(keep) != len(items):
        _save_library(keep)
        return True
    return False


# ----------------------------------------------------------------------------- Ablauf

def _run(jid, provider_id, item, title, poster, hoster_url, headers, fmt, cancel_ev):
    stage_glob_prefix = '%s-' % jid
    stage_path = None
    try:
        headers = dict(headers or {})
        if not hoster_url:
            _set(jid, state='resolving')
            out = R.resolve_item(provider_id, item or {}, {})
            hosters = out.get('hosters') or []
            if not hosters:
                raise RuntimeError(out.get('error') or 'Keine Quelle gefunden')
            h = hosters[0]
            if h.get('drm'):
                raise RuntimeError('Dieser Stream ist kopiergeschützt (DRM) - kein Download möglich')
            hoster_url, fmt = h['url'], h.get('format')
            headers.update(h.get('headers') or {})
        headers.setdefault('User-Agent', _UA)
        if cancel_ev.is_set():
            raise RuntimeError('Abgebrochen')

        base = STAGE_DIR / (stage_glob_prefix + _safe_name(title))
        if fmt == 'hls' or '.m3u8' in hoster_url.lower().split('?')[0]:
            _set(jid, method='hls')
            stage_path = _download_hls(jid, hoster_url, headers, base, cancel_ev)
        elif fmt == 'dash':
            raise RuntimeError('DASH-Streams (MPEG-DASH) können aktuell nicht heruntergeladen werden')
        else:
            _set(jid, method='direct')
            stage_path = _download_direct(jid, hoster_url, headers, base, cancel_ev)
        if cancel_ev.is_set():
            raise RuntimeError('Abgebrochen')

        _set(jid, state='moving', progress=99)
        name = _safe_name(title)
        ext = stage_path.suffix
        dest = READY_DIR / (name + ext)
        i = 2
        while dest.exists():
            dest = READY_DIR / ('%s (%d)%s' % (name, i, ext))
            i += 1
        shutil.move(str(stage_path), str(dest))
        stage_path = None
        size = dest.stat().st_size
        rec = {'id': jid, 'title': title, 'poster': poster, 'provider': provider_id,
              'path': str(dest), 'name': dest.name, 'ext': ext.lstrip('.'), 'size': size,
              'created': time.time()}
        with _LOCK:
            items = _load_library()
            items.append(rec)
            _save_library(items)
        _set(jid, state='done', progress=100, bytes_total=size, bytes_done=size,
            path=str(dest), ext=ext.lstrip('.'))
        NF.push('download', title, 'Download fertig', job=jid, ok=True)
    except Exception as e:
        _set(jid, state='error', error=str(e) or type(e).__name__)
        log.warning('Download %s fehlgeschlagen: %s', jid, e)
        if not cancel_ev.is_set():                          # selbst abgebrochen: keine Meldung
            NF.push('download', title, 'Download fehlgeschlagen: %s' % (str(e) or type(e).__name__), job=jid, ok=False)
    finally:
        with _LOCK:
            _CANCEL.pop(jid, None)
        if stage_path is not None:
            try:
                stage_path.unlink(missing_ok=True)
            except Exception:
                pass
        for p in STAGE_DIR.glob(stage_glob_prefix + '*'):
            try:
                p.unlink()
            except Exception:
                pass


def _ext_from_url(url, content_type):
    path = urlparse(url).path.lower()
    for e in ('.mp4', '.mkv', '.webm', '.mov', '.avi', '.ts', '.m4v'):
        if path.endswith(e):
            return e
    ct = (content_type or '').split(';')[0].strip().lower()
    return _EXT_BY_MIME.get(ct, '.mp4')


def _download_direct(jid, url, headers, base, cancel_ev):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as r:
        total = int(r.headers.get('Content-Length') or 0)
        path = base.with_suffix(_ext_from_url(url, r.headers.get('Content-Type')))
        _set(jid, state='downloading', bytes_total=total)
        done = 0
        with open(path, 'wb') as f:
            while True:
                if cancel_ev.is_set():
                    raise RuntimeError('Abgebrochen')
                chunk = r.read(_CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                pct = int(done * 100 / total) if total else min(95, done // (1024 * 1024))
                _set(jid, bytes_done=done, progress=min(99, pct))
    return path


def _fetch_text(url, headers, timeout=20):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', 'replace')


def _fetch_bytes(url, headers, timeout=30):
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _pick_variant(master_url, text):
    """Beste (höchste Bandbreite) Variante aus einer HLS-Master-Playlist."""
    best_url, best_bw, lines = None, -1, text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith('#EXT-X-STREAM-INF'):
            m = re.search(r'BANDWIDTH=(\d+)', line)
            bw = int(m.group(1)) if m else 0
            if i + 1 < len(lines) and lines[i + 1].strip() and not lines[i + 1].startswith('#'):
                u = urljoin(master_url, lines[i + 1].strip())
                if bw >= best_bw:
                    best_bw, best_url = bw, u
    return best_url


def _download_hls(jid, url, headers, base, cancel_ev):
    text = _fetch_text(url, headers)
    if '#EXT-X-STREAM-INF' in text:
        variant = _pick_variant(url, text)
        if not variant:
            raise RuntimeError('Keine abspielbare Variante in der HLS-Playlist gefunden')
        url = variant
        text = _fetch_text(url, headers)
    if re.search(r'#EXT-X-KEY:(?:(?!\n).)*METHOD=(?!NONE)', text):
        raise RuntimeError('Dieser Stream ist verschlüsselt (HLS mit Schlüssel) und kann aktuell nicht '
                            'heruntergeladen werden')

    init_url, segs = None, []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith('#EXT-X-MAP'):
            m = re.search(r'URI="([^"]+)"', line)
            if m:
                init_url = urljoin(url, m.group(1))
        elif line and not line.startswith('#'):
            segs.append(urljoin(url, line))
    if not segs:
        raise RuntimeError('Keine Segmente in der HLS-Playlist gefunden')

    fmp4 = bool(init_url) or any(s.lower().split('?')[0].endswith(('.m4s', '.mp4')) for s in segs[:3])
    total = len(segs) + (1 if init_url else 0)
    _set(jid, state='downloading', bytes_total=0)

    tmp = base.with_suffix('.part')
    done_bytes = [0]
    done_segs = [1 if init_url else 0]
    with open(tmp, 'wb') as out:
        if init_url:
            out.write(_fetch_bytes(init_url, headers))
        with ThreadPoolExecutor(max_workers=_HLS_WORKERS) as ex:
            futs = {ex.submit(_fetch_bytes, u, headers): i for i, u in enumerate(segs)}
            pending, next_write = {}, 0
            for fut in as_completed(futs):
                if cancel_ev.is_set():
                    for f in futs:
                        f.cancel()
                    raise RuntimeError('Abgebrochen')
                i = futs[fut]
                pending[i] = fut.result()
                while next_write in pending:
                    chunk = pending.pop(next_write)
                    out.write(chunk)
                    done_bytes[0] += len(chunk)
                    next_write += 1
                    done_segs[0] += 1
                    _set(jid, bytes_done=done_bytes[0], progress=min(99, int(done_segs[0] * 100 / total)))

    if _FFMPEG:
        out_path = base.with_suffix('.mp4')
        _set(jid, state='muxing')
        cmd = [_FFMPEG, '-y', '-loglevel', 'error', '-i', str(tmp), '-c', 'copy']
        if not fmp4:
            cmd += ['-bsf:a', 'aac_adtstoasc']
        cmd.append(str(out_path))
        try:
            subprocess.run(cmd, check=True, timeout=1800)
            tmp.unlink(missing_ok=True)
            return out_path
        except Exception as e:
            log.warning('ffmpeg-Remux fehlgeschlagen (%s) - liefere die Rohdatei', e)
            try:
                out_path.unlink(missing_ok=True)
            except Exception:
                pass
    out_path = base.with_suffix('.mp4' if fmp4 else '.ts')
    tmp.rename(out_path)
    return out_path
