# -*- coding: utf-8 -*-
"""Scraper-Assistent: eine Webseite laden, die Kachel-Listen darin erkennen und daraus fertigen Scraper-Code erzeugen.

Ablauf (die Oberfläche führt Schritt für Schritt hindurch):
  analyze(url)          Seite laden, Listen finden (Titel, Link, Poster), „Weiter“-Link und Suchformular erkennen
  preview(url, spec)    dieselbe Regel auf die Seite anwenden (zum Feinjustieren)
  analyze_detail(url)   Detailseite laden und die dort gefundenen Player/Hoster zeigen
  build(...)            fertigen Scraper (Python-Quelltext) erzeugen
"""
import re
from urllib.parse import quote, urljoin, urlparse

from resources.lib import htmlscrape as H

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/126.0.0.0 Safari/537.36')


class AssistError(Exception):
    pass


def fetch(url, timeout=20):
    url = (url or '').strip()
    if not url:
        raise AssistError('Bitte eine Internet-Adresse eingeben.')
    if not re.match(r'^https?://', url, re.I):
        url = 'https://' + url
    from resources.lib import multiquest
    try:
        r = multiquest.get(url, headers={'User-Agent': UA, 'Accept-Language': 'de-DE,de;q=0.9,en;q=0.5'}, timeout=timeout)
    except Exception as e:                                        # noqa: BLE001
        raise AssistError('Seite nicht erreichbar: %s' % e)
    if r.status_code >= 400:
        hint = ' (Cloudflare/Bot-Schutz? Dann braucht die Quelle use_cf im Scraper.)' if r.status_code in (403, 503) else ''
        raise AssistError('Die Seite antwortet mit HTTP %s%s.' % (r.status_code, hint))
    text = r.text or ''
    if len(text) < 200:
        raise AssistError('Die Seite ist (fast) leer – vermutlich lädt sie ihre Inhalte erst per JavaScript nach.')
    return text, (r.url or url)


# ----------------------------------------------------------------------------- Listen erkennen

_STATE = {'active', 'current', 'selected', 'first', 'last', 'odd', 'even', 'featured', 'hover', 'open', 'show', 'hidden',
          'visible', 'clearfix', 'new', 'hot', 'sticky', 'swiper-slide-active', 'slick-active', 'slick-current'}
_VOLATILE = re.compile(r'\d{3,}|^(?:css|sc|jsx|js|ng|svelte)[-_]|^[a-f0-9]{7,}$|^_', re.I)
_HEAVY_BAD = re.compile(r'menu|nav|footer|breadcrumb|pagination|pager|social|share|tabs?$|filter|alphabet|language|lang-', re.I)
_LIGHT_BAD = re.compile(r'sidebar|widget|aside', re.I)


def _sig(n):
    return tuple(sorted(c for c in n.classes if c.lower() not in _STATE and not _VOLATILE.search(c)))


def _comp(n, classes=None):
    cls = list(classes if classes is not None else _sig(n))[:3]
    if n.attrs.get('id') and not _VOLATILE.search(n.attrs['id']):
        return '%s#%s' % (n.tag, n.attrs['id'])
    return n.tag + ''.join('.' + c for c in cls)


def _has_id_or_class(n):
    return bool(_sig(n)) or (bool(n.attrs.get('id')) and not _VOLATILE.search(n.attrs['id']))


def _groups(root):
    out = []
    for parent in [root] + list(root.iter()):
        els = parent.elements()
        if len(els) < 4:
            continue
        buckets = {}
        for e in els:
            buckets.setdefault((e.tag, _sig(e)), []).append(e)
        for key, mem in buckets.items():
            if len(mem) >= 4:
                out.append((parent, key, mem))
        tags = {}
        for e in els:
            tags.setdefault(e.tag, []).append(e)
        for tag in ('li', 'article', 'tr'):
            mem = tags.get(tag, [])
            if len(mem) >= 4 and not any(k == (tag, _sig(mem[0])) and len(m) == len(mem) for _, k, m in out if _ is parent):
                out.append((parent, (tag, ()), mem))
    return out


def _penalty(parent):
    n, depth = parent, 0
    pen = 1.0
    while n is not None and n.tag != '#root' and depth < 7:
        label = ' '.join(n.classes) + ' ' + (n.attrs.get('id') or '') + ' ' + (n.attrs.get('role') or '')
        if n.tag in ('nav', 'footer') or _HEAVY_BAD.search(label):
            return 0.08
        if n.tag in ('header',):
            pen = min(pen, 0.3)
        if n.tag == 'aside' or _LIGHT_BAD.search(label):
            pen = min(pen, 0.7)
        n, depth = n.parent, depth + 1
    return pen


def _ok_link(v):
    return bool(v) and not v.startswith(('#', 'javascript:', 'mailto:', 'tel:'))


def _best_rule(members, candidates, base, valid, distinct=True, min_ratio=0.0):
    """Beste Regel aus candidates: viele gültige, möglichst verschiedene Werte."""
    best, best_score, best_vals = '', 0.0, []
    n = len(members)
    for rule in candidates:
        vals = [H.get(m, rule, base) for m in members]
        good = [v for v in vals if valid(v)]
        if len(good) / n < min_ratio or not good:
            continue
        score = len(good) / n
        if distinct:
            score *= len(set(good)) / len(good)
        if score > best_score + 1e-9:
            best, best_score, best_vals = rule, score, vals
    return best, best_score, best_vals


def _link_candidates(first):
    cands = []
    if first.tag == 'a':
        cands.append('@href')
    seen = set()
    for a in first.iter():
        if a.tag != 'a' or not _ok_link(a.attrs.get('href', '')):
            continue
        sel = _comp(a)
        rich = any(c.tag in ('img', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6') for c in a.iter())
        key = (sel, rich)
        if key in seen:
            continue
        seen.add(key)
        if rich:
            cands.insert(1 if first.tag == 'a' else 0, sel + '@href')
        else:
            cands.append(sel + '@href')
    if 'a@href' not in cands:
        cands.append('a@href')
    return cands[:8]


def _poster_candidates(first):
    cands = []
    imgs = [n for n in first.iter() if n.tag == 'img']
    for im in imgs[:3]:
        sel = _comp(im) if _sig(im) else 'img'
        cands.append(sel + '@data-src|data-lazy-src|data-original|data-srcset|srcset|src')
    cands.append('img@data-src|data-lazy-src|data-original|data-srcset|srcset|src')
    for n in first.iter():
        if 'url(' in (n.attrs.get('style') or ''):
            cands.append((_comp(n) if _sig(n) else n.tag) + '@bg')
    if 'url(' in (first.attrs.get('style') or ''):
        cands.append('@bg')
    out = []
    for c in cands:
        if c not in out:
            out.append(c)
    return out[:8]


def _title_candidates(first, link_rule):
    cands = []
    for n in first.iter():
        if n.tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6'):
            cands.append((_comp(n) if _sig(n) else n.tag) + '@text')
        elif any(re.search(r'title|titel|name|headline|caption', c, re.I) for c in n.classes):
            cands.append(_comp(n) + '@text')
    if first.tag == 'a':
        cands.append('@title')
    cands += ['a@title', 'img@alt']
    if link_rule:
        sel = link_rule.rsplit('@', 1)[0]
        cands.append((sel + '@text') if sel else '@text')
    cands.append('a@text')
    out = []
    for c in cands:
        if c not in out:
            out.append(c)
    return out[:10]


def _year_candidates(first):
    out = []
    for n in first.iter():
        if any(re.search(r'year|jahr|release|date', c, re.I) for c in n.classes):
            out.append(_comp(n) + '@text')
    return out[:4]


def _selector(root, parent, key, mem):
    """Auswahl für die Kacheln bauen: so kurz wie möglich, aber ohne fremde Treffer."""
    sig = key[1] if key[1] else ()
    member = key[0] + ''.join('.' + c for c in list(sig)[:3])
    want = len(mem)
    cnt = lambda s: len(H.select(root, s))               # noqa: E731
    sel = member
    if parent is not root and parent.tag != '#root':
        sel = (_comp(parent) + ' > ' + member) if (_has_id_or_class(parent) or cnt(member) > want) else member
    cur = parent
    for _ in range(4):
        if cnt(sel) <= want:
            break
        cur = cur.parent
        while cur is not None and cur.tag != '#root' and not _has_id_or_class(cur):
            cur = cur.parent
        if cur is None or cur.tag == '#root':
            break
        sel = _comp(cur) + ' ' + sel
    return sel


def _candidate(root, parent, key, mem, base):
    first = mem[0]
    link_rule, link_score, links = _best_rule(mem, _link_candidates(first), base, _ok_link, distinct=True, min_ratio=0.7)
    if not link_rule or link_score < 0.6:
        return None
    good = lambda v: bool(v) and 2 <= len(v) <= 160          # noqa: E731
    cands = _title_candidates(first, link_rule)
    t_rule, t_score, titles = _best_rule(mem, cands, base, good, distinct=True, min_ratio=0.7)
    if not t_rule or t_score < 0.5:
        return None
    # Rückfall-Regeln für einzelne Kacheln, bei denen die beste Regel leer bleibt
    fb = [c for c in cands if c != t_rule and sum(1 for m in mem if good(H.get(m, c, base))) / len(mem) >= 0.3][:2]
    title_rule = ' || '.join([t_rule] + fb)
    p_rule, p_score, posters = _best_rule(mem, _poster_candidates(first), base, lambda v: bool(v), distinct=False, min_ratio=0.3)
    y_rule, y_score, years = _best_rule(mem, _year_candidates(first), base, lambda v: bool(re.search(r'\b(19|20)\d\d\b', v or '')), distinct=False, min_ratio=0.3)
    sel = _selector(root, parent, key, mem)
    spec = {'item': sel, 'title': title_rule, 'link': link_rule, 'poster': p_rule, 'year': y_rule}
    items = _items_from_root(root, spec, base)
    if len(items) < 3:
        return None
    score = len(items) * (0.55 + 0.45 * p_score) * t_score * _penalty(parent)
    return {'selector': sel, 'count': len(items), 'score': score, 'spec': spec,
            'preview': items[:8], 'has_poster': bool(p_rule), 'links': set(i['link'] for i in items)}


def _items_from_root(root, spec, base):
    out, seen = [], set()
    for n in H.select(root, spec.get('item') or ''):
        title, link = H.get(n, spec.get('title', ''), base), H.get(n, spec.get('link', ''), base)
        if not title or not _ok_link(link) or link in seen:
            continue
        seen.add(link)
        out.append({'title': title, 'link': link, 'poster': H.get(n, spec.get('poster', ''), base),
                    'year': H.get(n, spec.get('year', ''), base), 'plot': H.get(n, spec.get('plot', ''), base)})
    return out


_NEXT_RULES = ['a[rel=next]@href', 'link[rel=next]@href', 'a.next@href', 'a.next-page@href', 'a.nextpostslink@href',
               'li.next a@href', 'a:contains(Weiter)@href', 'a:contains(Nächste)@href', 'a:contains(Next)@href',
               'a:contains(»)@href', 'a:contains(›)@href', 'a:contains(>>)@href']


def _find_next(root, base, current):
    for rule in _NEXT_RULES:
        v = H.get(root, rule, base)
        if _ok_link(v) and v.rstrip('/') != (current or '').rstrip('/'):
            return rule, v
    return '', ''


_SEARCH_NAMES = {'q', 's', 'query', 'search', 'keyword', 'keywords', 'suche', 'story', 'term', 'k', 'find'}


def _find_search(root, base):
    for form in H.select(root, 'form'):
        method = (form.attrs.get('method') or 'get').lower()
        if method != 'get':
            continue
        inputs = [n for n in form.iter() if n.tag == 'input']
        field = next((i for i in inputs if (i.attrs.get('type') or 'text').lower() in ('search', 'text')
                      and ((i.attrs.get('name') or '').lower() in _SEARCH_NAMES or (i.attrs.get('type') or '').lower() == 'search')), None)
        if not field or not field.attrs.get('name'):
            continue
        action = urljoin(base, form.attrs.get('action') or base)
        params = [(i.attrs['name'], i.attrs.get('value', '')) for i in inputs
                  if (i.attrs.get('type') or '').lower() == 'hidden' and i.attrs.get('name')]
        q = '&'.join('%s=%s' % (quote(k, safe=''), quote(v, safe='')) for k, v in params + [(field.attrs['name'], '{q}')])
        q = q.replace('%7Bq%7D', '{q}')
        return action + ('&' if '?' in action else '?') + q
    return ''


def _site_name(html, url):
    m = re.search(r'<meta[^>]+property=["\']og:site_name["\'][^>]+content=["\']([^"\']+)', html, re.I)
    if m:
        return m.group(1).strip()[:40]
    m = re.search(r'<title[^>]*>(.*?)</title>', html, re.I | re.S)
    if m:
        t = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', m.group(1))).strip()
        parts = [p.strip() for p in re.split(r'\s[-–—|:»]\s', t) if p.strip()]
        if parts:
            stem = slug_for(url).replace('_', '')
            for part in parts:                                # der Teil, der zur Adresse passt, ist meist der Seitenname
                if stem and stem in re.sub(r'[^a-z0-9]', '', part.lower()):
                    return part[:40]
            return (parts[-1] if len(parts[-1]) <= 25 else parts[0])[:40]
    host = (urlparse(url).hostname or 'quelle').replace('www.', '')
    return host.split('.')[0].capitalize()


def slug_for(url):
    host = (urlparse(url).hostname or 'quelle').lower().replace('www.', '')
    s = re.sub(r'[^a-z0-9]+', '_', host.rsplit('.', 1)[0] if '.' in host else host).strip('_')
    return s or 'quelle'


def analyze(url):
    html, final = fetch(url)
    root = H.parse(html)
    cands = []
    for parent, key, mem in _groups(root):
        c = _candidate(root, parent, key, mem, final)
        if c:
            cands.append(c)
    cands.sort(key=lambda c: -c['score'])
    out = []
    for c in cands:
        if any(len(c['links'] & o['links']) >= 0.9 * min(len(c['links']), len(o['links'])) for o in out):
            continue                                              # gleiche Liste noch einmal (z. B. Mobil-/Desktop-Fassung)
        out.append(c)
        if len(out) >= 4:
            break
    for c in out:
        c.pop('links', None)
        c['score'] = round(c['score'], 2)
    nrule, nurl = _find_next(root, final, final)
    return {
        'url': url, 'final_url': final,
        'site': {'name': _site_name(html, final), 'domain': (urlparse(final).hostname or '').replace('www.', ''), 'id': slug_for(final)},
        'candidates': out,
        'next': {'rule': nrule, 'url': nurl},
        'search': _find_search(root, final),
        'html_size': len(html),
    }


def preview(url, spec):
    html, final = fetch(url)
    spec = {k: str(spec.get(k) or '') for k in ('item', 'title', 'link', 'poster', 'year', 'plot')}
    if not spec['item']:
        raise AssistError('Es fehlt die Auswahl der Kacheln (item).')
    root = H.parse(html)
    items = _items_from_root(root, spec, final)
    return {'count': len(items), 'items': items[:12], 'final_url': final}


def analyze_detail(url):
    html, final = fetch(url)
    m = re.search(r'<title[^>]*>(.*?)</title>', html, re.I | re.S)
    return {'final_url': final, 'title': re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', m.group(1))).strip()[:120] if m else '',
            'embeds': H.embeds(html, final)[:12]}


# ----------------------------------------------------------------------------- Code erzeugen

def _q(s):
    return repr(str(s or ''))


def build(name, site_id, domain, start_url, spec, next_rule='', search_tpl='', movies=True):
    name = (name or 'Meine Quelle').strip()[:40]
    site_id = re.sub(r'[^a-z0-9_]+', '_', (site_id or slug_for(start_url)).lower()).strip('_') or 'quelle'
    spec = {k: str(spec.get(k) or '') for k in ('item', 'title', 'link', 'poster', 'year', 'plot')}
    spec_text = '{\n' + ''.join('    %r: %r,\n' % (k, v) for k, v in spec.items() if v) + '}'
    lines = [
        '# -*- coding: utf-8 -*-',
        '"""%s – mit dem Scraper-Assistenten erzeugt.' % name.replace('"', "'"),
        'Startseite: %s' % start_url,
        '',
        'Sieht die Seite einmal anders aus, müssen nur die Regeln in _LISTE angepasst werden (Auswahl@Attribut, siehe',
        'resources/lib/htmlscrape.py). In der Werkstatt mit „Testen“ sieht man sofort, ob wieder Einträge ankommen.',
        '"""',
        'import re',
        'from urllib.parse import quote_plus',
        '',
        'import xbmcgui',
        'from resources.lib import multiquest, log, htmlscrape',
        '',
        'SITE_ID = %s' % _q(site_id),
        'SITE_NAME = %s' % _q(name),
        'SITE_DOMAIN = %s' % _q(domain),
        'GLOBAL_SEARCH = %s' % ('True' if search_tpl else 'False'),
        '',
        '_START = %s' % _q(start_url),
        "_SUCHE = %s          # {q} wird durch den Suchbegriff ersetzt; leer = keine Suche" % _q(search_tpl),
        "_NAECHSTE = %s          # Regel für den „Weiter“-Link; leer = keine Seitenschaltung" % _q(next_rule),
        '_FILME = %s          # True: Einträge sind Filme/Folgen mit Player-Seite; False: Einträge öffnen eine weitere Liste' % ('True' if movies else 'False'),
        '',
        '_LISTE = %s' % spec_text,
        '',
        "_HEADERS = {'User-Agent': %s, 'Accept-Language': 'de-DE,de;q=0.9'}" % _q(UA),
        '',
        '',
        'def _html(url):',
        '    try:',
        '        r = multiquest.get(url, headers=_HEADERS, timeout=20)',
        '        return r.text, (r.url or url)',
        '    except Exception:',
        "        log.error('[%s] %s' % (SITE_ID, url))",
        "        return '', url",
        '',
        '',
        'def _eintraege(url):',
        '    html, final = _html(url)',
        '    out = []',
        '    for it in htmlscrape.items(html, _LISTE, base=final):',
        "        m = re.search(r'\\b(?:19|20)\\d\\d\\b', it['year'] or '')",
        "        out.append({'title': it['title'], 'url': it['link'], 'poster': it['poster'], 'plot': it['plot'],",
        "                    'year': m.group(0) if m else '', 'is_playable': _FILME,",
        "                    'next_func': 'get_hosters' if _FILME else 'load'})",
        '    if out and _NAECHSTE:',
        '        nxt = htmlscrape.pick(html, _NAECHSTE, final)',
        '        if nxt and nxt != final:',
        "            out.append({'title': 'Nächste Seite »', 'url': nxt, 'is_playable': False, 'next_func': 'load'})",
        '    return out, html, final',
        '',
        '',
        "def load(url='', params=None):",
        '    items, html, final = _eintraege(url or _START)',
        '    if not url:',
        '        if _SUCHE:',
        "            items.insert(0, {'title': 'Suche', 'url': '', 'next_func': 'search', 'is_playable': False})",
        '        return items',
        '    if not items and htmlscrape.embeds(html, final):',
        '        # keine Liste, aber ein Player: diese Seite selbst ist abspielbar',
        "        return [{'title': 'Abspielen', 'url': url, 'is_playable': True, 'next_func': 'get_hosters'}]",
        '    return items',
        '',
        '',
        "def search(query='', params=None):",
        '    if not _SUCHE:',
        '        return []',
        "    q = query or xbmcgui.Dialog().input('Suche')",
        '    if not q:',
        '        return []',
        "    return _eintraege(_SUCHE.replace('{q}', quote_plus(q)))[0]",
        '',
        '',
        "def get_hosters(title='', year='', season=0, episode=0, url='', params=None):",
        '    # Tupel: (Name, Link, direkt?, Qualität, Sprache, Quelle). Embeds löst die App beim Abspielen selbst auf.',
        '    html, final = _html(url)',
        "    return [(e['name'], e['url'], e['direct'], '', '', SITE_NAME) for e in htmlscrape.embeds(html, final)]",
        '',
    ]
    return '\n'.join(lines)
