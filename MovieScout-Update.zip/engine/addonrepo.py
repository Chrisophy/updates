# -*- coding: utf-8 -*-
"""Fehlende Abhängigkeiten eines Kodi-Addons (<requires><import addon="script.module.x"/>) aus dem offiziellen Kodi-Repository nachladen.

Ablauf: Index (addons.xml.gz) holen -> pro fehlender Kennung die neueste Version suchen -> <kennung>/<kennung>-<version>.zip laden ->
mit addonhost.install_zip installieren -> deren Abhängigkeiten ebenso (rekursiv, mit Schutz vor Kreisen und Obergrenze).
Nicht geholt wird, was die Engine selbst mitbringt (Kodi-Grundbausteine, inputstream.*, ResolveURL, requests …) oder als Python-Paket
schon vorhanden ist (z. B. script.module.six, wenn `six` importierbar ist).
Adressen: Umgebungsvariable MOVIESCOUT_KODI_REPO (kommagetrennt, mit / am Ende) überschreibt die Standardspiegel.
"""
import gzip
import importlib.util
import io
import logging
import os
import re
import threading
import time
import xml.etree.ElementTree as ET

from . import addonhost as AH
from . import proxy as P

log = logging.getLogger('engine.addonrepo')

DEFAULT_BASES = ('https://mirrors.kodi.tv/addons/omega/', 'https://mirrors.mit.edu/kodi/addons/omega/')
MAX_INDEX = 40 * 1024 * 1024            # entpackt
MAX_ZIP = 60 * 1024 * 1024
MAX_TOTAL = 25                          # höchstens so viele Pakete pro Installation
MAX_DEPTH = 6
INDEX_TTL = 3600

# Kennung -> Python-Paket: ist das Paket importierbar, zählt die Abhängigkeit als erfüllt
PY_EQUIV = {
    'script.module.six': 'six', 'script.module.certifi': 'certifi', 'script.module.chardet': 'chardet', 'script.module.idna': 'idna',
    'script.module.urllib3': 'urllib3', 'script.module.beautifulsoup4': 'bs4', 'script.module.bs4': 'bs4',
    'script.module.pycryptodome': 'Cryptodome', 'script.module.pil': 'PIL', 'script.module.dateutil': 'dateutil',
    'script.module.simplejson': 'simplejson', 'script.module.websocket': 'websocket', 'script.module.pytz': 'pytz',
    'script.module.pyyaml': 'yaml', 'script.module.lxml': 'lxml', 'script.module.future': 'future', 'script.module.markdown': 'markdown',
    'script.module.defusedxml': 'defusedxml', 'script.module.typing_extensions': 'typing_extensions',
}
ALWAYS = {'script.module.requests', 'script.module.resolveurl', 'script.module.urlresolver'}     # von der Engine selbst geliefert
_PROVIDED_PREFIX = ('xbmc.', 'kodi.', 'inputstream.', 'resource.language.', 'resource.images.')

_lock = threading.Lock()
_index = {'t': 0.0, 'base': '', 'items': {}}


class RepoError(Exception):
    """Meldung, die der Nutzer lesen kann."""


def bases():
    env = os.environ.get('MOVIESCOUT_KODI_REPO', '').strip()
    out = [b.strip() if b.strip().endswith('/') else b.strip() + '/' for b in env.split(',') if b.strip()] if env else list(DEFAULT_BASES)
    return out


def provided(aid):
    """True, wenn die Engine diese Kennung selbst abdeckt."""
    a = str(aid or '')
    if a in ALWAYS or a.lower().startswith(_PROVIDED_PREFIX):
        return True
    mod = PY_EQUIV.get(a)
    if mod:
        try:
            return importlib.util.find_spec(mod) is not None
        except (ImportError, ValueError):
            return False
    return False


def _get(url, limit, timeout=40):
    try:
        up = P.fetch('GET', url, {'Accept': '*/*'}, timeout=timeout)
    except P.Blocked as e:
        raise RepoError(str(e))
    except Exception as e:                                              # noqa: BLE001
        raise RepoError('Nicht erreichbar (%s)' % (getattr(e, 'reason', None) or e))
    try:
        if up.status >= 400:
            raise RepoError('HTTP %d' % up.status)
        chunks, n = [], 0
        while True:
            b = up.read(262144)
            if not b:
                break
            n += len(b)
            if n > limit:
                raise RepoError('Datei ist größer als erlaubt.')
            chunks.append(b)
        return b''.join(chunks)
    finally:
        up.close()


def _vkey(v):
    return [int(x) if x.isdigit() else x for x in re.split(r'[.\-+~]', str(v or '0'))] if v else [0]


def _newer(a, b):
    try:
        return _vkey(a) > _vkey(b)
    except TypeError:                                                   # gemischte Zahl/Text-Versionen
        return str(a) > str(b)


def load_index(force=False):
    """-> (base, {id: version}). Probiert die Spiegel der Reihe nach."""
    with _lock:
        if not force and _index['items'] and time.time() - _index['t'] < INDEX_TTL and _index.get('bases') == bases():
            return _index['base'], _index['items']
        last = ''
        for base in bases():
            try:
                raw = _get(base + 'addons.xml.gz', MAX_INDEX // 4)
                try:
                    xml = gzip.GzipFile(fileobj=io.BytesIO(raw)).read(MAX_INDEX + 1)
                except OSError:
                    xml = raw                                           # unkomprimierter Index
                if len(xml) > MAX_INDEX:
                    raise RepoError('Index ist zu groß.')
                if b'<!entity' in xml.lower():
                    raise RepoError('Index enthält ENTITY-Angaben.')
                root = ET.fromstring(xml)
                items = {}
                for a in root.iter('addon'):
                    aid, ver = a.get('id'), a.get('version')
                    if aid and ver and (aid not in items or _newer(ver, items[aid])):
                        items[aid] = ver
                if not items:
                    raise RepoError('Index ist leer.')
                _index.update({'t': time.time(), 'base': base, 'items': items, 'bases': bases()})
                return base, items
            except (RepoError, ET.ParseError) as e:
                last = '%s: %s' % (base, e)
                log.warning('Kodi-Repository %s', last)
        raise RepoError('Kodi-Repository nicht erreichbar (%s)' % last)


def missing(info):
    """Benötigte, nicht optionale Kennungen, die weder installiert noch von der Engine abgedeckt sind."""
    out = []
    for r in info.get('requires') or []:
        rid = r.get('id')
        if not rid or r.get('optional') or provided(rid) or AH.meta(rid):
            continue
        out.append(rid)
    return out


def fetch_one(aid):
    base, items = load_index()
    ver = items.get(aid)
    if not ver:
        raise RepoError('nicht im Kodi-Repository gefunden')
    data = _get('%s%s/%s-%s.zip' % (base, aid, aid, ver), MAX_ZIP, 120)
    try:
        return AH.install_zip(data)
    except AH.AddonError as e:
        raise RepoError(str(e))


def ensure(info, fetch=True):
    """Abhängigkeiten von `info` (Ergebnis von install_zip / meta) sicherstellen.
    -> {'installed': [ids], 'failed': [{'id','reason'}], 'missing': [ids] (nur wenn fetch=False oder gescheitert)}"""
    res = {'installed': [], 'failed': [], 'missing': []}
    seen = {info.get('id')}
    todo = [(m, 1) for m in missing(info)]
    count = 0
    while todo:
        aid, depth = todo.pop(0)
        if aid in seen:
            continue
        seen.add(aid)
        if not fetch:
            res['missing'].append(aid)
            continue
        if depth > MAX_DEPTH or count >= MAX_TOTAL:
            res['failed'].append({'id': aid, 'reason': 'Zu viele verschachtelte Abhängigkeiten.'})
            res['missing'].append(aid)
            continue
        count += 1
        try:
            got = fetch_one(aid)
        except RepoError as e:
            res['failed'].append({'id': aid, 'reason': str(e)})
            res['missing'].append(aid)
            continue
        res['installed'].append(aid)
        todo += [(m, depth + 1) for m in missing(got)]
    return res
