# -*- coding: utf-8 -*-
"""Fehlende Abhängigkeiten eines Kodi-Addons (<requires><import addon="script.module.x"/>) aus dem offiziellen Kodi-Repository nachladen.

Ablauf: Index (addons.xml.gz, optional weitere Repositories aus der Einstellung kodi_repos) holen -> pro fehlender Kennung die neueste Version suchen -> <kennung>/<kennung>-<version>.zip laden ->
mit addonhost.install_zip installieren -> deren Abhängigkeiten ebenso (rekursiv, mit Schutz vor Kreisen und Obergrenze).
Nicht geholt wird, was die Engine selbst mitbringt (Kodi-Grundbausteine, inputstream.*, ResolveURL, requests …) oder als Python-Paket
schon vorhanden ist (z. B. script.module.six, wenn `six` importierbar ist).
Adressen: Umgebungsvariable MOVIESCOUT_KODI_REPO (kommagetrennt, mit / am Ende) überschreibt die Standardspiegel.
"""
import gzip
import importlib.util
import io
import logging
import os
import re
import threading
import time
import xml.etree.ElementTree as ET

from . import addonhost as AH
from . import proxy as P

log = logging.getLogger('engine.addonrepo')

DEFAULT_BASES = ('https://mirrors.kodi.tv/addons/omega/', 'https://mirrors.mit.edu/kodi/addons/omega/')
MAX_INDEX = 40 * 1024 * 1024            # entpackt
MAX_ZIP = 60 * 1024 * 1024
MAX_TOTAL = 25                          # höchstens so viele Pakete pro Installation
MAX_DEPTH = 6
INDEX_TTL = 3600

# Kennung -> Python-Paket: ist das Paket importierbar, zählt die Abhängigkeit als erfüllt
PY_EQUIV = {
    'script.module.six': 'six', 'script.module.certifi': 'certifi', 'script.module.chardet': 'chardet', 'script.module.idna': 'idna',
    'script.module.urllib3': 'urllib3', 'script.module.beautifulsoup4': 'bs4', 'script.module.bs4': 'bs4',
    'script.module.pycryptodome': 'Cryptodome', 'script.module.pil': 'PIL', 'script.module.dateutil': 'dateutil',
    'script.module.simplejson': 'simplejson', 'script.module.websocket': 'websocket', 'script.module.pytz': 'pytz',
    'script.module.pyyaml': 'yaml', 'script.module.lxml': 'lxml', 'script.module.future': 'future', 'script.module.markdown': 'markdown',
    'script.module.defusedxml': 'defusedxml', 'script.module.typing_extensions': 'typing_extensions',
}
ALWAYS = {'script.module.requests', 'script.module.resolveurl', 'script.module.urlresolver'}     # von der Engine selbst geliefert
_PROVIDED_PREFIX = ('xbmc.', 'kodi.', 'inputstream.', 'resource.language.', 'resource.images.')

_lock = threading.Lock()
_index = {'t': 0.0, 'base': '', 'items': {}, 'key': None, 'errors': []}


class RepoError(Exception):
    """Meldung, die der Nutzer lesen kann."""


def bases():
    env = os.environ.get('MOVIESCOUT_KODI_REPO', '').strip()
    out = [b.strip() if b.strip().endswith('/') else b.strip() + '/' for b in env.split(',') if b.strip()] if env else list(DEFAULT_BASES)
    return out


def provided(aid):
    """True, wenn die Engine diese Kennung selbst abdeckt."""
    a = str(aid or '')
    if a in ALWAYS or a.lower().startswith(_PROVIDED_PREFIX):
        return True
    mod = PY_EQUIV.get(a)
    if mod:
        try:
            return importlib.util.find_spec(mod) is not None
        except (ImportError, ValueError):
            return False
    return False


def _get(url, limit, timeout=40):
    try:
        up = P.fetch('GET', url, {'Accept': '*/*'}, timeout=timeout)
    except P.Blocked as e:
        raise RepoError(str(e))
    except Exception as e:                                              # noqa: BLE001
        raise RepoError('Nicht erreichbar (%s)' % (getattr(e, 'reason', None) or e))
    try:
        if up.status >= 400:
            raise RepoError('HTTP %d' % up.status)
        chunks, n = [], 0
        while True:
            b = up.read(262144)
            if not b:
                break
            n += len(b)
            if n > limit:
                raise RepoError('Datei ist größer als erlaubt.')
            chunks.append(b)
        return b''.join(chunks)
    finally:
        up.close()


def _vkey(v):
    return [int(x) if x.isdigit() else x for x in re.split(r'[.\-+~]', str(v or '0'))] if v else [0]


def _newer(a, b):
    try:
        return _vkey(a) > _vkey(b)
    except TypeError:                                                   # gemischte Zahl/Text-Versionen
        return str(a) > str(b)


def extra_bases():
    """Zusätzliche Repositories aus der Einstellung „kodi_repos“ (Ordneradressen, in denen addons.xml liegt; getrennt durch Leerzeichen, Komma oder Zeilenumbruch)."""
    try:
        from kodi_runtime import xbmcaddon
        raw = str(xbmcaddon.all_settings().get('kodi_repos') or '')
    except Exception:                                                   # noqa: BLE001
        raw = ''
    out = []
    for part in re.split(r'[\s,;]+', raw):
        part = re.sub(r'addons\.xml(\.gz)?$', '', part.strip())
        if part.startswith(('http://', 'https://')):
            part = part if part.endswith('/') else part + '/'
            if part not in out:
                out.append(part)
    return out


_SUMMARY_LANGS = ('de_de', 'de', 'en_gb', 'en', 'en_us')


def _group(aid, points):
    """Einordnung für den Browser; 'other' (Skins, Wetter, Untertitel, Spiele-Kerne …) kann MovieScout nicht ausführen."""
    if 'xbmc.python.pluginsource' in points and aid.startswith('plugin.'):
        return 'video' if aid.startswith('plugin.video.') else 'audio' if aid.startswith('plugin.audio.') else 'program'
    if 'xbmc.python.module' in points:
        return 'module'
    if 'xbmc.python.script' in points:
        return 'program'
    if 'xbmc.service' in points:
        return 'service'
    return 'other'


def _entry(a, base):
    aid, ver = a.get('id'), a.get('version')
    if not aid or not ver:
        return None
    points, summ = [], {}
    for ext in a.findall('extension'):
        pt = ext.get('point') or ''
        points.append(pt)
        if pt == 'xbmc.addon.metadata':
            for sm in ext.findall('summary'):
                summ[(sm.get('lang') or '').lower().replace('-', '_')] = (sm.text or '').strip()
    text = next((summ[k] for k in _SUMMARY_LANGS if summ.get(k)), next((v for v in summ.values() if v), ''))
    return {'id': aid, 'version': ver, 'name': a.get('name') or aid, 'author': a.get('provider-name') or '', 'summary': text[:300],
            'group': _group(aid, points), 'base': base}


def _read_index(base, names):
    last = ''
    for nm in names:
        try:
            raw = _get(base + nm, MAX_INDEX // 4)
        except RepoError as e:
            last = str(e)
            continue
        try:
            xml = gzip.GzipFile(fileobj=io.BytesIO(raw)).read(MAX_INDEX + 1)
        except OSError:
            xml = raw                                                   # unkomprimierter Index
        if len(xml) > MAX_INDEX:
            raise RepoError('Index ist zu groß.')
        if b'<!entity' in xml.lower():
            raise RepoError('Index enthält ENTITY-Angaben.')
        try:
            root = ET.fromstring(xml)
        except ET.ParseError as e:
            raise RepoError('Index ist kein gültiges XML (%s)' % e)
        items = {}
        for a in root.iter('addon'):
            ent = _entry(a, base)
            if ent and (ent['id'] not in items or _newer(ent['version'], items[ent['id']]['version'])):
                items[ent['id']] = ent
        if not items:
            raise RepoError('Index ist leer.')
        return items
    raise RepoError(last or 'nicht erreichbar')


def catalog(force=False):
    """-> ({id: Eintrag}, [Fehlermeldungen]). Offizielles Repository (erster erreichbarer Spiegel) plus zusätzliche; bei gleicher Kennung gewinnt die neuere Version."""
    with _lock:
        key = (tuple(bases()), tuple(extra_bases()))
        if not force and _index['items'] and time.time() - _index['t'] < INDEX_TTL and _index.get('key') == key:
            return _index['items'], _index.get('errors', [])
        items, errors = {}, []
        last = ''
        for base in key[0]:
            try:
                items = _read_index(base, ('addons.xml.gz',))
                break
            except RepoError as e:
                last = '%s: %s' % (base, e)
                log.warning('Kodi-Repository %s', last)
        else:
            errors.append('Kodi-Repository nicht erreichbar (%s)' % last)
        for base in key[1]:
            try:
                for aid, ent in _read_index(base, ('addons.xml.gz', 'addons.xml')).items():
                    if aid not in items or _newer(ent['version'], items[aid]['version']):
                        items[aid] = ent
            except RepoError as e:
                errors.append('%s: %s' % (base, e))
                log.warning('Zusätzliches Repository %s: %s', base, e)
        if not items:
            raise RepoError(errors[0] if errors else 'Kodi-Repository nicht erreichbar')
        _index.update({'t': time.time(), 'items': items, 'key': key, 'errors': errors, 'base': next(iter(items.values()))['base']})
        return items, errors


def load_index(force=False):
    """-> (base, {id: version}) – für ältere Aufrufer."""
    items, _errs = catalog(force)
    return _index['base'], {k: v['version'] for k, v in items.items()}


def _inst_version(aid):
    m = AH.meta(aid)
    return m.get('version') if m else None


def search(q='', group='', page=0, size=40):
    """Suche im Katalog. -> {'items': [...], 'total', 'page', 'pages', 'errors'}. Nur, was MovieScout ausführen kann."""
    cat, errors = catalog()
    ql = (q or '').strip().lower()
    words = [w for w in re.split(r'\s+', ql) if w]
    out = []
    for e in cat.values():
        if e['group'] == 'other' or provided(e['id']):
            continue
        if group and e['group'] != group:
            continue
        score = 0
        if words:
            name, aid, summ = e['name'].lower(), e['id'].lower(), e['summary'].lower()
            if not all(w in name or w in aid or w in summ for w in words):
                continue
            score = (3 if name.startswith(ql) else 0) + (2 if ql in name else 0) + (1 if ql in aid else 0) + sum(1 for w in words if w in name)
        out.append((-score, e['name'].lower(), e))
    out.sort(key=lambda t: (t[0], t[1]))
    total = len(out)
    size = max(5, min(100, int(size or 40)))
    pages = max(1, (total + size - 1) // size)
    page = max(0, min(int(page or 0), pages - 1))
    items = []
    for _s, _n, e in out[page * size:(page + 1) * size]:
        iv = _inst_version(e['id'])
        items.append({'id': e['id'], 'name': e['name'], 'version': e['version'], 'author': e['author'], 'summary': e['summary'], 'group': e['group'],
                      'installed': iv is not None, 'installed_version': iv, 'update': bool(iv is not None and _newer(e['version'], iv))})
    return {'items': items, 'total': total, 'page': page, 'pages': pages, 'errors': errors}


_ZIPS = {}                                                              # id -> (Zeit, Version, Bytes): geprüftes Paket wird bei „Installieren“ nicht noch einmal geladen
_ZIP_LOCK = threading.Lock()


def get_zip(aid):
    cat, _errs = catalog()
    ent = cat.get(aid)
    if not ent:
        raise RepoError('nicht im Kodi-Repository gefunden')
    with _ZIP_LOCK:
        hit = _ZIPS.get(aid)
        if hit and hit[1] == ent['version'] and time.time() - hit[0] < 900:
            return ent, hit[2]
    data = _get('%s%s/%s-%s.zip' % (ent['base'], aid, aid, ent['version']), MAX_ZIP, 120)
    with _ZIP_LOCK:
        for k in [k for k, v in _ZIPS.items() if time.time() - v[0] > 900]:
            _ZIPS.pop(k, None)
        while len(_ZIPS) >= 3:
            _ZIPS.pop(next(iter(_ZIPS)), None)
        _ZIPS[aid] = (time.time(), ent['version'], data)
    return ent, data


def check(aid):
    """Paket laden und auf Kompatibilität prüfen, ohne zu installieren. -> {'entry', 'addon', 'report'}"""
    from . import compat
    ent, data = get_zip(aid)
    try:
        info, rep = compat.scan_zip(data)
    except AH.AddonError as e:
        raise RepoError(str(e))
    return {'entry': {k: ent[k] for k in ('id', 'name', 'version', 'author', 'summary', 'group')}, 'addon': info, 'report': rep,
            'size': len(data)}


def missing(info):
    """Benötigte, nicht optionale Kennungen, die weder installiert noch von der Engine abgedeckt sind."""
    out = []
    for r in info.get('requires') or []:
        rid = r.get('id')
        if not rid or r.get('optional') or provided(rid) or AH.meta(rid):
            continue
        out.append(rid)
    return out


def fetch_one(aid):
    _ent, data = get_zip(aid)
    try:
        return AH.install_zip(data)
    except AH.AddonError as e:
        raise RepoError(str(e))


def ensure(info, fetch=True):
    """Abhängigkeiten von `info` (Ergebnis von install_zip / meta) sicherstellen.
    -> {'installed': [ids], 'failed': [{'id','reason'}], 'missing': [ids] (nur wenn fetch=False oder gescheitert)}"""
    res = {'installed': [], 'failed': [], 'missing': []}
    seen = {info.get('id')}
    todo = [(m, 1) for m in missing(info)]
    count = 0
    while todo:
        aid, depth = todo.pop(0)
        if aid in seen:
            continue
        seen.add(aid)
        if not fetch:
            res['missing'].append(aid)
            continue
        if depth > MAX_DEPTH or count >= MAX_TOTAL:
            res['failed'].append({'id': aid, 'reason': 'Zu viele verschachtelte Abhängigkeiten.'})
            res['missing'].append(aid)
            continue
        count += 1
        try:
            got = fetch_one(aid)
        except RepoError as e:
            res['failed'].append({'id': aid, 'reason': str(e)})
            res['missing'].append(aid)
            continue
        res['installed'].append(aid)
        todo += [(m, depth + 1) for m in missing(got)]
    return res
