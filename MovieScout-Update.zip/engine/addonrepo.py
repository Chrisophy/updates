# -*- coding: utf-8 -*-
"""Fehlende Abhängigkeiten eines Kodi-Addons (<requires><import addon="script.module.x"/>) aus dem offiziellen Kodi-Repository nachladen.

Ablauf: Index (addons.xml.gz, optional weitere Repositories aus der Einstellung kodi_repos) holen -> pro fehlender Kennung die neueste Version suchen -> <kennung>/<kennung>-<version>.zip laden ->
mit addonhost.install_zip installieren -> deren Abhängigkeiten ebenso (rekursiv, mit Schutz vor Kreisen und Obergrenze).
Nicht geholt wird, was die Engine selbst mitbringt (Kodi-Grundbausteine, inputstream.*, ResolveURL, requests …) oder als Python-Paket
schon vorhanden ist (z. B. script.module.six, wenn `six` importierbar ist).
Adressen: Umgebungsvariable MOVIESCOUT_KODI_REPO (kommagetrennt, mit / am Ende) überschreibt die Standardspiegel.
"""
import gzip
import hashlib
import importlib.util
import io
import json
import logging
import os
import re
import threading
import time
import urllib.parse
import zipfile
import xml.etree.ElementTree as ET

from kodi_runtime import paths as _paths
from . import addonhost as AH
from . import proxy as P

log = logging.getLogger('engine.addonrepo')

DEFAULT_BASES = ('https://mirrors.kodi.tv/addons/omega/', 'https://mirrors.mit.edu/kodi/addons/omega/')
MAX_INDEX = 40 * 1024 * 1024            # entpackt
MAX_ZIP = 60 * 1024 * 1024
MAX_TOTAL = 25                          # höchstens so viele Pakete pro Installation
MAX_DEPTH = 6
INDEX_TTL = 3600                         # im Speicher
INDEX_DISK_TTL = 12 * 3600               # auf der Platte: so lange wird nach einem Neustart nichts heruntergeladen
_CACHE_DIR = _paths.DATA_DIR / 'repo_index'
_ORIGIN_FILE = _paths.DATA_DIR / 'addon_origins.json'

# Kennung -> Python-Paket: ist das Paket importierbar, zählt die Abhängigkeit als erfüllt
PY_EQUIV = {
    'script.module.six': 'six', 'script.module.certifi': 'certifi', 'script.module.chardet': 'chardet', 'script.module.idna': 'idna',
    'script.module.urllib3': 'urllib3', 'script.module.beautifulsoup4': 'bs4', 'script.module.bs4': 'bs4',
    'script.module.pycryptodome': 'Cryptodome', 'script.module.pil': 'PIL', 'script.module.dateutil': 'dateutil',
    'script.module.simplejson': 'simplejson', 'script.module.websocket': 'websocket', 'script.module.pytz': 'pytz',
    'script.module.pyyaml': 'yaml', 'script.module.lxml': 'lxml', 'script.module.future': 'future', 'script.module.markdown': 'markdown',
    'script.module.defusedxml': 'defusedxml', 'script.module.typing_extensions': 'typing_extensions',
}
ALWAYS = {'script.module.requests', 'script.module.resolveurl', 'script.module.urlresolver'}     # von der Engine selbst geliefert
_PROVIDED_PREFIX = ('xbmc.', 'kodi.', 'inputstream.', 'resource.language.', 'resource.images.')

_lock = threading.Lock()
_index = {'t': 0.0, 'base': '', 'items': {}, 'key': None, 'errors': []}


class RepoError(Exception):
    """Meldung, die der Nutzer lesen kann."""


def bases():
    env = os.environ.get('MOVIESCOUT_KODI_REPO', '').strip()
    out = [b.strip() if b.strip().endswith('/') else b.strip() + '/' for b in env.split(',') if b.strip()] if env else list(DEFAULT_BASES)
    return out


def provided(aid):
    """True, wenn die Engine diese Kennung selbst abdeckt."""
    a = str(aid or '')
    if a in ALWAYS or a.lower().startswith(_PROVIDED_PREFIX):
        return True
    mod = PY_EQUIV.get(a)
    if mod:
        try:
            return importlib.util.find_spec(mod) is not None
        except (ImportError, ValueError):
            return False
    return False


def _get(url, limit, timeout=40):
    try:
        up = P.fetch('GET', url, {'Accept': '*/*'}, timeout=timeout)
    except P.Blocked as e:
        raise RepoError(str(e))
    except Exception as e:                                              # noqa: BLE001
        raise RepoError('Nicht erreichbar (%s)' % (getattr(e, 'reason', None) or e))
    try:
        if up.status >= 400:
            raise RepoError('HTTP %d' % up.status)
        chunks, n = [], 0
        while True:
            b = up.read(262144)
            if not b:
                break
            n += len(b)
            if n > limit:
                raise RepoError('Datei ist größer als erlaubt.')
            chunks.append(b)
        return b''.join(chunks)
    finally:
        up.close()


def _vkey(v):
    return [int(x) if x.isdigit() else x for x in re.split(r'[.\-+~]', str(v or '0'))] if v else [0]


def _newer(a, b):
    try:
        return _vkey(a) > _vkey(b)
    except TypeError:                                                   # gemischte Zahl/Text-Versionen
        return str(a) > str(b)


def _raw_tokens():
    try:
        from kodi_runtime import xbmcaddon
        raw = str(xbmcaddon.all_settings().get('kodi_repos') or '')
    except Exception:                                                   # noqa: BLE001
        raw = ''
    return [t for t in re.split(r'[\s,;]+', raw) if t]


def _norm(part):
    """Eintrag aus der Einstellung bereinigen; '' wenn unbrauchbar."""
    part = part.strip().strip('"\'<>()[]')
    if not part.lower().startswith(('http://', 'https://')):
        return ''
    if '|' not in part and not part.lower().split('?')[0].endswith('.zip'):
        part = re.sub(r'addons\.xml(\.gz|\.md5)?$', '', part)
        part = part if part.endswith('/') else part + '/'
    return part


def extra_bases():
    """Zusätzliche Repositories aus der Einstellung „kodi_repos“ (getrennt durch Leerzeichen, Komma, Semikolon oder Zeilenumbruch).
    Erlaubt: Ordneradresse mit addons.xml, direkter Link auf addons.xml(.gz), GitHub-Repository-/Ordner-Link, Link auf eine repository.*.zip
    und „<addons.xml-Adresse>|<Datenordner>[|<Name>]“ (so trägt MovieScout installierte Repository-ZIPs ein; der Name ist URL-kodiert)."""
    out = []
    for t in _raw_tokens():
        part = _norm(t)
        if part and part not in out:
            out.append(part)
    return out


_GH = re.compile(r'^https?://(?:www\.)?github\.com/([^/\s]+)/([^/\s#?]+?)(?:\.git)?(?:/(?:tree|blob|raw)/([^/\s]+)(?:/([^\s#?]*))?)?/?$', re.I)


def _gh_raw(owner, repo, ref, path):
    path = (path or '').strip('/')
    return 'https://raw.githubusercontent.com/%s/%s/%s/%s' % (owner, repo, ref, path + '/' if path else '')


def _candidates(src):
    """Eine Eintragung -> Liste möglicher Quellen [(art, adresse[, datenordner])]; art 'dir' (Ordner mit addons.xml), 'zip' (Repository-Addon) oder 'index'."""
    if '|' in src:
        parts = [x.strip() for x in src.split('|')]
        return [('index', parts[0], parts[1] if len(parts) > 1 else '')]
    m = _GH.match(src.rstrip('/') if not src.lower().endswith('.zip') else src)
    if m:
        owner, repo, ref, path = m.groups()
        path = (path or '').strip('/')
        refs = [ref] if ref else ['main', 'master']
        if path.lower().endswith('.zip'):
            return [('zip', _gh_raw(owner, repo, r, path).rstrip('/')) for r in refs]
        out = []
        for r in refs:
            base = _gh_raw(owner, repo, r, path)
            out.append(('dir', base))
            if not path.endswith('zips'):
                out.append(('dir', base + 'zips/'))
        return out
    if src.lower().split('?')[0].endswith('.zip'):
        return [('zip', src)]
    return [('dir', src), ('dir', src + 'zips/')]                      # viele Repositories legen ihre Dateien in „zips/“ ab


def _repo_dirs(xml_bytes):
    """addon.xml eines Repository-Addons -> [(addons.xml-Adresse, Datenordner)]."""
    if b'<!entity' in xml_bytes.lower():
        raise RepoError('addon.xml enthält ENTITY-Angaben.')
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as e:
        raise RepoError('addon.xml ist kein gültiges XML (%s)' % e)
    out = []
    for ext in root.findall('extension'):
        if ext.get('point') != 'xbmc.addon.repository':
            continue
        for d in ext.findall('dir'):
            info = (d.findtext('info') or '').strip()
            data = (d.findtext('datadir') or '').strip()
            if info.lower().startswith(('http://', 'https://')) and data.lower().startswith(('http://', 'https://')):
                out.append((info, data if data.endswith('/') else data + '/'))
    return root.get('id') or '', root.get('name') or '', out


def zip_repo_info(data):
    """Ist `data` ein Repository-Addon (repository.*.zip)? -> (id, name, [(addons.xml-Adresse, Datenordner)]) oder None."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        return None
    names = [n for n in zf.namelist() if n.replace('\\', '/').count('/') <= 1 and n.replace('\\', '/').endswith('addon.xml')]
    if not names:
        return None
    nm = sorted(names, key=lambda n: n.count('/'))[0]
    if zf.getinfo(nm).file_size > 1024 * 1024:
        return None
    raw = zf.read(nm)
    if b'xbmc.addon.repository' not in raw:
        return None
    return _repo_dirs(raw)


def _save_tokens(tokens):
    from kodi_runtime import xbmcaddon
    xbmcaddon.save_settings({'kodi_repos': '\n'.join(tokens)})
    _index['t'] = 0.0                                                   # Katalog beim nächsten Öffnen neu laden


def register_repo(data):
    """Repository-ZIP auswerten und in die Einstellung kodi_repos eintragen. -> {'id','name','added':[…]} oder None, wenn `data` kein Repository-Addon ist."""
    res = zip_repo_info(data)
    if res is None:
        return None
    rid, name, dirs = res
    if not dirs:
        raise RepoError('Dieses Repository-Addon enthält keine Adressen (<dir><info>/<datadir>).')
    cur = _raw_tokens()
    have = {_norm(t).split('|')[0] + '|' + (_norm(t).split('|') + ['', ''])[1] for t in cur if _norm(t)}
    added = []
    for info, datadir in dirs:
        if '%s|%s' % (info, datadir) in have:
            continue
        entry = '%s|%s|%s' % (info, datadir, urllib.parse.quote(name or rid))
        cur.append(entry)
        added.append(entry)
    if added:
        _save_tokens(cur)
    return {'id': rid, 'name': name or rid, 'added': added, 'dirs': len(dirs)}


def add_repo(text):
    """Adresse(n) aus dem Eingabefeld prüfen (wird wirklich geladen) und in kodi_repos eintragen. -> {'added': [Namen], 'sources': …}"""
    new = [n for n in (_norm(t) for t in re.split(r'[\s,;]+', str(text or ''))) if n]
    if not new:
        raise RepoError('Bitte eine Adresse eingeben (http:// oder https://).')
    cur = _raw_tokens()
    have = set(extra_bases())
    added = []
    for n in new:
        if n in have:
            continue
        items, label = _load_extra(n)                                   # wirft RepoError mit der Meldung, warum es nicht geht
        cur.append(n)
        have.add(n)
        added.append(label or _label(n))
    if added:
        _save_tokens(cur)
    return {'added': added}


def remove_repo(entry):
    """Eintrag (so wie extra_bases ihn liefert) aus kodi_repos entfernen."""
    cur = _raw_tokens()
    keep = [t for t in cur if _norm(t) != entry]
    if len(keep) == len(cur):
        raise RepoError('Eintrag nicht gefunden.')
    _save_tokens(keep)
    return {'removed': True}


_SUMMARY_LANGS = ('de_de', 'de', 'en_gb', 'en', 'en_us')


def _group(aid, points):
    """Einordnung für den Browser; 'other' (Skins, Wetter, Untertitel, Spiele-Kerne …) kann MovieScout nicht ausführen."""
    if 'xbmc.python.pluginsource' in points and aid.startswith('plugin.'):
        return 'video' if aid.startswith('plugin.video.') else 'audio' if aid.startswith('plugin.audio.') else 'program'
    if 'xbmc.python.module' in points:
        return 'module'
    if 'xbmc.python.script' in points:
        return 'program'
    if 'xbmc.service' in points:
        return 'service'
    return 'other'


def _entry(a, base):
    aid, ver = a.get('id'), a.get('version')
    if not aid or not ver:
        return None
    points, summ = [], {}
    for ext in a.findall('extension'):
        pt = ext.get('point') or ''
        points.append(pt)
        if pt == 'xbmc.addon.metadata':
            for sm in ext.findall('summary'):
                summ[(sm.get('lang') or '').lower().replace('-', '_')] = (sm.text or '').strip()
    text = next((summ[k] for k in _SUMMARY_LANGS if summ.get(k)), next((v for v in summ.values() if v), ''))
    return {'id': aid, 'version': ver, 'name': a.get('name') or aid, 'author': a.get('provider-name') or '', 'summary': text[:300],
            'group': _group(aid, points), 'base': base}


def _read_index(base, names, data=None):
    base = base if base.endswith('/') else base + '/'
    last = ''
    for nm in names:
        try:
            raw = _get(base + nm, MAX_INDEX // 4)
        except RepoError as e:
            last = str(e)
            continue
        try:
            xml = gzip.GzipFile(fileobj=io.BytesIO(raw)).read(MAX_INDEX + 1)
        except OSError:
            xml = raw                                                   # unkomprimierter Index
        if len(xml) > MAX_INDEX:
            raise RepoError('Index ist zu groß.')
        if b'<!entity' in xml.lower():
            raise RepoError('Index enthält ENTITY-Angaben.')
        try:
            root = ET.fromstring(xml)
        except ET.ParseError as e:
            raise RepoError('Index ist kein gültiges XML (%s)' % e)
        items = {}
        for a in root.iter('addon'):
            ent = _entry(a, data or base)
            if ent and (ent['id'] not in items or _newer(ent['version'], items[ent['id']]['version'])):
                items[ent['id']] = ent
        if not items:
            raise RepoError('Index ist leer.')
        return items
    raise RepoError(last or 'nicht erreichbar')


def _merge(items, new):
    for aid, ent in new.items():
        if aid not in items or _newer(ent['version'], items[aid]['version']):
            items[aid] = ent


def _label(src):
    """Lesbarer Name aus der Adresse, wenn das Repository selbst keinen nennt."""
    u = src.split('|')[0]
    m = re.match(r'^https?://raw\.githubusercontent\.com/([^/]+)/([^/]+)/', u, re.I) or _GH.match(u)
    if m:
        return '%s/%s' % (m.group(1), m.group(2))
    u = re.sub(r'^https?://', '', u)
    u = re.sub(r'/(addons\.xml(\.gz)?)?$', '', u)
    return u.rsplit('/', 1)[-1] if u.lower().endswith('.zip') else u


def _items_label(items):
    """Nennt der Index genau ein Repository-Addon (repository.*), ist dessen Name der Name des Repositorys."""
    reps = [e for k, e in items.items() if k.startswith('repository.')]
    return reps[0]['name'] if len(reps) == 1 and reps[0]['name'] != reps[0]['id'] else ''


def _load_extra(src):
    """Eine Eintragung aus kodi_repos laden (siehe extra_bases). -> ({id: Eintrag}, Name oder ''). Wirft RepoError mit der ersten aussagekräftigen Meldung."""
    first = ''
    for cand in _candidates(src):
        kind, url = cand[0], cand[1]
        try:
            if kind == 'index':
                base, nm = url.rsplit('/', 1)
                items = _read_index(base + '/', (nm,) if nm else ('addons.xml.gz', 'addons.xml'), cand[2] or None)
                parts = src.split('|')
                return items, (urllib.parse.unquote(parts[2]) if len(parts) > 2 and parts[2] else _items_label(items))
            if kind == 'dir':
                items = _read_index(url, ('addons.xml.gz', 'addons.xml'))
                return items, _items_label(items)
            items, last = {}, ''
            _rid, zname, dirs = _repo_dirs(_zip_addon_xml(_get(url, MAX_ZIP, 60)))
            if not dirs:
                raise RepoError('Das ZIP ist kein Repository-Addon (keine <dir>-Angaben).')
            for info, datadir in dirs:
                base, nm = info.rsplit('/', 1)
                try:
                    _merge(items, _read_index(base + '/', (nm,), datadir))
                except RepoError as e:
                    last = str(e)
            if items:
                return items, zname or _rid
            raise RepoError(last or 'Index ist leer.')
        except RepoError as e:
            first = first or '%s: %s' % (url, e)
    raise RepoError(first or 'nicht erreichbar')


def _zip_addon_xml(data):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise RepoError('Das ist keine gültige ZIP-Datei.')
    names = [n for n in zf.namelist() if n.replace('\\', '/').count('/') <= 1 and n.replace('\\', '/').endswith('addon.xml')]
    if not names:
        raise RepoError('Im ZIP fehlt die addon.xml.')
    nm = sorted(names, key=lambda n: n.count('/'))[0]
    if zf.getinfo(nm).file_size > 1024 * 1024:
        raise RepoError('addon.xml ist zu groß.')
    return zf.read(nm)


OFFICIAL = 'official'
OFFICIAL_LABEL = 'Kodi (offiziell)'
_SRC = {}                                                               # Kennung -> (Zeit, items, label, Hinweis): Zwischenspeicher je Quelle im Speicher


def _runnable(e):
    return e['group'] != 'other' and not provided(e['id'])


def _cfile(ident):
    return _CACHE_DIR / (hashlib.sha1(ident.encode('utf-8')).hexdigest()[:20] + '.json.gz')


def _disk_load(ident):
    try:
        d = json.loads(gzip.decompress(_cfile(ident).read_bytes()).decode('utf-8'))
        if d.get('id') == ident and isinstance(d.get('items'), dict) and d['items']:
            return float(d.get('t') or 0), d['items'], d.get('label') or ''
    except Exception:                                                   # noqa: BLE001
        pass
    return None


def _disk_save(ident, items, label):
    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        f = _cfile(ident)
        tmp = f.with_suffix('.tmp')
        tmp.write_bytes(gzip.compress(json.dumps({'id': ident, 't': time.time(), 'label': label, 'items': items}, ensure_ascii=False).encode('utf-8'), 3))
        os.replace(tmp, f)
    except Exception as e:                                              # noqa: BLE001
        log.warning('Zwischenspeicher nicht geschrieben: %s', e)


def _fmt_time(t):
    return time.strftime('%d.%m.%Y %H:%M', time.localtime(t))


def _source(ident, loader, force=False):
    """-> (items, label, Hinweis). Reihenfolge: Speicher (frisch) -> Platte (frisch) -> Netz -> alter Stand von der Platte, wenn das Netz fehlt."""
    now = time.time()
    hit = _SRC.get(ident)
    if hit and not force and now - hit[0] < INDEX_TTL:
        return hit[1], hit[2], hit[3]
    disk = _disk_load(ident)
    if disk and not force and now - disk[0] < INDEX_DISK_TTL:
        _SRC[ident] = (disk[0], disk[1], disk[2], '')
        return disk[1], disk[2], ''
    try:
        items, label = loader()
    except RepoError as e:
        if disk:
            note = 'Zwischenspeicher vom %s (%s)' % (_fmt_time(disk[0]), e)
            _SRC[ident] = (now - INDEX_TTL + 300, disk[1], disk[2], note)       # in 5 Minuten wieder versuchen
            return disk[1], disk[2], note
        raise
    _SRC[ident] = (now, items, label, '')
    _disk_save(ident, items, label)
    return items, label, ''


def _load_official():
    last = ''
    for base in bases():
        try:
            return _read_index(base, ('addons.xml.gz',)), ''
        except RepoError as e:
            last = '%s: %s' % (base, e)
            log.warning('Kodi-Repository %s', last)
    raise RepoError('Kodi-Repository nicht erreichbar (%s)' % last)


def catalog(force=False):
    """-> ({id: Eintrag}, [Fehlermeldungen]). Offizielles Repository (erster erreichbarer Spiegel) plus zusätzliche, zusammengeführt (neuere Version gewinnt) –
    für die Auflösung von Abhängigkeiten. Die Einzelkataloge bleiben getrennt in _index['sources'] (siehe sources()).
    Jede Quelle hat ihren eigenen Zwischenspeicher (Speicher 1 h, Platte 12 h); force=True lädt alles neu (bei Netzfehler bleibt der alte Stand)."""
    with _lock:
        key = (tuple(bases()), tuple(extra_bases()))
        if not force and _index['items'] and time.time() - _index['t'] < INDEX_TTL and _index.get('key') == key:
            return _index['items'], _index.get('errors', [])
        off, off_err, off_note, errors = {}, '', '', []
        try:
            off, _l, off_note = _source('official|' + '|'.join(key[0]), _load_official, force)
        except RepoError as e:
            off_err = str(e)
            errors.append(off_err)
        srcs, used = [], {}
        for i, src in enumerate(key[1]):
            its, err, label, note = {}, '', '', ''
            try:
                its, label, note = _source('extra|' + src, lambda s=src: _load_extra(s), force)
            except RepoError as e:
                err = str(e)
                errors.append('%s: %s' % (src, e))
                log.warning('Zusätzliches Repository %s: %s', src, e)
            label = label or _label(src)
            used[label] = used.get(label, 0) + 1
            if used[label] > 1:
                label = '%s (%d)' % (label, used[label])
            srcs.append({'key': 'x%d' % i, 'label': label, 'entry': src, 'items': its, 'error': err, 'note': note})
        srcs.append({'key': OFFICIAL, 'label': OFFICIAL_LABEL, 'entry': '', 'items': off, 'error': off_err, 'note': off_note})
        items = {}
        _merge(items, off)
        for sc in srcs[:-1]:
            _merge(items, sc['items'])
        for sc in srcs:
            sid = sc['entry'] or OFFICIAL
            for e in sc['items'].values():
                e['srcid'], e['srclabel'] = sid, sc['label']
            sc['count'] = sum(1 for e in sc['items'].values() if _runnable(e))
        if not items:
            raise RepoError(errors[0] if errors else 'Kodi-Repository nicht erreichbar')
        _index.update({'t': time.time(), 'items': items, 'key': key, 'errors': errors, 'sources': srcs,
                       'base': next(iter(items.values()))['base']})
        return items, errors


def refresh():
    """Alle Kataloge neu laden (Knopf „Neu laden“)."""
    catalog(force=True)
    return sources()


_SRC_KEYS = ('key', 'label', 'entry', 'count', 'error', 'note')


def sources():
    """Liste der Repositories für die Anzeige: eigene zuerst, das offizielle zuletzt."""
    catalog()
    return [{k: sc.get(k, '') for k in _SRC_KEYS} for sc in _index.get('sources', [])]


# ----------------------------------------------------------------------------- Herkunft: aus welchem Repository wurde ein Addon installiert?

_ORIGIN_LOCK = threading.Lock()


def _origins():
    try:
        d = json.loads(_ORIGIN_FILE.read_text('utf-8'))
        return d if isinstance(d, dict) else {}
    except Exception:                                                   # noqa: BLE001
        return {}


def _write_origins(d):
    tmp = _ORIGIN_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(tmp, _ORIGIN_FILE)


def record_origin(aid, srcid, label=''):
    """Merkt sich, aus welchem Repository `aid` installiert wurde (srcid: Adresse des Eintrags oder 'official')."""
    if not aid or not srcid:
        return
    with _ORIGIN_LOCK:
        d = _origins()
        d[aid] = {'src': srcid, 'label': label or '', 't': int(time.time())}
        _write_origins(d)


def clear_origin(aid):
    with _ORIGIN_LOCK:
        d = _origins()
        if d.pop(aid, None) is not None:
            _write_origins(d)


def origin_of(aid):
    """-> {'src','label'} oder None (unbekannt: per ZIP installiert, vor dem Merken der Herkunft installiert oder Repository wurde entfernt)."""
    o = _origins().get(aid)
    if not o or not AH.meta(aid):
        return None
    if o['src'] != OFFICIAL and o['src'] not in {sc['entry'] for sc in _index.get('sources', [])}:
        return None
    return o


def load_index(force=False):
    """-> (base, {id: version}) – für ältere Aufrufer."""
    items, _errs = catalog(force)
    return _index['base'], {k: v['version'] for k, v in items.items()}


def _inst_version(aid):
    m = AH.meta(aid)
    return m.get('version') if m else None


def search(q='', group='', page=0, size=40, src=''):
    """Suche im Katalog. -> {'items': [...], 'total', 'page', 'pages', 'errors', 'sources'}. Nur, was MovieScout ausführen kann.
    src = Schlüssel aus sources() (nur dieses Repository) oder '' (alle, nach Repository gruppiert: eigene zuerst)."""
    _cat, errors = catalog()
    all_src = _index.get('sources', [])
    pick = [sc for sc in all_src if sc['key'] == src] if src else []
    if not pick:
        pick, src = all_src, ''                                         # keine oder veraltete Auswahl: alle Repositories
    ql = (q or '').strip().lower()
    words = [w for w in re.split(r'\s+', ql) if w]
    out = []
    for order, sc in enumerate(pick):
        for e in sc['items'].values():
            if not _runnable(e):
                continue
            if group and e['group'] != group:
                continue
            score = 0
            if words:
                name, aid, summ = e['name'].lower(), e['id'].lower(), e['summary'].lower()
                if not all(w in name or w in aid or w in summ for w in words):
                    continue
                score = (3 if name.startswith(ql) else 0) + (2 if ql in name else 0) + (1 if ql in aid else 0) + sum(1 for w in words if w in name)
            out.append((order, -score, e['name'].lower(), e, sc))
    out.sort(key=lambda t: t[:3])
    total = len(out)
    size = max(5, min(100, int(size or 40)))
    pages = max(1, (total + size - 1) // size)
    page = max(0, min(int(page or 0), pages - 1))
    items = []
    for _o, _s, _n, e, sc in out[page * size:(page + 1) * size]:
        iv = _inst_version(e['id'])
        org = origin_of(e['id']) if iv is not None else None
        here = org is None or org['src'] == (sc['entry'] or OFFICIAL)
        items.append({'id': e['id'], 'name': e['name'], 'version': e['version'], 'author': e['author'], 'summary': e['summary'], 'group': e['group'],
                      'installed': iv is not None, 'installed_version': iv, 'update': bool(iv is not None and here and _newer(e['version'], iv)),
                      'origin_label': org['label'] if org and not here else '', 'src': sc['key'], 'src_label': sc['label']})
    return {'items': items, 'total': total, 'page': page, 'pages': pages, 'errors': errors, 'src': src,
            'sources': [{k: sc.get(k, '') for k in _SRC_KEYS} for sc in all_src], 'updates': len(updates())}


_ZIPS = {}                                                              # id -> (Zeit, Version, Bytes): geprüftes Paket wird bei „Installieren“ nicht noch einmal geladen
_ZIP_LOCK = threading.Lock()


def updates():
    """Installierte Addons mit neuerer Version -> [{'id','name','group','installed_version','version','src','src_label','from_origin'}].
    Ist die Herkunft bekannt, zählt nur dieses Repository; sonst das Repository mit der neuesten Version."""
    catalog()
    srcs = _index.get('sources', [])
    out = []
    for m in AH.installed():
        aid, iv = m.get('id'), m.get('version')
        if not aid or not iv:
            continue
        org = origin_of(aid)
        pool = [sc for sc in srcs if org and (sc['entry'] or OFFICIAL) == org['src']] if org else srcs
        best, bsc = None, None
        for sc in pool:
            e = sc['items'].get(aid)
            if e and _runnable(e) and _newer(e['version'], iv) and (best is None or _newer(e['version'], best['version'])):
                best, bsc = e, sc
        if best:
            out.append({'id': aid, 'name': best['name'] or aid, 'group': best['group'], 'installed_version': iv, 'version': best['version'],
                        'src': bsc['key'], 'src_label': bsc['label'], 'from_origin': bool(org)})
    out.sort(key=lambda x: x['name'].lower())
    return out


def _entry_for(aid, src=''):
    cat, _errs = catalog()
    if src:
        sc = next((x for x in _index.get('sources', []) if x['key'] == src), None)
        if sc is not None:
            ent = sc['items'].get(aid)
            if not ent:
                raise RepoError('nicht in „%s“ gefunden' % sc['label'])
            return ent
    ent = cat.get(aid)
    if not ent:
        raise RepoError('nicht im Kodi-Repository gefunden')
    return ent


def get_zip(aid, src=''):
    ent = _entry_for(aid, src)
    ck = '%s@%s' % (aid, ent['base'])
    with _ZIP_LOCK:
        hit = _ZIPS.get(ck)
        if hit and hit[1] == ent['version'] and time.time() - hit[0] < 900:
            return ent, hit[2]
    data = _get('%s%s/%s-%s.zip' % (ent['base'], aid, aid, ent['version']), MAX_ZIP, 120)
    with _ZIP_LOCK:
        for k in [k for k, v in _ZIPS.items() if time.time() - v[0] > 900]:
            _ZIPS.pop(k, None)
        while len(_ZIPS) >= 3:
            _ZIPS.pop(next(iter(_ZIPS)), None)
        _ZIPS[ck] = (time.time(), ent['version'], data)
    return ent, data


def check(aid, src=''):
    """Paket laden und auf Kompatibilität prüfen, ohne zu installieren. -> {'entry', 'addon', 'report'}"""
    from . import compat
    ent, data = get_zip(aid, src)
    try:
        info, rep = compat.scan_zip(data)
    except AH.AddonError as e:
        raise RepoError(str(e))
    return {'entry': {k: ent[k] for k in ('id', 'name', 'version', 'author', 'summary', 'group')}, 'addon': info, 'report': rep,
            'size': len(data)}


def missing(info):
    """Benötigte, nicht optionale Kennungen, die weder installiert noch von der Engine abgedeckt sind."""
    out = []
    for r in info.get('requires') or []:
        rid = r.get('id')
        if not rid or r.get('optional') or provided(rid) or AH.meta(rid):
            continue
        out.append(rid)
    return out


def fetch_one(aid):
    ent, data = get_zip(aid)
    try:
        info = AH.install_zip(data)
    except AH.AddonError as e:
        raise RepoError(str(e))
    record_origin(info.get('id') or aid, ent.get('srcid'), ent.get('srclabel'))
    return info


def ensure(info, fetch=True):
    """Abhängigkeiten von `info` (Ergebnis von install_zip / meta) sicherstellen.
    -> {'installed': [ids], 'failed': [{'id','reason'}], 'missing': [ids] (nur wenn fetch=False oder gescheitert)}"""
    res = {'installed': [], 'failed': [], 'missing': []}
    seen = {info.get('id')}
    todo = [(m, 1) for m in missing(info)]
    count = 0
    while todo:
        aid, depth = todo.pop(0)
        if aid in seen:
            continue
        seen.add(aid)
        if not fetch:
            res['missing'].append(aid)
            continue
        if depth > MAX_DEPTH or count >= MAX_TOTAL:
            res['failed'].append({'id': aid, 'reason': 'Zu viele verschachtelte Abhängigkeiten.'})
            res['missing'].append(aid)
            continue
        count += 1
        try:
            got = fetch_one(aid)
        except RepoError as e:
            res['failed'].append({'id': aid, 'reason': str(e)})
            res['missing'].append(aid)
            continue
        res['installed'].append(aid)
        todo += [(m, depth + 1) for m in missing(got)]
    return res
