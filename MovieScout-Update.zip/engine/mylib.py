# -*- coding: utf-8 -*-
"""Meine Bibliothek: eigene Bewertungen und Kommentare zu Filmen und Serien.

Pro Titel: Punkte (1-10, 0 = nicht bewertet), Kommentar, gesehen (mit Datum und Anzahl), „nochmal schauen?“ (ja/nein).
Gespeichert in mylib.json (Sicherung/Wiederherstellung sind eingebunden). Der Schlüssel eines Titels ist die TMDB- oder
IMDb-Nummer, sonst Titel + Jahr - damit derselbe Film aus verschiedenen Quellen derselbe Eintrag bleibt.
"""
import json
import re
import threading
import time

from kodi_runtime import paths as _paths

MAX_ENTRIES = 5000
MAX_COMMENT = 2000
_lock = threading.RLock()


def _file():
    return _paths.DATA_DIR / 'mylib.json'


def _norm(s):
    s = str(s or '').lower()
    for a, b in (('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'), ('ß', 'ss')):
        s = s.replace(a, b)
    return re.sub(r'[^a-z0-9]+', ' ', s).strip()


def key_of(item):
    item = item if isinstance(item, dict) else {}
    tm = str(item.get('tmdb') or item.get('tmdb_id') or '').strip()
    if tm.isdigit() and int(tm) > 0:
        return 'tmdb:' + tm
    im = str(item.get('imdb') or item.get('imdb_id') or '').strip()
    if re.match(r'^tt\d+$', im):
        return 'imdb:' + im
    t = _norm(re.sub(r'\s*[\(\[]\d{4}[\)\]]\s*$', '', str(item.get('parent_title') or item.get('title') or '')))
    if not t:
        return ''
    y = str(item.get('year') or '').strip()
    return 'titel:%s|%s' % (t, y if y.isdigit() else '')


def _load():
    try:
        d = json.loads(_file().read_text('utf-8'))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save(data):
    p = _file()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False), 'utf-8')
    tmp.replace(p)


def _clean(e):
    return {
        'key': e.get('key', ''), 'title': str(e.get('title') or '')[:200], 'year': int(e['year']) if str(e.get('year') or '').isdigit() else 0,
        'poster': str(e.get('poster') or '')[:500], 'type': 'tv' if e.get('type') == 'tv' else 'movie',
        'stars': max(0, min(10, int(e.get('stars') or 0))), 'comment': str(e.get('comment') or '')[:MAX_COMMENT],
        'seen': bool(e.get('seen')), 'seen_at': int(e.get('seen_at') or 0), 'seen_count': max(0, int(e.get('seen_count') or 0)),
        'rewatch': e.get('rewatch') if e.get('rewatch') in ('ja', 'nein') else '', 'updated': int(e.get('updated') or 0),
        'item': e.get('item') if isinstance(e.get('item'), dict) else {},
    }


def _slim(item):
    """Nur das, was zum erneuten Öffnen der Titel-Info nötig ist."""
    return {k: item[k] for k in ('title', 'year', 'poster', 'tmdb', 'imdb', 'mediatype', 'plot') if k in item and item[k] not in (None, '')}


def get(item_or_key):
    k = item_or_key if isinstance(item_or_key, str) else key_of(item_or_key)
    return _clean(_load()[k]) if k in _load() else None


def set_(item, patch):
    """Eintrag anlegen/ändern. patch: stars, comment, seen, rewatch. Ohne jeden Inhalt wird der Eintrag entfernt."""
    k = key_of(item)
    if not k:
        raise ValueError('Titel fehlt')
    patch = patch if isinstance(patch, dict) else {}
    with _lock:
        data = _load()
        e = data.get(k) or {'key': k, 'seen_count': 0}
        e.update({'title': item.get('title') or e.get('title') or '', 'year': item.get('year') or e.get('year') or 0,
                  'poster': item.get('poster') or e.get('poster') or '',
                  'type': 'tv' if (item.get('mediatype') in ('tvshow', 'season', 'episode', 'tv') or item.get('season')) else e.get('type', 'movie')})
        e['item'] = _slim(item) or e.get('item') or {}
        if 'stars' in patch:
            e['stars'] = max(0, min(10, int(patch['stars'] or 0)))
        if 'comment' in patch:
            e['comment'] = str(patch['comment'] or '')[:MAX_COMMENT]
        if 'rewatch' in patch:
            e['rewatch'] = patch['rewatch'] if patch['rewatch'] in ('ja', 'nein') else ''
        if 'seen' in patch:
            now = int(time.time())
            if patch['seen'] and not e.get('seen'):
                e['seen'], e['seen_at'] = True, now
                e['seen_count'] = max(1, int(e.get('seen_count') or 0))
            elif not patch['seen']:
                e['seen'], e['seen_at'], e['seen_count'] = False, 0, 0
        if patch.get('again'):                                  # nochmal gesehen: Zähler hoch
            e['seen'], e['seen_at'] = True, int(time.time())
            e['seen_count'] = int(e.get('seen_count') or 0) + 1
        if e.get('stars') or e.get('comment') or e.get('seen') or e.get('rewatch'):
            e['updated'] = int(time.time())
            data[k] = e
            if len(data) > MAX_ENTRIES:
                for old in sorted(data, key=lambda x: data[x].get('updated', 0))[:len(data) - MAX_ENTRIES]:
                    data.pop(old, None)
        else:
            data.pop(k, None)
            e = {'key': k}
        _save(data)
        return _clean(e) if k in data else None


def mark_seen(item):
    """Beim Ende einer Wiedergabe: als gesehen merken (Bewertung und Kommentar bleiben unberührt)."""
    k = key_of(item)
    if not k or not str(item.get('title') or '').strip():
        return None
    cur = get(k)
    if cur and cur['seen']:
        return cur
    return set_(item, {'seen': True})


def remove(key):
    with _lock:
        data = _load()
        ok = data.pop(str(key), None) is not None
        if ok:
            _save(data)
        return ok


def listing(filter_='', sort='neu', q=''):
    """-> {'items': [...], 'stats': {...}}. filter_: gesehen | offen | nochmal | bewertet | '' (alle)."""
    es = [_clean(e) for e in _load().values()]
    st = {'total': len(es), 'seen': sum(1 for e in es if e['seen']), 'rated': sum(1 for e in es if e['stars']),
          'avg': round(sum(e['stars'] for e in es if e['stars']) / max(1, sum(1 for e in es if e['stars'])), 1),
          'rewatch': sum(1 for e in es if e['rewatch'] == 'ja')}
    f = {'gesehen': lambda e: e['seen'], 'offen': lambda e: not e['seen'], 'nochmal': lambda e: e['rewatch'] == 'ja',
         'bewertet': lambda e: e['stars'] > 0}.get(filter_)
    if f:
        es = [e for e in es if f(e)]
    if q:
        n = _norm(q)
        es = [e for e in es if n in _norm(e['title'] + ' ' + e['comment'])]
    keyf = {'bewertung': lambda e: (-e['stars'], e['title'].lower()), 'titel': lambda e: e['title'].lower(),
            'neu': lambda e: -e['updated']}.get(sort, lambda e: -e['updated'])
    es.sort(key=keyf)
    return {'items': es, 'stats': st}


# ----------------------------------------------------------------------------- Sicherung

def export_data():
    return _load()


def import_data(raw, replace=False):
    if not isinstance(raw, dict):
        return 0
    with _lock:
        data = {} if replace else _load()
        n = 0
        for k, e in list(raw.items())[:MAX_ENTRIES]:
            if isinstance(e, dict) and isinstance(k, str) and k:
                e = dict(e, key=k)
                old = data.get(k)
                if old and int(old.get('updated') or 0) >= int(e.get('updated') or 0):
                    continue
                data[k] = _clean(e)
                n += 1
        _save(data)
    return n
