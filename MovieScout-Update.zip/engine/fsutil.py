# -*- coding: utf-8 -*-
"""Ordner sicher tauschen – auch auf dem Android-Speicher.

Auf /storage/emulated/0 (FUSE, z. B. Pydroid mit MovieScout im Download-Ordner) verbietet Android oft das Umbenennen von Ordnern
(„PermissionError: [Errno 1] Operation not permitted“) und das Setzen von Rechten/Zeitstempeln. move_dir versucht deshalb erst das
schnelle Umbenennen und kopiert sonst Datei für Datei (ohne Rechte/Zeitstempel) und löscht danach die Quelle.
"""
import logging
import os
import shutil
import stat
from pathlib import Path

log = logging.getLogger('engine')


def _writable(func, path, _exc):
    try:
        os.chmod(path, stat.S_IWRITE | stat.S_IREAD | stat.S_IEXEC)
        func(path)
    except OSError:
        pass


def rm_tree(p):
    """Ordner löschen; was sich nicht löschen lässt, bleibt still liegen."""
    p = Path(p)
    if p.is_dir() and not p.is_symlink():
        shutil.rmtree(str(p), onerror=_writable)
    elif p.exists() or p.is_symlink():
        try:
            p.unlink()
        except OSError:
            pass


def copy_tree(src, dst):
    """Inhalt von src nach dst kopieren (vorhandene Dateien werden überschrieben), nur Inhalte – keine Rechte/Zeitstempel."""
    src, dst = Path(src), Path(dst)
    dst.mkdir(parents=True, exist_ok=True)
    for root, dirs, files in os.walk(str(src)):
        rel = os.path.relpath(root, str(src))
        tgt = dst if rel == '.' else dst / rel
        tgt.mkdir(parents=True, exist_ok=True)
        for d in dirs:
            (tgt / d).mkdir(exist_ok=True)
        for f in files:
            shutil.copyfile(os.path.join(root, f), str(tgt / f))


def move_dir(src, dst):
    """src an die Stelle von dst setzen (ein vorhandenes dst wird ersetzt). -> 'rename' oder 'copy'."""
    src, dst = Path(src), Path(dst)
    if dst.exists():
        rm_tree(dst)
    try:
        os.replace(str(src), str(dst))
        return 'rename'
    except OSError as e:
        first = e
    if dst.exists():                                     # z. B. ein Dienst hat inzwischen __pycache__ angelegt: noch einmal leeren
        rm_tree(dst)
        try:
            os.replace(str(src), str(dst))
            return 'rename'
        except OSError:
            pass
    log.info('Ordner umbenennen nicht erlaubt (%s) - kopiere %s', first, dst.name)
    copy_tree(src, dst)
    rm_tree(src)
    return 'copy'
