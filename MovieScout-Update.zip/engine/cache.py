# -*- coding: utf-8 -*-
"""Zwischenspeicher mit Ablaufzeit (TTL): Arbeitsspeicher, optional zusätzlich SQLite (überlebt Neustarts).

    C = cache.Cache('tmdb', ttl=14 * 86400, persist=True)
    v = C.get(key)              # None bei Fehlen/Ablauf
    C.put(key, value)           # value muss JSON-fähig sein, wenn persist=True
    v, stale = C.get_stale(key, max_stale=7200)   # abgelaufen, aber noch brauchbar (-> im Hintergrund erneuern)

Die SQLite-Datei liegt in userData (cache.sqlite). Ist sie nicht schreibbar oder kaputt, läuft alles nur im
Arbeitsspeicher weiter - der Zwischenspeicher darf nie einen Fehler nach außen geben.
"""
import json
import logging
import sqlite3
import threading
import time

from kodi_runtime import paths as _paths

log = logging.getLogger('cache')

_REG = {}                       # Name -> Cache
_DB = None
_DB_LOCK = threading.RLock()
_DB_BROKEN = False


def _db():
    global _DB, _DB_BROKEN
    if _DB is not None or _DB_BROKEN:
        return _DB
    with _DB_LOCK:
        if _DB is not None or _DB_BROKEN:
            return _DB
        try:
            path = _paths.DATA_DIR / 'cache.sqlite'
            path.parent.mkdir(parents=True, exist_ok=True)
            con = sqlite3.connect(str(path), timeout=5, check_same_thread=False, isolation_level=None)
            con.execute('PRAGMA journal_mode=WAL')
            con.execute('PRAGMA synchronous=NORMAL')
            con.execute('CREATE TABLE IF NOT EXISTS kv (ns TEXT NOT NULL, k TEXT NOT NULL, v TEXT NOT NULL, '
                        'exp REAL NOT NULL, ts REAL NOT NULL, PRIMARY KEY (ns, k))')
            con.execute('DELETE FROM kv WHERE exp < ?', (int(time.time()) - 86400,))
            _DB = con
        except Exception as e:                            # noqa: BLE001
            log.warning('Zwischenspeicher-Datei nicht nutzbar (%s) - nur Arbeitsspeicher', e)
            _DB_BROKEN = True
    return _DB


class Cache:
    def __init__(self, name, ttl=600, max_mem=500, persist=False):
        self.name, self.ttl, self.max_mem, self.persist = name, ttl, max_mem, persist
        self._mem = {}                                    # key -> (gespeichert, läuft ab, Wert)
        self._lock = threading.Lock()
        self.hits = self.misses = self.stale_hits = 0
        self._puts = 0
        _REG[name] = self

    # -- lesen
    def _read(self, key):
        now = time.time()
        with self._lock:
            ent = self._mem.get(key)
        if ent:
            return ent
        if self.persist:
            con = _db()
            if con is not None:
                try:
                    with _DB_LOCK:
                        row = con.execute('SELECT v, exp, ts FROM kv WHERE ns=? AND k=?', (self.name, key)).fetchone()
                    if row:
                        ent = (float(row[2]), float(row[1]), json.loads(row[0]))
                        with self._lock:
                            self._mem[key] = ent
                        return ent
                except Exception as e:                    # noqa: BLE001
                    log.debug('SQLite lesen: %s', e)
        return None

    def get(self, key):
        key = str(key)
        ent = self._read(key)
        if ent and time.time() < ent[1]:
            self.hits += 1
            return ent[2]
        self.misses += 1
        return None

    def get_stale(self, key, max_stale=3600):
        """(Wert, abgelaufen?) - ein abgelaufener Wert zählt noch bis max_stale Sekunden nach seinem Ablauf."""
        key = str(key)
        ent = self._read(key)
        now = time.time()
        if ent and now < ent[1]:
            self.hits += 1
            return ent[2], False
        if ent and now < ent[1] + max_stale:
            self.stale_hits += 1
            return ent[2], True
        self.misses += 1
        return None, False

    # -- schreiben
    def put(self, key, value, ttl=None):
        key = str(key)
        now = time.time()
        exp = now + (self.ttl if ttl is None else ttl)
        with self._lock:
            if len(self._mem) >= self.max_mem:
                for k in sorted(self._mem, key=lambda k: self._mem[k][0])[:max(1, self.max_mem // 4)]:
                    self._mem.pop(k, None)
            self._mem[key] = (now, exp, value)
            self._puts += 1
            prune = self._puts % 200 == 0
        if self.persist:
            con = _db()
            if con is not None:
                try:
                    blob = json.dumps(value, ensure_ascii=False, default=str)
                    with _DB_LOCK:
                        con.execute('INSERT OR REPLACE INTO kv (ns, k, v, exp, ts) VALUES (?,?,?,?,?)',
                                    (self.name, key, blob, float(exp), float(now)))
                        if prune:
                            con.execute('DELETE FROM kv WHERE exp < ?', (int(now) - 86400,))
                except Exception as e:                    # noqa: BLE001
                    log.debug('SQLite schreiben: %s', e)

    def delete(self, key):
        key = str(key)
        with self._lock:
            self._mem.pop(key, None)
        if self.persist and _db() is not None:
            try:
                with _DB_LOCK:
                    _db().execute('DELETE FROM kv WHERE ns=? AND k=?', (self.name, key))
            except Exception:                             # noqa: BLE001
                pass

    def clear(self):
        with self._lock:
            self._mem.clear()
        if self.persist and _db() is not None:
            try:
                with _DB_LOCK:
                    _db().execute('DELETE FROM kv WHERE ns=?', (self.name,))
            except Exception:                             # noqa: BLE001
                pass

    def stats(self):
        n_db = 0
        if self.persist and _db() is not None:
            try:
                with _DB_LOCK:
                    n_db = _db().execute('SELECT COUNT(*) FROM kv WHERE ns=? AND exp>?', (self.name, int(time.time()))).fetchone()[0]
            except Exception:                             # noqa: BLE001
                pass
        total = self.hits + self.misses + self.stale_hits
        with self._lock:
            mem = len(self._mem)
        return {'name': self.name, 'memory': mem, 'stored': n_db, 'hits': self.hits, 'stale': self.stale_hits,
                'misses': self.misses, 'rate': round((self.hits + self.stale_hits) * 100.0 / total) if total else 0,
                'ttl': self.ttl, 'persist': self.persist}


def clear_all():
    for c in list(_REG.values()):
        c.clear()


def maintain(full=False):
    """SQLite-Datei pflegen: abgelaufene (full: alle) Einträge löschen, Journal einarbeiten, Datei verkleinern."""
    if full:
        clear_all()
    con = _db()
    if con is None:
        return
    with _DB_LOCK:
        try:
            if full:
                con.execute('DELETE FROM kv')
            else:
                con.execute('DELETE FROM kv WHERE exp < ?', (int(time.time()),))
            con.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            con.execute('VACUUM')
            con.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        except Exception as e:                            # noqa: BLE001
            log.debug('Pflege der Zwischenspeicher-Datei: %s', e)


def all_stats():
    return [c.stats() for c in _REG.values()]
