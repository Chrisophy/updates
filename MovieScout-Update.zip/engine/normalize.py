# -*- coding: utf-8 -*-
"""Wandelt die Rückgaben der Kodi-Scraper in sauberes JSON für die Web-UI um.

Reine Funktionen ohne Netzwerkzugriff - dadurch gut testbar.
"""
import html as _html
import json
import re
from urllib.parse import unquote, urlparse, parse_qsl

DEFAULT_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')

_MARKUP = re.compile(r'\[/?(?:B|I|U|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|COLOR[^\]]*|CR)\]', re.I)
_SEARCH_TITLE = re.compile(r'^\W*(?:suche|suchen|search|globale suche)\b\W*$', re.I)

KIND_FOLDER, KIND_PLAY, KIND_SEARCH, KIND_ACTION = 'folder', 'play', 'search', 'action'
ACTION_FUNCS = {'clear_cache'}
SEARCH_FUNCS = {'search', 'do_search'}


def clean_markup(text):
    if text is None:
        return ''
    t = str(text)
    t = re.sub(r'\[CR\]', ' ', t, flags=re.I)
    t = _MARKUP.sub('', t)
    t = _html.unescape(t)
    return re.sub(r'\s+', ' ', t).strip()


def jsonable(obj):
    """Entfernt alles, was nicht JSON-fähig ist (ListItems, Funktionen, ...)."""
    return json.loads(json.dumps(obj, default=lambda o: str(o), ensure_ascii=False))


def clean_image(u):
    if not u or not isinstance(u, str):
        return ''
    u = u.split('|')[0].strip()
    if u.lower() in ('null', 'none', 'undefined', 'nan'):
        return ''
    if u.startswith('//'):
        u = 'https:' + u
    if u.startswith(('http://', 'https://', 'data:image/')):
        return u
    return ''


def _txt(v):
    if v is None:
        return ''
    return clean_markup(v) if isinstance(v, str) else str(v)


# ----------------------------------------------------------------------------- Items

def item_kind(raw):
    nf = (raw.get('next_func') or '').strip()
    title = clean_markup(raw.get('title') or raw.get('label') or '')
    if nf in ACTION_FUNCS:
        return KIND_ACTION
    if nf in SEARCH_FUNCS:
        return KIND_SEARCH
    if nf == 'get_hosters':
        return KIND_PLAY
    if 'next_func' not in raw and 'is_playable' not in raw:
        return KIND_PLAY          # z. B. Suchergebnisse ohne Flags (filmpalast): Treffer = Film
    if not nf and raw.get('is_playable'):
        return KIND_PLAY
    if not raw.get('is_playable') and _SEARCH_TITLE.match(title):
        return KIND_SEARCH
    return KIND_FOLDER


def norm_item(raw, provider_id='', provider_name='', parent_title=''):
    if not isinstance(raw, dict):
        return None
    it = jsonable(raw)
    kind = item_kind(it)
    title = clean_markup(it.get('title') or it.get('label') or '') or 'Unbekannt'
    nf = (it.get('next_func') or '').strip()
    if not nf:
        nf = 'get_hosters' if kind == KIND_PLAY else 'load'
    poster = clean_image(it.get('poster')) or clean_image(it.get('thumb')) or clean_image(it.get('icon'))
    it.update({
        'title': title,
        'kind': kind,
        'next_func': nf,
        'is_playable': kind == KIND_PLAY,
        'url': '' if it.get('url') is None else str(it.get('url')),
        'poster': poster,
        'fanart': clean_image(it.get('fanart')) or poster,
        'plot': _txt(it.get('plot')),
        'year': _txt(it.get('year')),
        'mediatype': _txt(it.get('mediatype')),
        'provider_id': provider_id,
        'provider': provider_name,
    })
    it.pop('icon', None) if not clean_image(it.get('icon')) else None
    for k, v in list(it.items()):             # nie „null“ anzeigen: leere Felder der Scraper (None) werden zu ''
        if v is None:
            it[k] = ''
    if parent_title and not it.get('parent_title'):
        it['parent_title'] = parent_title
    return it


def items_from_plugin_url(url):
    """plugin://id/?a=b&c=d -> dict (für Scraper, die nur addDirectoryItem nutzen)."""
    q = dict(parse_qsl(urlparse(url).query, keep_blank_values=True))
    return q


# ----------------------------------------------------------------------------- Hoster

_HDR_SPEC = re.compile(r'^[A-Za-z][\w\-]*=[^&|]*(?:&[A-Za-z][\w\-]*=[^&|]*)*$')
_EXT_FORMAT = {
    '.m3u8': 'hls', '.m3u': 'hls', '.mpd': 'dash',
    '.mp4': 'mp4', '.m4v': 'mp4', '.mov': 'mp4', '.webm': 'webm', '.mkv': 'mkv',
    '.avi': 'avi', '.ts': 'ts', '.mp3': 'audio', '.aac': 'audio', '.m4a': 'audio',
    '.ogg': 'audio', '.flac': 'audio', '.wav': 'audio', '.opus': 'audio', '.flv': 'flv',
}


def split_kodi_url(url):
    """'https://x/y.m3u8|User-Agent=..&Referer=..' -> (url, {headers})"""
    if not isinstance(url, str):
        return '', {}
    if '|' not in url:
        return url.strip(), {}
    base, tail = url.split('|', 1)
    headers = {}
    if _HDR_SPEC.match(tail.strip()):
        for pair in tail.strip().split('&'):
            k, _, v = pair.partition('=')
            headers[k] = unquote(v)
        return base.strip(), headers
    return url.strip(), {}


def classify_format(url, hint=''):
    h = (hint or '').lower()
    if h in ('mpd', 'dash'):
        return 'dash'
    if h in ('hls', 'm3u8'):
        return 'hls'
    path = urlparse(url).path.lower()
    for ext, fmt in _EXT_FORMAT.items():
        if path.endswith(ext):
            return fmt
    low = url.lower()
    if '.m3u8' in low:
        return 'hls'
    if '.mpd' in low:
        return 'dash'
    return 'embed'


def parse_license_key(key):
    """Kodi/inputstream.adaptive-Format: url|headers|post|response"""
    parts = (key or '').split('|')
    url = parts[0].strip()
    headers = {}
    if len(parts) > 1 and parts[1].strip():
        for pair in parts[1].split('&'):
            k, _, v = pair.partition('=')
            if k.strip():
                headers[k.strip()] = unquote(v)
    post = parts[2].strip() if len(parts) > 2 else 'R{SSM}'
    resp = parts[3].strip() if len(parts) > 3 else ''
    return url, headers, post, resp


def _resp_mode(resp):
    """'JBlicense' -> 'json:license:b64' | 'B' -> 'b64' | 'R'/'' -> ''"""
    r = (resp or '').strip()
    if not r or r.upper() == 'R':
        return ''
    if r[0] == 'J':
        rest = r[1:]
        b64 = rest.startswith('B')
        key = rest[1:] if b64 else rest
        return 'json:%s%s' % (key or 'license', ':b64' if b64 else '')
    if r[0] == 'B':
        return 'b64'
    return ''


def _key_system(t):
    t = (t or 'widevine').lower()
    if 'widevine' in t:
        return 'com.widevine.alpha'
    if 'playready' in t:
        return 'com.microsoft.playready'
    if 'clearkey' in t:
        return 'org.w3.clearkey'
    if 'fairplay' in t:
        return 'com.apple.fps.1_0'
    return t


def norm_drm(info, default_headers=None):
    """DRM-Angaben der Scraper -> {'key_system','license_url','license_headers',...} oder None."""
    if not isinstance(info, dict) or not info:
        return None
    lic = (info.get('drm_license') or info.get('license_url') or '').strip()
    headers = dict(default_headers or {})
    resp = ''
    post = 'R{SSM}'
    lk = info.get('license_key')
    if isinstance(lk, str) and lk.strip():
        if '|' in lk or lk.startswith('http'):
            u, h, post, r = parse_license_key(lk)
            lic = lic or u
            headers.update(h)
            resp = _resp_mode(r)
        else:
            return {'key_system': 'org.w3.clearkey', 'clearkey': lk, 'license_url': '',
                    'license_headers': {}, 'supported': True}
    if not lic:
        return None
    if info.get('drm_token'):
        headers.setdefault('x-dt-auth-token', info['drm_token'])
    cert = info.get('server_certificate') or ''
    if isinstance(cert, bytes):
        import base64
        cert = base64.b64encode(cert).decode('ascii')
    ks = _key_system(info.get('license_type') or info.get('drm_type'))
    return {
        'key_system': ks,
        'license_url': lic,
        'license_headers': headers,
        'server_certificate': cert if isinstance(cert, str) else '',
        'certificate_url': info.get('drm_certificate') or '',
        'response': resp,
        'request': 'b64' if post.upper().startswith('B') else 'raw',
        'supported': post in ('R{SSM}', 'B{SSM}', ''),
    }


def _origin_of(domain):
    d = (domain or '').strip()
    if not d:
        return ''
    if not d.startswith('http'):
        d = 'https://' + d
    p = urlparse(d)
    return '%s://%s' % (p.scheme, p.netloc)


def norm_hoster(h, index=0, site_domain='', site_name=''):
    """Eine Zeile aus get_hosters() -> dict. Gibt None bei ungültigen Zeilen."""
    name = url = ''
    quality = lang = source = ''
    direct_flag = False
    drm_info = None
    extra = {}
    subs_raw = None
    if isinstance(h, dict):
        name = h.get('name') or h.get('label') or h.get('hoster') or ''
        url = h.get('url') or h.get('stream') or h.get('link') or ''
        quality = h.get('quality') or ''
        lang = h.get('lang') or h.get('language') or ''
        source = h.get('source') or ''
        direct_flag = bool(h.get('direct') or h.get('is_direct'))
        drm_info = h.get('drm') if isinstance(h.get('drm'), dict) else None
        extra = h.get('headers') if isinstance(h.get('headers'), dict) else {}
        subs_raw = h.get('subtitles') or h.get('subs')
    elif isinstance(h, (list, tuple)):
        if len(h) < 2:
            return None
        name, url = h[0], h[1]
        for v in h[2:]:
            if isinstance(v, bool):
                direct_flag = direct_flag or v
            elif isinstance(v, dict):
                drm_info = v
        strs = [v for v in h[2:] if isinstance(v, str)]
        if len(h) > 3 and isinstance(h[3], str):
            quality = h[3]
        if len(h) > 4 and isinstance(h[4], str):
            lang = h[4]
        if len(h) > 5 and isinstance(h[5], str):
            source = h[5]
        del strs
    elif isinstance(h, str):
        name, url = 'Stream', h
    else:
        return None

    if not isinstance(url, str) or not url.strip():
        return None
    url = url.strip()
    if url.startswith('//'):
        url = 'https:' + url
    url, headers = split_kodi_url(url)
    headers = {**headers, **extra}
    if not url.startswith(('http://', 'https://', 'msfile://')):     # msfile: Datei, die ein Kodi-Addon auf dem Gerät erzeugt hat
        return None

    hint = ''
    live = False
    if drm_info:
        hint = str(drm_info.get('manifest_type') or '')
        live = bool(drm_info.get('is_live'))
        if drm_info.get('stream_headers') and isinstance(drm_info['stream_headers'], dict):
            headers.update(drm_info['stream_headers'])
    fmt = classify_format(url, hint)
    if fmt == 'embed' and direct_flag:
        fmt = 'direct'   # Scraper sagt "direkt", aber ohne Endung: Typ wird beim Abspielen geprüft

    drm = None
    if drm_info:
        origin = _origin_of(site_domain)
        dflt = {'User-Agent': DEFAULT_UA}
        if origin:
            dflt.update({'Origin': origin, 'Referer': origin + '/'})
        if drm_info.get('exact_license_headers'):
            dflt = {}        # Scraper will die Lizenz-Kopfzeilen genau wie im Kodi-Addon (nur was in license_key steht)
        drm = norm_drm(drm_info, dflt)
        if drm and origin:
            headers.setdefault('Origin', origin)
            headers.setdefault('Referer', origin + '/')

    out = {
        'id': index,
        'name': clean_markup(name) or 'Stream',
        'url': url,
        'format': fmt,                      # hls | dash | mp4 | webm | ts | audio | embed ...
        'direct': fmt != 'embed',
        'quality': clean_markup(quality),
        'lang': clean_markup(lang),
        'source': clean_markup(source) or site_name,
        'headers': headers,
        'drm': drm,
        'live': live,
    }
    if subs_raw:
        from . import subs as _subs
        sl = _subs.norm_subtitles(subs_raw)
        if sl:
            out['subtitles'] = sl
    return out


def norm_hosters(raw, site_domain='', site_name=''):
    out, seen = [], set()
    for i, h in enumerate(raw or []):
        n = norm_hoster(h, len(out), site_domain, site_name)
        if not n:
            continue
        key = (n['url'], n['name'])
        if key in seen:
            continue
        seen.add(key)
        out.append(n)
    # direkte Streams zuerst (stabil), dann Embeds
    out.sort(key=lambda x: (0 if x['direct'] else 1))
    for i, n in enumerate(out):
        n['id'] = i
    return out


def hoster_from_resolved(path, listitem=None, site_domain='', site_name=''):
    """xbmc.Player().play()/setResolvedUrl() -> Hoster. Versteht die ListItem-Eigenschaften von inputstream.adaptive
    (license_type/-key, server_certificate, manifest_type, stream-/manifest_headers) und inputstream.ffmpegdirect
    (manifest_type, is_realtime_stream) sowie den MIME-Typ als Formathinweis."""
    props = dict(getattr(listitem, 'properties', {}) or {}) if listitem is not None else {}
    props = {str(k).lower(): v for k, v in props.items()}
    drm_info = {}
    lt = props.get('inputstream.adaptive.license_type')
    lk = props.get('inputstream.adaptive.license_key')
    if lk:
        drm_info['license_key'] = lk
        drm_info['license_type'] = lt or 'com.widevine.alpha'
        cert = props.get('inputstream.adaptive.server_certificate')
        if cert:
            drm_info['server_certificate'] = cert
    mt = (props.get('inputstream.adaptive.manifest_type') or props.get('inputstream.ffmpegdirect.manifest_type') or '').strip()
    if not mt:
        mime = str(getattr(listitem, 'mime', '') or '').lower()
        if 'mpegurl' in mime:
            mt = 'hls'
        elif 'dash' in mime:
            mt = 'mpd'
    if mt:
        drm_info['manifest_type'] = mt
    if str(props.get('inputstream.ffmpegdirect.is_realtime_stream') or '').lower() == 'true':
        drm_info['is_live'] = True
    heads = {}
    for key in ('inputstream.adaptive.manifest_headers', 'inputstream.adaptive.stream_headers'):
        sh = props.get(key)
        if sh:
            heads.update({k: unquote(v) for k, _, v in (p.partition('=') for p in str(sh).split('&')) if k})
    if heads:
        drm_info['stream_headers'] = heads
    row = [getattr(listitem, 'getLabel', lambda: site_name)() or site_name, path]
    if drm_info:
        row.append(drm_info)
    row.append(True)                       # setResolvedUrl/Player().play: Kodi spielt genau diese Adresse ab (auch ohne Dateiendung, z. B. lokaler Stream-Server)
    hs = norm_hoster(row, 0, site_domain, site_name)
    subs = getattr(listitem, 'subtitles', None) if listitem is not None else None
    if hs and subs:
        from . import subs as _subs
        sl = _subs.norm_subtitles(subs)
        if sl:
            hs['subtitles'] = sl
    return hs
