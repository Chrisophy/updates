# -*- coding: utf-8 -*-
# IT('s) Possible
# MovieScout - gemeinsame EPG-Logik (XMLTV) für M3U / IPTV und Stalker-Portale.
# Der Guide aus den Engine-Einstellungen ("epg_url") wird einmal geladen und gecacht; Sender werden zuerst über
# die Kennung (tvg-id / xmltv_id), danach über den Namen zugeordnet - die Kennungen von Playlist/Portal und Guide
# passen in der Praxis oft nicht zusammen.
import gzip
import re
import threading
import time
from datetime import datetime, timedelta, timezone

import xbmcaddon
from resources.lib import multiquest

_XMLTV_TIME = re.compile(r'^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4}|[+-]\d{2}:?\d{2})?$')
_LOCK = threading.Lock()
_EPG_CACHE = {}           # url -> (geladen_um, {'progs': {id: [(start, stop, titel)]}, 'names': {name: id}, ...})
_EPG_TTL = 3 * 3600


def epg_url():
    return (xbmcaddon.all_settings().get('epg_url') or '').strip()


def clear():
    with _LOCK:
        _EPG_CACHE.clear()


def _parse_xmltv_time(s):
    m = _XMLTV_TIME.match((s or '').strip())
    if not m:
        return None
    y, mo, d, h, mi, se, off = m.groups()
    try:
        dt = datetime(int(y), int(mo), int(d), int(h), int(mi), int(se))
    except ValueError:
        return None
    if off:
        off = off.replace(':', '')
        sign = 1 if off[0] == '+' else -1
        oh, om = int(off[1:3]), int(off[3:5])
        dt = dt - sign * timedelta(hours=oh, minutes=om)
    return dt.replace(tzinfo=timezone.utc)


_EPG_STATE = {'loading': False, 'error': '', 'at': 0, 'programmes': 0, 'epg_channels': 0}
_EPG_FAIL_TTL = 600       # nach einem Fehler 10 Minuten nicht erneut versuchen (statt bei jedem Öffnen 40 s zu warten)
_QUALITY = re.compile(r'\b(?:hd|uhd|fhd|sd|4k|hevc|h265|h264|1080p?|720p?|raw|backup)\b', re.I)
_ALIASES = {'rtlzwei': 'rtl2', 'kabeleins': 'kabel1', 'pro7': 'prosieben', 'ard': 'daserste'}


def _norm_name(s):
    """Sendername vergleichbar machen: 'Das Erste HD' / 'DasErste' / 'Das Erste' -> 'daserste'."""
    import unicodedata
    s = unicodedata.normalize('NFKD', str(s or '')).encode('ascii', 'ignore').decode('ascii').lower()
    s = re.sub(r'^[\s|\[(]*(?:de|ger|deu|at|aut|ch|che|uk|us)\s*[|\])\:\-]+\s*', '', s)      # Länderpräfix: "DE: ZDF", "|DE| ZDF"
    s = re.sub(r'[\(\[].*?[\)\]]', ' ', s)
    s = _QUALITY.sub(' ', s)
    for _ in range(3):                                                   # Länderkürzel am Rand: "ZDF FHD DE", "DE ZDF"
        s = re.sub(r'(?:^|\s)(?:de|ger|deu|germany|deutschland|at|ch)\s*$', ' ', s.strip())
        s = re.sub(r'^\s*(?:de|ger|deu|germany|deutschland)\s+', ' ', s)
    s = re.sub(r'[^a-z0-9]+', '', s.replace('&', 'und'))
    return _ALIASES.get(s, s)


def _fix_mojibake(t):
    """Manche Guides haben doppelt kodierte Umlaute ('fÃ¼r')."""
    if 'Ã' in t or 'â€' in t:
        for enc in ('latin-1', 'cp1252'):
            try:
                return t.encode(enc).decode('utf-8')
            except Exception:                               # noqa: BLE001
                continue
    return t


def _epg_fetch(url):
    """Holt und liest den Guide. Gibt {'progs': {id: [...]}, 'names': {norm: id}, 'ids': set} zurück, wirft bei Fehlern."""
    import io
    import xml.etree.ElementTree as ET
    r = multiquest.get(url, headers={'User-Agent': 'MovieScout'}, timeout=60)
    if r.status_code != 200:
        raise RuntimeError('EPG nicht erreichbar (HTTP %s)' % r.status_code)
    data = r.content
    if url.lower().split('?')[0].endswith('.gz') or data[:2] == b'\x1f\x8b':
        try:
            data = gzip.decompress(data)
        except Exception:                                   # noqa: BLE001  (abgeschnittener Download: Lesbares behalten)
            import zlib
            data = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(data)
    if not data.strip():
        raise RuntimeError('EPG-Datei ist leer')
    now = datetime.now(timezone.utc)
    win_from, win_to = now.timestamp() - 3600, now.timestamp() + 36 * 3600
    progs, names, display = {}, {}, {}
    n = 0
    try:
        for _, el in ET.iterparse(io.BytesIO(data), events=('end',)):
            if el.tag == 'channel':
                cid = el.get('id') or ''
                if cid:
                    display[cid] = [(d.text or '').strip() for d in el.findall('display-name') if (d.text or '').strip()]
                el.clear()
            elif el.tag == 'programme':
                try:
                    ch = el.get('channel') or ''
                    start = _parse_xmltv_time(el.get('start'))
                    stop = _parse_xmltv_time(el.get('stop'))
                    if not ch or not start or not stop or stop.timestamp() < win_from or start.timestamp() > win_to:
                        continue
                    title_el = el.find('title')
                    title = _fix_mojibake((title_el.text or '').strip()) if title_el is not None else ''
                    progs.setdefault(ch, []).append((start, stop, title))
                    n += 1
                finally:
                    el.clear()
    except ET.ParseError:
        if not n:
            raise RuntimeError('EPG-Datei ist kein gültiges XMLTV')
        # abgeschnittene Datei: bis hierhin Gelesenes behalten
    for ch in progs:
        progs[ch].sort(key=lambda t: t[0])
    for cid, dn in display.items():                          # Name -> Kennung (bei Doppelten die mit den meisten Sendungen)
        for nm in dn:
            k = _norm_name(nm)
            if k and (k not in names or len(progs.get(cid, ())) > len(progs.get(names[k], ()))):
                names[k] = cid
    for cid in progs:                                        # Kennungen ohne <channel> auch über ihren Namen auffindbar
        k = _norm_name(cid)
        if k and k not in names:
            names[k] = cid
    if not n:
        raise RuntimeError('EPG enthält keine aktuellen Sendungen (Datei veraltet?)')
    return {'progs': progs, 'names': names, 'programmes': n, 'epg_channels': len(progs)}


def epg_id(epg, c):
    """Kennung des Senders im Guide: erst tvg-id, dann über den Namen (die Kennungen von M3U und Guide passen oft nicht)."""
    if not epg:
        return ''
    progs, names = epg['progs'], epg['names']
    tid = c.get('tvg_id') or ''
    if tid and tid in progs:
        return tid
    for cand in (tid.rsplit('.', 1)[0] if '.' in tid else tid, c.get('tvg_name') or '', c.get('name') or ''):
        k = _norm_name(cand)
        if k and k in names and names[k] in progs:
            return names[k]
    return ''


def get(wait=True):
    """Der Guide wird einmal komplett geladen und gecacht. wait=False: nur aus dem Cache (und im Hintergrund holen)."""
    url_ = epg_url()
    if not url_:
        return {}
    with _LOCK:
        hit = _EPG_CACHE.get(url_)
        if hit and time.time() - hit[0] < (_EPG_TTL if hit[1] else _EPG_FAIL_TTL):
            return hit[1]
        busy = _EPG_STATE['loading']
        if not busy:
            _EPG_STATE['loading'] = True
    if busy:                                                 # läuft schon (z. B. im Hintergrund): kurz darauf warten
        for _ in range(120 if wait else 0):
            time.sleep(0.5)
            with _LOCK:
                hit = _EPG_CACHE.get(url_)
                if not _EPG_STATE['loading']:
                    return hit[1] if hit else {}
        return {}
    if not wait:
        threading.Thread(target=lambda: _load_now(url_), daemon=True).start()
        return {}
    return _load_now(url_)


def _load_now(url):
    try:
        epg = _epg_fetch(url)
        err = ''
    except Exception as e:                                   # noqa: BLE001
        epg, err = {}, str(e) or type(e).__name__
    with _LOCK:
        _EPG_CACHE[url] = (time.time(), epg)
        _EPG_STATE.update(loading=False, error=err, at=time.time(),
                          programmes=(epg or {}).get('programmes', 0), epg_channels=(epg or {}).get('epg_channels', 0))
    return epg


def _local(dt):
    """Ortszeit; läuft das Gerät ohne Zeitzone (UTC), gilt mitteleuropäische Zeit mit Sommerzeit."""
    loc = dt.astimezone()
    off = loc.utcoffset()
    if off and off.total_seconds() != 0:
        return loc
    y = dt.year
    def last_sun(m):
        d = datetime(y, m, 31, 1, tzinfo=timezone.utc)
        return d - timedelta(days=(d.weekday() + 1) % 7)
    return dt + timedelta(hours=2 if last_sun(3) <= dt < last_sun(10) else 1)


def now_next(epg, c):
    rows = (epg or {}).get('progs', {}).get(epg_id(epg, c)) or []
    if not rows:
        return '', ''
    now = datetime.now(timezone.utc)
    cur = nxt = None
    for i, (start, stop, title) in enumerate(rows):
        if start <= now < stop:
            cur = (title, stop)
            if i + 1 < len(rows):
                nxt = rows[i + 1][2]
            break
        if start > now and nxt is None and cur is None:
            nxt = title
    parts = []
    if cur:
        parts.append('Jetzt: %s (bis %s)' % (cur[0], _local(cur[1]).strftime('%H:%M')))
    if nxt:
        parts.append('Danach: %s' % nxt)
    return ' · '.join(parts), (cur[0] if cur else '')


def prefetch():
    """Guide im Hintergrund holen (blockiert nicht)."""
    return get(wait=False)


def status_line(channels):
    """Eine Infozeile für die Menüs: ob/wie viel EPG geladen wurde und für wie viele Sender es passt (None ohne EPG-Adresse)."""
    if not epg_url():
        return None
    epg = get(wait=False)
    with _LOCK:
        st = dict(_EPG_STATE)
    if st['loading'] and not epg:
        return 'EPG wird geladen … (später erneut öffnen bzw. aktualisieren)'
    if epg:
        n = sum(1 for c in channels if epg_id(epg, c))
        text = 'EPG: %d von %d Sendern zugeordnet (%d Sendungen)' % (n, len(channels), epg['programmes'])
        return text + (' – Sendernamen passen nicht zum Guide' if channels and n == 0 else '')
    return 'EPG: %s' % (st['error'] or 'noch nicht geladen')


def unmatched(channels, limit=15):
    """Namen von Sendern ohne Guide-Eintrag (zur Fehlersuche, wird in der Statuszeile unter "Info" gezeigt)."""
    epg = get(wait=False)
    if not epg:
        return []
    out = []
    for c in channels:
        nm = (c.get('name') or '').strip()
        if nm and not nm.startswith(('#', '*', '=')) and not epg_id(epg, c):
            out.append(nm)
            if len(out) >= limit:
                break
    return out

