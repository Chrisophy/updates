# -*- coding: utf-8 -*-
"""Stream-/Lizenz-Proxy.

Browser dürfen (anders als Kodi) keine beliebigen Header (Referer, Origin, User-Agent) setzen und
scheitern an fehlendem CORS. Dieser Proxy holt Medien serverseitig mit den vom Scraper geforderten
Headern und schreibt HLS-/DASH-Manifeste so um, dass auch alle Segmente über ihn laufen.

Sicherheit: Ziele im lokalen Netz/Loopback sind gesperrt (SSRF-Schutz), außer
MOVIESCOUT_ALLOW_PRIVATE=1. Optional schützt MOVIESCOUT_TOKEN alle /api-Aufrufe.
"""
import base64
import gzip
import ipaddress
import json
import os
import re
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
import zlib
from urllib.parse import quote, urljoin, urlparse

from resources.lib import multiquest

from . import normalize as N

ALLOW_PRIVATE = os.environ.get('MINIKODI_ALLOW_PRIVATE', '').lower() in ('1', 'true', 'yes')
MAX_MANIFEST = 12 * 1024 * 1024
TIMEOUT = 25


class Blocked(Exception):
    pass


# ----------------------------------------------------------------------------- Token

def b64e(obj):
    raw = json.dumps(obj, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def b64d(s):
    s = (s or '') + '=' * (-len(s or '') % 4)
    return json.loads(base64.urlsafe_b64decode(s.encode('ascii')).decode('utf-8'))


def pack_headers(headers):
    h = {k: v for k, v in (headers or {}).items()
         if v and not (k.lower() == 'user-agent' and v == N.DEFAULT_UA)}
    return b64e(h) if h else ''


def unpack_headers(tok):
    if not tok:
        return {}
    try:
        h = b64d(tok)
        return h if isinstance(h, dict) else {}
    except Exception:
        return {}


# ----------------------------------------------------------------------------- Sicherheit

_NAT64 = ipaddress.ip_network('64:ff9b::/96')


def _real_ip(ip):
    """Mobilnetze mit IPv6-only/DNS64 liefern Adressen wie 64:ff9b::5db8:d822 (= IPv4 93.184.216.34). Die gelten sonst
    als 'reserviert' und würden fälschlich gesperrt - geprüft wird deshalb die eingebettete IPv4-Adresse."""
    if ip.version == 6:
        if ip.ipv4_mapped:
            return ip.ipv4_mapped
        if ip in _NAT64:
            return ipaddress.IPv4Address(int(ip) & 0xFFFFFFFF)
    return ip


LOCAL_OK = set()          # (host, port) lokaler Mini-Server, die ein installiertes Kodi-Addon selbst gestartet hat (z. B. NewPipe)


def allow_local(url):
    """Erlaubt dem Proxy genau diesen lokalen Server (Host + Port), weil ein Addon der Engine ihn als Stream-Adresse genannt hat."""
    try:
        p = urlparse(str(url).split('|')[0])
        if p.scheme in ('http', 'https') and p.hostname in ('127.0.0.1', 'localhost', '::1') and p.port:
            LOCAL_OK.add(('127.0.0.1' if p.hostname != '::1' else '::1', p.port))
            LOCAL_OK.add((p.hostname, p.port))
            return True
    except ValueError:
        pass
    return False


def check_url(url):
    p = urlparse(url)
    if p.scheme not in ('http', 'https') or not p.hostname:
        raise Blocked('Nur http(s)-Ziele erlaubt')
    if ALLOW_PRIVATE:
        return
    if (p.hostname, p.port) in LOCAL_OK:
        return
    try:
        infos = socket.getaddrinfo(p.hostname, p.port or (443 if p.scheme == 'https' else 80),
                                   proto=socket.IPPROTO_TCP)
    except socket.gaierror as e:
        raise Blocked('DNS-Fehler für %s: %s' % (p.hostname, e))
    for info in infos:
        ip = _real_ip(ipaddress.ip_address(info[4][0].split('%')[0]))
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
                or ip.is_multicast or ip.is_unspecified):
            raise Blocked('Ziel im lokalen Netz gesperrt (MOVIESCOUT_ALLOW_PRIVATE=1 erlaubt es)')


class _GuardRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        check_url(urljoin(req.full_url, newurl))
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _opener():
    ctx = multiquest._ssl_context()
    return urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), _GuardRedirect())


# ----------------------------------------------------------------------------- Abruf

class Upstream:
    def __init__(self, status, headers, final_url, resp):
        self.status, self.headers, self.final_url, self.resp = status, headers, final_url, resp

    def read(self, n=-1):
        return self.resp.read(n) if n and n > 0 else self.resp.read()

    def close(self):
        try:
            self.resp.close()
        except Exception:
            pass

    def iter(self, first=b'', chunk=65536):
        try:
            if first:
                yield first
            while True:
                data = self.resp.read(chunk)
                if not data:
                    break
                yield data
        finally:
            self.close()


def fetch(method, url, headers=None, body=None, range_header='', timeout=TIMEOUT):
    check_url(url)
    h = {'User-Agent': N.DEFAULT_UA, 'Accept': '*/*', 'Accept-Encoding': 'identity'}
    h.update({k: v for k, v in (headers or {}).items() if k.lower() not in ('host', 'content-length')})
    if range_header:
        h['Range'] = range_header
    req = urllib.request.Request(url, data=body, method=method, headers=h)
    try:
        resp = _opener().open(req, timeout=timeout)
        status = resp.status
    except urllib.error.HTTPError as e:
        resp, status = e, e.code
    hdrs = {k.lower(): v for k, v in resp.headers.items()}
    final = resp.geturl() if hasattr(resp, 'geturl') else url
    return Upstream(status, hdrs, final, resp)


def _decode_body(up, data):
    enc = (up.headers.get('content-encoding') or '').lower()
    try:
        if 'gzip' in enc:
            return gzip.decompress(data)
        if 'deflate' in enc:
            try:
                return zlib.decompress(data)
            except zlib.error:
                return zlib.decompress(data, -zlib.MAX_WBITS)
    except Exception:
        pass
    return data


# ----------------------------------------------------------------------------- Erkennung

_MEDIA_EXT = ('.mp4', '.m4v', '.webm', '.mkv', '.ts', '.m4s', '.mp3', '.aac', '.m4a', '.mov', '.avi',
              '.jpg', '.png', '.vtt', '.srt', '.key', '.cmfv', '.cmfa')


def sniff_format(content_type, url, head):
    ct = (content_type or '').lower().split(';')[0].strip()
    h = head or b''
    if h.lstrip(b'\xef\xbb\xbf \r\n\t')[:7] == b'#EXTM3U':
        return 'hls'
    if b'<MPD' in h[:4096]:
        return 'dash'
    if 'mpegurl' in ct:
        return 'hls'
    if 'dash+xml' in ct:
        return 'dash'
    if h[4:8] == b'ftyp' or ct in ('video/mp4', 'application/mp4'):
        return 'mp4'
    if h[:4] == b'\x1a\x45\xdf\xa3' or 'webm' in ct or 'matroska' in ct:
        return 'webm' if 'webm' in ct else 'mkv'
    if 'mp2t' in ct or (len(h) > 188 and h[0] == 0x47 and h[188] == 0x47):
        return 'ts'
    if ct.startswith('video/'):
        return 'mp4'
    if ct.startswith('audio/'):
        return 'audio'
    f = N.classify_format(url)
    return f if f != 'embed' else 'unknown'


def probe(url, headers=None):
    """Ermittelt Typ und endgültige URL eines Streams ohne Dateiname-Hinweis."""
    up = fetch('GET', url, headers, range_header='bytes=0-4095', timeout=15)
    try:
        head = up.read(4096)
    finally:
        up.close()
    head = _decode_body(up, head)
    return {
        'status': up.status,
        'final_url': up.final_url,
        'content_type': up.headers.get('content-type', ''),
        'format': sniff_format(up.headers.get('content-type', ''), up.final_url, head)
        if up.status < 400 else 'error',
    }


# ----------------------------------------------------------------------------- Umschreiben

def proxied(abs_url, htok, prefix='', auth=''):
    q = '%s/api/proxy?u=%s' % (prefix, quote(abs_url, safe=''))
    if htok:
        q += '&h=' + htok
    if auth:
        q += '&token=' + quote(auth, safe='')
    return q


def pathform(abs_base, headers, prefix='', auth=''):
    tok = {'b': abs_base}
    h = {k: v for k, v in (headers or {}).items() if v and not (k.lower() == 'user-agent' and v == N.DEFAULT_UA)}
    if h:
        tok['h'] = h
    if auth:
        tok['a'] = auth
    return '%s/api/p/%s/' % (prefix, b64e(tok))


_URI_ATTR = re.compile(r'URI="([^"]*)"')


def rewrite_hls(text, base, headers, prefix='', auth=''):
    htok = pack_headers(headers)
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            out.append(line)
        elif s.startswith('#'):
            if 'URI="' in s:
                line = _URI_ATTR.sub(
                    lambda m: 'URI="%s"' % (proxied(urljoin(base, m.group(1)), htok, prefix, auth)
                                            if m.group(1) and not m.group(1).startswith('data:') else m.group(1)),
                    line)
            out.append(line)
        else:
            out.append(proxied(urljoin(base, s), htok, prefix, auth))
    return '\n'.join(out) + '\n'


_TAG = re.compile(r'<!--.*?-->|<!\[CDATA\[.*?\]\]>|<\?.*?\?>|<(/?)([A-Za-z_][\w:.\-]*)([^>]*?)(/?)>', re.S)


_TPL_ATTR = re.compile(r'''(\b(?:media|initialization|sourceURL|index)=)(["'])([^"']*)\2''')


def _rewrite_template_attrs(text, base, headers, prefix, auth):
    """SegmentTemplate/Initialization/SegmentURL mit '/pfad/...' oder 'https://...' über den Pfad-Proxy leiten."""
    def fix(m):
        attr, q, val = m.group(1), m.group(2), m.group(3)
        if val.startswith('//'):
            val = urlparse(base).scheme + ':' + val
        if val.startswith('/'):
            pu = urlparse(base)
            return '%s%s%s%s%s' % (attr, q, pathform('%s://%s/' % (pu.scheme, pu.netloc), headers, prefix, auth) , val[1:], q)
        mm = re.match(r'(https?://[^/]+/)(.*)$', val, re.I | re.S)
        if mm:
            return '%s%s%s%s%s' % (attr, q, pathform(mm.group(1), headers, prefix, auth), mm.group(2), q)
        return m.group(0)
    return _TPL_ATTR.sub(fix, text)


def rewrite_mpd(text, base, headers, prefix='', auth=''):
    """BaseURL-Elemente auf den Pfad-Proxy zeigen lassen (relative Segmente laufen dann mit)."""
    out, pos, depth = [], 0, 0
    in_base = None            # (depth, start_of_text)
    top_has_base = False
    root_end = None
    for m in _TAG.finditer(text):
        closing, name, _attrs, selfclose = m.group(1), m.group(2), m.group(3), m.group(4)
        if name is None:
            continue
        local = name.split(':')[-1]
        if not closing and not selfclose:
            depth += 1
            if local == 'MPD' and depth == 1 and root_end is None:
                root_end = m.end()
            if local == 'BaseURL':
                in_base = (depth, m.end())
        elif closing:
            if local == 'BaseURL' and in_base and in_base[0] == depth:
                value = text[in_base[1]:m.start()].strip()
                if value:
                    top = depth == 2
                    # Auch verschachtelte BaseURLs, die vom Host-Wurzelverzeichnis ('/pfad/') oder absolut ('https://...')
                    # ausgehen, müssen umgeschrieben werden - sonst löst der Browser sie gegen die Engine auf (-> 404).
                    if top or re.match(r'(https?:)?//', value, re.I) or value.startswith('/'):
                        top_has_base = top_has_base or top
                        out.append(text[pos:in_base[1]])
                        out.append(pathform(urljoin(base, value), headers, prefix, auth))
                        pos = m.start()
                in_base = None
            depth -= 1
    out.append(text[pos:])
    result = ''.join(out)
    result = _rewrite_template_attrs(result, base, headers, prefix, auth)
    if not top_has_base and root_end is not None:
        ins = '<BaseURL>%s</BaseURL>' % pathform(base, headers, prefix, auth)
        # root_end bezieht sich auf das Original; Einfügeposition im Ergebnis ist identisch,
        # weil vor dem Root-Tag nichts umgeschrieben wird.
        result = result[:root_end] + ins + result[root_end:]
    return result


# ----------------------------------------------------------------------------- Antwort

_PASS = ('content-type', 'content-length', 'content-range', 'accept-ranges', 'last-modified',
         'etag', 'content-encoding')


def _license_response(data, mode):
    """Antwort des Lizenzservers gemäß inputstream.adaptive-Regel ('JBlicense') umformen."""
    if not mode:
        return data
    try:
        if mode == 'b64':
            return base64.b64decode(data)
        if mode.startswith('json:'):
            _, key, *rest = mode.split(':')
            obj = json.loads(data.decode('utf-8'))
            for part in key.split('.'):
                obj = obj[part]
            return base64.b64decode(obj) if 'b64' in rest else (
                obj.encode('utf-8') if isinstance(obj, str) else json.dumps(obj).encode())
    except Exception:
        return data
    return data


def serve(method, url, headers, req_range='', body=None, prefix='', auth='', resp_mode='',
          req_mode=''):
    """Gibt (status, headers, body|iterator) zurück."""
    if req_mode == 'b64' and body:
        body = base64.b64encode(body)
    up = fetch(method, url, headers, body=body, range_header=req_range)
    hdrs = {k: v for k, v in up.headers.items() if k in _PASS}
    ct = up.headers.get('content-type', '')
    path = urlparse(up.final_url).path.lower()

    if method == 'POST' or resp_mode:
        data = _decode_body(up, up.read())
        up.close()
        data = _license_response(data, resp_mode)
        hdrs.pop('content-encoding', None)
        hdrs['content-length'] = str(len(data))
        return up.status, hdrs, data

    if method == 'HEAD' or up.status in (204, 304):
        up.close()
        return up.status, hdrs, b''

    known_media = path.endswith(_MEDIA_EXT) or ct.lower().startswith(('video/', 'audio/', 'image/'))
    first = b''
    kind = 'other'
    if not known_media and up.status < 400:
        first = up.read(2048)
        kind = sniff_format(ct, up.final_url, _decode_body(up, first))
    if kind in ('hls', 'dash'):
        data = _decode_body(up, first + up.resp.read(MAX_MANIFEST))
        up.close()
        text = data.decode('utf-8', 'replace')
        text = (rewrite_hls if kind == 'hls' else rewrite_mpd)(text, up.final_url, headers, prefix, auth)
        raw = text.encode('utf-8')
        out = {'content-type': 'application/vnd.apple.mpegurl' if kind == 'hls' else 'application/dash+xml',
               'content-length': str(len(raw)), 'cache-control': 'no-store'}
        return up.status, out, raw
    return up.status, hdrs, up.iter(first)
