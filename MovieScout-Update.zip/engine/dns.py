# -*- coding: utf-8 -*-
"""DNS-Wechsler für MovieScout: Namensauflösung der Engine über einen frei wählbaren DNS-over-HTTPS-Dienst.

Hilft, wenn der DNS des Routers/Providers Seiten nicht auflöst oder sperrt, und bringt Tempo/Datenschutz bei schwachen
Router-DNS. Gewählt wird in den Einstellungen (Bereich „Netzwerk“): Gerät/Router (Standard), Cloudflare, Google, Quad9,
AdGuard oder eine eigene DoH-Adresse.

Reichweite - ehrlich: Das gilt für alles, was die ENGINE aufruft (Scraper, Hoster-Abfragen, TMDB, Stream-Proxy). Direkte
Verbindungen des Browsers/Players der App zu Videoservern nutzen weiter den DNS des Systems; systemweit geht das nur in
Android unter Einstellungen → Netzwerk → Privates DNS.

Technik: socket.getaddrinfo wird ersetzt. Namen im eigenen Netz, IP-Adressen und localhost gehen unverändert durch.
Schlägt die DoH-Abfrage fehl, fällt die Auflösung selbstständig auf den normalen System-DNS zurück - der DNS-Wechsler
kann also nie dazu führen, dass gar nichts mehr geht. Antworten werden kurz zwischengespeichert.
"""
import base64
import http.client
import logging
import os
import socket
import ssl
import struct
import threading
import time
from urllib.parse import urlparse

from kodi_runtime import xbmcaddon

log = logging.getLogger('dns')

# Wire-Format (RFC 8484) per POST: funktioniert bei allen Diensten gleich. IP-Adressen statt Namen -> kein DNS nötig.
PRESETS = {
    'system': {'name': 'Gerät/Router (Standard)', 'urls': []},
    'cloudflare': {'name': 'Cloudflare (1.1.1.1)', 'urls': ['https://1.1.1.1/dns-query', 'https://1.0.0.1/dns-query']},
    'google': {'name': 'Google (8.8.8.8)', 'urls': ['https://8.8.8.8/dns-query', 'https://8.8.4.4/dns-query']},
    'quad9': {'name': 'Quad9 (9.9.9.9, mit Schadseiten-Filter)', 'urls': ['https://9.9.9.9/dns-query', 'https://149.112.112.112/dns-query']},
    'adguard': {'name': 'AdGuard (ohne Werbung/Tracker)', 'urls': ['https://94.140.14.14/dns-query', 'https://94.140.15.15/dns-query']},
    'custom': {'name': 'Eigene DoH-Adresse', 'urls': []},
}

_ORIG = socket.getaddrinfo
_lock = threading.Lock()
_CACHE = {}                     # (name, 'A'/'AAAA') -> (läuft ab, [ips])
_CONF = {'t': 0.0, 'v': None}
STATS = {'doh': 0, 'cached': 0, 'fallback': 0, 'last_error': '', 'last_ms': 0}
_CTX = None


def _ctx():
    global _CTX
    if _CTX is None:
        try:
            import certifi
            _CTX = ssl.create_default_context(cafile=certifi.where())
        except Exception:                                   # noqa: BLE001
            _CTX = ssl.create_default_context()
    return _CTX


def _conf():
    now = time.time()
    with _lock:
        if _CONF['v'] is not None and now - _CONF['t'] < 3.0:
            return _CONF['v']
    try:
        s = xbmcaddon.all_settings()
    except Exception:                                       # noqa: BLE001
        s = {}
    mode = str(s.get('dns_mode') or 'system').lower()
    if mode not in PRESETS:
        mode = 'system'
    urls = list(PRESETS[mode]['urls'])
    custom = str(s.get('dns_custom') or '').strip()
    if mode == 'custom':
        urls = [custom] if custom.lower().startswith('https://') else []
    v = {'mode': mode, 'urls': urls}
    with _lock:
        _CONF.update(t=now, v=v)
    return v


def invalidate():
    with _lock:
        _CONF.update(t=0.0, v=None)
        _CACHE.clear()


# ----------------------------------------------------------------------------- DNS-Nachrichten

def _build(name, qtype):
    tid = os.urandom(2)
    labels = [p for p in name.rstrip('.').split('.') if p]
    q = b''.join(bytes([len(p.encode('idna'))]) + p.encode('idna') for p in labels) + b'\x00' + struct.pack('>HH', qtype, 1)
    return tid, tid + b'\x01\x00' + struct.pack('>HHHH', 1, 0, 0, 0) + q


def _skip_name(msg, pos):
    while True:
        ln = msg[pos]
        if ln == 0:
            return pos + 1
        if ln & 0xC0 == 0xC0:
            return pos + 2
        pos += 1 + ln


def _parse(msg, tid, qtype):
    if len(msg) < 12 or msg[:2] != tid:
        raise ValueError('Antwort passt nicht zur Anfrage')
    flags, qd, an = struct.unpack('>HHH', msg[2:8])
    if flags & 0x8000 == 0:
        raise ValueError('keine Antwort')
    rcode = flags & 0xF
    if rcode not in (0, 3):                                  # 3 = Name existiert nicht
        raise ValueError('DNS-Fehlercode %d' % rcode)
    pos = 12
    for _ in range(qd):
        pos = _skip_name(msg, pos) + 4
    ips, ttl_min = [], 3600
    for _ in range(an):
        pos = _skip_name(msg, pos)
        rtype, _cls, ttl, rdlen = struct.unpack('>HHIH', msg[pos:pos + 10])
        pos += 10
        rd = msg[pos:pos + rdlen]
        pos += rdlen
        if rtype == qtype == 1 and rdlen == 4:
            ips.append(socket.inet_ntoa(rd))
            ttl_min = min(ttl_min, ttl)
        elif rtype == qtype == 28 and rdlen == 16:
            ips.append(socket.inet_ntop(socket.AF_INET6, rd))
            ttl_min = min(ttl_min, ttl)
    return ips, ttl_min


def _doh(url, name, qtype, timeout=3.5):
    u = urlparse(url)
    tid, payload = _build(name, qtype)
    port = u.port or 443
    # Der DoH-Server selbst wird mit dem System-DNS gesucht (bei IP-Adressen entfällt das)
    infos = _ORIG(u.hostname, port, socket.AF_UNSPEC, socket.SOCK_STREAM)
    last = None
    for af, st, pr, _c, sa in sorted(infos, key=lambda i: i[0] != socket.AF_INET):
        try:
            raw = socket.socket(af, st, pr)
            raw.settimeout(timeout)
            raw.connect(sa)
            tls = _ctx().wrap_socket(raw, server_hostname=u.hostname)
            conn = http.client.HTTPSConnection(u.hostname, port, timeout=timeout)
            conn.sock = tls
            conn.request('POST', u.path or '/dns-query', body=payload,
                         headers={'Content-Type': 'application/dns-message', 'Accept': 'application/dns-message'})
            r = conn.getresponse()
            data = r.read()
            conn.close()
            if r.status != 200:
                raise ValueError('HTTP %d' % r.status)
            return _parse(data, tid, qtype)
        except Exception as e:                               # noqa: BLE001
            last = e
    raise last or OSError('DoH nicht erreichbar')


def _lookup(urls, name, qtype):
    last = None
    for url in urls:
        try:
            return _doh(url, name, qtype)
        except Exception as e:                               # noqa: BLE001
            last = e
    raise last or OSError('kein DoH-Dienst eingetragen')


def resolve(name, urls=None, want6=False):
    """Namen über DoH auflösen -> ([IPv4 …], [IPv6 …]). Wirft bei Fehlschlag."""
    urls = urls if urls is not None else _conf()['urls']
    out = {}

    def job(q, qt):
        try:
            out[q] = _lookup(urls, name, qt)
        except Exception as e:                               # noqa: BLE001
            out[q] = e
    ths = [threading.Thread(target=job, args=('A', 1), daemon=True)]
    if want6:
        ths.append(threading.Thread(target=job, args=('AAAA', 28), daemon=True))
    for t in ths:
        t.start()
    for t in ths:
        t.join(6)
    a = out.get('A')
    if a is None:
        raise OSError('Zeitüberschreitung bei der DNS-Abfrage')
    if isinstance(a, Exception):
        raise a
    v4, ttl = a
    v6 = []
    b = out.get('AAAA')
    if b is not None and not isinstance(b, Exception):
        v6, ttl = b[0], min(ttl, b[1])
    return v4, v6, ttl


# ----------------------------------------------------------------------------- Einhängen

def _skip(host):
    if not host or not isinstance(host, str):
        return True
    h = host.lower()
    if h in ('localhost',) or h.endswith(('.local', '.lan', '.home', '.internal', '.localdomain')) or '.' not in h:
        return True
    try:
        socket.inet_pton(socket.AF_INET, h)
        return True
    except OSError:
        pass
    try:
        socket.inet_pton(socket.AF_INET6, h.strip('[]'))
        return True
    except OSError:
        pass
    return False


def getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    c = _conf()
    if c['mode'] == 'system' or not c['urls'] or _skip(host) or flags & socket.AI_NUMERICHOST:
        return _ORIG(host, port, family, type, proto, flags)
    name = host.lower()
    want6 = family in (0, socket.AF_UNSPEC, socket.AF_INET6)
    now = time.time()
    key = (name, want6)
    with _lock:
        hit = _CACHE.get(key)
    if hit and hit[0] > now:
        v4, v6 = hit[1], hit[2]
        STATS['cached'] += 1
    else:
        t0 = time.time()
        try:
            v4, v6, ttl = resolve(name, c['urls'], want6)
            if not v4 and not v6:
                raise OSError('keine Adresse')
            STATS['doh'] += 1
            STATS['last_ms'] = int((time.time() - t0) * 1000)
            with _lock:
                if len(_CACHE) > 800:
                    _CACHE.clear()
                _CACHE[key] = (now + max(30, min(300, ttl)), v4, v6)
        except Exception as e:                               # noqa: BLE001
            STATS['fallback'] += 1
            STATS['last_error'] = '%s: %s' % (name, e)
            return _ORIG(host, port, family, type, proto, flags)
    try:
        port = int(port) if port is not None else 0
    except (TypeError, ValueError):
        return _ORIG(host, port, family, type, proto, flags)
    res = []
    st = type or socket.SOCK_STREAM
    if family in (0, socket.AF_UNSPEC, socket.AF_INET):
        res += [(socket.AF_INET, st, proto or 6, '', (ip, port)) for ip in v4]
    if family in (0, socket.AF_UNSPEC, socket.AF_INET6):
        res += [(socket.AF_INET6, st, proto or 6, '', (ip, port, 0, 0)) for ip in v6]
    if not res:
        return _ORIG(host, port, family, type, proto, flags)
    return res


def apply():
    socket.getaddrinfo = getaddrinfo


def status():
    c = _conf()
    return {'mode': c['mode'], 'urls': c['urls'], 'stats': dict(STATS),
            'presets': {k: v['name'] for k, v in PRESETS.items()}}


def test(mode, custom=''):
    """Probelauf mit einer (noch nicht gespeicherten) Auswahl: Dauer und Adressen, verglichen mit dem System-DNS."""
    urls = list(PRESETS.get(mode, PRESETS['system'])['urls'])
    if mode == 'custom':
        urls = [custom.strip()] if custom.strip().lower().startswith('https://') else []
    out = {'mode': mode, 'rows': []}
    for name in ('example.com', 'api.themoviedb.org', 'github.com'):
        row = {'name': name}
        t0 = time.time()
        try:
            sysip = sorted({i[4][0] for i in _ORIG(name, 443, socket.AF_INET, socket.SOCK_STREAM)})
            row['system'] = sysip
            row['system_ms'] = int((time.time() - t0) * 1000)
        except Exception as e:                               # noqa: BLE001
            row['system'] = []
            row['system_error'] = str(e)
        if urls:
            t0 = time.time()
            try:
                ips, _ttl = _lookup(urls, name, 1)
                row['doh'] = ips
                row['doh_ms'] = int((time.time() - t0) * 1000)
            except Exception as e:                           # noqa: BLE001
                row['doh'] = []
                row['doh_error'] = '%s: %s' % (type(e).__name__, e)
        out['rows'].append(row)
    out['ok'] = bool(urls) and all(r.get('doh') for r in out['rows'])
    return out


apply()
