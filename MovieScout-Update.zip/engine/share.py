# -*- coding: utf-8 -*-
"""Freigabe im WLAN mit Passwort.

Der Host (das Gerät mit der Engine) schaltet in der Oberfläche „Teilen“ die Freigabe ein und vergibt ein Passwort.
Andere Geräte im selben WLAN öffnen http://<Adresse des Hosts>:<Port>/ im Browser (Anmeldeseite /share) oder tragen
Adresse + Passwort in ihrer MovieScout-App ein. Nach der Anmeldung dürfen sie stöbern, suchen, abspielen und den
Familienchat nutzen - NICHT aber Einstellungen, Scraper, Erweiterungen, Updates oder die Zugangsdaten des Hosts.
Ausnahme: Mehrspieler-Spiele (Erweiterung mit EXT_GUEST = True) dürfen Gäste öffnen und spielen.

Technik: Die Anmeldung liefert ein Zugangszeichen (aus dem Passwort abgeleitet, nicht das Passwort selbst). Es kann als
Cookie "ms_share", als Header X-Token oder als ?token= mitkommen (der Stream-Proxy reicht es in umgeschriebene
Adressen weiter). Falsche Versuche werden je Gerät gezählt und gebremst. Wird das Passwort geändert oder die Freigabe
ausgeschaltet, sind alle Gäste sofort abgemeldet.
"""
import hashlib
import hmac
import secrets
import threading
import time
from urllib.parse import parse_qs

from kodi_runtime import xbmcaddon

ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'          # ohne leicht verwechselbare Zeichen (0/O, 1/I/L)
MIN_LEN = 6
COOKIE = 'ms_share'
MAX_FAILS = 8                                           # je Gerät und Minute

# Was ein angemeldeter Gast darf (alles andere bleibt dem Host vorbehalten)
GUEST_EXACT = {'/', '/api/info', '/api/providers', '/api/open', '/api/load', '/api/resolve', '/api/play', '/api/search',
               '/api/meta', '/api/health', '/api/lan', '/api/event', '/api/notify', '/api/ext/ui', '/api/ext/items',
               '/api/ext/widgets', '/api/chat', '/ws/chat', '/api/proxy', '/api/share/status', '/api/share/logout'}
GUEST_PREFIX = ('/ui/', '/api/p/', '/api/files')
GUEST_GET_PREFIX = ('/api/downloads',)                 # die Offline-Bibliothek des Hosts ansehen/abspielen, nicht ändern
PUBLIC = ('/share', '/api/share/login')               # ohne Anmeldung erreichbar (solange die Freigabe an ist)

_lock = threading.Lock()
_cache = {'t': 0.0, 'v': None}
_FAILS = {}
SEEN = {}                                               # Geräteadresse -> {'first','last','n'}


def _settings():
    try:
        return xbmcaddon.all_settings()
    except Exception:                                   # noqa: BLE001
        return {}


def config():
    """{'enabled': bool, 'password': str} - kurz zwischengespeichert, damit nicht jede Anfrage die Datei liest."""
    now = time.time()
    with _lock:
        if _cache['v'] is not None and now - _cache['t'] < 2.0:
            return _cache['v']
    s = _settings()
    pw = str(s.get('share_password') or '')
    v = {'enabled': str(s.get('share_enabled') or '') == 'true' and len(pw) >= MIN_LEN, 'password': pw}
    with _lock:
        _cache.update(t=now, v=v)
    return v


def invalidate():
    with _lock:
        _cache.update(t=0.0, v=None)


def new_password(n=8):
    return ''.join(secrets.choice(ALPHABET) for _ in range(n))


def set_config(enabled, password=None, regenerate=False):
    """Speichert Freigabe an/aus und Passwort. Leeres Passwort beim Einschalten: ein neues wird erzeugt."""
    s = _settings()
    pw = str(s.get('share_password') or '')
    if regenerate:
        pw = new_password()
    elif password is not None and str(password).strip():
        pw = str(password).strip()
        if len(pw) < MIN_LEN:
            raise ValueError('Das Passwort braucht mindestens %d Zeichen.' % MIN_LEN)
        if len(pw) > 64:
            raise ValueError('Das Passwort ist zu lang (höchstens 64 Zeichen).')
    if enabled and len(pw) < MIN_LEN:
        pw = new_password()
    xbmcaddon.save_settings({'share_enabled': 'true' if enabled else 'false', 'share_password': pw})
    invalidate()
    return config()


def token_for(password):
    """Zugangszeichen für Gäste (aus dem Passwort abgeleitet; das Passwort selbst wandert nicht herum)."""
    return hmac.new(str(password).encode('utf-8'), b'moviescout-share-v1', hashlib.sha256).hexdigest()[:40]


def check_password(candidate, conf=None):
    conf = conf or config()
    return bool(conf['enabled']) and hmac.compare_digest(str(candidate or '').encode('utf-8'), conf['password'].encode('utf-8'))


def _cookie_value(headers):
    raw = headers.get(b'cookie', b'').decode('latin-1', 'ignore')
    for part in raw.split(';'):
        k, _, v = part.strip().partition('=')
        if k == COOKIE:
            return v
    return ''


def presented(scope):
    """Alle mitgeschickten Zugangszeichen/Passwörter eines Aufrufs (leere Liste = nichts mitgeschickt)."""
    headers = dict(scope.get('headers') or [])
    qs = parse_qs(scope.get('query_string', b'').decode('utf-8', 'ignore'))
    out = [headers.get(b'x-token', b'').decode('utf-8', 'ignore'), headers.get(b'x-share', b'').decode('utf-8', 'ignore'),
           _cookie_value(headers), (qs.get('token') or [''])[0], (qs.get('share') or [''])[0]]
    path = scope.get('path', '')
    if path.startswith('/api/p/'):                      # Stream-Proxy in Pfadform: das Zeichen steckt im Pfad-Token
        try:
            from . import proxy as P
            tok = P.b64d(path[len('/api/p/'):].split('/', 1)[0])
            out.append(str(tok.get('a') or ''))
        except Exception:                               # noqa: BLE001
            pass
    return [x for x in out if x]


def authed(scope, conf=None):
    conf = conf or config()
    if not conf['enabled']:
        return False
    st = token_for(conf['password'])
    for c in presented(scope):
        if hmac.compare_digest(c.encode('utf-8'), st.encode('utf-8')) or \
                hmac.compare_digest(c.encode('utf-8'), conf['password'].encode('utf-8')):
            return True
    return False


def guest_allowed(path, method='GET'):
    if path in GUEST_EXACT or path.startswith(GUEST_PREFIX):
        return True
    if path.startswith('/api/x/'):                         # Mehrspieler-Spiele: nur Erweiterungen, die EXT_GUEST = True setzen
        try:
            from . import extensions as X
            return X.guest_ext(path[len('/api/x/'):].split('/', 1)[0])
        except Exception:                                  # noqa: BLE001
            return False
    return method in ('GET', 'HEAD', 'OPTIONS') and path.startswith(GUEST_GET_PREFIX)


# ----------------------------------------------------------------------------- Bremse gegen Durchprobieren

def blocked(ip):
    now = time.time()
    with _lock:
        lst = [t for t in _FAILS.get(ip, []) if now - t < 60]
        _FAILS[ip] = lst
        return len(lst) >= MAX_FAILS


def fail(ip):
    now = time.time()
    with _lock:
        lst = [t for t in _FAILS.get(ip, []) if now - t < 60]
        lst.append(now)
        _FAILS[ip] = lst
        return len(lst) >= MAX_FAILS


def clear_fails(ip):
    with _lock:
        _FAILS.pop(ip, None)


def touch(ip):
    now = int(time.time())
    with _lock:
        d = SEEN.get(ip)
        if d is None:
            if len(SEEN) > 200:
                SEEN.pop(min(SEEN, key=lambda k: SEEN[k]['last']), None)
            SEEN[ip] = {'first': now, 'last': now, 'n': 1}
        else:
            d['last'] = now
            d['n'] += 1


def seen():
    with _lock:
        return sorted(({'ip': k, **v} for k, v in SEEN.items()), key=lambda r: -r['last'])[:20]


def forget():
    with _lock:
        SEEN.clear()
        _FAILS.clear()


# ----------------------------------------------------------------------------- Anmeldeseite

def login_page(message='', enabled=True):
    msg = ('<p class="m">%s</p>' % message) if message else ''
    body = ('''<form method="post" action="#" id="f"><label>Passwort<input id="p" type="password" autocomplete="current-password" autofocus></label>
<button type="submit">Anmelden</button></form>%s''' % msg) if enabled else \
        '<p class="m">Die Freigabe ist ausgeschaltet. Der Besitzer muss sie in MovieScout unter „Teilen“ einschalten.</p>'
    return '''<!doctype html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MovieScout – Anmelden</title><style>
:root{color-scheme:light dark}body{margin:0;min-height:100vh;display:grid;place-items:center;font:16px system-ui,sans-serif;background:#0f1115;color:#eee}
main{width:min(92vw,360px);padding:28px;border-radius:16px;background:#1a1d24;box-shadow:0 8px 30px #0006}
h1{margin:0 0 6px;font-size:1.3rem}p{color:#9aa}label{display:block;margin:18px 0 6px;color:#bcd}
input{width:100%;box-sizing:border-box;padding:12px;border-radius:10px;border:1px solid #445;background:#0f1115;color:#fff;font-size:1.1rem}
button{margin-top:16px;width:100%;padding:12px;border:0;border-radius:10px;background:#3d7bff;color:#fff;font-size:1.05rem;cursor:pointer}
.m{color:#ffb4a8}</style></head><body><main><h1>MovieScout</h1><p>Dieses Gerät wird im WLAN geteilt. Bitte das Passwort eingeben, das dir der Besitzer gegeben hat.</p>
''' + body + '''</main><script>
const f=document.getElementById('f');if(f)f.addEventListener('submit',async(e)=>{e.preventDefault();
const r=await fetch('/api/share/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:document.getElementById('p').value})});
if(r.ok){location.href='/ui/';}else{let m='Passwort falsch.';try{m=(await r.json()).error||m}catch(_){}
let el=document.querySelector('.m');if(!el){el=document.createElement('p');el.className='m';f.after(el)}el.textContent=m;}});
</script></body></html>'''
