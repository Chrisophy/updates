# -*- coding: utf-8 -*-
"""Eigene Kopie des json-Moduls für installierte Kodi-Addons.

Manche Addons tauschen json.loads global aus (z. B. GitPlayGer). Im normalen Python würde das die ganze Engine verändern.
Beim Installieren wird "import json" im Addon durch diese Kopie ersetzt: das Addon sieht seine Änderung, die Engine nicht.
"""
import json as _json
import types

clone = types.ModuleType('json')
clone.__dict__.update({k: v for k, v in _json.__dict__.items() if k not in ('__name__', '__spec__', '__loader__')})
clone.__name__ = 'json'
