# -*- coding: utf-8 -*-
"""Lädt die Scraper (providers/*.py) und führt sie sicher aus.

* Dispatch wie im Kodi-Router: das Feld `next_func` eines Items bestimmt die Funktion.
* Jeder Aufruf läuft in einem Worker-Thread mit eigenem Kodi-Kontext und Timeout.
* Ergebnisse (Items/Hoster) werden normalisiert (engine.normalize).
"""
import importlib.util
import inspect
import json
import logging
import os
import re
import sys
import threading
import time
import traceback
from collections import deque
import copy
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, TimeoutError as FutTimeout, wait
from pathlib import Path

import kodi_runtime  # noqa: F401  (registriert xbmc* in sys.modules)
from kodi_runtime import context, paths, xbmcplugin, ui_dialogs

from . import cache as CACHE
from . import normalize as N
from . import system as SYS
from . import extensions as X

ROOT = Path(__file__).resolve().parent.parent
PROVIDERS_DIR = Path(os.environ.get('MINIKODI_PROVIDERS', str(ROOT / 'providers')))

log = logging.getLogger('engine')

_POOL = ThreadPoolExecutor(max_workers=64, thread_name_prefix='scraper')
TIMEOUT_LOAD = 45
TIMEOUT_RESOLVE = 60
TIMEOUT_SEARCH = 30
TIMEOUT_HEALTH = 25

REGISTRY = {}          # id -> Provider
HEALTH = {}            # id -> dict (bad_since: seit wann ununterbrochen 'error'/'empty', sonst None)
_HEALTH_FILE = paths.DATA_DIR / 'health.json'
# Zwischenspeicher (siehe cache.py). Menüs: 10 Min. frisch, danach bis zu 3 Std. sofort als „alt“ gezeigt und im
# Hintergrund erneuert (Stöbern ist so fast verzögerungsfrei). Suchtreffer 10 Min., Streamlisten 8 Min.
_LIST_C = CACHE.Cache('menus', ttl=600, max_mem=400)
_HOSTER_C = CACHE.Cache('hosters', ttl=480, max_mem=200)
_SEARCH_C = CACHE.Cache('search', ttl=600, max_mem=300)
LIST_STALE = 3 * 3600
_REFRESHING = set()
_REFRESH_LOCK = threading.Lock()
LOG_RING = deque(maxlen=600)


def _load_health():
    try:
        data = json.loads(_HEALTH_FILE.read_text('utf-8'))
        if isinstance(data, dict):
            HEALTH.update(data)
    except Exception:
        pass


def _save_health():
    try:
        _HEALTH_FILE.write_text(json.dumps(HEALTH, ensure_ascii=False), 'utf-8')
    except Exception:
        pass


def _finalize_health(pid, h):
    """Setzt/trägt 'bad_since' fort (seit wann ununterbrochen 'error' oder 'empty') und speichert
    den Gesundheits-Status, damit er einen Neustart der Engine überlebt (passive Überwachung,
    siehe _start_health_watch in app.py - nicht nur bei einem Klick auf 'Alle prüfen')."""
    prev = HEALTH.get(pid) or {}
    bad = h.get('status') in ('error', 'empty')
    if bad:
        h['bad_since'] = prev.get('bad_since') if prev.get('status') in ('error', 'empty') and prev.get('bad_since') else int(time.time())
    else:
        h['bad_since'] = None
    HEALTH[pid] = h
    _save_health()
    return h


_load_health()


# ----------------------------------------------------------------------------- Logging

class _RingHandler(logging.Handler):
    def emit(self, record):
        try:
            LOG_RING.append({
                't': time.strftime('%H:%M:%S', time.localtime(record.created)),
                'level': record.levelname,
                'src': record.name,
                'provider': getattr(context.current(), 'provider', ''),
                'msg': record.getMessage()[:700],
            })
        except Exception:
            pass


def setup_logging(level=logging.INFO):
    root = logging.getLogger()
    if not any(isinstance(h, _RingHandler) for h in root.handlers):
        root.addHandler(_RingHandler())
    if not any(isinstance(h, logging.StreamHandler) and not isinstance(h, _RingHandler)
               for h in root.handlers):
        sh = logging.StreamHandler()
        sh.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s: %(message)s',
                                          '%H:%M:%S'))
        root.addHandler(sh)
    root.setLevel(level)


def recent_logs(provider_id='', limit=150, level=''):
    out = [r for r in LOG_RING
           if (not provider_id or r['provider'] == provider_id)
           and (not level or r['level'] in level.upper().split(','))]
    return out[-limit:]


# ----------------------------------------------------------------------------- Provider

class Provider:
    def __init__(self, pid, name, domain, module, file):
        self.id, self.name, self.domain = pid, name, domain
        self.module, self.file = module, file
        self.error = ''
        self.enabled = True
        self.origin = 'bundled'
        self.calls = 0
        self.fails = 0
        self.last_error = ''

    @property
    def has_search(self):
        return callable(getattr(self.module, 'search', None))

    @property
    def global_search(self):
        return self.has_search and getattr(self.module, 'GLOBAL_SEARCH', True) is not False

    def info(self):
        h = HEALTH.get(self.id, {})
        return {
            'id': self.id, 'name': self.name, 'domain': self.domain,
            'enabled': self.enabled, 'origin': self.origin, 'file': self.file,
            'search': self.has_search, 'global_search': self.global_search,
            'addon': getattr(self.module, 'ADDON_ID', '') or '',
            'status': 'error' if self.error else h.get('status', 'unknown'),
            'error': self.error or h.get('error', '') or self.last_error,
            'checked': h.get('checked', 0), 'ms': h.get('ms', 0), 'count': h.get('count', 0),
        }


def load_providers(directory=None):
    """Importiert alle Scraper (mitgelieferte + eigene aus userData/user/providers). Eigene Dateien überschreiben
    gleichnamige mitgelieferte. Fehlerhafte werden mit Fehlertext gelistet statt zu verschwinden."""
    sys.path.insert(0, str(ROOT))
    reg = {}
    st = SYS.load_state()
    dirs = [(Path(directory), 'bundled')] if directory else SYS.provider_dirs()
    files = {}
    for d, origin in dirs:
        for f in sorted(Path(d).glob('*.py')):
            if f.name.startswith('_'):
                continue
            if origin == 'bundled' and f.name in st['removed_provider']:
                continue
            files[f.name] = (f, origin)
    for name in sorted(files):
        f, origin = files[name]
        stem = f.stem
        enabled = name not in st['disabled_provider']
        if not enabled:
            meta = SYS.static_meta(f)
            p = Provider(meta.get('SITE_ID', stem), meta.get('SITE_NAME', stem), meta.get('SITE_DOMAIN', ''), None, f.name)
            p.enabled, p.origin = False, origin
            reg[p.id] = p
            continue
        try:
            spec = importlib.util.spec_from_file_location(stem, f)
            mod = importlib.util.module_from_spec(spec)
            _prev = sys.modules.get(stem)
            sys.modules[stem] = mod                    # nur während des Ladens (Dataclasses & Co. suchen ihr Modul unter diesem Namen)
            try:
                spec.loader.exec_module(mod)
            finally:
                # Danach unter eigenem Namen ablegen: Kodi-Addons haben gleichnamige Module (xStream: sites/netzkino.py, internetarchive.py)
                if _prev is None:
                    sys.modules.pop(stem, None)
                else:
                    sys.modules[stem] = _prev
            sys.modules['ms_scraper_' + stem] = mod
        except BaseException as e:   # auch SystemExit/KeyboardInterrupt aus kaputten Modulen
            if isinstance(e, KeyboardInterrupt):
                raise
            msg = '%s: %s' % (type(e).__name__, e)
            log.error('Scraper %s nicht ladbar: %s', f.name, msg)
            reg[stem] = Provider(stem, stem, '', None, f.name)
            reg[stem].error = msg[:300]
            reg[stem].origin = origin
            continue
        if not any(callable(getattr(mod, n, None)) for n in ('load', 'showEntries', 'search', 'get_hosters')):
            log.info('%s ist kein Scraper (übersprungen)', f.name)
            continue
        pid = getattr(mod, 'SITE_ID', stem)
        reg[pid] = Provider(pid, getattr(mod, 'SITE_NAME', stem),
                                 getattr(mod, 'SITE_DOMAIN', ''), mod, f.name)
        reg[pid].origin = origin
        log.info('Scraper geladen: %s [%s]', reg[pid].name, pid)
    for k in [k for k in REGISTRY if k not in reg]:      # atomar austauschen, laufende Anfragen sehen nie eine leere Liste
        REGISTRY.pop(k, None)
    REGISTRY.update(reg)
    return REGISTRY


def reload_all():
    """Scraper und Erweiterungen neu einlesen (nach Hinzufügen/Löschen/Aktivieren)."""
    clear_cache()
    load_providers()
    X.load_all()
    for pid in list(HEALTH):
        if pid not in REGISTRY:
            HEALTH.pop(pid, None)


def get_provider(pid):
    p = REGISTRY.get(pid)
    if p is None:
        raise KeyError('Provider nicht gefunden: %s' % pid)
    if not p.enabled:
        raise RuntimeError('Diese Quelle ist deaktiviert (Einstellungen → Quellen verwalten)')
    if p.module is None:
        raise RuntimeError('Provider konnte nicht geladen werden: %s' % p.error)
    return p


# ----------------------------------------------------------------------------- Aufruf

class ScraperTimeout(Exception):
    pass


def _to_int(v, default=0):
    try:
        return int(str(v).strip() or default)
    except (ValueError, TypeError):
        return default


_GENERIC_TITLE = re.compile(r'^(episode|folge|staffel|season|e\d+|s\d+)\b', re.I)


def build_kwargs(fn, item, query=''):
    item = item or {}
    params = {}
    for k, v in item.items():
        if isinstance(v, (str, int, float)) and not isinstance(v, bool) and k != 'plot':
            params[k] = str(v)
    if isinstance(item.get('params'), dict):
        params.update({k: v for k, v in item['params'].items()})
    if query:
        params['query'] = params['keyword'] = query
    title = item.get('title') or ''
    season = _to_int(item.get('season'))
    if season and item.get('parent_title') and (not title or _GENERIC_TITLE.match(title)):
        title = item['parent_title']
    avail = {
        'url': item.get('url') or '',
        'params': params,
        'title': title,
        'year': item.get('year') or '',
        'season': season,
        'episode': _to_int(item.get('episode')),
        'imdb': item.get('imdb') or item.get('imdb_id') or '',
        'tmdb': item.get('tmdb') or item.get('tmdb_id') or '',
        'query': query,
    }
    sig = inspect.signature(fn)
    var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
    return {k: v for k, v in avail.items() if var_kw or k in sig.parameters}, params


def _run(provider, fn, kwargs, ctx, timeout):
    provider.calls += 1
    ctx.provider = provider.id
    if not ctx.rid:
        ctx.rid = ui_dialogs.RID.get()
    if provider.id.startswith('addon_'):
        timeout = max(timeout, 180)                          # Addon-Aktionen (Playlisten suchen, Anmelden …) dürfen länger dauern

    def job():
        with context.use(ctx):
            return fn(**kwargs)

    fut = _POOL.submit(job)
    t0 = time.time()
    try:
        while True:
            try:
                return fut.result(timeout=0.3)
            except FutTimeout:
                if time.time() - t0 - ctx.paused_now() > timeout:     # Zeit, in der das Addon auf den Nutzer wartet, zählt nicht
                    raise
    except FutTimeout:
        provider.fails += 1
        provider.last_error = 'Zeitüberschreitung (%ss)' % timeout
        ctx.cancelled.set()                 # DialogProgress.iscanceled() wird True: Scraper-Schleifen können aufhören
        fut.cancel()
        raise ScraperTimeout(provider.last_error)
    except Exception as e:
        provider.fails += 1
        provider.last_error = '%s: %s' % (type(e).__name__, e)
        log.error('[%s] %s\n%s', provider.id, provider.last_error,
                  ''.join(traceback.format_exception(type(e), e, e.__traceback__)[-4:]))
        raise


def _collect_items(provider, res, ctx, parent_title):
    source = res if isinstance(res, list) and res else list(ctx.items)
    ctx.items = []
    items = []
    for raw in source:
        if isinstance(raw, dict):
            it = N.norm_item(raw, provider.id, provider.name, parent_title)
            if it:
                items.append(it)
    return X.apply_items(provider.id, items) if items else items


def _cache_key(*parts):
    return '|'.join(str(p) for p in parts)


def clear_cache():
    """Menüs, Suchtreffer und Streamlisten verwerfen (TMDB-Infos bleiben - die ändern sich nicht durch Einstellungen)."""
    for c in (_LIST_C, _HOSTER_C, _SEARCH_C):
        c.clear()


def _refresh_menu(pid, item, query, key):
    """Menü im Hintergrund neu laden und den Zwischenspeicher auffrischen (höchstens einmal je Menü gleichzeitig)."""
    with _REFRESH_LOCK:
        if key in _REFRESHING:
            return
        _REFRESHING.add(key)

    def _go():
        try:
            open_item(pid, item, query, use_cache=False, refresh=True)
        except Exception as e:                            # noqa: BLE001
            log.info('Hintergrund-Aktualisierung %s: %s', pid, e)
        finally:
            with _REFRESH_LOCK:
                _REFRESHING.discard(key)
    _POOL.submit(_go)


def open_item(pid, item=None, query='', use_cache=True, refresh=False):
    """Menü/Ordner öffnen. item=None oder url='' -> Startmenü des Providers."""
    p = get_provider(pid)
    item = dict(item or {})
    url = item.get('url') or ''
    nf = (item.get('next_func') or '').strip() or 'load'
    kind = N.item_kind(item) if item else N.KIND_FOLDER
    if kind == N.KIND_SEARCH and not query:
        return {'needs_input': True, 'items': [], 'notes': []}
    if kind == N.KIND_PLAY:
        raise ValueError('Spielbarer Eintrag - bitte /api/resolve verwenden')

    cache_key = _cache_key(pid, nf, url, item.get('season'), item.get('episode'), item.get('episode_anchor'), query)
    if use_cache and not query and not refresh:
        hit, stale = _LIST_C.get_stale(cache_key, max_stale=LIST_STALE)
        if hit is not None:
            if stale:
                _refresh_menu(pid, item, query, cache_key)
            return hit

    candidates = [nf] + [n for n in ('showEntries', 'load') if n != nf]
    if not url and not any(callable(getattr(p.module, n, None)) for n in candidates) and p.has_search:
        # Reiner Such-Scraper (z. B. FilmPalast): Startmenü = nur die Suche
        entry = N.norm_item({'title': 'Suche in %s' % p.name, 'url': '', 'next_func': 'search',
                             'is_playable': False}, p.id, p.name)
        return {'items': [entry], 'notes': [], 'count': 1, 'search_only': True}
    fn = None
    for name in candidates:
        cand = getattr(p.module, name, None)
        if callable(cand):
            fn, nf = cand, name
            break
    if fn is None:
        raise RuntimeError('Scraper hat keine Funktion "%s"' % item.get('next_func'))

    kwargs, params = build_kwargs(fn, item, query)
    ctx = context.RequestContext(query=query, params=params)
    res = _run(p, fn, kwargs, ctx, TIMEOUT_LOAD)

    # Startmenü: manche Scraper liefern erst über showEntries etwas
    if not url and not (isinstance(res, list) and res) and not ctx.items and nf != 'showEntries':
        alt = getattr(p.module, 'showEntries', None)
        if callable(alt):
            kw2, _ = build_kwargs(alt, item, query)
            res = _run(p, alt, kw2, ctx, TIMEOUT_LOAD)

    if N.item_kind(item) == N.KIND_ACTION:
        out = {'items': [], 'notes': ctx.notes or [{'level': 'info', 'heading': p.name,
                                                    'message': 'Erledigt'}], 'action': True}
        if ctx.ui:
            out['ui'] = ctx.ui
        clear_cache()
        return out

    items = _collect_items(p, res, ctx, item.get('title') or '')
    out = {'items': items, 'notes': ctx.notes, 'count': len(items)}
    if ctx.ui:                                         # Container.Refresh/Update des Addons: Oberfläche neu laden lassen, nichts merken
        out['ui'] = ctx.ui
        clear_cache()
        return out
    if items and (use_cache or refresh) and not query:
        _LIST_C.put(cache_key, out)
    return out


def resolve_item(pid, item, client=None, fresh=False):
    """get_hosters() ausführen und Hoster normalisieren. client: Fähigkeiten des abspielenden Browsers
    (für Scraper über xbmc.getInfoLabel('MovieScout.Client.Widevine') abfragbar)."""
    p = get_provider(pid)
    fn = getattr(p.module, 'get_hosters', None)
    if not callable(fn):
        raise RuntimeError('Dieser Scraper liefert keine Streams (get_hosters fehlt)')
    kwargs, params = build_kwargs(fn, item or {})
    hkey = _cache_key(pid, json.dumps(params, sort_keys=True, default=str), json.dumps(client or {}, sort_keys=True, default=str))
    if not fresh:
        hit = _HOSTER_C.get(hkey)
        if hit is not None:
            return copy.deepcopy(hit)
    ctx = context.RequestContext(params=params, client=client)
    raw = _run(p, fn, kwargs, ctx, TIMEOUT_RESOLVE)
    if isinstance(raw, tuple) and raw and isinstance(raw[0], (list, tuple)):
        raw = list(raw)
    hosters = N.norm_hosters(raw if isinstance(raw, list) else [], p.domain, p.name)
    for r in ctx.resolved:      # xbmc.Player().play(...) / setResolvedUrl(...)
        h = N.hoster_from_resolved(r.get('path') or '', r.get('listitem'), p.domain, p.name)
        if h:
            hosters.insert(0, h)
    hosters = X.apply_hosters(p.id, item or {}, hosters)
    out = {'hosters': hosters, 'notes': ctx.notes}
    if ctx.ui:
        out['ui'] = ctx.ui
        clear_cache()
    if hosters and not any(n.get('level') == 'error' for n in (ctx.notes or []) if isinstance(n, dict)):
        _HOSTER_C.put(hkey, copy.deepcopy(out))
    return out


def search_provider(pid, query, timeout=None):
    p = get_provider(pid)
    fn = getattr(p.module, 'search', None)
    if not callable(fn):
        return {'items': [], 'notes': []}
    kwargs, params = build_kwargs(fn, {'url': ''}, query)
    ctx = context.RequestContext(query=query, params=params)
    res = _run(p, fn, kwargs, ctx, timeout or TIMEOUT_SEARCH)
    items = _collect_items(p, res, ctx, '')
    return {'items': items, 'notes': ctx.notes, 'count': len(items)}


# ----- Globale Suche: parallel, mit Fristen, ohne dass langsame Quellen alles aufhalten -----
# Jede Quelle läuft für sich. Es wird nicht auf die Langsamste gewartet: sind nach SEARCH_SOFT Sekunden mindestens 60 %
# der Quellen fertig und es gibt Treffer, kommt die Antwort sofort; spätestens nach SEARCH_HARD Sekunden. Quellen, die
# noch laufen, arbeiten weiter und legen ihre Treffer in den Zwischenspeicher (die Oberfläche kann sie nachladen).
# Quellen, die mehrfach hintereinander scheitern, werden für eine Weile übersprungen (Sicherung), und die Reihenfolge
# richtet sich nach der gemessenen Antwortzeit (schnelle zuerst).
SEARCH_SOFT = 6
SEARCH_HARD = 16
_SEARCH_POOL = ThreadPoolExecutor(max_workers=32, thread_name_prefix='search')
_SSTAT = {}
_SSTAT_LOCK = threading.Lock()


def search_stats():
    with _SSTAT_LOCK:
        return {pid: dict(v) for pid, v in _SSTAT.items()}


def _record_search(pid, ok, ms):
    with _SSTAT_LOCK:
        st = _SSTAT.setdefault(pid, {'ema': 0.0, 'fails': 0, 'until': 0.0, 'n': 0})
        st['n'] += 1
        if ok:
            st['fails'] = 0
            st['until'] = 0.0
            st['ema'] = ms if not st['ema'] else 0.7 * st['ema'] + 0.3 * ms
        else:
            st['fails'] += 1
            if st['fails'] >= 3:                          # 1, 2, 4 … bis 15 Minuten Pause
                st['until'] = time.time() + min(900, 60 * 2 ** (st['fails'] - 3))


def _search_job(pid, query, timeout, fresh):
    key = _cache_key(pid, query.lower())
    if not fresh:
        hit = _SEARCH_C.get(key)
        if hit is not None:
            return {'items': copy.deepcopy(hit), 'notes': [], 'cached': True}
    t0 = time.time()
    try:
        out = search_provider(pid, query, timeout=timeout)
    except BaseException:
        _record_search(pid, False, (time.time() - t0) * 1000)
        raise
    _record_search(pid, True, (time.time() - t0) * 1000)
    if out.get('items'):
        _SEARCH_C.put(key, copy.deepcopy(out['items']))
    return out


def search_one(pid, query, fresh=False):
    """Suche in genau einer Quelle - mit Zwischenspeicher und Messung (Sicherung bei Dauerfehlern)."""
    return _search_job(pid, query, TIMEOUT_SEARCH, fresh)


def search_all(query, provider_ids=None, hard=None, soft=None, fresh=False, info=None):
    """Parallele Suche. Gibt (results, errors) zurück. info (dict, optional) bekommt:
    pending (noch laufende Quellen), skipped ({id: Sekunden Pause}), ms (Dauer)."""
    hard = hard or SEARCH_HARD
    soft = soft or SEARCH_SOFT
    now = time.time()
    ids, skipped = [], {}
    for pid, p in REGISTRY.items():
        if not (p.enabled and p.module is not None and p.global_search and (not provider_ids or pid in provider_ids)):
            continue
        st = _SSTAT.get(pid)
        if st and st['until'] > now and not provider_ids:
            skipped[pid] = int(st['until'] - now)
            continue
        ids.append(pid)
    ids.sort(key=lambda pid: (_SSTAT.get(pid) or {}).get('ema') or 8000)

    def tmo(pid):
        ema = (_SSTAT.get(pid) or {}).get('ema') or 0
        return TIMEOUT_SEARCH if not ema else min(TIMEOUT_SEARCH, max(8, ema * 4 / 1000))
    futs = {_SEARCH_POOL.submit(_search_job, pid, query, tmo(pid), fresh): pid for pid in ids}
    t0 = time.time()
    pending, results, errors = set(futs), [], {}
    total = len(futs)
    cut_hard = False
    while pending:
        el = time.time() - t0
        if el >= hard:
            cut_hard = True
            break
        if results and el >= soft and (total - len(pending)) * 10 >= total * 6:
            break
        done, pending = wait(pending, timeout=min(0.4, hard - el), return_when=FIRST_COMPLETED)
        for f in done:
            try:
                results.extend(f.result().get('items', []))
            except Exception as e:                        # noqa: BLE001
                errors[futs[f]] = '%s: %s' % (type(e).__name__, e)
    for f in pending:
        f.cancel()
        if cut_hard:
            errors[futs[f]] = 'Zeitüberschreitung'
    if info is not None:
        info.update(pending=[futs[f] for f in pending], skipped=skipped, ms=int((time.time() - t0) * 1000))
    return results, errors


def check_provider(pid):
    """Start-Menü laden und Ergebnis als Gesundheits-Status ablegen."""
    p = REGISTRY.get(pid)
    if p is None:
        raise KeyError(pid)
    t0 = time.time()
    h = {'id': pid, 'checked': int(t0)}
    if not p.enabled:
        h.update(status='unknown', error='deaktiviert', ms=0, count=0)
    elif p.module is None:
        h.update(status='error', error=p.error, ms=0, count=0)
    elif pid.startswith('addon_'):                # Kodi-Addons nie von selbst starten (Anmeldungen, native Bibliotheken, Hintergrundlast)
        h.update(status='unknown', error='Addon - wird nur auf Wunsch gestartet', ms=0, count=0)
    else:
        try:
            fn_name = next((n for n in ('load', 'showEntries') if callable(getattr(p.module, n, None))), '')
            if not fn_name:
                out = open_item(pid, {}, use_cache=False)      # reiner Such-Scraper
                h.update(status='ok' if p.has_search else 'error', count=out.get('count', 0),
                         error='' if p.has_search else 'Weder Menü noch Suche vorhanden',
                         sample=['nur Suche'])
                h['ms'] = int((time.time() - t0) * 1000)
                return _finalize_health(pid, h)
            fn = getattr(p.module, fn_name)
            kwargs, params = build_kwargs(fn, {'url': ''})
            ctx = context.RequestContext(params=params)
            res = _run(p, fn, kwargs, ctx, TIMEOUT_HEALTH)
            items = _collect_items(p, res, ctx, '')
            h.update(status='ok' if items else 'empty', count=len(items),
                     error='' if items else 'Startmenü ist leer',
                     sample=[i['title'] for i in items[:4]])
        except Exception as e:
            h.update(status='error', error='%s: %s' % (type(e).__name__, e), count=0)
        h['ms'] = int((time.time() - t0) * 1000)
    return _finalize_health(pid, h)


def check_all(timeout=TIMEOUT_HEALTH + 10):
    futs = {_POOL.submit(check_provider, pid): pid for pid in list(REGISTRY) if REGISTRY[pid].enabled}
    done, pending = wait(list(futs), timeout=timeout)
    for f in pending:
        pid = futs[f]
        _finalize_health(pid, {'id': pid, 'status': 'error', 'error': 'Zeitüberschreitung', 'ms': 0,
                                'count': 0, 'checked': int(time.time())})
    return [HEALTH.get(pid) for pid in REGISTRY if REGISTRY[pid].enabled]
