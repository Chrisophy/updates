# -*- coding: utf-8 -*-
"""Kodi-Video-Addons (plugin.video.*) installieren und ausführen.

Ein Addon-ZIP wird nach userData/addons/<id>/ entpackt. Dazu legt MovieScout eine kleine Quelle (Scraper-Datei) an, die das
Addon wie in Kodi aufruft: sys.argv = [plugin://<id>/, handle, ?query] und main.py ausführt. Was das Addon per
addDirectoryItem / setResolvedUrl meldet, sammelt der Kodi-Kontext der Engine und die Oberfläche zeigt es als gewohnte Listen.

Damit sich das Paket "resources" des Addons nicht mit dem von MovieScout beißt, wird es beim Installieren unter einem
eigenen Namen (ao_<kennung>) eingehängt: "from resources.lib import x" wird zu "from ao_<kennung>.lib import x".
"""
import collections
import io
import json
import logging
import os
import re
import shutil
import sys
import threading
import time
import types
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import parse_qsl, quote, urlparse

from kodi_runtime import context, paths

from . import fsutil as FS
from . import system as SYS


def _need_requests():
    """Kodi-Addons machen `import requests` (script.module.requests). Fehlt das Paket auf dem Gerät (z. B. Pydroid),
    springt ein schlanker urllib-Ersatz ein; das echte Paket hat immer Vorrang."""
    import importlib.util
    try:
        fehlt = importlib.util.find_spec('requests') is None
    except (ImportError, ValueError):                # defektes Paket zählt wie fehlend
        fehlt = True
    try:
        if fehlt:
            from kodi_runtime import requests_compat
            if requests_compat.install():
                logging.getLogger('engine').info('requests fehlt - Ersatz aus kodi_runtime eingebunden')
    except Exception:                                # noqa: BLE001
        logging.getLogger('engine').warning('requests-Ersatz nicht eingebunden', exc_info=True)


_need_requests()

log = logging.getLogger('engine')

try:
    from kodi_runtime import ui_dialogs as _UDLG
except Exception:                                    # noqa: BLE001
    _UDLG = None

ADDONS_DIR = paths.DATA_DIR / 'addons'
MAX_UNPACKED = 80 * 1024 * 1024
MAX_FILES = 3000
_RUN = threading.RLock()                      # sys.argv / sys.path sind global: Addon-Läufe nacheinander


class _YieldRun:
    """Sperre für Addon-Läufe vorübergehend ganz freigeben (offenes Addon-Fenster: ein Spiel kann lange laufen) und danach wieder
    übernehmen. Andere Läufe stellen sys.argv/sys.path nach sich selbst wieder her."""

    def __enter__(self):
        self._saved = None
        try:
            if _RUN._is_owned():
                self._saved = _RUN._release_save()
        except (AttributeError, RuntimeError):
            self._saved = None
        return self

    def __exit__(self, *exc):
        if self._saved is not None:
            _RUN._acquire_restore(self._saved)
        return False


if _UDLG is not None:
    _UDLG.RUN_YIELD = _YieldRun
_SEARCH_RE = re.compile(r'(?:[?&](?:action|mode|route|method|a|do)=(?:search|suche|search_input|new_search|search_prompt|search_channels|search_dialog)(?:&|$))|(?:^plugin://[^/]+/(?:search|suche)/?(?:\?|$))', re.I)


class AddonError(Exception):
    pass


def slug(addon_id):
    return re.sub(r'[^a-z0-9]+', '_', str(addon_id).lower()).strip('_')[:50] or 'addon'


def pkg_name(addon_id):
    return 'ao_' + slug(addon_id)


def addon_path(addon_id):
    return ADDONS_DIR / addon_id


def meta(addon_id):
    try:
        return json.loads((addon_path(addon_id) / 'moviescout-addon.json').read_text('utf-8'))
    except Exception:                                      # noqa: BLE001
        return {}


def installed():
    out = []
    if ADDONS_DIR.exists():
        for d in sorted(ADDONS_DIR.iterdir()):
            m = meta(d.name) if d.is_dir() else {}
            if m:
                out.append(m)
    return out


# ----------------------------------------------------------------------------- Installieren

def _safe_members(zf):
    names = zf.namelist()
    if len(names) > MAX_FILES:
        raise AddonError('Das ZIP enthält zu viele Dateien.')
    total = 0
    for i in zf.infolist():
        n = i.filename.replace('\\', '/')
        if n.startswith('/') or '..' in n.split('/') or re.match(r'^[A-Za-z]:', n):
            raise AddonError('Unsicherer Pfad im ZIP: ' + n)
        total += i.file_size
    if total > MAX_UNPACKED:
        raise AddonError('Das Addon ist entpackt zu groß (max. %d MB).' % (MAX_UNPACKED // 1048576))


def _parse_xml(text):
    try:
        root = ET.fromstring(text)
    except ET.ParseError as e:
        raise AddonError('addon.xml ist ungültig: %s' % e)
    if root.tag != 'addon' or not root.get('id'):
        raise AddonError('addon.xml enthält keine Addon-Kennung.')
    aid = root.get('id')
    lib = script_lib = module_lib = service_lib = ''
    points = []
    for ext in root.findall('extension'):
        pt = ext.get('point') or ''
        points.append(pt)
        if pt == 'xbmc.python.pluginsource':
            lib = ext.get('library') or 'default.py'
        elif pt == 'xbmc.python.script':
            script_lib = ext.get('library') or 'default.py'
        elif pt == 'xbmc.python.module':
            module_lib = ext.get('library') or 'lib'
        elif pt == 'xbmc.service':
            service_lib = ext.get('library') or ''
    if lib and not aid.startswith('plugin.'):
        lib = ''                                   # Videoquellen heißen plugin.*; pluginsource unter fremder Kennung zählt nicht
    kinds = [k for k, v in (('plugin', lib), ('script', script_lib), ('module', module_lib), ('service', service_lib)) if v]
    kind = kinds[0] if kinds else 'other'
    requires = []
    for imp in root.findall('requires/import'):
        rid = (imp.get('addon') or '').strip()
        if rid:
            requires.append({'id': rid, 'version': imp.get('version') or '', 'optional': (imp.get('optional') or '').lower() == 'true'})
    desc = ''
    for ext in root.findall('extension'):
        if ext.get('point') == 'xbmc.addon.metadata':
            for s in ext.findall('summary'):
                if s.get('lang') in ('de', 'en') and not desc or s.get('lang') == 'de':
                    desc = (s.text or '').strip()
    icon = 'icon.png'
    fan = ''
    for a in root.iter('icon'):
        icon = (a.text or icon).strip() or icon
    for a in root.iter('fanart'):
        fan = (a.text or '').strip()
    return {'id': aid, 'name': root.get('name') or aid, 'version': root.get('version') or '',
            'author': root.get('provider-name') or '', 'library': lib, 'script_lib': script_lib, 'module_lib': module_lib, 'service_lib': service_lib,
            'kind': kind, 'kinds': kinds, 'points': points, 'requires': requires,
            'summary': desc, 'icon': icon, 'fanart': fan}


_IMP = re.compile(r'(^[ \t]*|[:;][ \t]*)(from|import)([ \t]+)resources\b', re.M)     # auch Einzeiler wie "if x: from resources.lib import y"


_JSON1 = re.compile(r'^(\s*)import json[ \t]*(?:#.*)?$', re.M)
_JSON2 = re.compile(r'^(\s*)import json as (\w+)', re.M)


def _rewrite(text, pkg):
    text = _IMP.sub(lambda m: m.group(1) + m.group(2) + m.group(3) + pkg, text)
    text = _JSON1.sub(lambda m: m.group(1) + 'from engine.addonjson import clone as json', text)
    return _JSON2.sub(lambda m: m.group(1) + 'from engine.addonjson import clone as ' + m.group(2), text)


REWRITE_VERSION = 2          # 2: auch Einzeiler-Importe ("if x: from resources.lib import y") werden umgeleitet


def _migrate(addon_id, m):
    """Ältere Installationen (Umschreib-Stand < REWRITE_VERSION) einmalig nachziehen, ohne Neuinstallieren."""
    if m.get('rw', 1) >= REWRITE_VERSION:
        return m
    adir = addon_path(addon_id)
    pkg = m.get('pkg') or pkg_name(addon_id)
    for f in adir.rglob('*.py'):
        try:
            t = f.read_text('utf-8')
        except (OSError, UnicodeDecodeError):
            continue
        n = _rewrite(t, pkg)
        if n != t:
            f.write_text(n, 'utf-8')
    m['rw'] = REWRITE_VERSION
    try:
        (adir / 'moviescout-addon.json').write_text(json.dumps(m, ensure_ascii=False, indent=1), 'utf-8')
    except OSError:
        pass
    for k in [k for k in sys.modules if k == pkg or k.startswith(pkg + '.')]:
        sys.modules.pop(k, None)
    return m


SHIM = '''# -*- coding: utf-8 -*-
"""Kodi-Addon "%(name)s" (%(id)s) - von MovieScout automatisch angelegt, nicht bearbeiten."""
SITE_ID = %(sid)r
SITE_NAME = %(name)r
SITE_DOMAIN = 'kodi-addon'
GLOBAL_SEARCH = False
ADDON_ID = %(id)r

from engine import addonhost as _A


def load(url='', params=None):
    return _A.run(ADDON_ID, url, params)


def search(query='', url='', params=None):
    return _A.run(ADDON_ID, url, params, query=query, search=True)


def get_hosters(url='', params=None):
    return _A.run(ADDON_ID, url, params, play=True)
'''


SCRIPT_SHIM = '''# -*- coding: utf-8 -*-
"""Kodi-Programm "%(name)s" (%(id)s) - von MovieScout automatisch angelegt, nicht bearbeiten."""
SITE_ID = %(sid)r
SITE_NAME = %(name)r
SITE_DOMAIN = 'kodi-addon'
GLOBAL_SEARCH = False
ADDON_ID = %(id)r

from engine import addonhost as _A


def load(url='', params=None):
    return _A.script_menu(ADDON_ID, url, params)


def search(query='', url='', params=None):
    return _A.script_menu(ADDON_ID, '', params)


def get_hosters(url='', params=None):
    return _A.script_menu(ADDON_ID, url, params)
'''


def _obfuscated(raw):
    """Verschleierte Addons (riesige Base64-/Hex-Zeilen, die per exec/eval entpackt werden und oft marshal-Bytecode enthalten)."""
    try:
        txt = raw.decode('utf-8', 'ignore')
    except Exception:                                      # noqa: BLE001
        return False
    if len(txt) < 20000:
        return False
    return any(len(l) > 100000 and ('exec(' in txt or 'eval(' in txt) for l in txt.split('\n'))


def _ensure_settings(adir):
    """Manche Addons liefern settings-kodi19.xml / settings-kodi20.xml und legen die passende settings.xml erst beim Start
    in Kodi an (Dienst). Hier fehlt dieser Schritt oft: dann gäbe es weder Formular noch Standardwerte. Wir nehmen die neue Fassung."""
    try:
        res = Path(adir) / 'resources'
        tgt = res / 'settings.xml'
        if tgt.is_file():
            return
        for n in ('settings-kodi20.xml', 'settings-kodi21.xml', 'settings-kodi19.xml', 'settings-kodi18.xml'):
            if (res / n).is_file():
                shutil.copyfile(str(res / n), str(tgt))
                return
    except OSError:
        log.warning('settings.xml konnte nicht angelegt werden', exc_info=True)


def install_zip(data):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise AddonError('Das ist keine ZIP-Datei.')
    _safe_members(zf)
    xmls = [n for n in zf.namelist() if n.replace('\\', '/').count('/') <= 1 and n.replace('\\', '/').endswith('addon.xml')]
    if not xmls:
        raise AddonError('Keine addon.xml gefunden – das ist kein Kodi-Addon.')
    xmln = sorted(xmls, key=lambda n: n.count('/'))[0].replace('\\', '/')
    base = xmln[:-len('addon.xml')]
    info = _parse_xml(zf.read(xmln).decode('utf-8', 'replace'))
    if info['kind'] == 'other':
        raise AddonError('Dieser Addon-Typ wird nicht unterstützt (%s). Möglich sind Video-/Audio-Addons (plugin.*), Programme und Dienste '
                         '(script.*, xbmc.service) und Bibliotheken (script.module.*) – dieses Paket ist %s.'
                         % (', '.join(p for p in info['points'] if p and p != 'xbmc.addon.metadata') or 'ohne Einstiegspunkt', info['id']))
    if not re.match(r'^[A-Za-z0-9_.-]{3,80}$', info['id']):
        raise AddonError('Ungültige Addon-Kennung.')
    target = addon_path(info['id'])
    tmp = ADDONS_DIR / ('.tmp_' + slug(info['id']))
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True, exist_ok=True)
    pkg = pkg_name(info['id'])
    try:
        for i in zf.infolist():
            n = i.filename.replace('\\', '/')
            if not n.startswith(base) or n.endswith('/'):
                continue
            rel = n[len(base):]
            dest = tmp / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            raw = zf.read(i)
            if rel.endswith('.py') and _obfuscated(raw):
                raise AddonError('Dieses Addon ist verschleiert (der Code liegt als gepackter Text/Bytecode vor, Datei %s). Solcher Code '
                                 'ist an eine bestimmte Python-Version gebunden und bringt die Engine zum Absturz („Segmentation fault“). '
                                 'Bitte die unverschlüsselte Version des Addons verwenden.' % rel)
            if rel.endswith('.py'):
                raw = _rewrite(raw.decode('utf-8', 'replace'), pkg).encode('utf-8')
            dest.write_bytes(raw)
        _ensure_settings(tmp)
        for lib in (info['library'], info['script_lib']):
            if lib and not (tmp / lib).is_file():
                raise AddonError('Einstiegsdatei %s fehlt im Addon.' % lib)
        if info['service_lib'] and not (tmp / info['service_lib']).is_file():
            raise AddonError('Die Datei des Dienstes fehlt im Addon.')
        if info['kind'] == 'module' and not (tmp / (info['module_lib'] or 'lib')).exists():
            info['module_lib'] = ''                       # Ordner fehlt: dann liegt die Bibliothek im Hauptordner
        info['pkg'] = pkg
        info['rw'] = REWRITE_VERSION
        info['provider_id'] = ('addon_' + slug(info['id'])) if (info['library'] or info['script_lib']) else ''
        (tmp / 'moviescout-addon.json').write_text(json.dumps(info, ensure_ascii=False, indent=1), 'utf-8')
        stop_service(info['id'])
        _DEP_CACHE.clear()
        try:
            FS.move_dir(tmp, target)                     # Android-Speicher erlaubt oft kein Umbenennen von Ordnern: dann wird kopiert
        except OSError as e:
            raise AddonError('Der Addon-Ordner lässt sich nicht schreiben (%s). Ist der Speicher voll oder schreibgeschützt?' % e)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    for k in [k for k in sys.modules if k == pkg or k.startswith(pkg + '.')]:
        sys.modules.pop(k, None)                          # frischer Import nach Update
    if info['provider_id']:
        SYS.PROV_DIR.mkdir(parents=True, exist_ok=True)
        fname = info['provider_id'] + '.py'
        tpl = SHIM if info['library'] else SCRIPT_SHIM
        (SYS.PROV_DIR / fname).write_text(tpl % {'name': info['name'], 'id': info['id'], 'sid': info['provider_id']}, 'utf-8')
        info['file'] = fname
    return info


def remove(addon_id):
    m = meta(addon_id)
    if not m:
        raise AddonError('Addon nicht installiert.')
    if m.get('provider_id') or m.get('file'):
        try:
            SYS.delete_file('provider', m.get('file') or m['provider_id'] + '.py')
        except Exception:                                  # noqa: BLE001
            pass
    stop_service(addon_id)
    _DEP_CACHE.clear()
    shutil.rmtree(addon_path(addon_id), ignore_errors=True)
    return m


# ----------------------------------------------------------------------------- Abhängigkeiten (script.module.*)

def module_lib_dir(addon_id):
    """Ordner, in dem die Python-Pakete einer Bibliothek (script.module.*) liegen, oder None."""
    m = meta(addon_id)
    if not m or 'module' not in (m.get('kinds') or []):
        return None
    adir = addon_path(addon_id)
    p = adir / (m.get('module_lib') or '.')
    if p.is_file():
        p = p.parent
    return p if p.is_dir() else adir


def dep_ids(addon_id, _seen=None):
    """Alle (auch mittelbar) benötigten, installierten Bibliotheken in Kodi-Reihenfolge."""
    seen = _seen if _seen is not None else {addon_id}
    out = []
    for r in meta(addon_id).get('requires') or []:
        rid = r.get('id')
        if rid in seen or not meta(rid):
            continue
        seen.add(rid)
        out.append(rid)
        out += dep_ids(rid, seen)
    return out


def dep_paths(addon_id):
    """Bibliotheks-Ordner der benötigten Addons (für sys.path und den Importfinder); legt deren `resources`-Pakete an."""
    out = []
    for rid in dep_ids(addon_id):
        d = module_lib_dir(rid)
        if d is not None:
            _ensure_pkg(rid)
            out.append(str(d))
    return out


# ----------------------------------------------------------------------------- Ausführen

def _ensure_pkg(addon_id):
    pkg = pkg_name(addon_id)
    mod = sys.modules.get(pkg)
    rdir = str(addon_path(addon_id) / 'resources')
    if mod is None:
        mod = types.ModuleType(pkg)
        mod.__path__ = [rdir]
        mod.__file__ = rdir + '/__init__.py'
        sys.modules[pkg] = mod
    return pkg


def _plugin_query(addon_id, url):
    url = str(url or '')
    if url.startswith('plugin://'):
        return urlparse(url).query
    return url.lstrip('?')


LOCAL_FILES = {}             # Token -> Pfad: Dateien, die ein Addon als Wiedergabe-Ergebnis geliefert hat (z. B. entschlüsselte Titel)


def local_file_url(path):
    import secrets
    from urllib.parse import quote as _q
    if len(LOCAL_FILES) > 300:
        for k in list(LOCAL_FILES)[:100]:
            LOCAL_FILES.pop(k, None)
    tok = secrets.token_urlsafe(12)
    LOCAL_FILES[tok] = str(path)
    return 'msfile://%s/%s' % (tok, _q(Path(path).name))


def _localize_resolved(ctx):
    """Addons, die eine Datei statt einer Adresse liefern (Deezer entschlüsselt Titel in special://temp), bekommen eine
    Adresse der Engine: msfile://<Token>/<Name>."""
    from kodi_runtime import xbmcvfs
    for r in ctx.resolved:
        pth = str(r.get('path') or '')
        if not pth or re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*://', pth) and not pth.startswith('special://'):
            continue
        real = xbmcvfs.translatePath(pth) if pth.startswith('special://') else pth
        try:
            if Path(real).is_file():
                r['path'] = local_file_url(real)
        except OSError:
            pass


# ----------------------------------------------------------------------------- Dienste (xbmc.service)
# Manche Addons brauchen einen Hintergrunddienst (Telegram Scraper: lokaler Stream-Server auf 127.0.0.1). Wie Kodi ihn beim
# Start startet, wird er hier beim ersten Aufruf des Addons gestartet und läuft im Hintergrund weiter.
_SERVICES = {}                                    # addon_id -> {'thread', 'abort', 'paths'}
_SVC_LOCK = threading.Lock()


def _service_lib(addon_id):
    try:
        root = ET.fromstring((addon_path(addon_id) / 'addon.xml').read_text('utf-8'))
    except Exception:                              # noqa: BLE001
        return ''
    for ext in root.findall('extension'):
        if ext.get('point') == 'xbmc.service' and ext.get('library'):
            return ext.get('library')
    return ''


_THREAD_PATCHED = False


def _patch_threads():
    """Threads, die ein Addon-Dienst startet (Stream-Server, Event-Loop …), erben dessen Kontext - sonst wüssten sie nicht, zu welchem
    Addon sie gehören (xbmcaddon.Addon() ohne Kennung, Einstellungen, Protokoll)."""
    global _THREAD_PATCHED
    if _THREAD_PATCHED:
        return
    _THREAD_PATCHED = True
    orig_init = threading.Thread.__init__
    orig_run = threading.Thread.run

    def init(self, *a, **k):
        orig_init(self, *a, **k)
        c = context.peek()
        self._ms_ctx = c if (c is not None and getattr(c, 'abort', None) is not None) else None

    def run(self):
        c = getattr(self, '_ms_ctx', None)
        if c is None:
            return orig_run(self)
        with context.use(c):
            return orig_run(self)
    threading.Thread.__init__ = init
    threading.Thread.run = run


def service_status(addon_id):
    cur = _SERVICES.get(addon_id)
    lib = _service_lib(addon_id)
    if not lib:
        return {'has_service': False}
    ctx = (cur or {}).get('ctx')
    return {'has_service': True, 'running': bool(cur and cur['thread'].is_alive()),
            'log': list(ctx.svc_log)[-15:] if ctx is not None and ctx.svc_log is not None else []}


def _service_main(addon_id, entry, abort, ctx):
    with context.use(ctx):
        try:
            code = compile(Path(entry).read_text('utf-8'), str(entry), 'exec')
            exec(code, {'__name__': '__main__', '__file__': str(entry), '__builtins__': __builtins__, 'sys': sys})
        except SystemExit:
            pass
        except BaseException as e:                 # noqa: BLE001
            ctx.svc_log.append('%s Dienst beendet: %s: %s' % (time.strftime('%H:%M:%S'), type(e).__name__, e))
            log.warning('Dienst von %s beendet', addon_id, exc_info=True)


def start_service(addon_id):
    with _SVC_LOCK:
        cur = _SERVICES.get(addon_id)
        if cur and cur['thread'].is_alive():
            return False
        lib = _service_lib(addon_id)
        adir = addon_path(addon_id)
        entry = adir / lib if lib else None
        if not entry or not entry.is_file():
            _SERVICES[addon_id] = {'thread': threading.Thread(), 'abort': threading.Event(), 'paths': []}   # keiner: nicht erneut suchen
            return False
        _patch_threads()
        _ensure_pkg(addon_id)
        try:
            dep_paths(addon_id)
        except Exception:                          # noqa: BLE001
            log.warning('Bibliotheken von %s nicht vorbereitet', addon_id, exc_info=True)
        if len(sys.argv) > 1 and not sys.argv[0].startswith('plugin://'):
            sys.argv = [sys.argv[0]]                 # Kodi-Dienste haben keine Plugin-Argumente (ENGINE_ARGV merkt sich die echten für den Neustart)
        abort = threading.Event()
        ctx = context.RequestContext()
        ctx.addon_id = addon_id
        ctx.abort = abort
        ctx.svc_log = collections.deque(maxlen=60)
        t = threading.Thread(target=_service_main, args=(addon_id, entry, abort, ctx), name='svc-' + addon_id, daemon=True)
        _SERVICES[addon_id] = {'thread': t, 'abort': abort, 'ctx': ctx, 'paths': []}
        t.start()
        return True


ENGINE_ARGV = list(sys.argv)                       # echte Startargumente der Engine (für den Neustart)


_DEP_CACHE = {}


def _dep_dirs_cached(aid):
    """Bibliotheks-Ordner für den Importfinder (kurz gemerkt: find_spec läuft bei jedem Import)."""
    hit = _DEP_CACHE.get(aid)
    if hit and time.time() - hit[0] < 30:
        return hit[1]
    try:
        v = [str(module_lib_dir(r)) for r in dep_ids(aid) if module_lib_dir(r) is not None]
    except Exception:                                  # noqa: BLE001
        v = []
    _DEP_CACHE[aid] = (time.time(), v)
    return v


class _AddonFinder:
    """Top-Level-Module eines Addons (z. B. `import service`) für Threads, die zu einem Addon gehören – ohne dessen Ordner global in sys.path
    zu legen (zwei Addons mit gleich benannten Dateien würden sich sonst verwechseln). Steht am Ende von sys.meta_path: verdeckt nichts."""

    def find_spec(self, name, path=None, target=None):
        if path is not None or '.' in name:
            return None
        ctx = context.peek()
        aid = getattr(ctx, 'addon_id', '') if ctx is not None else ''
        if not aid:
            return None
        import importlib.util
        adir = addon_path(aid)
        bases = [adir, adir / 'resources' / 'lib'] + [Path(x) for x in _dep_dirs_cached(aid)]
        for base in bases:
            f = base / (name + '.py')
            if f.is_file():
                return importlib.util.spec_from_file_location(name, str(f))
            d = base / name / '__init__.py'
            if d.is_file():
                return importlib.util.spec_from_file_location(name, str(d), submodule_search_locations=[str(base / name)])
        return None


if not any(isinstance(f, _AddonFinder) for f in sys.meta_path):
    sys.meta_path.append(_AddonFinder())


def start_all_services(delay=3.0):
    """Wie Kodi beim Start: Dienste aller installierten Addons hochfahren (xStream etwa prüft dort Domains und aktualisiert ResolveURL;
    sein Hauptmenü wartet sonst beim ersten Öffnen bis zu 16 s darauf). Läuft im Hintergrund, damit der Start nicht aufgehalten wird."""
    def _go():
        time.sleep(delay)
        for m in installed():
            try:
                if _service_lib(m['id']):
                    if start_service(m['id']):
                        time.sleep(2)                    # nacheinander: parallele Start-Prüfungen (Domains, Updates) überlasten sonst Handy und Netz
            except Exception:                              # noqa: BLE001
                log.warning('Dienst von %s nicht gestartet', m.get('id'), exc_info=True)
    threading.Thread(target=_go, name='svc-start', daemon=True).start()


def stop_service(addon_id):
    with _SVC_LOCK:
        cur = _SERVICES.pop(addon_id, None)
    if cur:
        cur['abort'].set()
        if cur['thread'].ident:
            cur['thread'].join(3)
        for pp in cur.get('paths') or []:
            while pp in sys.path:
                sys.path.remove(pp)


def _hide_engine_modules():
    """Die Scraper der Engine stehen unter ihrem Dateinamen in sys.modules (z. B. `internetarchive`, `netzkino`, `vavoo`).
    Ein Addon mit gleichnamigem Modul (xStream: sites/netzkino.py) bekäme sonst das falsche. Für die Dauer des Laufs beiseite legen."""
    dirs = {str(SYS.PROV_DIR), str(SYS.BUNDLED_DIR)}
    saved = {}
    for name, mod in list(sys.modules.items()):
        f = getattr(mod, '__file__', None) or ''
        if f and '.' not in name and os.path.dirname(f) in dirs:
            saved[name] = sys.modules.pop(name, None)
    return saved


def _forget_modules(adir):
    """Module, die der Lauf aus dem Addon-Ordner geladen hat (z. B. `import default`), wieder vergessen: jeder Aufruf startet frisch wie in Kodi,
    und ein gleichnamiges Modul eines anderen Addons wird nicht verwechselt."""
    root = str(adir)
    for name, mod in list(sys.modules.items()):
        f = getattr(mod, '__file__', None) or ''
        if f and os.path.dirname(f) == root and name != '__main__' and '.' not in name:     # nur Module direkt im Addon-Ordner, nicht dessen Bibliotheken (Telethon laden ist teuer)
            sys.modules.pop(name, None)


WEB_FORCED = {'plugin.video.multitrailer': {'prefer_dash': 'false'}}


def _force_settings(addon_id):
    """Einstellungen, die im Web-Player immer so stehen müssen: MultiTrailer baut für YouTube sonst DASH-Manifeste, die der Player nicht
    abspielen kann („DASH-Fehler … is not available“). Gilt für jeden Aufruf des Addons (Trailer-Knopf und normale Quellenliste)."""
    force = WEB_FORCED.get(addon_id)
    if not force:
        return
    try:
        from kodi_runtime import xbmcaddon
        sid = xbmcaddon.store_id(addon_id)
        cur = xbmcaddon._load(sid)
        todo = {k: v for k, v in force.items() if str(cur.get(k, 'true')).lower() != v}
        if todo:
            xbmcaddon.save_settings(todo, sid)
    except Exception:                                      # noqa: BLE001
        log.warning('Einstellung für %s nicht gesetzt', addon_id, exc_info=True)


def friendly_error(addon_id, exc):
    """Fehler eines Addons in einen Satz übersetzen, den man ohne Python-Kenntnisse versteht."""
    import traceback
    m = meta(addon_id)
    name = m.get('name') or addon_id
    if isinstance(exc, ModuleNotFoundError) or (isinstance(exc, ImportError) and getattr(exc, 'name', None)):
        mod = getattr(exc, 'name', '') or ''
        try:
            from . import addonrepo as AR
            miss = AR.missing(m)
        except Exception:                                  # noqa: BLE001
            miss = []
        if miss:
            return '„%s“ braucht noch %s. Unter Quellen & System → „Kodi-Programme, Dienste & Bibliotheken“ auf „Nachladen“ tippen.' % (name, ', '.join(miss))
        return '„%s“ braucht das Python-Modul „%s“, das auf diesem Gerät fehlt (kein passendes script.module.* installiert).' % (name, mod)
    where = ''
    try:
        root = str(ADDONS_DIR)
        for fr in reversed(traceback.extract_tb(exc.__traceback__)):
            if fr.filename.startswith(root):
                where = ' (%s, Zeile %d)' % (os.path.relpath(fr.filename, root).split(os.sep, 1)[-1], fr.lineno)
                break
    except Exception:                                      # noqa: BLE001
        pass
    return '„%s“ wurde mit einem Fehler beendet: %s: %s%s' % (name, type(exc).__name__, str(exc)[:200], where)


def run(addon_id, url='', params=None, query='', search=False, play=False, _depth=0, script=False, args=None):
    """main.py des Addons wie Kodi aufrufen. Ergebnisse landen im Kontext der Engine (ctx.items / ctx.resolved).
    script=True: Programm (xbmc.python.script) wie RunScript(id, args …) starten."""
    m = meta(addon_id)
    if not m:
        raise RuntimeError('Addon %s ist nicht installiert.' % addon_id)
    m = _migrate(addon_id, m)
    adir = addon_path(addon_id)
    _ensure_settings(adir)
    ctx = context.current()
    lib = (m.get('script_lib') if script else m.get('library')) or ''
    if not lib:
        raise RuntimeError('%s ist %s.' % (addon_id, 'kein Programm' if script else 'keine Videoquelle'))
    if search and not url and not script:
        url = _search_url(addon_id) or url
    q = '' if script else _plugin_query(addon_id, url)
    _force_settings(addon_id)
    if search and query:
        ctx.query = query
        q = (q + '&' if q else '') + 'query=' + quote(query)         # Addons lesen die Eingabe aus der Adresse oder per Dialog
    if addon_id not in _SERVICES:
        try:
            start_service(addon_id)
        except Exception:                          # noqa: BLE001
            log.warning('Dienst von %s nicht gestartet', addon_id, exc_info=True)
    with _RUN:
        _ensure_pkg(addon_id)
        old_argv, old_path, old_id = list(sys.argv), list(sys.path), getattr(ctx, 'addon_id', '')
        import json as _j
        old_json = (_j.loads, _j.load, _j.dumps, _j.dump)
        if script:
            sys.argv = [str(adir / lib)] + [str(x) for x in (args or [])]
        else:
            sys.argv = ['plugin://%s/' % addon_id, '1', '?' + q if q else '']
        sys.path.insert(0, str(adir))
        try:
            sys.path[1:1] = dep_paths(addon_id)             # benötigte Bibliotheken (script.module.*) hinter dem Addon-Ordner
        except Exception:                                  # noqa: BLE001
            log.warning('Bibliotheken von %s nicht eingebunden', addon_id, exc_info=True)
        hidden = _hide_engine_modules()
        old_cwd = os.getcwd()
        ctx.addon_id = addon_id
        import marshal as _m
        old_marshal = _m.loads

        def _safe_loads(data, *a, **k):                      # Bytecode anderer Python-Versionen würde den Interpreter abstürzen lassen
            r = old_marshal(data, *a, **k)
            caller = sys._getframe(1).f_globals.get('__name__', '')
            if isinstance(r, types.CodeType) and not caller.startswith(('importlib', '_frozen_importlib', 'zipimport', 'pkgutil', 'runpy')):
                raise RuntimeError('Addon will gepackten Bytecode ausführen - auf diesem Gerät nicht erlaubt (Absturzgefahr).')
            return r
        _m.loads = _safe_loads
        try:
            try:
                entry = adir / lib                          # nicht runpy: das würde sys.argv[0] auf den Dateipfad setzen
                code = compile(entry.read_text('utf-8'), str(entry), 'exec')
                exec(code, {'__name__': '__main__', '__file__': str(entry), '__builtins__': __builtins__, 'sys': sys})   # Kodi: sys ist im Hauptmodul schon da
            except SystemExit:
                pass
            except ImportError as e:
                raise AddonError(friendly_error(addon_id, e)) from e      # fehlende Bibliothek: verständlich melden
        finally:
            try:
                os.chdir(old_cwd)                    # Addons wechseln gern das Arbeitsverzeichnis (os.chdir) – das gilt für den ganzen Prozess
            except OSError:
                pass
            _forget_modules(adir)
            for k, v in hidden.items():
                if v is not None:
                    sys.modules[k] = v                 # nach dem Lauf gehört der Name wieder der Engine (Module des Addons mit gleichem Namen werden verworfen)
            _m.loads = old_marshal
            sys.argv, sys.path[:] = old_argv, old_path
            for sv in list(_SERVICES.values()):         # Bibliotheks-Pfade laufender Dienste bleiben erhalten (sie importieren später nach)
                for pth in sv.get('paths') or []:
                    if pth not in sys.path and sv['thread'].is_alive():
                        sys.path.append(pth)
            if (_j.loads, _j.load, _j.dumps, _j.dump) != old_json:       # Sicherheitsnetz: Addon hat das echte json verändert
                _j.loads, _j.load, _j.dumps, _j.dump = old_json
                log.warning('Addon %s hat json verändert - zurückgesetzt', addon_id)
            ctx.addon_id = old_id
    if script:
        return None
    if play and ctx.follow and not ctx.resolved and _depth < 2:     # Addon hat Player().play(Wiedergabeliste/plugin://…) aufgerufen: den Eintrag jetzt auflösen
        nxt, ctx.follow = ctx.follow, ''
        run(addon_id, nxt, params, play=True, _depth=_depth + 1)
        return None
    if play:
        _localize_resolved(ctx)
    if play:                                                # Mini-Server des Addons (127.0.0.1:Port) dem Proxy bekannt machen
        from . import proxy as P
        for r in ctx.resolved:
            P.allow_local(r.get('path') or '')
    if not q and not search and not play:                    # Startmenü: Eintrag für die Einstellungen des Addons anhängen
        if (adir / 'resources' / 'settings.xml').is_file():
            ctx.items.append({'title': 'Einstellungen', 'url': 'ms-settings:' + addon_id, 'next_func': 'ms_settings', 'is_playable': False,
                              'plot': 'Anmelden, Zugangsdaten und Optionen dieses Addons.', 'poster': '', 'icon': '', 'fanart': ''})
    if not q:
        for it in ctx.items:                                # Startmenü merken: dort steckt die Such-Adresse
            if _SEARCH_RE.search(str(it.get('url') or '')) and not it.get('is_playable'):
                _remember_search(addon_id, it['url'])
                break
    return None


_SCRIPT_DEPTH = threading.local()


def script_target(ref):
    """RunScript-Ziel -> Addon-Kennung: `script.foo`, `special://home/addons/script.foo/default.py` oder ein Pfad im Addon-Ordner."""
    ref = str(ref or '').strip().strip('"\'')
    if meta(ref):
        return ref
    m = re.search(r'(?:addons[\\/]|^)([A-Za-z0-9_.-]{3,80})[\\/]', ref.replace('special://home/', '').replace('special://xbmc/', ''))
    if m and meta(m.group(1)):
        return m.group(1)
    try:
        rp = Path(ref).resolve()
        if str(rp).startswith(str(ADDONS_DIR.resolve())):
            aid = rp.relative_to(ADDONS_DIR.resolve()).parts[0]
            if meta(aid):
                return aid
    except (OSError, ValueError, IndexError):
        pass
    return ''


def run_script(ref, args=None, rid=''):
    """RunScript(ref, args …): Programm eines installierten Addons starten. Läuft in eigenem Unter-Kontext; Meldungen, Rückfragen und
    Oberflächen-Wünsche gehen an den Aufrufer. Rückgabe: {'ok', 'notes', 'id'}."""
    aid = script_target(ref)
    if not aid:
        raise AddonError('Programm %s ist nicht installiert.' % ref)
    m = meta(aid)
    if not m.get('script_lib'):
        raise AddonError('%s ist kein startbares Programm.' % (m.get('name') or aid))
    depth = getattr(_SCRIPT_DEPTH, 'n', 0)
    if depth >= 3:
        raise AddonError('RunScript ruft sich zu oft selbst auf.')
    parent = context.peek()
    sub = context.RequestContext()
    own_abort = threading.Event()
    if parent is not None:
        sub.rid, sub.client, sub.parent, sub.cancelled = parent.rid, parent.client, parent, parent.cancelled
    sub.abort = own_abort                       # Threads des Programms (Spiel-Schleife) erben so den Kontext: Rückfragen, Fenster
    if rid:
        sub.rid = rid
    _patch_threads()
    _SCRIPT_DEPTH.n = depth + 1
    try:
        with context.use(sub):
            try:
                run(aid, script=True, args=list(args or []))
            except SystemExit:
                pass
            except AddonError:
                raise
            except Exception as e:                         # noqa: BLE001
                log.warning('Programm %s beendet mit Fehler', aid, exc_info=True)
                raise AddonError(friendly_error(aid, e)) from e
    finally:
        _SCRIPT_DEPTH.n = depth
        own_abort.set()                                    # übrig gebliebene Schleifen des Programms (Monitor) enden
        if _UDLG is not None and sub.rid and depth == 0:
            _UDLG.close_windows(sub.rid)
    if parent is not None:
        parent.notes.extend(sub.notes)
        del parent.notes[:-20]
        if sub.ui and not parent.ui:
            parent.ui = sub.ui
    return {'ok': True, 'id': aid, 'notes': sub.notes}


def script_menu(addon_id, url='', params=None):
    """Quelle eines Programms (script.*): ein Eintrag „Starten“; ein Klick führt das Programm aus, Meldungen erscheinen in der Oberfläche."""
    ctx = context.current()
    m = meta(addon_id)
    u = str(url or '')
    if u.startswith('script://'):
        qs = dict(parse_qsl(urlparse(u).query))
        res = run_script(addon_id, [x for x in qs.get('args', '').split('\n') if x] if qs.get('args') else [])
        if not res['notes']:
            ctx.note('info', m.get('name') or addon_id, 'Programm beendet.')
        ctx.items.append({'title': 'Erneut starten', 'url': u, 'next_func': 'load', 'is_playable': False,
                          'plot': 'Das Programm noch einmal ausführen.', 'poster': '', 'icon': '', 'fanart': ''})
    else:
        ctx.items.append({'title': 'Starten: ' + (m.get('name') or addon_id), 'url': 'script://%s/run' % addon_id, 'next_func': 'load',
                          'is_playable': False, 'plot': (m.get('summary') or 'Programm ausführen.') + '\nEigene Fenster (Spiele) erscheinen im Vollbild; Zurück schließt sie. '
                          'Fenster aus Skin-Dateien (WindowXML) gehen hier nicht.', 'poster': '', 'icon': '', 'fanart': ''})
        if (addon_path(addon_id) / 'resources' / 'settings.xml').is_file():
            ctx.items.append({'title': 'Einstellungen', 'url': 'ms-settings:' + addon_id, 'next_func': 'ms_settings', 'is_playable': False,
                              'plot': 'Optionen dieses Programms.', 'poster': '', 'icon': '', 'fanart': ''})
    return None


def _remember_search(addon_id, url):
    m = meta(addon_id)
    if m and m.get('search_url') != url:
        m['search_url'] = url
        try:
            (addon_path(addon_id) / 'moviescout-addon.json').write_text(json.dumps(m, ensure_ascii=False, indent=1), 'utf-8')
        except OSError:
            pass


def _search_url(addon_id):
    m = meta(addon_id)
    if m.get('search_url'):
        return m['search_url']
    sub = context.RequestContext()                          # Startmenü still einlesen, um die Such-Adresse zu finden
    with context.use(sub):
        run(addon_id, '')
    return meta(addon_id).get('search_url', '')


def decorate(item, ctx_addon_id):
    """Für xbmcplugin: aus einem addDirectoryItem eines Addons ein MovieScout-Item machen (volle plugin://-Adresse behalten)."""
    url = item.get('url') or ''
    is_search = bool(_SEARCH_RE.search(url))
    item['next_func'] = 'search' if is_search else ('get_hosters' if item.get('is_playable') else 'load')
    item.pop('params', None)
    if re.search(r'[?&]action=(open_settings|settings)(&|$)', url):        # Einstellungen des Addons gibt es hier nicht
        return None
    return item


# ----------------------------------------------------------------------------- Einstellungen (settings.xml -> Formular)

def _label(addon_id, v):
    """Beschriftung: Zahl = Eintrag aus strings.po, sonst Text (Kodi-Markup entfernt)."""
    from kodi_runtime import xbmcaddon
    from . import normalize as N
    v = (v or '').strip()
    if v.lstrip('-').isdigit():
        return N.clean_markup(xbmcaddon._strings(addon_id).get(int(v), '')) or ''
    return N.clean_markup(v)


def _first(el, tag):
    c = el.find(tag)
    return (c.text or '').strip() if c is not None and c.text is not None else None


def settings_schema(addon_id):
    """Liest resources/settings.xml (altes und neues Kodi-Format) und gibt Formularfelder zurück:
    [{id,type,label,value,default,options,min,max,step,hidden,action,category,group,help}] - type: text|bool|select|number|action|sep."""
    from kodi_runtime import xbmcaddon
    _ensure_settings(addon_path(addon_id))
    p = addon_path(addon_id) / 'resources' / 'settings.xml'
    if not p.is_file():
        return []
    try:
        root = ET.parse(str(p)).getroot()
    except ET.ParseError as e:
        raise AddonError('settings.xml ist ungültig: %s' % e)
    saved = xbmcaddon.all_settings(xbmcaddon.store_id(addon_id))
    fields = []

    def walk(node, category='', group=''):
        for ch in node:
            if ch.tag == 'category':
                walk(ch, _label(addon_id, ch.get('label')), group)
            elif ch.tag == 'group':
                walk(ch, category, _label(addon_id, ch.get('label')))
            elif ch.tag == 'section':
                walk(ch, category, group)
            elif ch.tag == 'setting':
                f = _field(ch, category, group)
                if f:
                    fields.append(f)

    def _field(el, category, group):
        sid = el.get('id') or ''
        typ = (el.get('type') or 'text').lower()
        ctl = el.find('control')
        ctype = ((ctl.get('type') if ctl is not None else '') or '').lower()
        label = _label(addon_id, el.get('label')) or sid
        f = {'id': sid, 'label': label, 'category': category, 'group': group, 'type': 'text', 'help': _label(addon_id, el.get('help')),
             'hidden': False, 'options': [], 'default': ''}
        if typ in ('sep', 'lsep'):
            return {'id': '', 'type': 'sep', 'label': label if typ == 'lsep' else '', 'category': category, 'group': group}
        if not sid and typ != 'action':
            return None
        d = el.get('default')
        if d is None:
            d = _first(el, 'default')
        f['default'] = d if d is not None else ''
        if ctl is not None and (_first(ctl, 'hidden') or '').lower() == 'true' or el.get('option') == 'hidden':
            f['hidden'] = True
        # Auswahlmöglichkeiten
        opts = []
        for o in el.iter('option'):
            if (o.text or '').strip() != '' or o.get('label'):
                opts.append({'value': (o.text or '').strip(), 'label': _label(addon_id, o.get('label')) or (o.text or '').strip()})
        values, lvalues = el.get('values'), el.get('lvalues')
        if typ in ('enum', 'labelenum', 'select') or values or lvalues:
            vals = (values or '').split('|') if values else []
            lv = (lvalues or '').split('|') if lvalues else []
            n = max(len(vals), len(lv))
            for i in range(n):
                lab = _label(addon_id, lv[i]) if i < len(lv) else (vals[i] if i < len(vals) else str(i))
                opts.append({'value': str(i) if typ == 'enum' or (lvalues and not values) else (vals[i] if i < len(vals) else str(i)), 'label': lab or str(i)})
        if typ in ('bool', 'boolean') or ctype == 'toggle':
            f['type'] = 'bool'
        elif opts:
            f['type'] = 'select'
            f['options'] = opts
        elif typ in ('number', 'integer', 'slider', 'float') or ctype in ('slider', 'spinner'):
            f['type'] = 'number'
            rng = el.get('range')
            if rng:
                a = [x.strip() for x in rng.split(',')]
                try:
                    f['min'], f['step'], f['max'] = (float(a[0]), float(a[1]), float(a[2])) if len(a) == 3 else (float(a[0]), 1.0, float(a[-1]))
                except (ValueError, IndexError):
                    pass
            cons = el.find('constraints')
            if cons is not None:
                for key, tag in (('min', 'minimum'), ('max', 'maximum'), ('step', 'step')):
                    v = _first(cons, tag)
                    if v:
                        try:
                            f[key] = float(v)
                        except ValueError:
                            pass
        elif typ == 'action' or ctype == 'button':
            data = _first(el, 'data') or el.get('action') or ''
            m = re.search(r'(?:RunPlugin|RunScript|ActivateWindow)\(([^)]*)\)', data)
            f['type'] = 'action'
            f['action'] = (m.group(1) if m else data).strip().strip('"\'')
        elif typ in ('lsep',):
            return None
        # aktueller Wert
        if f['type'] != 'action':
            f['value'] = saved.get(sid, f['default']) if sid in saved else f['default']
            if sid in WEB_FORCED.get(addon_id, {}):
                f['value'] = WEB_FORCED[addon_id][sid]
                f['help'] = ((f.get('help') or '') + ' Im MovieScout immer aus: der Web-Player kann diese Art Stream nicht abspielen.').strip()
            if f['type'] == 'bool':
                f['value'] = str(f['value']).lower() in ('true', '1', 'yes')
        return f

    walk(root)
    return fields


def save_settings(addon_id, values):
    from kodi_runtime import xbmcaddon
    ok_ids = {f['id'] for f in settings_schema(addon_id) if f.get('id') and f['type'] != 'action'}
    clean = {}
    for k, v in (values or {}).items():
        if k in ok_ids:
            clean[k] = ('true' if v else 'false') if isinstance(v, bool) else str(v)
    xbmcaddon.save_settings(clean, xbmcaddon.store_id(addon_id))
    return clean


def run_action(addon_id, url, rid=''):
    """Knopf aus den Einstellungen („Anmelden“, „Ordner wählen“ …) ausführen; Meldungen des Addons zurückgeben."""
    if not url.startswith('plugin://%s' % addon_id):
        parts = _split_script_args(url)                     # Einstellungs-Knopf „RunScript(script.x, a, b)“
        tgt = script_target(parts[0]) if parts else ''
        if not tgt or tgt != addon_id and not (meta(tgt) or {}).get('script_lib'):
            raise AddonError('Nur Aktionen des Addons selbst sind erlaubt.')
        ctx = context.RequestContext()
        ctx.rid = rid
        with context.use(ctx):
            run_script(tgt, parts[1:], rid)
        return {'notes': ctx.notes, 'items': 0}
    ctx = context.RequestContext()
    ctx.rid = rid
    with context.use(ctx):
        run(addon_id, url)
    return {'notes': ctx.notes, 'items': len(ctx.items)}


def _split_script_args(text):
    return [x.strip().strip('"\'') for x in str(text or '').split(',') if x.strip()]
