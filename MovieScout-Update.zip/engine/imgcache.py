# -*- coding: utf-8 -*-
"""Bilder-Speicher: Poster & Co. werden einmal geladen und danach vom Gerät geliefert (schneller, auch bei langsamem Netz).
Datei-Cache unter <Daten>/imgcache, älteste Dateien werden bei Überschreitung der Höchstgröße zuerst gelöscht."""
import hashlib
import json
import logging
import os
import threading
import time
from pathlib import Path

from kodi_runtime import paths as _paths
from . import proxy as P

log = logging.getLogger('minikodi.img')
DIR = _paths.DATA_DIR / 'imgcache'
MAX_FILE = 6 * 1024 * 1024
DEFAULT_MB = 300
_lock = threading.Lock()
_bad = {}                 # url -> Zeitpunkt des letzten Fehlschlags (nicht ständig neu versuchen)
_writes = 0


def _path(url):
    k = hashlib.sha1(url.encode('utf-8')).hexdigest()
    return DIR / k[:2] / k


def get(url, max_mb=DEFAULT_MB):
    """(Bytes, Content-Type, aus_dem_Speicher). Wirft P.Blocked / ValueError / OSError bei Problemen."""
    global _writes
    p = _path(url)
    try:
        raw = p.read_bytes()
        head, _, body = raw.partition(b'\n')
        try:
            os.utime(str(p), None)
        except OSError:
            pass
        return body, json.loads(head.decode('utf-8')).get('ct', 'image/jpeg'), True
    except (OSError, ValueError):
        pass
    if time.time() - _bad.get(url, 0) < 60:
        raise ValueError('Bild kürzlich nicht ladbar')
    try:
        up = P.fetch('GET', url, {'Accept': 'image/*,*/*;q=0.5'}, timeout=15)
        try:
            ct = (up.headers.get('content-type') or '').split(';')[0].strip().lower()
            if up.status != 200 or not ct.startswith('image/'):
                raise ValueError('Kein Bild (HTTP %s, %s)' % (up.status, ct or '?'))
            data = up.read(MAX_FILE + 1)
        finally:
            up.close()
        if not data or len(data) > MAX_FILE:
            raise ValueError('Bild leer oder zu groß')
    except Exception:
        _bad[url] = time.time()
        if len(_bad) > 2000:
            _bad.clear()
        raise
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix('.tmp%d' % threading.get_ident())
        tmp.write_bytes(json.dumps({'ct': ct}).encode('utf-8') + b'\n' + data)
        os.replace(str(tmp), str(p))
        with _lock:
            _writes += 1
            do_prune = _writes % 40 == 0
        if do_prune:
            prune(max_mb)
    except OSError as e:
        log.warning('Bild nicht gespeichert: %s', e)
    return data, ct, False


def _files():
    out = []
    try:
        for sub in DIR.iterdir():
            if sub.is_dir():
                for f in sub.iterdir():
                    try:
                        st = f.stat()
                        out.append((st.st_mtime, st.st_size, f))
                    except OSError:
                        pass
    except OSError:
        pass
    return out


def prune(max_mb=DEFAULT_MB):
    limit = max(20, int(max_mb)) * 1024 * 1024
    files = _files()
    total = sum(s for _, s, _ in files)
    if total <= limit:
        return 0
    n = 0
    for _, size, f in sorted(files):
        try:
            f.unlink()
            total -= size
            n += 1
        except OSError:
            pass
        if total <= limit * 0.8:
            break
    return n


def stats():
    files = _files()
    return {'files': len(files), 'mb': round(sum(s for _, s, _ in files) / 1048576, 1)}


def clear():
    n = 0
    for _, _, f in _files():
        try:
            f.unlink()
            n += 1
        except OSError:
            pass
    return n
