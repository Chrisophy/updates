# -*- coding: utf-8 -*-
"""Entdecken (TMDB-Listen) und Trakt (Watchlist, Verlauf, Angesagt, Empfehlungen).

Beides war bisher nur im Kodi-Addon „MovieScout“ vorhanden. Hier läuft es in der Engine, die Oberfläche zeigt die Ergebnisse
als Poster-Listen; ein Klick sucht den Titel in allen Quellen.

TMDB: braucht den (kostenlosen) API-Schlüssel aus den Einstellungen (api.tmdb). Trakt: eigene App-Daten (Client-ID und Secret von
trakt.tv/oauth/applications) in den Einstellungen; die Anmeldung läuft über den Geräte-Code (PIN auf trakt.tv/activate).
Die Anmelde-Token liegen in userData/trakt.json, nicht in den Einstellungen.
"""
import json
import logging
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from kodi_runtime import paths, xbmcaddon

from . import cache as _cachemod
from . import metadata as MD

log = logging.getLogger('engine.discover')

TRAKT_BASE = os.environ.get('MOVIESCOUT_TRAKT_BASE', 'https://api.trakt.tv').rstrip('/')
_C = _cachemod.Cache('discover', ttl=600, max_mem=200, persist=False)
_CT = _cachemod.Cache('traktmeta', ttl=7 * 24 * 3600, max_mem=800, persist=True)
_LOCK = threading.Lock()
_POOL = ThreadPoolExecutor(max_workers=6, thread_name_prefix='disc')


class DiscoverError(Exception):
    """Meldung, die der Nutzer lesen kann (kein Schlüssel, Netzfehler, nicht angemeldet …)."""


# --------------------------------------------------------------------------- TMDB-Listen

MOVIE_LISTS = {
    'kino': ('Neu im Kino', '/movie/now_playing', {'region': 'DE'}),
    'popular': ('Am populärsten', '/movie/popular', {}),
    'top_rated': ('Am besten bewertet', '/movie/top_rated', {}),
    'votes': ('Meist bewertet', '/discover/movie', {'sort_by': 'vote_count.desc'}),
    'revenue': ('Box Office', '/discover/movie', {'sort_by': 'revenue.desc'}),
}
TV_LISTS = {
    'airing': ('Aktuell im TV', '/discover/tv', {'with_status': '0', 'sort_by': 'popularity.desc'}),
    'popular': ('Am populärsten', '/tv/popular', {}),
    'top_rated': ('Am besten bewertet', '/tv/top_rated', {}),
    'votes': ('Meist bewertet', '/discover/tv', {'sort_by': 'vote_count.desc'}),
}


def lists():
    return {'movie': [{'id': k, 'name': v[0]} for k, v in MOVIE_LISTS.items()],
            'tv': [{'id': k, 'name': v[0]} for k, v in TV_LISTS.items()]}


def _key():
    k = MD._key()
    if not k:
        raise DiscoverError('Für „Entdecken“ fehlt der TMDB-Schlüssel. Er ist kostenlos: themoviedb.org → Konto → Einstellungen → API. '
                            'Eintragen unter Einstellungen → Konten & Inhalte.')
    return k


def _tmdb(path, params):
    key = _key()
    q = {'language': 'de-DE', **params}
    try:
        return MD._get(path, q, key)
    except urllib.error.HTTPError as e:
        raise DiscoverError('TMDB: ' + ('Schlüssel ungültig' if e.code in (401, 403) else 'Fehler %d' % e.code))
    except Exception as e:                                  # noqa: BLE001
        raise DiscoverError('TMDB nicht erreichbar (%s)' % (getattr(e, 'reason', None) or e))


def _poster(p):
    return MD.IMG_BASE + p if p else ''


def _item(d, kind):
    title = d.get('title') or d.get('name') or ''
    date = d.get('release_date') or d.get('first_air_date') or ''
    return {'title': title, 'year': date[:4] if date[:4].isdigit() else '', 'poster': _poster(d.get('poster_path')),
            'plot': d.get('overview') or '', 'rating': round(float(d.get('vote_average') or 0), 1), 'tmdb': d.get('id') or 0, 'kind': kind}


def genres(kind):
    kind = 'tv' if kind == 'tv' else 'movie'
    ck = 'g|' + kind
    v = _C.get(ck)
    if v is None:
        v = [{'id': g['id'], 'name': g['name']} for g in (_tmdb('/genre/%s/list' % kind, {}).get('genres') or [])]
        _C.put(ck, v)
    return v


def discover(kind='movie', lst='popular', page=1, pages=2, genre='', year='', q=''):
    """-> {'items': [...], 'title': str}. pages = wie viele TMDB-Seiten (je 20 Titel) auf einmal."""
    kind = 'tv' if kind == 'tv' else 'movie'
    pages = max(1, min(int(pages or 1), 4))
    page = max(1, int(page or 1))
    q = (q or '').strip()
    year = str(year or '').strip()
    genre = str(genre or '').strip()
    if q:
        path, params, title = '/search/' + kind, {'query': q}, 'Suche „%s“' % q
    elif genre or year:
        path = '/discover/' + kind
        params = {'sort_by': 'popularity.desc', 'vote_count.gte': '20'}
        title = []
        if genre:
            if not genre.replace(',', '').isdigit():
                raise DiscoverError('Ungültiges Genre')
            params['with_genres'] = genre
            title.append(next((g['name'] for g in genres(kind) if str(g['id']) == genre), 'Genre'))
        if year:
            if not (year.isdigit() and 1880 <= int(year) <= 2100):
                raise DiscoverError('Ungültiges Jahr')
            params['primary_release_year' if kind == 'movie' else 'first_air_date_year'] = year
            title.append(year)
        title = ' · '.join(title)
    else:
        table = MOVIE_LISTS if kind == 'movie' else TV_LISTS
        if lst not in table:
            raise DiscoverError('Unbekannte Liste')
        title, path, params = table[lst][0], table[lst][1], dict(table[lst][2])
    ck = '|'.join([kind, path, json.dumps(params, sort_keys=True), str(page), str(pages)])
    hit = _C.get(ck)
    if hit is not None:
        return {'items': hit, 'title': title}
    futs = [_POOL.submit(_tmdb, path, {**params, 'page': page + i}) for i in range(pages)]
    items, seen = [], set()
    for f in futs:
        try:
            res = f.result(timeout=30)
        except DiscoverError:
            if not items:
                raise
            break
        for d in res.get('results') or []:
            if not (d.get('title') or d.get('name')) or d.get('id') in seen:
                continue
            seen.add(d.get('id'))
            items.append(_item(d, kind))
    _C.put(ck, items)
    return {'items': items, 'title': title}


# --------------------------------------------------------------------------- Trakt

TRAKT_FILE = lambda: paths.DATA_DIR / 'trakt.json'      # noqa: E731  (DATA_DIR kann sich im Test ändern)


def _client():
    s = xbmcaddon.all_settings()
    return (s.get('trakt.client_id') or '').strip(), (s.get('trakt.client_secret') or '').strip()


def _tokens():
    try:
        return json.loads(TRAKT_FILE().read_text('utf-8'))
    except (OSError, ValueError):
        return {}


def _save_tokens(t):
    f = TRAKT_FILE()
    with _LOCK:
        if not t:
            try:
                f.unlink()
            except OSError:
                pass
            return
        f.parent.mkdir(parents=True, exist_ok=True)
        tmp = f.with_suffix('.tmp')
        tmp.write_text(json.dumps(t), 'utf-8')
        try:
            os.chmod(str(tmp), 0o600)
        except OSError:
            pass
        os.replace(str(tmp), str(f))


def _trakt_http(method, path, body=None, params=None, auth=False, cid=''):
    cid = cid or _client()[0]
    if not cid:
        raise DiscoverError('Trakt: Client-ID fehlt (Einstellungen → Konten & Inhalte → Trakt).')
    url = TRAKT_BASE + path + (('?' + urllib.parse.urlencode(params)) if params else '')
    h = {'Content-Type': 'application/json', 'trakt-api-version': '2', 'trakt-api-key': cid, 'User-Agent': 'MovieScout'}
    if auth:
        tok = _tokens().get('access_token')
        if not tok:
            raise DiscoverError('Trakt: nicht angemeldet.')
        h['Authorization'] = 'Bearer ' + tok
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            raw = r.read().decode('utf-8', 'replace')
            return r.status, (json.loads(raw) if raw.strip() else {})
    except urllib.error.HTTPError as e:
        try:
            raw = e.read().decode('utf-8', 'replace')
            return e.code, (json.loads(raw) if raw.strip() else {})
        except Exception:                                   # noqa: BLE001
            return e.code, {}
    except Exception as e:                                  # noqa: BLE001
        raise DiscoverError('Trakt nicht erreichbar (%s)' % (getattr(e, 'reason', None) or e))


def _refresh():
    t = _tokens()
    cid, sec = _client()
    if not t.get('refresh_token') or not cid or not sec:
        return False
    code, d = _trakt_http('POST', '/oauth/token', {'refresh_token': t['refresh_token'], 'client_id': cid, 'client_secret': sec,
                                                   'redirect_uri': 'urn:ietf:wg:oauth:2.0:oob', 'grant_type': 'refresh_token'})
    if code == 200 and d.get('access_token'):
        _save_tokens({**t, 'access_token': d['access_token'], 'refresh_token': d.get('refresh_token') or t['refresh_token'],
                      'expires_at': int(time.time()) + int(d.get('expires_in') or 7776000)})
        return True
    return False


def status():
    cid, sec = _client()
    t = _tokens()
    return {'configured': bool(cid and sec), 'has_id': bool(cid), 'connected': bool(t.get('access_token')), 'user': t.get('user') or ''}


def auth_start():
    cid, sec = _client()
    if not (cid and sec):
        raise DiscoverError('Trakt: Client-ID und Client-Secret eintragen (Einstellungen → Konten & Inhalte → Trakt). '
                            'Erstellen: trakt.tv/oauth/applications → New Application, Redirect-URI urn:ietf:wg:oauth:2.0:oob.')
    code, d = _trakt_http('POST', '/oauth/device/code', {'client_id': cid})
    if code != 200 or not d.get('device_code'):
        raise DiscoverError('Trakt hat die Anmeldung abgelehnt (Fehler %s). Client-ID prüfen.' % code)
    return {'device_code': d['device_code'], 'user_code': d.get('user_code', ''), 'url': d.get('verification_url') or 'https://trakt.tv/activate',
            'interval': int(d.get('interval') or 5), 'expires_in': int(d.get('expires_in') or 600)}


def auth_poll(device_code):
    cid, sec = _client()
    code, d = _trakt_http('POST', '/oauth/device/token', {'code': device_code, 'client_id': cid, 'client_secret': sec})
    if code == 200 and d.get('access_token'):
        user = ''
        _save_tokens({'access_token': d['access_token'], 'refresh_token': d.get('refresh_token', ''),
                      'expires_at': int(time.time()) + int(d.get('expires_in') or 7776000), 'user': ''})
        try:
            c2, u = _trakt_http('GET', '/users/settings', auth=True)
            user = ((u.get('user') or {}).get('username') or '') if c2 == 200 else ''
        except DiscoverError:
            pass
        t = _tokens(); t['user'] = user; _save_tokens(t)
        return {'state': 'ok', 'user': user}
    return {'state': {400: 'pending', 429: 'slow', 404: 'error', 409: 'error', 410: 'expired', 418: 'denied'}.get(code, 'error'), 'code': code}


def logout():
    t = _tokens()
    cid, sec = _client()
    if t.get('access_token') and cid and sec:
        try:
            _trakt_http('POST', '/oauth/revoke', {'token': t['access_token'], 'client_id': cid, 'client_secret': sec})
        except DiscoverError:
            pass
    _save_tokens({})
    return {'connected': False}


TRAKT_LISTS = {
    'watchlist': ('Watchlist', '/sync/watchlist/%s', True), 'history': ('Zuletzt gesehen', '/sync/history/%s', True),
    'recommended': ('Empfehlungen', '/recommendations/%s', True), 'trending': ('Angesagt', '/%s/trending', False),
    'popular': ('Beliebt', '/%s/popular', False),
}


def trakt_lists():
    return [{'id': k, 'name': v[0], 'auth': v[2]} for k, v in TRAKT_LISTS.items()]


def _meta(kind, tid):
    """Poster und Beschreibung zu einer TMDB-Nummer (nur mit Schlüssel; Fehler sind hier nicht schlimm)."""
    ck = '%s|%s' % (kind, tid)
    v = _CT.get(ck)
    if v is not None:
        return v
    try:
        d = MD._get('/%s/%s' % (kind, tid), {'language': 'de-DE'}, MD._key())
    except Exception:                                       # noqa: BLE001
        return {}
    v = {'poster': _poster(d.get('poster_path')), 'plot': d.get('overview') or '', 'rating': round(float(d.get('vote_average') or 0), 1)}
    _CT.put(ck, v)
    return v


def trakt_list(name, kind='movie', limit=40):
    if name not in TRAKT_LISTS:
        raise DiscoverError('Unbekannte Trakt-Liste')
    kind = 'tv' if kind in ('tv', 'shows', 'show') else 'movie'
    title, path, need_auth = TRAKT_LISTS[name][0], TRAKT_LISTS[name][1], TRAKT_LISTS[name][2]
    if need_auth and not _tokens().get('access_token'):
        raise DiscoverError('Trakt: nicht angemeldet. Einstellungen → Konten & Inhalte → Trakt → Anmelden.')
    seg = 'shows' if kind == 'tv' else 'movies'
    params = {'limit': max(1, min(int(limit or 40), 100)), 'extended': 'full'}
    code, d = _trakt_http('GET', path % seg, params=params, auth=need_auth)
    if code == 401 and need_auth and _refresh():
        code, d = _trakt_http('GET', path % seg, params=params, auth=True)
    if code == 401:
        raise DiscoverError('Trakt: Anmeldung abgelaufen. Bitte neu anmelden.')
    if code != 200 or not isinstance(d, list):
        raise DiscoverError('Trakt: Fehler %s' % code)
    items, seen = [], set()
    for e in d:
        m = e.get('movie') or e.get('show') or (e if e.get('title') else None)
        if not m or not m.get('title'):
            continue
        tmdb = (m.get('ids') or {}).get('tmdb') or 0
        key = tmdb or m['title']
        if key in seen:
            continue
        seen.add(key)
        items.append({'title': m['title'], 'year': str(m.get('year') or ''), 'poster': '', 'plot': m.get('overview') or '', 'rating': round(float(m.get('rating') or 0), 1),
                      'tmdb': tmdb, 'kind': kind})
    if MD._key():
        def fill(it):
            if it['tmdb']:
                it.update({k: v for k, v in _meta(it['kind'], it['tmdb']).items() if v})
        list(_POOL.map(fill, items))
    return {'items': items, 'title': 'Trakt · ' + title}
