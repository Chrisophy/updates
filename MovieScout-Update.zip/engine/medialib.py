# -*- coding: utf-8 -*-
"""Eigene Mediathek (Mediaplayer) und Dateibrowser der Engine.

* ``roots()`` / ``listdir()``  - Ordner auf dem Gerät durchsuchen (für Mediaplayer und "Sicherung aus Ordner einspielen").
  Funktioniert ohne das Dateiauswahl-Fenster des Systems (das gibt es auf manchen TV-Boxen nicht).
* Bibliothek mit drei Listen: ``music``, ``video``, ``image``. Einträge werden gespeichert (medialib.json),
  lassen sich innerhalb einer Liste und zwischen den Listen verschieben und löschen.
* Abgespielt wird immer über die ID eines Eintrags - es lässt sich also nur ausliefern, was in der Mediathek steht.
"""
import json
import os
import secrets
import threading
import time
from pathlib import Path

from kodi_runtime import paths as _paths

LISTS = ('music', 'video', 'image')
LIST_NAMES = {'music': 'Musik', 'video': 'Videos', 'image': 'Bilder'}
EXT = {
    'music': {'mp3', 'flac', 'wav', 'ogg', 'oga', 'opus', 'm4a', 'aac', 'wma', 'mka', 'aif', 'aiff', 'ape', 'wv'},
    'video': {'mp4', 'm4v', 'mkv', 'webm', 'avi', 'mov', 'ts', 'm2ts', 'mts', 'mpg', 'mpeg', 'wmv', 'flv', '3gp', 'ogv', 'vob'},
    'image': {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif', 'heic', 'heif'},
}
MAX_PER_LIST = 5000
MAX_SCAN = 3000                  # höchstens so viele Dateien beim Ordner-Durchsuchen auf einmal
MAX_DEPTH = 8
PKG = 'de.itspossible.moviescout'

_lock = threading.RLock()
_cache = {'t': 0.0, 'mtime': -1.0, 'data': None}


class MediaError(Exception):
    pass


def _file():
    return _paths.DATA_DIR / 'medialib.json'


def kind_of(name):
    ext = str(name).rsplit('.', 1)[-1].lower() if '.' in str(name) else ''
    for k in LISTS:
        if ext in EXT[k]:
            return k
    return ''


# ----------------------------------------------------------------------------- Dateibrowser

def _is_android():
    return os.environ.get('MOVIESCOUT_EMBEDDED') == '1' or (os.path.isdir('/system/app') and os.path.isdir('/storage'))


def roots():
    """Startpunkte zum Durchsuchen: [{name, path}]. Nur vorhandene, lesbare Ordner."""
    out, seen = [], set()

    def add(name, path):
        try:
            p = str(Path(path))
            if p in seen or not os.path.isdir(p):
                return
            os.listdir(p)
        except OSError:
            return
        seen.add(p)
        out.append({'name': name, 'path': p})

    if _is_android():
        base = '/storage/emulated/0'
        add('Interner Speicher', base)
        add('Download', base + '/Download')
        add('Filme', base + '/Movies')
        add('Musik', base + '/Music')
        add('Bilder', base + '/Pictures')
        add('Fotos (Kamera)', base + '/DCIM')
        add('MovieScout-Ordner', '%s/Android/data/%s/files' % (base, PKG))
        try:
            for n in sorted(os.listdir('/storage')):
                if n not in ('emulated', 'self') and not n.startswith('.'):
                    add('Wechseldatenträger ' + n, '/storage/' + n)
        except OSError:
            pass
    else:
        home = Path.home()
        add('Persönlicher Ordner', home)
        for n, d in (('Videos', 'Videos'), ('Musik', 'Music'), ('Bilder', 'Pictures'), ('Downloads', 'Downloads'), ('Dokumente', 'Documents')):
            add(n, home / d)
        if os.name == 'nt':
            for c in 'CDEFGHIJKLMNOPQRSTUVWXYZ':
                add('Laufwerk ' + c, c + ':\\')
        else:
            for base in ('/media', '/mnt', '/run/media'):
                try:
                    for n in sorted(os.listdir(base)):
                        add(n, os.path.join(base, n))
                except OSError:
                    pass
            add('Hauptordner /', '/')
    add('Daten von MovieScout', _paths.DATA_DIR)
    return out


def listdir(path, only=''):
    """Inhalt eines Ordners. only: '' (alles), 'media' (Ordner + Musik/Videos/Bilder) oder 'zip' (Ordner + .zip)."""
    path = str(path or '')
    if not path:
        return {'path': '', 'parent': '', 'entries': [], 'roots': roots()}
    p = Path(path)
    try:
        p = p.resolve()
    except OSError:
        raise MediaError('Ordner nicht lesbar.')
    if not p.is_dir():
        raise MediaError('Das ist kein Ordner.')
    try:
        names = os.listdir(p)
    except PermissionError:
        raise MediaError('Kein Zugriff auf diesen Ordner. Auf Android: In MovieScout „Dateizugriff erlauben“ wählen.')
    except OSError as e:
        raise MediaError('Ordner nicht lesbar: %s' % e)
    entries = []
    for n in names:
        if n.startswith('.'):
            continue
        fp = p / n
        try:
            is_dir = fp.is_dir()
            if is_dir:
                entries.append({'name': n, 'path': str(fp), 'dir': True, 'size': 0, 'kind': ''})
                continue
            k = kind_of(n)
            if only == 'media' and not k:
                continue
            if only == 'zip' and not n.lower().endswith('.zip'):
                continue
            entries.append({'name': n, 'path': str(fp), 'dir': False, 'size': fp.stat().st_size, 'kind': k})
        except OSError:
            continue
    entries.sort(key=lambda e: (not e['dir'], e['name'].lower()))
    parent = str(p.parent) if p.parent != p else ''
    return {'path': str(p), 'parent': parent, 'entries': entries[:5000], 'truncated': len(entries) > 5000}


def scan_folder(path, recursive=True):
    """Alle Mediendateien eines Ordners (rekursiv bis MAX_DEPTH, höchstens MAX_SCAN) in Namensreihenfolge."""
    base = Path(path)
    if not base.is_dir():
        raise MediaError('Das ist kein Ordner.')
    found = []

    def walk(d, depth):
        if len(found) >= MAX_SCAN:
            return
        try:
            names = sorted(os.listdir(d), key=str.lower)
        except OSError:
            return
        subs = []
        for n in names:
            if n.startswith('.'):
                continue
            fp = Path(d) / n
            try:
                if fp.is_dir():
                    subs.append(fp)
                elif kind_of(n):
                    found.append(str(fp))
                    if len(found) >= MAX_SCAN:
                        return
            except OSError:
                continue
        if recursive and depth < MAX_DEPTH:
            for s in subs:
                walk(s, depth + 1)
    walk(base, 0)
    return found


# ----------------------------------------------------------------------------- Bibliothek

def _empty():
    return {k: [] for k in LISTS}


def _load():
    with _lock:
        f = _file()
        try:
            mt = f.stat().st_mtime
        except OSError:
            mt = -1.0
        if _cache['data'] is not None and _cache['mtime'] == mt:
            return _cache['data']
        data = _empty()
        try:
            raw = json.loads(f.read_text('utf-8'))
            for k in LISTS:
                for e in (raw.get(k) or []):
                    if isinstance(e, dict) and e.get('path') and e.get('id'):
                        data[k].append({'id': str(e['id']), 'path': str(e['path']), 'name': str(e.get('name') or Path(str(e['path'])).name),
                                        'added': int(e.get('added') or 0)})
        except Exception:                                    # noqa: BLE001
            pass
        _cache.update(data=data, mtime=mt)
        return data


def _save(data):
    with _lock:
        f = _file()
        f.parent.mkdir(parents=True, exist_ok=True)
        tmp = f.with_suffix('.tmp')
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), 'utf-8')
        os.replace(str(tmp), str(f))
        try:
            mt = f.stat().st_mtime
        except OSError:
            mt = -1.0
        _cache.update(data=data, mtime=mt)


def library():
    """Mediathek für die Oberfläche; ``missing`` markiert Dateien, die es nicht mehr gibt."""
    data = _load()
    out = {}
    for k in LISTS:
        out[k] = [dict(e, missing=not os.path.isfile(e['path'])) for e in data[k]]
    return out


def add(paths, target=''):
    """Dateien/Ordner hinzufügen. Ordner werden samt Unterordnern durchsucht.
    target: '' = nach Dateityp einsortieren, sonst feste Liste. Gibt {'added': n, 'skipped': n, 'lists': {...}} zurück."""
    if target and target not in LISTS:
        raise MediaError('Unbekannte Liste.')
    files = []
    for p in (paths or [])[:2000]:
        p = str(p or '')
        if not p:
            continue
        if os.path.isdir(p):
            files.extend(scan_folder(p))
        elif os.path.isfile(p):
            files.append(p)
    with _lock:
        data = _load()
        data = {k: list(v) for k, v in data.items()}
        have = {k: {e['path'] for e in data[k]} for k in LISTS}
        added, skipped = 0, 0
        counts = {k: 0 for k in LISTS}
        for fp in files:
            k = target or kind_of(fp)
            if not k:
                skipped += 1
                continue
            if fp in have[k] or len(data[k]) >= MAX_PER_LIST:
                skipped += 1
                continue
            have[k].add(fp)
            data[k].append({'id': secrets.token_hex(6), 'path': fp, 'name': Path(fp).name, 'added': int(time.time())})
            counts[k] += 1
            added += 1
        if added:
            _save(data)
    return {'added': added, 'skipped': skipped, 'lists': counts}


def _find(data, eid):
    for k in LISTS:
        for i, e in enumerate(data[k]):
            if e['id'] == eid:
                return k, i
    return None, -1


def move(eid, to='', pos=None, delta=None):
    """Eintrag verschieben. to = andere Liste (ans Ende oder an Position pos), delta = ±n Plätze in der Liste, pos = absolute Position."""
    with _lock:
        data = {k: list(v) for k, v in _load().items()}
        k, i = _find(data, str(eid))
        if k is None:
            raise MediaError('Eintrag nicht gefunden.')
        e = data[k].pop(i)
        dest = to if to in LISTS else k
        if dest != k:
            if any(x['path'] == e['path'] for x in data[dest]):
                data[k].insert(i, e)
                raise MediaError('Die Datei steht in dieser Liste schon.')
            idx = len(data[dest]) if pos is None else int(pos)
        elif delta is not None:
            idx = i + int(delta)
        else:
            idx = i if pos is None else int(pos)
        idx = max(0, min(len(data[dest]), idx))
        data[dest].insert(idx, e)
        _save(data)
    return {'list': dest, 'index': idx}


def reorder(listname, ids):
    """Reihenfolge einer Liste setzen (Ziehen mit Maus/Finger). Unbekannte IDs werden ignoriert, fehlende bleiben am Ende."""
    if listname not in LISTS:
        raise MediaError('Unbekannte Liste.')
    with _lock:
        data = {k: list(v) for k, v in _load().items()}
        by = {e['id']: e for e in data[listname]}
        new = [by[i] for i in ids if i in by]
        rest = [e for e in data[listname] if e['id'] not in set(ids)]
        data[listname] = new + rest
        _save(data)


def remove(ids):
    ids = {str(i) for i in (ids or [])}
    with _lock:
        data = {k: [e for e in v if e['id'] not in ids] for k, v in _load().items()}
        n = sum(len(v) for v in _load().values()) - sum(len(v) for v in data.values())
        if n:
            _save(data)
    return {'removed': n}


def clear(listname):
    if listname not in LISTS:
        raise MediaError('Unbekannte Liste.')
    with _lock:
        data = {k: list(v) for k, v in _load().items()}
        n = len(data[listname])
        data[listname] = []
        _save(data)
    return {'removed': n}


_adhoc = {}                      # id -> Pfad, nur im Speicher (Sammlungen aus Geräteordnern); begrenzt, älteste fallen heraus
ADHOC_MAX = 20000


def scan_adhoc(path):
    """Ordner (samt Unterordnern) durchsuchen und die Dateien abspielbar machen, ohne sie in die Mediathek zu legen.
    Gibt [{id, name, kind, folder}] zurück (Reihenfolge wie im Dateisystem: Ordner für Ordner)."""
    files = scan_folder(path)
    base = Path(path)
    out = []
    with _lock:
        for fp in files:
            eid = 'a' + secrets.token_hex(6)
            _adhoc[eid] = fp
            try:
                folder = str(Path(fp).parent.relative_to(base)) if Path(fp).parent != base else ''
            except ValueError:
                folder = ''
            out.append({'id': eid, 'name': Path(fp).name, 'kind': kind_of(fp), 'folder': folder})
        while len(_adhoc) > ADHOC_MAX:
            _adhoc.pop(next(iter(_adhoc)))
    return out


def path_of(eid):
    """Pfad eines Mediathek-Eintrags (nur was in der Liste oder in einer geöffneten Sammlung steht), sonst ''."""
    eid = str(eid)
    p = _adhoc.get(eid)
    if p:
        return p if os.path.isfile(p) else ''
    data = _load()
    for k in LISTS:
        for e in data[k]:
            if e['id'] == eid:
                return e['path'] if os.path.isfile(e['path']) else ''
    return ''


# ----------------------------------------------------------------------------- Sicherung

def export_data():
    """Für die Sicherung (ZIP): die Listen ohne Zusatzfelder."""
    return {k: [{'path': e['path'], 'name': e['name']} for e in v] for k, v in _load().items()}


def import_data(raw, replace=False):
    """Aus der Sicherung wiederherstellen. Gibt die Zahl neu übernommener Einträge zurück."""
    if not isinstance(raw, dict):
        return 0
    with _lock:
        data = {k: ([] if replace else list(v)) for k, v in _load().items()}
        n = 0
        for k in LISTS:
            have = {e['path'] for e in data[k]}
            for e in (raw.get(k) or [])[:MAX_PER_LIST]:
                if isinstance(e, dict) and e.get('path') and str(e['path']) not in have and len(data[k]) < MAX_PER_LIST:
                    p = str(e['path'])
                    have.add(p)
                    data[k].append({'id': secrets.token_hex(6), 'path': p, 'name': str(e.get('name') or Path(p).name), 'added': int(time.time())})
                    n += 1
        _save(data)
    return n
