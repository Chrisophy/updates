# -*- coding: utf-8 -*-
"""HTTP-API der MovieScout-Engine (Starlette). Die Oberfläche liegt in static/ und kann
auch separat (z. B. GitHub Pages) betrieben werden - sie spricht nur diese API an."""
import asyncio
import base64
import hmac
import json
import logging
import mimetypes
import os
import re
import secrets
import socket
import sys
import threading
import time
from contextlib import asynccontextmanager
from concurrent.futures import TimeoutError as FutTimeout
from pathlib import Path
from urllib.parse import quote, urljoin, urlparse

from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import FileResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from starlette.routing import Mount, Route, WebSocketRoute
from starlette.staticfiles import StaticFiles
from starlette.websockets import WebSocketDisconnect

from kodi_runtime import xbmcaddon
from resources.lib import multiquest
from kodi_runtime import paths as _paths

from . import netfix  # noqa: F401  (robuster Verbindungsaufbau im Mobilnetz, wirkt beim Import)
from . import normalize as N
from . import proxy as P
from . import registry as R
from . import resolvers as RS
from . import system as SYS

try:                                   # Absturz-Protokoll: bei „Segmentation fault“ steht der Python-Weg in <Daten>/crash.log
    import faulthandler
    if not faulthandler.is_enabled():
        _cf = open(str(_paths.DATA_DIR / 'crash.log'), 'a')
        _cf.write('--- Start %s ---\n' % time.strftime('%Y-%m-%d %H:%M:%S')); _cf.flush()
        faulthandler.enable(file=_cf, all_threads=True)
except Exception:                      # noqa: BLE001
    pass
from . import extensions as X
from . import assist as AS
from . import examples as EX
from . import metadata as META
from . import freemeta as FM
from . import mylib as MYLIB
from . import downloads as DL
from . import notify as NF
from . import subs as SUBS
from . import imgcache as IMG
from . import cleanup as CLEAN
from . import updater as UP
from . import share as SH
from . import addonhost as AH
from . import addonrepo as AR
from . import compat as CP
from . import discover as DISC
from . import trailer as TRL
from . import feeds as FEEDS
from kodi_runtime import ui_dialogs as UD
from . import cache as CACHE
from . import ratelimit as RL
from . import dns as DNS
from . import medialib as ML

VERSION = UP.running_version()
ROOT = Path(__file__).resolve().parent.parent
TOKEN = os.environ.get('MINIKODI_TOKEN', '')
log = logging.getLogger('engine')

def _convert_to_github_api_url(url):
    """Wandelt einen normalen GitHub-Web-Link (Repository-Root oder Ordner) in die GitHub-API-URL um."""
    if not url:
        return None
    url = url.strip().rstrip('/')
    if url.endswith('.git'):
        url = url[:-4]
    if 'api.github.com' in url:
        return url
    
    # 1. Fall: Unterordner mit /tree/ref/path
    m = re.match(r'^https?://github\.com/([^/]+)/([^/]+)/tree/([^/]+)/(.+)$', url)
    if m:
        owner, repo, ref, path = m.groups()
        return f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={ref}"
    
    # 1b. Fall: nur Branch ohne Unterordner (z.B. https://github.com/user/repo/tree/main)
    m1 = re.match(r'^https?://github\.com/([^/]+)/([^/]+)/tree/([^/]+)$', url)
    if m1:
        owner, repo, ref = m1.groups()
        return f"https://api.github.com/repos/{owner}/{repo}/contents?ref={ref}"

    # 2. Fall: Repository-Root (z.B. https://github.com/Chrisophy/scraper)
    m2 = re.match(r'^https?://github\.com/([^/]+)/([^/]+)(?:/)?$', url)
    if m2:
        owner, repo = m2.groups()
        return f"https://api.github.com/repos/{owner}/{repo}/contents"
        
    return None



def J(obj, status=200):
    return JSONResponse(N.jsonable(obj), status_code=status, headers={'Cache-Control': 'no-store'})


def err(message, status=500, **extra):
    return J({'error': str(message), **extra}, status)


async def body_json(request):
    try:
        data = await request.json()
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _prefix(request):
    return (request.scope.get('root_path') or '').rstrip('/')


# ----------------------------------------------------------------------------- Middleware

# ----- Chat-Schlüssel: schützt Chat und Dateien, wenn ein anderes Gerät (Handy) sie über das WLAN abruft -----
_CHAT_KEY_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
_CHAT_KEY = ''
_KEY_FAILS = {}


def _chat_key():
    global _CHAT_KEY
    if _CHAT_KEY:
        return _CHAT_KEY
    f = _paths.DATA_DIR / 'chat_key.txt'
    try:
        k = f.read_text('utf-8').strip().upper()
        if re.fullmatch(r'[A-Z0-9]{8}', k):
            _CHAT_KEY = k
            return k
    except Exception:                                       # noqa: BLE001
        pass
    _CHAT_KEY = ''.join(secrets.choice(_CHAT_KEY_CHARS) for _ in range(8))
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(_CHAT_KEY, 'utf-8')
    except Exception:                                       # noqa: BLE001
        pass
    return _CHAT_KEY


def _key_from_scope(scope):
    from urllib.parse import parse_qs
    qs = parse_qs(scope.get('query_string', b'').decode('utf-8', 'ignore'))
    k = (qs.get('key', [''])[0] or dict(scope.get('headers') or []).get(b'x-chat-key', b'').decode('utf-8', 'ignore'))
    return re.sub(r'[^A-Za-z0-9]', '', k).upper()


def _scope_key_ok(scope):
    k = _key_from_scope(scope)
    return bool(k) and hmac.compare_digest(k.encode(), _chat_key().encode())


def _is_chat_path(path):
    return path in ('/api/chat', '/ws/chat', '/ws/haus') or path.startswith('/api/files')


class Guard:
    """Optionaler Zugriffsschutz: MOVIESCOUT_TOKEN setzen -> alle /api-Aufrufe brauchen ?token= oder X-Token."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if TOKEN and scope['type'] == 'http' and not scope.get('ms_share_ok'):
            path = scope['path']
            if _is_chat_path(path) and (scope.get('ms_key_ok') or _scope_key_ok(scope)):
                return await self.app(scope, receive, send)      # Chat/Dateien: der Chat-Schlüssel genügt
            if (path.startswith('/api/') and not path.startswith('/api/p/') and path != '/api/info'
                    and scope['method'] != 'OPTIONS'):
                from urllib.parse import parse_qs
                qs = parse_qs(scope.get('query_string', b'').decode())
                hdr = dict(scope['headers']).get(b'x-token', b'').decode()
                if (qs.get('token', [''])[0] or hdr) != TOKEN:
                    resp = JSONResponse({'error': 'Zugriff verweigert (Token fehlt/falsch)'}, 401)
                    return await resp(scope, receive, send)
        await self.app(scope, receive, send)


def _private_v4(ip):
    try:
        a, b = [int(x) for x in ip.split('.')[:2]]
    except Exception:                                       # noqa: BLE001
        return False
    return a == 10 or (a == 192 and b == 168) or (a == 172 and 16 <= b <= 31)


def _ifaddrs_v4():
    """[(Schnittstelle, IPv4)] über getifaddrs (libc) - geht auch dort, wo der UDP-Trick keine Route findet (z. B. Android 16)."""
    import ctypes
    import ctypes.util
    import socket

    class SockAddr(ctypes.Structure):
        _fields_ = [('family', ctypes.c_ushort), ('data', ctypes.c_ubyte * 14)]

    class IfAddrs(ctypes.Structure):
        pass
    IfAddrs._fields_ = [('next', ctypes.POINTER(IfAddrs)), ('name', ctypes.c_char_p), ('flags', ctypes.c_uint),
                        ('addr', ctypes.POINTER(SockAddr)), ('mask', ctypes.POINTER(SockAddr)),
                        ('ifu', ctypes.c_void_p), ('data', ctypes.c_void_p)]
    libc = ctypes.CDLL(ctypes.util.find_library('c') or 'libc.so', use_errno=True)
    libc.getifaddrs.argtypes = [ctypes.POINTER(ctypes.POINTER(IfAddrs))]
    libc.freeifaddrs.argtypes = [ctypes.POINTER(IfAddrs)]
    head = ctypes.POINTER(IfAddrs)()
    if libc.getifaddrs(ctypes.byref(head)) != 0:
        return []
    out = []
    try:
        cur = head
        while cur:
            ia = cur.contents
            if ia.addr and ia.addr.contents.family == socket.AF_INET and (ia.flags & 1):      # IFF_UP
                raw = bytes(ia.addr.contents.data[2:6])
                out.append(((ia.name or b'').decode('ascii', 'ignore'), socket.inet_ntoa(raw)))
            cur = ia.next
    finally:
        libc.freeifaddrs(head)
    return out


def _java_ips():
    """Android: Adressen aller Netze über ConnectivityManager (Chaquopy). Leer, wenn nicht verfügbar."""
    out = []
    try:
        from java import jclass
        ctx = jclass('com.chaquo.python.Python').getPlatform().getApplication()
        cm = ctx.getSystemService('connectivity')
        for net in cm.getAllNetworks().toArray() if hasattr(cm.getAllNetworks(), 'toArray') else cm.getAllNetworks():
            lp = cm.getLinkProperties(net)
            if lp is None:
                continue
            name = str(lp.getInterfaceName() or '')
            for la in lp.getLinkAddresses().toArray():
                ip = str(la.getAddress().getHostAddress() or '')
                if ip.count('.') == 3:
                    out.append((name, ip))
    except Exception:                                       # noqa: BLE001
        pass
    return out


def _lan_ip():
    """Adresse dieses Geräts im WLAN/LAN ('' wenn keine). Es wird nichts gesendet. Mehrere Verfahren, weil nicht jedes
    Android (z. B. 16) dem UDP-Trick eine Route gibt; bevorzugt WLAN/Ethernet/Hotspot-Schnittstellen mit privater Adresse."""
    import socket
    cands = []
    for fn in (_ifaddrs_v4, _java_ips):
        try:
            cands += fn()
        except Exception:                                   # noqa: BLE001
            pass
    for target in ('10.255.255.255', '192.168.255.255', '8.8.8.8'):
        try:
            sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sk.connect((target, 1))
            cands.append(('udp', sk.getsockname()[0]))
            sk.close()
        except Exception:                                   # noqa: BLE001
            pass
    try:
        cands.append(('host', socket.gethostbyname(socket.gethostname())))
    except Exception:                                       # noqa: BLE001
        pass
    bad = ('lo', 'rmnet', 'ccmni', 'tun', 'ppp', 'docker', 'dummy', 'veth', 'p2p', 'br-', 'virbr', 'tailscale', 'wg')
    good = ('wlan', 'swlan', 'ap', 'eth', 'en', 'wl')

    def score(c):
        name, ip = c
        if ip.startswith(('127.', '169.254.', '0.')) or ip == '0.0.0.0':
            return -1
        if name.startswith(bad):
            return 0
        if name in ('udp', 'host'):                          # geratene Route: nur Notnagel
            return 1 if _private_v4(ip) else 0.5
        pts = 2 if _private_v4(ip) else 1
        if name.startswith(good):
            pts += 3
        return pts
    best = max(cands, key=score, default=None)
    return best[1] if best and score(best) > 0 else ''


def _is_loopback(host):
    return host in ('127.0.0.1', '::1', 'localhost') or host.startswith('::ffff:127.') or host.startswith('127.')


_SELF_IPS = {'t': 0.0, 'v': set()}


def _is_self(client):
    """Anfrage vom Gerät selbst: Loopback oder eine der eigenen Adressen (Host öffnet die eigene WLAN-Adresse)."""
    if _is_loopback(client):
        return True
    now = time.time()
    if now - _SELF_IPS['t'] > 30:
        ips = set()
        for fn in (_ifaddrs_v4, _java_ips):
            try:
                ips |= {ip for _n, ip in fn()}
            except Exception:                               # noqa: BLE001
                pass
        _SELF_IPS.update(t=now, v=ips)
    return client in _SELF_IPS['v']


class LanGate:
    """Zugriff von anderen Geräten im WLAN.
    - Android-App (strict, MOVIESCOUT_LAN_GATE=1): von außen nur die Fernbedienungs-Kopplung (/remote, /ws/remote) und
      der Familienchat mit Chat-Schlüssel.
    - Freigabe mit Passwort (Einstellung „Teilen“, siehe share.py): wer sich angemeldet hat, darf stöbern, suchen,
      abspielen und chatten, aber nichts verwalten. Ohne Anmeldung gibt es nur die Anmeldeseite /share.
    - Desktop ohne Freigabe (nicht strict): wie bisher offen (Hinweis beim Start: MOVIESCOUT_TOKEN setzen)."""
    ALLOWED = ('/remote', '/ws/remote', '/remote/poll', '/remote/send')

    def __init__(self, app, strict=True):
        self.app = app
        self.strict = strict

    async def _deny(self, scope, receive, send, status, text, redirect=False):
        if scope['type'] == 'http':
            if redirect:
                return await RedirectResponse('/share', 303)(scope, receive, send)
            return await JSONResponse({'error': text, 'share': True}, status)(scope, receive, send)
        await receive()
        return await send({'type': 'websocket.close', 'code': 4429 if status == 429 else 4401})

    async def __call__(self, scope, receive, send):
        if scope['type'] in ('http', 'websocket'):
            client = (scope.get('client') or ('', 0))[0] or ''
            if not _is_self(client):
                path = scope.get('path', '')
                method = scope.get('method', 'GET') if scope['type'] == 'http' else 'GET'
                conf = SH.config()
                if path in self.ALLOWED:
                    scope['ms_lan'] = True
                elif conf['enabled']:
                    if path in SH.PUBLIC:
                        pass                                   # Anmeldeseite und Anmeldung (die bremst der Handler selbst)
                    elif method == 'OPTIONS' and SH.guest_allowed(path, 'OPTIONS'):
                        pass                                   # CORS-Vorabfrage trägt keine Zugangsdaten
                    elif SH.authed(scope, conf):
                        if not SH.guest_allowed(path, method):
                            return await self._deny(scope, receive, send, 403, 'Das darf nur der Besitzer dieses Geräts.')
                        scope['ms_share_ok'] = True
                        scope['ms_key_ok'] = True
                        SH.touch(client)
                    elif _is_chat_path(path) and _scope_key_ok(scope):
                        scope['ms_key_ok'] = True              # Chat-Schlüssel (Handy-Kopplung) gilt weiter
                    else:
                        if SH.blocked(client):
                            return await self._deny(scope, receive, send, 429, 'Zu viele Versuche. Bitte kurz warten.')
                        if SH.presented(scope):                # etwas mitgeschickt, aber falsch -> zählt als Fehlversuch
                            SH.fail(client)
                        nav = (scope['type'] == 'http' and method == 'GET' and (path == '/' or path.startswith('/ui')))
                        return await self._deny(scope, receive, send, 401, 'Passwort nötig.', redirect=nav)
                elif self.strict:
                    if _is_chat_path(path):                    # Familienchat + Dateien: nur mit dem Chat-Schlüssel
                        if scope['type'] == 'http' and method == 'OPTIONS':
                            pass                                  # CORS-Vorabfrage trägt keine Zugangsdaten
                        elif _scope_key_ok(scope):
                            scope['ms_key_ok'] = True
                        else:
                            now = time.time()
                            fails = [t for t in _KEY_FAILS.get(client, []) if now - t < 60]
                            fails.append(now)
                            _KEY_FAILS[client] = fails
                            if scope['type'] == 'http':
                                msg = 'Zu viele Versuche.' if len(fails) > 8 else 'Chat-Schlüssel fehlt oder ist falsch.'
                                return await JSONResponse({'error': msg}, 429 if len(fails) > 8 else 401)(scope, receive, send)
                            await receive()
                            await send({'type': 'websocket.accept'})
                            return await send({'type': 'websocket.close', 'code': 4429 if len(fails) > 8 else 4401})
                    else:
                        if scope['type'] == 'http':
                            return await Response('Nur Fernbedienung, Chat und Dateien sind von außen erreichbar. '
                                                  'Zum Teilen im WLAN: in MovieScout „Teilen“ einschalten.', 403)(scope, receive, send)
                        await receive()
                        return await send({'type': 'websocket.close', 'code': 4403})
        await self.app(scope, receive, send)


class PrivateNetwork:
    """Chrome 'Private Network Access': https-Seite (GitHub Pages) -> http://localhost/LAN."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        wants = any(k == b'access-control-request-private-network' for k, _ in scope['headers'])

        async def _send(message):
            if message['type'] == 'http.response.start' and wants:
                message.setdefault('headers', []).append((b'access-control-allow-private-network', b'true'))
            await send(message)
        await self.app(scope, receive, _send)


# ----------------------------------------------------------------------------- Endpunkte

async def root(request):
    return RedirectResponse(_prefix(request) + '/ui/')


def _ws_ok():
    """Kann uvicorn WebSockets? Ohne das Paket websockets/wsproto (z. B. Pydroid) gibt es keine Live-Verbindung (Chat, Fernbedienung)."""
    import importlib.util
    for m in ('websockets', 'wsproto'):
        try:
            if importlib.util.find_spec(m) is not None:
                return True
        except (ImportError, ValueError):
            pass
    return False


WS_OK = _ws_ok()


async def info(request):
    return J({'name': 'MovieScout Engine', 'version': VERSION, 'auth': bool(TOKEN), 'ws': WS_OK,
              'providers': len(R.REGISTRY), 'time': int(time.time()),
              'resolvers': RS.status(), 'github_sync': dict(SYNC), 're_guard': __import__('kodi_runtime.safere', fromlist=['x']).status()})


async def providers(request):
    items = [p.info() for p in R.REGISTRY.values()]
    if request.query_params.get('all') not in ('1', 'true'):
        items = [i for i in items if i['enabled']]
    items.sort(key=lambda x: x['name'].lower())
    return J({'providers': items})


_STATEFUL_URL = re.compile(r'^(toggle|switch|sync|refresh|update|reset|clear)(?:[_\-:=/ ]|$)', re.I)


def _is_stateful_item(item):
    """Menüpunkt, der etwas umschaltet/ausführt (url "toggle_…", "sync", … oder Flag no_cache)."""
    u = str(item.get('url') or '')
    return bool(item.get('no_cache') or _STATEFUL_URL.match(u) or u.startswith('script://'))     # script://: Programm starten, nie aus dem Speicher


async def api_open(request):
    if request.method == 'POST':
        d = await body_json(request)
    else:
        q = request.query_params
        d = {'provider_id': q.get('provider_id', ''), 'q': q.get('q', ''),
             'item': {'url': q.get('url', ''), 'next_func': q.get('next_func', '')}}
    pid = d.get('provider_id') or ''
    item = d.get('item') or {}
    query = d.get('q') or ''
    try:
        # Suchleiste einer Quelle: Suchbegriff ohne Menü-Eintrag -> search() der Quelle aufrufen (nicht load())
        if query and not (item.get('next_func') or '').strip() and not item.get('url'):
            try:
                if R.get_provider(pid).has_search:
                    item = dict(item, next_func='search', url='')
            except KeyError:
                pass
        # Schalter/Aktionen (z. B. "TV-Filme: JA/NEIN", "Datenbank aktualisieren") dürfen nie aus dem Zwischenspeicher
        # kommen, sonst wird beim zweiten Klick nichts mehr ausgeführt; danach sind alle Menüs veraltet.
        stateful = _is_stateful_item(item)
        rid = _rid(d)

        def _open():
            UD.RID.set(rid)
            return R.open_item(pid, item, query, use_cache=not stateful)
        try:
            out = await run_in_threadpool(_open)
        finally:
            UD.end(rid)
        if stateful:
            R.clear_cache()
        return J(out)
    except KeyError as e:
        return err(e, 404)
    except R.ScraperTimeout as e:
        return err(e, 504)
    except Exception as e:
        return err(str(e) if isinstance(e, AH.AddonError) else '%s: %s' % (type(e).__name__, e), 502 if isinstance(e, AH.AddonError) else 500)


def _client_info(d):
    """Vom Browser gemeldete Fähigkeiten (nur bekannte Felder, gekürzt)."""
    c = d.get('client') if isinstance(d.get('client'), dict) else {}
    lvl = str(c.get('widevine') or '').upper()[:4]
    return {'widevine': lvl if lvl in ('L1', 'L2', 'L3', 'NONE') else '', 'android': bool(c.get('android'))}


async def api_resolve(request):
    d = await body_json(request)
    pid = d.get('provider_id') or ''
    try:
        rid = _rid(d)

        def _resolve():
            UD.RID.set(rid)
            return R.resolve_item(pid, d.get('item') or {}, _client_info(d), bool(d.get('fresh')))
        try:
            out = await run_in_threadpool(_resolve)
        finally:
            UD.end(rid)
        if not out['hosters']:
            notes = [n for n in (out.get('notes') or []) if isinstance(n, dict) and n.get('message') and n.get('level') != 'text']   # Lesetexte (textviewer) öffnet die Oberfläche selbst
            if not notes and any(isinstance(n, dict) and n.get('level') == 'text' for n in (out.get('notes') or [])) and pid.startswith('addon_'):
                out['error'] = 'Text'
                out['info'] = True
                R.clear_cache()
            elif notes:                                   # Addon-Aktion (z. B. „Backup erstellen“): deren Meldung zeigen statt „Keine Streams“
                out['error'] = ' · '.join(str(n['message']) for n in notes[-3:])
                out['info'] = not any(n.get('level') == 'error' for n in notes)
                if pid.startswith('addon_'):
                    R.clear_cache()
            elif pid.startswith('addon_'):              # Aktion eines Kodi-Addons ohne Wiedergabe und ohne Meldung
                out['error'] = 'Erledigt.'
                out['info'] = True
                R.clear_cache()                          # Menüs des Addons können sich geändert haben
            else:
                out['error'] = 'Keine Streams gefunden (Seite geändert, geo-blockiert oder Inhalt entfernt).'
            if pid.startswith('addon_'):                # Hinweis, wenn der Hintergrunddienst des Addons nicht läuft oder Fehler gemeldet hat
                try:
                    st = AH.service_status(getattr(R.get_provider(pid).module, 'ADDON_ID', ''))
                    bad = [l for l in st.get('log', []) if re.search(r'fehl|error|exception|beendet', l, re.I)]
                    if st.get('has_service') and (not st.get('running') or bad):
                        out['error'] = (out.get('error') or '') + ' · Hintergrunddienst: ' + ('gestoppt' if not st.get('running') else bad[-1][:160])
                except Exception:                      # noqa: BLE001
                    pass
        return J(out)
    except KeyError as e:
        return err(e, 404)
    except R.ScraperTimeout as e:
        return err(e, 504)
    except Exception as e:
        return err(str(e) if isinstance(e, AH.AddonError) else '%s: %s' % (type(e).__name__, e), 502 if isinstance(e, AH.AddonError) else 500)


def _fetch_cert(url, headers, post=False):
    """Widevine-Serverzertifikat holen (base64). post=True: Zertifikatsanfrage an den Lizenzserver
    (so macht es inputstream.adaptive bei server_certificate='CAQ=')."""
    try:
        up = P.fetch('POST' if post else 'GET', url, headers, body=b'\x08\x04' if post else None, timeout=10)
        try:
            data = up.read()
        finally:
            up.close()
        if up.status >= 400 or not data:
            return ''
        return base64.b64encode(data).decode('ascii')
    except Exception as e:
        log.warning('Zertifikat konnte nicht geladen werden: %s', e)
        return ''


def _resolve_embed(url):
    res, ok, via = RS.resolve_embed(url)
    if ok:
        log.info('Embed aufgelöst via %s: %s', via, url[:80])
    return res, ok


def _addon_local(url):
    """Adresse eines Mini-Servers, den ein Addon der Engine genannt hat (127.0.0.1:Port): nur die Engine erreicht ihn, andere Geräte nicht."""
    try:
        from urllib.parse import urlparse as _up
        pu = _up(url)
        return bool(pu.hostname in ('127.0.0.1', 'localhost', '::1') and pu.port and (pu.hostname, pu.port) in P.LOCAL_OK)
    except ValueError:
        return False


def play_plan(hoster, request_prefix=''):
    """Aus einem Hoster einen abspielbaren Plan machen (Embed auflösen, Typ prüfen, DRM vorbereiten)."""
    url = hoster.get('url') or ''
    headers = dict(hoster.get('headers') or {})
    fmt = hoster.get('format') or N.classify_format(url)
    drm = hoster.get('drm')
    notes = []

    if url.startswith('msfile://'):                           # Datei, die ein Kodi-Addon erzeugt hat: von der Engine ausliefern
        from urllib.parse import urlparse as _up
        tok = _up(url).netloc
        if tok not in AH.LOCAL_FILES or not os.path.isfile(AH.LOCAL_FILES[tok]):
            raise RuntimeError('Die Datei des Addons ist nicht mehr da - bitte neu starten.')
        nm = os.path.basename(AH.LOCAL_FILES[tok])
        return {'mode': 'media', 'format': N.classify_format(nm) if N.classify_format(nm) != 'embed' else 'mp4', 'url': url, 'headers': {},
                'name': hoster.get('name', ''), 'live': False, 'notes': [], 'needs_proxy': True,
                'proxy_path': '%s/api/localfile/%s/%s' % (request_prefix, tok, quote(nm))}

    if fmt == 'embed' and hoster.get('trailer') and re.match(r'^https://(www\.youtube-nocookie\.com|www\.youtube\.com|player\.vimeo\.com)/', url):
        return {'mode': 'embed', 'embed_url': url, 'headers': {}, 'notes': notes, 'name': hoster.get('name', ''), 'trailer': True}

    if fmt == 'embed':
        try:
            fut = R._POOL.submit(_resolve_embed, url)
            res, ok = fut.result(timeout=45)
        except FutTimeout:
            res, ok = url, False
            notes.append('Auflösen dauerte zu lange')
        except Exception as e:
            res, ok = url, False
            notes.append('Auflösen fehlgeschlagen: %s' % e)
        if ok and res:
            u2, h2 = N.split_kodi_url(res)
            url, headers = u2, {**headers, **h2}
            fmt = N.classify_format(url)
            if fmt == 'embed':
                fmt = 'direct'
        else:
            return {'mode': 'embed', 'embed_url': url, 'headers': headers, 'notes': notes,
                    'name': hoster.get('name', '')}

    if fmt in ('direct', 'unknown', 'ts'):
        try:
            pr = P.probe(url, headers)
            if pr['format'] not in ('unknown', 'error'):
                fmt = pr['format']
            elif pr['format'] == 'error':
                notes.append('Server antwortet mit HTTP %s' % pr['status'])
        except Exception as e:
            notes.append('Typ-Prüfung fehlgeschlagen: %s' % e)
        if fmt in ('direct', 'unknown'):
            fmt = 'mp4'

    htok = P.pack_headers(headers)
    plan = {
        'mode': 'media', 'format': fmt, 'url': url, 'headers': headers,
        'name': hoster.get('name', ''), 'live': bool(hoster.get('live')), 'notes': notes,
        'proxy_path': '%s/api/proxy?u=%s%s' % (request_prefix, quote(url, safe=''),
                                              ('&h=' + htok) if htok else ''),
        'needs_proxy': bool(headers) or bool(drm) or _addon_local(url),   # Mini-Server des Addons: nur die Engine erreicht ihn
    }
    if hoster.get('subtitles'):
        plan['subtitles'] = [{'label': x['label'], 'lang': x['lang'], 'path': '%s/api/subtitle?u=%s%s' % (
            request_prefix, quote(x['url'], safe=''), ('&h=' + htok) if htok else ''), **({'default': True} if x.get('default') else {})} for x in hoster['subtitles']]
    if drm:
        lh = P.pack_headers(drm.get('license_headers') or {})
        lic = drm.get('license_url') or ''
        cert = drm.get('server_certificate') or ''
        lhdr = drm.get('license_headers') or {}
        if cert == 'CAQ=':                    # Kodi-Konvention: "Zertifikat beim Lizenzserver anfragen"
            cert = _fetch_cert(lic, lhdr, post=True) if lic else ''
        elif not cert and drm.get('certificate_url'):
            cert = _fetch_cert(drm['certificate_url'], lhdr)
        plan['drm'] = {
            'key_system': drm.get('key_system'),
            'license_url': lic,
            'license_path': '%s/api/proxy?u=%s%s%s%s' % (
                request_prefix, quote(lic, safe=''), ('&h=' + lh) if lh else '',
                ('&resp=' + quote(drm['response'], safe='')) if drm.get('response') else '',
                ('&req=b64') if drm.get('request') == 'b64' else ''),
            'server_certificate': cert,
            'clearkey': drm.get('clearkey', ''),
            'supported': drm.get('supported', True),
        }
        plan['needs_proxy'] = True
    return plan


def _ranged_file(request, path, ctype=None):
    """Datei mit Bereichsanfragen (Spulen) ausliefern."""
    size = os.path.getsize(path)
    ctype = ctype or mimetypes.guess_type(path)[0] or ('audio/flac' if path.lower().endswith('.flac') else 'application/octet-stream')
    start, end, status = 0, size - 1, 200
    m = re.match(r'bytes=(\d*)-(\d*)$', request.headers.get('range', '').strip())
    if m and size:
        a, b = m.groups()
        if a == '' and b:
            start = max(0, size - int(b))
        elif a:
            start = int(a)
            if b:
                end = min(int(b), size - 1)
        if start > end or start >= size:
            return Response(status_code=416, headers={'Content-Range': 'bytes */%d' % size})
        status = 206
    length = end - start + 1
    hdr = {'Accept-Ranges': 'bytes', 'Content-Length': str(length), 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'}
    if status == 206:
        hdr['Content-Range'] = 'bytes %d-%d/%d' % (start, end, size)
    if request.method == 'HEAD':
        return Response(status_code=status, headers=hdr, media_type=ctype)

    def gen():
        left = length
        with open(path, 'rb') as f:
            f.seek(start)
            while left > 0:
                chunk = f.read(min(65536, left))
                if not chunk:
                    break
                left -= len(chunk)
                yield chunk
    return StreamingResponse(gen(), status_code=status, headers=hdr, media_type=ctype)


async def api_localfile(request):
    """Datei ausliefern, die ein Kodi-Addon als Wiedergabe geliefert hat (nur per Token, mit Bereichsanfragen zum Spulen)."""
    path = AH.LOCAL_FILES.get(request.path_params.get('token', ''))
    if not path or not os.path.isfile(path):
        return err('Datei nicht gefunden', 404)
    return _ranged_file(request, path)


# ----------------------------------------------------------------------------- Mediaplayer (eigene Mediathek) und Dateibrowser

_MEDIA_MIME = {'mkv': 'video/x-matroska', 'ts': 'video/mp2t', 'm2ts': 'video/mp2t', 'mts': 'video/mp2t', 'flac': 'audio/flac',
               'm4a': 'audio/mp4', 'opus': 'audio/ogg', 'oga': 'audio/ogg', 'mka': 'audio/x-matroska', 'avif': 'image/avif',
               'heic': 'image/heic', 'heif': 'image/heif', 'aac': 'audio/aac'}


async def api_media_file(request):
    """Eintrag der Mediathek ausliefern (nur was dort steht; die ID ist der Schlüssel)."""
    path = ML.path_of(request.path_params.get('eid', ''))
    if not path:
        return err('Datei nicht gefunden (verschoben oder gelöscht?)', 404)
    ext = path.rsplit('.', 1)[-1].lower() if '.' in path else ''
    return _ranged_file(request, path, _MEDIA_MIME.get(ext))


def _ml(fn):
    """Mediathek-Fehler als normale Fehlermeldung (400) ausgeben."""
    async def wrapper(request):
        try:
            return await fn(request)
        except ML.MediaError as e:
            return err(e, 400)
    wrapper.__name__ = fn.__name__
    return wrapper


async def api_play(request):
    d = await body_json(request)
    hoster = d.get('hoster') or {}
    if not hoster.get('url'):
        return err('hoster.url fehlt', 400)
    try:
        plan = await run_in_threadpool(play_plan, hoster, _prefix(request))
        return J(plan)
    except P.Blocked as e:
        return err(e, 403)
    except Exception as e:
        return err('%s: %s' % (type(e).__name__, e), 500)


async def api_search(request):
    q = (request.query_params.get('q') or '').strip()
    pid = request.query_params.get('provider_id') or ''
    if not q:
        return err('Suchbegriff fehlt', 400)
    try:
        if pid:
            out = await run_in_threadpool(R.search_one, pid, q, request.query_params.get('fresh') in ('1', 'true'))
            return J({'query': q, 'count': len(out['items']), 'results': out['items'], 'items': out['items']})
        only = [x for x in (request.query_params.get('providers') or '').split(',') if x] or None
        info = {}
        fresh = request.query_params.get('fresh') in ('1', 'true')
        res, errors = await run_in_threadpool(lambda: R.search_all(q, only, fresh=fresh, info=info))
        return J({'query': q, 'count': len(res), 'results': res, 'items': res, 'errors': errors,
                  'pending': info.get('pending', []), 'skipped': info.get('skipped', {}), 'ms': info.get('ms', 0)})
    except KeyError as e:
        return err(e, 404)
    except R.ScraperTimeout as e:
        return err(e, 504)
    except Exception as e:
        return err('%s: %s' % (type(e).__name__, e), 500)


async def api_meta(request):
    """Filminfos zu einem Eintrag (Scraper-Daten + TMDB, falls Schlüssel eingetragen)."""
    d = await body_json(request)
    item = d.get('item') if isinstance(d.get('item'), dict) else {}
    if not (item.get('title') or '').strip():
        return err('Titel fehlt', 400)
    try:
        return J({'meta': await run_in_threadpool(META.lookup, item)})
    except Exception as e:
        return err('%s: %s' % (type(e).__name__, e), 500)


async def api_meta_ratings(request):
    """Bewertungen von IMDb, Rotten Tomatoes, Moviepilot, Filmstarts (kostenlos, ohne Schlüssel; wird nachgeladen)."""
    d = await body_json(request)
    item = d.get('item') if isinstance(d.get('item'), dict) else {}
    title = META.clean_title(item.get('parent_title') or item.get('title') or '')
    if not title:
        return err('Titel fehlt', 400)
    tv = bool(item.get('season') or str(item.get('mediatype') or '').lower() in ('tvshow', 'season', 'episode', 'tv'))
    try:
        year = int(item.get('year') or 0)
    except (TypeError, ValueError):
        year = 0
    return J(await run_in_threadpool(FM.ratings_only, title, year, tv))


async def api_mylib(request):
    q = request.query_params
    return J(await run_in_threadpool(MYLIB.listing, q.get('filter', ''), q.get('sort', 'neu'), q.get('q', '')))


async def api_mylib_get(request):
    d = await body_json(request)
    item = d.get('item') if isinstance(d.get('item'), dict) else {}
    return J({'entry': await run_in_threadpool(MYLIB.get, item)})


async def api_mylib_set(request):
    d = await body_json(request)
    item = d.get('item') if isinstance(d.get('item'), dict) else {}
    try:
        return J({'entry': await run_in_threadpool(MYLIB.set_, item, d.get('patch') or {})})
    except ValueError as e:
        return err(e, 400)


async def api_mylib_delete(request):
    d = await body_json(request)
    return J({'ok': await run_in_threadpool(MYLIB.remove, str(d.get('key') or ''))})


async def api_health(request):
    pid = request.query_params.get('provider_id') or ''
    run = request.query_params.get('run') in ('1', 'true')
    try:
        if pid:
            h = await run_in_threadpool(R.check_provider, pid) if run else R.HEALTH.get(pid, {})
            return J({'health': [h]})
        if run:
            return J({'health': await run_in_threadpool(R.check_all)})
        return J({'health': list(R.HEALTH.values())})
    except KeyError as e:
        return err(e, 404)


async def api_logs(request):
    q = request.query_params
    return J({'logs': R.recent_logs(q.get('provider_id', ''), int(q.get('limit', 150) or 150),
                                    q.get('level', ''))})


async def api_settings(request):
    if request.method == 'POST':
        d = await body_json(request)
        out = xbmcaddon.save_settings(d.get('settings') or d)
        DNS.invalidate()
        RL.invalidate()
        SH.invalidate()
        R.clear_cache()      # z. B. M3U/Stalker-Portale, Filter: nicht bis zu 3 Minuten alte Menüs zeigen
        return J({'settings': out})
    return J({'settings': xbmcaddon.all_settings(), 'templates': URL_TEMPLATES})


async def api_cache_clear(request):
    if request.query_params.get('all') in ('1', 'true'):
        CACHE.clear_all()
    R.clear_cache()
    return J({'ok': True})


async def api_cache_stats(request):
    return J({'caches': CACHE.all_stats(), 'search': R.search_stats(), 'hosts': RL.snapshot()})


# ----------------------------------------------------------------------------- Downloads (offline speichern)

def _dl_view(j):
    j = dict(j)
    j.setdefault('poster', '')
    return j


async def api_downloads_list(request):
    return J({'jobs': [_dl_view(j) for j in DL.jobs()], 'library': DL.library()})


async def api_downloads_start(request):
    d = await body_json(request)
    pid = d.get('provider_id') or ''
    item = d.get('item') or {}
    hoster = d.get('hoster') or {}
    jid = DL.start(pid, item, title=d.get('title') or item.get('title'),
                   poster=d.get('poster') or item.get('poster'),
                   hoster_url=hoster.get('url') or None, headers=hoster.get('headers'),
                   fmt=hoster.get('format'))
    return J({'id': jid})


async def api_downloads_one(request):
    jid = request.path_params['id']
    j = DL.job(jid)
    if j:
        return J(_dl_view(j))
    it = DL.library_item(jid)
    if it:
        return J(dict(it, state='done', progress=100))
    return err('Unbekannter Download', 404)


async def api_downloads_delete(request):
    jid = request.path_params['id']
    ok = DL.remove(jid)
    return J({'ok': ok})


async def api_downloads_moved(request):
    """Die App hat die fertige Datei selbst nach Filme/Movies verschoben (Android-Download-Manager) -
    aus der engine-eigenen Bibliothek entfernen, ohne die (schon verschobene) Datei erneut zu löschen."""
    jid = request.path_params['id']
    return J({'ok': DL.mark_moved(jid)})


async def api_downloads_file(request):
    jid = request.path_params['id']
    it = DL.library_item(jid)
    if not it:
        j = DL.job(jid)
        if j and j.get('state') not in ('done',):
            return err('Download läuft noch oder ist fehlgeschlagen', 409)
        return err('Unbekannter Download', 404)
    p = Path(it['path'])
    if not p.exists():
        return err('Datei nicht mehr vorhanden', 404)
    return FileResponse(str(p), filename=it.get('name') or p.name, media_type='video/%s' % (it.get('ext') or 'mp4'))


# ----------------------------------------------------------------------------- Proxy

def _proxy_common(request, url, headers, extra_auth=''):
    rng = request.headers.get('range', '')
    prefix = _prefix(request)
    return rng, prefix


_WV_TYPES = {1: 'Lizenzanfrage', 2: 'Lizenz', 3: 'Fehler', 4: 'Zertifikatsanfrage', 5: 'Zertifikat'}
_LIC_LOCKS = {}
_LIC_LOCKS_GUARD = threading.Lock()


def _lic_lock(url):
    key = urlparse(url)._replace(query='', fragment='').geturl()
    with _LIC_LOCKS_GUARD:
        return _LIC_LOCKS.setdefault(key, threading.Lock())


def _serve_license(method, url, headers, rng, body, prefix, auth, resp_mode, req_mode):
    """Lizenzanfragen nacheinander (nicht parallel) abschicken und protokollieren - Server wie Rakuten lehnen
    gleichzeitige Anfragen derselben Sitzung teilweise mit 403 ab. Das Protokoll zeigt, was genau abgelehnt wurde."""
    kind = '?'
    if body and body[:1] == b'\x08' and len(body) > 1:
        kind = _WV_TYPES.get(body[1], 'Typ %d' % body[1])
    with _lic_lock(url):
        t0 = time.time()
        status, hdrs, data = P.serve(method, url, headers, rng, body, prefix, auth, resp_mode, req_mode)
    size = len(data) if isinstance(data, (bytes, bytearray)) else -1
    msg = 'Lizenz-Server %s: %s (%d Byte) -> HTTP %s, Antwort %d Byte, %.1fs, gesendete Header: %s' % (
        urlparse(url).netloc, kind, len(body or b''), status, size, time.time() - t0,
        ', '.join(sorted(headers or {})) or '-')
    if status >= 400:
        snippet = bytes(data[:200]).decode('utf-8', 'replace') if isinstance(data, (bytes, bytearray)) else ''
        log.warning('%s | Antwort: %s', msg, snippet)
    else:
        log.info(msg)
    return status, hdrs, data


async def api_proxy(request):
    q = request.query_params
    url = q.get('u', '')
    if not url:
        return err('u fehlt', 400)
    headers = P.unpack_headers(q.get('h', ''))
    body = await request.body() if request.method == 'POST' else None
    auth = q.get('token', '') or request.headers.get('x-token', '')
    try:
        serve = _serve_license if request.method == 'POST' else P.serve
        status, hdrs, data = await run_in_threadpool(
            serve, request.method, url, headers, request.headers.get('range', ''), body,
            _prefix(request), auth, q.get('resp', ''), q.get('req', ''))
    except P.Blocked as e:
        return err(e, 403)
    except Exception as e:
        return err('Proxy: %s: %s' % (type(e).__name__, e), 502)
    if isinstance(data, (bytes, bytearray)):
        return Response(bytes(data), status_code=status, headers=hdrs)
    return StreamingResponse(data, status_code=status, headers=hdrs)


async def api_subtitle(request):
    """Untertitel als WebVTT: GET ?u=<Adresse>&h=<Kopfzeilen> holt und wandelt um, POST (Dateiinhalt) wandelt eine lokale Datei um."""
    try:
        if request.method == 'POST':
            data = await request.body()
        else:
            url = request.query_params.get('u', '')
            if not url:
                return err('u fehlt', 400)
            hdrs = P.unpack_headers(request.query_params.get('h', ''))

            def load():
                up = P.fetch('GET', url, hdrs, timeout=20)
                try:
                    if up.status != 200:
                        raise ValueError('Untertitel nicht abrufbar (HTTP %s)' % up.status)
                    return up.read(SUBS.MAX_BYTES + 1)
                finally:
                    up.close()
            data = await run_in_threadpool(load)
        if len(data) > SUBS.MAX_BYTES:
            return err('Untertitel-Datei zu groß', 413)
        vtt = SUBS.to_vtt(data)
    except P.Blocked as e:
        return err(e, 403)
    except ValueError as e:
        return err(e, 422)
    except Exception as e:
        return err('Untertitel: %s: %s' % (type(e).__name__, e), 502)
    return Response(vtt, media_type='text/vtt; charset=utf-8', headers={'Cache-Control': 'private, max-age=3600'})


async def api_img(request):
    """Bild über den Bilder-Speicher der Engine liefern (nur Bilder, nur http/https, ohne lokale Ziele)."""
    url = request.query_params.get('u', '')
    if not url.startswith(('http://', 'https://')):
        return err('u fehlt oder ist keine Adresse', 400)
    try:
        mb = int(xbmcaddon.all_settings().get('imgcache_mb') or IMG.DEFAULT_MB)
    except (TypeError, ValueError):
        mb = IMG.DEFAULT_MB
    try:
        data, ct, hit = await run_in_threadpool(IMG.get, url, mb)
    except P.Blocked as e:
        return err(e, 403)
    except Exception as e:
        return err('Bild: %s' % e, 502)
    return Response(data, media_type=ct, headers={'Cache-Control': 'public, max-age=2592000', 'X-Img-Cache': 'hit' if hit else 'miss'})


async def api_proxy_path(request):
    try:
        tok = P.b64d(request.path_params['tok'])
        base = tok['b']
    except Exception:
        return err('Ungültiges Token', 400)
    if TOKEN and tok.get('a') != TOKEN and not request.scope.get('ms_share_ok'):
        return err('Zugriff verweigert', 401)
    rest = request.path_params.get('rest', '')
    url = urljoin(base, quote(rest, safe="/:@!$&'()*+,;=-._~%")) if rest else base
    if request.url.query:
        url += ('&' if '?' in url else '?') + request.url.query
    headers = tok.get('h') or {}
    body = await request.body() if request.method == 'POST' else None
    try:
        status, hdrs, data = await run_in_threadpool(
            P.serve, request.method, url, headers, request.headers.get('range', ''), body,
            _prefix(request), tok.get('a', ''), '', '')
    except P.Blocked as e:
        return err(e, 403)
    except Exception as e:
        return err('Proxy: %s: %s' % (type(e).__name__, e), 502)
    if isinstance(data, (bytes, bytearray)):
        return Response(bytes(data), status_code=status, headers=hdrs)
    return StreamingResponse(data, status_code=status, headers=hdrs)



# ----------------------------------------------------------------------------- Verwaltung (Scraper, Erweiterungen, Sicherung)

APP_ORIGIN = 'https://appassets.androidplatform.net'     # Android-App (WebView, Oberfläche aus den App-Assets)


_FRAME_KEY = secrets.token_urlsafe(18)       # nur im Speicher; die Oberfläche holt ihn für Seiten von Erweiterungen im Rahmen


def _frame_ok(request):
    """Seite einer Erweiterung im Rahmen der App: die Oberfläche (https://appassets…) hängt den Schlüssel an."""
    fk = request.query_params.get('fk', '')
    return bool(fk) and request.url.path.startswith('/api/x/') and hmac.compare_digest(fk, _FRAME_KEY)


def _admin_ok(request):
    """Verwaltungs-Endpunkte führen/ändern Python-Code der Engine. Damit keine fremde Webseite sie aus dem Browser
    anstoßen kann, gilt: mit MOVIESCOUT_TOKEN schützt das Token (Guard). Ohne Token sind nur Anfragen ohne Origin
    (curl, Skripte), von der Engine selbst (gleiche Herkunft), von localhost/127.0.0.1 oder aus
    MOVIESCOUT_ADMIN_ORIGINS (kommagetrennt, z. B. https://name.github.io) erlaubt. Die Android-App (WebView mit
    Herkunft https://appassets.androidplatform.net) gilt ebenfalls als eigene Oberfläche."""
    if TOKEN or _frame_ok(request):
        return True
    origin = request.headers.get('origin', '')
    if not origin:
        if request.headers.get('sec-fetch-site', 'none') in ('none', 'same-origin', 'same-site'):
            return True
        # Adresse zeigt auf einen anderen Namen derselben Engine (z. B. Seite auf localhost, Link auf 127.0.0.1):
        # ein Klick aus einer vertrauenswürdigen Seite trägt sie als Referer; eine fremde Webseite kann das nicht fälschen.
        ref = urlparse(request.headers.get('referer', ''))
        if not ref.scheme or not ref.netloc:
            return False
        origin = '%s://%s' % (ref.scheme, ref.netloc)
    host = urlparse(origin).hostname or ''
    if host in ('localhost', '127.0.0.1', '::1'):
        return True
    if origin.rstrip('/') == '%s://%s' % (request.url.scheme, request.headers.get('host', '')):
        return True
    if origin.rstrip('/') == APP_ORIGIN:
        return True
    allowed = [o.strip().rstrip('/') for o in os.environ.get('MINIKODI_ADMIN_ORIGINS', '').split(',') if o.strip()]
    return origin.rstrip('/') in allowed


def admin(fn):
    async def wrapper(request):
        if not _admin_ok(request):
            return err('Verwaltung nur über localhost, mit Zugriffstoken (MOVIESCOUT_TOKEN) oder von einer in '
                       'MOVIESCOUT_ADMIN_ORIGINS freigegebenen Seite möglich.', 403)
        try:
            return await fn(request)
        except SYS.SystemError_ as e:
            return err(e, 400)
        except KeyError as e:
            return err(e.args[0] if e.args else e, 404)
        except Exception as e:
            log.exception('Verwaltung %s', request.url.path)
            return err('%s: %s' % (type(e).__name__, e), 500)
    wrapper.__name__ = fn.__name__
    return wrapper


@admin
async def adm_discover(request):
    q = request.query_params
    try:
        out = await run_in_threadpool(lambda: DISC.discover(q.get('kind') or 'movie', q.get('list') or 'popular', int(q.get('page') or 1),
                                                            int(q.get('pages') or 2), q.get('genre') or '', q.get('year') or '', q.get('q') or ''))
    except DISC.DiscoverError as e:
        return err(e, 400)
    except ValueError:
        return err('Ungültige Seitenzahl', 400)
    return J(out)


@admin
async def adm_discover_meta(request):
    kind = request.query_params.get('kind')
    out = {'lists': DISC.lists(), 'trakt_lists': DISC.trakt_lists(), 'trakt': DISC.status(), 'has_key': bool(META._key())}
    if kind and out['has_key']:
        try:
            out['genres'] = await run_in_threadpool(DISC.genres, kind)
        except DISC.DiscoverError as e:                  # Genres sind nur eine Zugabe: Listen gehen auch ohne
            out['genres'] = []
            out['genres_error'] = str(e)
    return J(out)


@admin
async def adm_feed(request):
    """RSS-/Atom-Feed lesen (Startseiten-Bereich „Nachrichten & Notizen“)."""
    q = request.query_params
    try:
        return J(await run_in_threadpool(FEEDS.read, q.get('url') or '', q.get('fresh') in ('1', 'true')))
    except FEEDS.FeedError as e:
        return err(e, 400)
    except Exception as e:
        return err('%s: %s' % (type(e).__name__, e), 500)


@admin
async def adm_trailer(request):
    """Trailer zu einem Titel: Quellen (MultiTrailer-Addon + TMDB/YouTube) für den eingebauten Player."""
    d = await body_json(request)
    item = d.get('item') if isinstance(d.get('item'), dict) else {}
    try:
        return J(await run_in_threadpool(TRL.find, item))
    except TRL.TrailerError as e:
        return err(e, 404)
    except Exception as e:
        return err('%s: %s' % (type(e).__name__, e), 500)


@admin
async def adm_trakt_auth(request):
    d = await body_json(request)
    act = d.get('action')
    try:
        if act == 'start':
            return J(await run_in_threadpool(DISC.auth_start))
        if act == 'poll':
            return J(await run_in_threadpool(DISC.auth_poll, str(d.get('device_code') or '')))
        if act == 'logout':
            return J(await run_in_threadpool(DISC.logout))
    except DISC.DiscoverError as e:
        return err(e, 400)
    return err('Unbekannte Aktion', 400)


@admin
async def adm_trakt_list(request):
    q = request.query_params
    try:
        return J(await run_in_threadpool(DISC.trakt_list, q.get('name') or 'trending', q.get('kind') or 'movie'))
    except DISC.DiscoverError as e:
        return err(e, 400)


@admin
async def adm_imgcache(request):
    if request.method == 'POST':
        return J({'cleared': await run_in_threadpool(IMG.clear), **IMG.stats()})
    return J(IMG.stats())


@admin
async def adm_cleanup(request):
    if request.method == 'POST':
        try:
            d = await request.json()
        except Exception:                                  # noqa: BLE001
            d = {}
        ids = d.get('ids') if isinstance(d.get('ids'), list) else None
        if d.get('auto') or not ids:
            return J(await run_in_threadpool(CLEAN.auto_run))
        return J(await run_in_threadpool(CLEAN.clean, [str(i) for i in ids], True))
    return J(await run_in_threadpool(CLEAN.scan))


def _kind(request, d=None):
    k = (d or {}).get('kind') or request.query_params.get('kind') or 'provider'
    if k not in SYS.KINDS:
        raise SYS.SystemError_('Unbekannte Art: %s' % k)
    return k


def _fetch_code(url):
    from resources.lib import multiquest
    if not url.lower().startswith(('http://', 'https://')):
        raise SYS.SystemError_('Nur http(s)-Adressen sind erlaubt.')
    m = re.match(r'^https?://github\.com/([^/]+)/([^/]+)/blob/(.+\.py)$', url)
    if m:                                                    # normale GitHub-Seite -> Rohdatei
        url = 'https://raw.githubusercontent.com/%s/%s/%s' % (m.group(1), m.group(2), m.group(3))
    r = multiquest.get(url, timeout=25)
    if r.status_code != 200:
        raise SYS.SystemError_('Download fehlgeschlagen (HTTP %s)' % r.status_code)
    return r.text, os.path.basename(urlparse(url).path) or 'skript.py'


# ----------------------------------------------------------------------------- GitHub-Ordner laden / beim Start abgleichen

_GH_UA = 'MovieScout-Engine'
SYNC = {'state': 'idle', 'url': '', 'changed': 0, 'unchanged': 0, 'failed': 0, 'skipped': 0, 'files': [], 'warnings': [],
        'error': '', 'time': 0, 'kind': 'provider'}   # Stand für /api/info (state: idle | running | done | error)

# Vorlagen für die Adress-Felder (System-Update, GitHub-Ordner für Scraper und Erweiterungen). Die Oberfläche trägt sie vor, solange der
# Nutzer nichts Eigenes gespeichert hat; eine eigene Adresse (auch ein geleertes Feld) hat immer Vorrang. Code wird erst geladen, wenn der
# Nutzer selbst auf „Jetzt laden“/„Speichern“ tippt - beim Start der Engine nur aus Adressen, die er gespeichert hat.
URL_TEMPLATES = {
    'update_source': 'https://github.com/Chrisophy/updates/raw/main/MovieScout-Update.zip',
    'github_repo': 'https://github.com/Chrisophy/scraper',
    'github_ext_repo': 'https://github.com/Chrisophy/gadgets',
}
SYNC_KEYS = {'provider': 'github_repo', 'extension': 'github_ext_repo'}
_SYNC_LOCK = threading.Lock()


def _sync_hash(text):
    """Hash des Quelltexts, unempfindlich gegen Zeilenenden, BOM und Leerraum am Ende (sonst 'geändert' bei jedem Lauf)."""
    import hashlib
    t = str(text or '').lstrip('﻿').replace('\r\n', '\n').replace('\r', '\n')
    t = '\n'.join(x.rstrip() for x in t.split('\n')).rstrip('\n')
    return hashlib.sha256(t.encode('utf-8', 'replace')).hexdigest()[:20]


def _sync_marks(new=None):
    """Merkt sich, welche Fassung je Datei zuletzt von GitHub geladen wurde (github_sync.json)."""
    p = _paths.DATA_DIR / 'github_sync.json'
    if new is not None:
        try:
            tmp = p.with_suffix('.tmp')
            tmp.write_text(json.dumps(new, ensure_ascii=False), 'utf-8')
            tmp.replace(p)
        except OSError:
            log.warning('github_sync.json nicht gespeichert')
        return new
    try:
        d = json.loads(p.read_text('utf-8'))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def sync_github_providers(url=None, kind='provider', reload=True):
    """Lädt die .py-Dateien eines GitHub-Ordners (oder einer einzelnen .py-Adresse), prüft sie und speichert sie
    als eigene Scraper. Unveränderte Dateien werden übersprungen (kein Papierkorb-Eintrag bei jedem Start).
    url=None: Adresse aus den Einstellungen (github_repo bzw. github_ext_repo). Leere Adresse: nichts tun."""
    from resources.lib import multiquest
    if kind not in SYNC_KEYS:
        kind = 'provider'
    if url is None:
        url = xbmcaddon.all_settings().get(SYNC_KEYS[kind]) or ''
    url = str(url).strip()
    if not url:
        return {'state': 'idle', 'changed': 0, 'unchanged': 0, 'failed': 0, 'files': [], 'warnings': [], 'error': ''}
    with _SYNC_LOCK:
        SYNC.update(state='running', url=url, changed=0, unchanged=0, failed=0, skipped=0, files=[], warnings=[], error='',
                    time=int(time.time()), kind=kind)
        try:
            todo = []                                           # (Dateiname, Quelltext)
            api_url = _convert_to_github_api_url(url)
            if api_url:
                resp = multiquest.get(api_url, headers={'User-Agent': _GH_UA, 'Accept': 'application/vnd.github.v3+json'},
                                      timeout=15)
                if resp.status_code != 200:
                    raise SYS.SystemError_('GitHub-Ordner konnte nicht geladen werden (HTTP %s)' % resp.status_code)
                entries = json.loads(resp.text)
                if isinstance(entries, dict):
                    entries = [entries]
                for e in (entries if isinstance(entries, list) else []):
                    if not isinstance(e, dict) or e.get('type') != 'file':
                        continue
                    name = str(e.get('name') or '')
                    if not name.lower().endswith('.py') or name.lower() == '__init__.py' or not e.get('download_url'):
                        continue
                    try:
                        r = multiquest.get(e['download_url'], headers={'User-Agent': _GH_UA}, timeout=20)
                        if r.status_code != 200:
                            raise SYS.SystemError_('HTTP %s' % r.status_code)
                        todo.append((name, r.text))
                    except Exception as ex:             # noqa: BLE001
                        SYNC['failed'] += 1
                        SYNC['warnings'].append('%s: %s' % (name, ex))
                        log.warning('GitHub-Sync: %s nicht geladen: %s', name, ex)
            else:
                code, name = _fetch_code(url)
                todo.append((name, code))
            for name, code in todo:
                try:
                    code = str(code or '').lstrip('﻿')     # BOM (Windows-Editoren) würde die Syntaxprüfung scheitern lassen
                    k = kind
                    chk = SYS.check_code(k, name, code)
                    if not chk['ok'] and all(e.startswith(('Das ist kein Scraper', 'Keine Erweiterung')) for e in chk['errors']):
                        other = 'extension' if kind == 'provider' else 'provider'
                        if SYS.check_code(other, name, code)['ok']:
                            k = other                       # liegt im falschen Ordner (z. B. Scraper bei den Gadgets): dort einordnen, wo es hingehört
                            log.info('GitHub-Sync: %s ist %s und wird als solche(r) übernommen', name, 'ein Scraper' if k == 'provider' else 'eine Erweiterung')
                        else:
                            SYNC['skipped'] += 1            # Hilfsdatei (Bibliothek ohne Scraper-/Erweiterungsfunktionen): kein Fehler
                            log.info('GitHub-Sync: %s übersprungen (Hilfsdatei, weder Scraper noch Erweiterung)', name)
                            continue
                    target = SYS.kind_dir(k) / SYS.clean_name(name)
                    h = _sync_hash(code)
                    marks = _sync_marks()
                    mk = '%s/%s' % (k, SYS.clean_name(name))
                    same = False
                    if target.exists():
                        if marks.get(mk) == h:              # dieselbe Fassung wie beim letzten Abgleich geladen
                            same = True
                        else:
                            same = _sync_hash(target.read_text('utf-8', errors='replace')) == h
                    if same:
                        SYNC['unchanged'] += 1
                        SYNC['files'].append(name)
                        if marks.get(mk) != h:
                            marks[mk] = h
                            _sync_marks(marks)
                        continue
                    log.info('GitHub-Sync: %s neu/geändert (Hash %s, vorher %s)', name, h, marks.get(mk))
                    SYS.save_file(k, name, code, overwrite=True)
                    marks[mk] = h
                    _sync_marks(marks)
                    SYNC['changed'] += 1
                    SYNC['files'].append(name)
                except Exception as ex:                 # noqa: BLE001
                    SYNC['failed'] += 1
                    SYNC['warnings'].append('%s: %s' % (name, ex))
                    log.warning('GitHub-Sync: %s nicht übernommen: %s', name, ex)
            if SYNC['changed'] and reload:
                R.reload_all()
            SYNC['state'] = 'done'
            log.info('GitHub-Sync: %d neu/aktualisiert, %d unverändert, %d übersprungen, %d fehlgeschlagen',
                     SYNC['changed'], SYNC['unchanged'], SYNC['skipped'], SYNC['failed'])
        except Exception as e:                          # noqa: BLE001
            SYNC.update(state='error', error=str(e))
            log.warning('GitHub-Sync fehlgeschlagen: %s', e)
        return dict(SYNC)


HEALTH_WATCH_DELAY = 25             # erster Lauf kurz nach dem Start (Start selbst soll nicht warten)
HEALTH_WATCH_INTERVAL = 6 * 3600    # danach alle 6 Stunden erneut


def _start_health_watch():
    """Prüft regelmäßig im Hintergrund alle Quellen (wie der Knopf 'Alle prüfen' in der Diagnose), damit
    man sieht, seit wann ein Scraper leer/fehlerhaft ist, ohne das von Hand anstoßen zu müssen."""
    def _run():
        time.sleep(HEALTH_WATCH_DELAY)
        while True:
            try:
                R.check_all()
            except Exception:                               # noqa: BLE001
                log.exception('Automatischer Gesundheitscheck')
            time.sleep(HEALTH_WATCH_INTERVAL)
    threading.Thread(target=_run, name='health-watch', daemon=True).start()


def _start_github_sync():
    """Beim Start: stehen in den Einstellungen GitHub-Links (Scraper, Erweiterungen), werden sie im Hintergrund abgeglichen
    (der Start wartet nicht aufs Netz). Leeres Feld = nichts tun."""
    st = xbmcaddon.all_settings()
    todo = [(k, str(st.get(key) or '').strip()) for k, key in SYNC_KEYS.items()]
    todo = [(k, u) for k, u in todo if u]
    if not todo:
        return

    def _netz_fehler(msg):
        m = str(msg or '').lower()
        return any(x in m for x in ('urlopen error', 'errno', 'timed out', 'no address', 'temporary failure', 'name or service',
                                    'network is unreachable', 'connection reset', 'connection refused', 'eof occurred'))

    def _warte_aufs_netz(max_s=120):                    # direkt nach dem Hochfahren steht das Netz (DNS) oft noch nicht
        t0 = time.time()
        while time.time() - t0 < max_s:
            try:
                socket.getaddrinfo('api.github.com', 443)
                return True
            except OSError:
                time.sleep(3)
        return False

    def _run():
        _warte_aufs_netz()
        for kind, url in todo:
            for versuch in range(5):                    # Netzfehler: nach kurzer Pause nochmal, still (kein Fehler beim Start anzeigen)
                try:
                    sync_github_providers(url, kind)
                except Exception:                       # noqa: BLE001
                    log.exception('GitHub-Sync')
                    break
                if SYNC.get('state') == 'error' and _netz_fehler(SYNC.get('error')) and versuch < 4:
                    log.warning('GitHub-Sync: Netz noch nicht bereit (%s), neuer Versuch', SYNC.get('error'))
                    SYNC.update(state='running')
                    time.sleep(10)
                    _warte_aufs_netz(60)
                    continue
                break
    SYNC.update(state='running', url=todo[0][1], kind=todo[0][0])
    threading.Thread(target=_run, name='github-sync', daemon=True).start()


@admin
async def adm_list(request):
    kind = _kind(request)
    rows = SYS.list_files(kind) or []
    if kind == 'provider':
        by_file = {p.file: p.info() for p in R.REGISTRY.values() if p and getattr(p, 'file', None)}
        for r in rows:
            if isinstance(r, dict):
                r['info'] = by_file.get(r.get('file'))
    else:
        by_file = {e['file']: e for e in X.infos() if isinstance(e, dict) and e.get('file')}
        for r in rows:
            if isinstance(r, dict):
                r['info'] = by_file.get(r.get('file'))
    trash_items = SYS.list_trash() or []
    return J({
        'kind': kind,
        'items': rows,
        'files': rows,
        'extensions': rows,
        'providers': rows,
        'trash': trash_items,
        'errors': [],
        'error': None
    })


@admin
async def adm_source(request):
    kind = _kind(request)
    f = request.query_params.get('file', '')
    return J({'file': SYS.clean_name(f), 'code': SYS.get_source(kind, f)})


@admin
async def adm_templates(request):
    return J({'templates': SYS.TEMPLATES})



@admin
async def adm_save(request):
    d = await body_json(request)
    kind = _kind(request, d)
    code, name = d.get('code') or '', d.get('file') or ''
    url = str(d.get('url') or '').strip()
    
    if not code and url:
        if _convert_to_github_api_url(url):                  # GitHub-Ordner/Repository: alle .py-Dateien laden
            res = await run_in_threadpool(sync_github_providers, url, kind)
            if res.get('error'):
                raise SYS.SystemError_(res['error'])
            names = res.get('files') or []
            return J({
                'ok': True,
                'file': '%d Scraper aus Ordner' % len(names),
                'saved_count': res.get('changed', 0),
                'warnings': res.get('warnings') or [],
                'files': names, 'items': names, 'extensions': names, 'providers': names,
                'added': names, 'list': names, 'data': names,
                'errors': [], 'error': None
            })
        code, guess = await run_in_threadpool(_fetch_code, url)
        name = name or guess

    res = SYS.save_file(kind, name, code, overwrite=bool(d.get('overwrite', True)))
    await run_in_threadpool(R.reload_all)
    single_list = [res.get('file', name)]
    return J({
        'ok': True,
        **res,
        'files': single_list,
        'items': single_list,
        'extensions': single_list,
        'providers': single_list,
        'added': single_list,
        'list': single_list,
        'data': single_list,
        'errors': [],
        'error': None
    })


@admin
async def adm_github_sync(request):
    """Sofort abgleichen (Knopf in den Einstellungen). Ohne url: Adresse aus den Einstellungen."""
    d = await body_json(request)
    url = str(d.get('url') or '').strip() or None
    kind = 'extension' if d.get('kind') == 'extension' else 'provider'
    res = await run_in_threadpool(sync_github_providers, url, kind)
    if res.get('state') == 'idle':
        return err('Kein GitHub-Link eingetragen.', 400)
    return J(res)


@admin
async def adm_check(request):
    """Prüfen (statisch) und optional im Trockenlauf testen (run=true führt load() des Scrapers aus)."""
    d = await body_json(request)
    kind = _kind(request, d)
    res = SYS.check_code(kind, d.get('file') or 'test.py', d.get('code') or '')
    if res['ok'] and d.get('run'):
        res['run'] = await run_in_threadpool(_dry_run, kind, d.get('file') or 'test.py', d.get('code') or '')
    return J(res)


def _dry_run(kind, filename, code):
    """Code in einem Wegwerf-Modul ausführen (ohne es zu speichern) und Ergebnis kurz zusammenfassen."""
    import importlib.util
    import types
    import traceback
    from kodi_runtime import context
    out = {'imported': False}
    mod = types.ModuleType('mk_dry_%d' % int(time.time() * 1000))
    mod.__file__ = filename
    try:
        exec(compile(code, filename, 'exec'), mod.__dict__)
        out['imported'] = True
    except BaseException as e:   # noqa: BLE001
        out['error'] = '%s: %s' % (type(e).__name__, e)
        out['trace'] = ''.join(traceback.format_exception(type(e), e, e.__traceback__)[-3:])[-900:]
        return out
    if kind == 'provider':
        p = R.Provider(getattr(mod, 'SITE_ID', 'test'), getattr(mod, 'SITE_NAME', 'Test'), getattr(mod, 'SITE_DOMAIN', ''), mod, filename)
        fn = getattr(mod, 'load', None) or getattr(mod, 'showEntries', None)
        if not callable(fn):
            out['note'] = 'Keine load()-Funktion – nur Suche/Streams vorhanden.'
            return out
        t0 = time.time()
        try:
            kwargs, params = R.build_kwargs(fn, {'url': ''})
            ctx = context.RequestContext(params=params)
            res = R._run(p, fn, kwargs, ctx, 30)
            items = R._collect_items(p, res, ctx, '')
            out.update(ms=int((time.time() - t0) * 1000), count=len(items), sample=[i['title'] for i in items[:8]],
                       playable=sum(1 for i in items if i.get('kind') == 'play'))
        except Exception as e:   # noqa: BLE001
            out['error'] = '%s: %s' % (type(e).__name__, e)
    else:
        out['hooks'] = [n for n in X.HOOK_NAMES if callable(getattr(mod, n, None))]
        out['settings'] = len(getattr(mod, 'EXT_SETTINGS', []) or [])
    return out


@admin
async def adm_enable(request):
    d = await body_json(request)
    kind = _kind(request, d)
    SYS.set_enabled(kind, d.get('file') or '', bool(d.get('enabled')))
    await run_in_threadpool(R.reload_all)
    return J({'ok': True})


@admin
async def adm_delete(request):
    d = await body_json(request)
    kind = _kind(request, d)
    how = SYS.delete_file(kind, d.get('file') or '')
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, 'how': how})


@admin
async def adm_restore(request):
    d = await body_json(request)
    if d.get('purge'):
        SYS.purge_trash(d.get('id') or '')
        return J({'ok': True})
    name = SYS.restore_trash(d.get('id') or '')
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, 'file': name})


@admin
async def adm_reload(request):
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, 'providers': len(R.REGISTRY), 'extensions': len(X.EXTS)})


@admin
async def adm_export(request):
    d = await body_json(request)
    data = await run_in_threadpool(SYS.export_zip, d.get('ui') or {}, bool(d.get('full')))
    name = 'moviescout-sicherung-%s.zip' % time.strftime('%Y%m%d-%H%M')
    return Response(data, media_type='application/zip', headers={
        'Content-Disposition': 'attachment; filename="%s"' % name, 'Cache-Control': 'no-store'})


def _net_test():
    """Netzwerk-Diagnose: Wie kommt die Engine ins Internet (WLAN/Mobilnetz)? DNS, IPv4/IPv6, HTTPS, Proxy-Sperre."""
    import ipaddress
    out = []
    try:
        ifs = ', '.join('%s %s' % (n, a) for n, a in _ifaddrs_v4()) or 'keine'
    except Exception:
        ifs = 'unbekannt'
    out.append('Eigene IPv4-Adressen: ' + ifs)
    for host in ('www.google.com', 'github.com', 'api.themoviedb.org', 'streamtape.com'):
        out.append('')
        out.append('== ' + host)
        t0 = time.time()
        try:
            infos = socket.getaddrinfo(host, 443, 0, socket.SOCK_STREAM)
        except Exception as e:
            out.append('  DNS FEHLER: %s' % e)
            continue
        out.append('  DNS %.0f ms' % ((time.time() - t0) * 1000))
        seen = []
        for af, _t, _p, _c, sa in infos:
            ip = sa[0]
            if ip in seen:
                continue
            seen.append(ip)
            fam = 'IPv4' if af == socket.AF_INET else 'IPv6'
            t1 = time.time()
            try:
                s = socket.socket(af, socket.SOCK_STREAM)
                s.settimeout(6)
                s.connect(sa)
                s.close()
                res = 'verbunden in %.0f ms' % ((time.time() - t1) * 1000)
            except Exception as e:
                res = 'FEHLER nach %.1f s: %s' % (time.time() - t1, e)
            real = P._real_ip(ipaddress.ip_address(ip.split('%')[0]))
            blocked = real.is_private or real.is_loopback or real.is_link_local or real.is_reserved or real.is_multicast
            out.append('  %s %s: %s%s' % (fam, ip, res, '  [Proxy würde sperren!]' if blocked else ''))
        t2 = time.time()
        try:
            r = multiquest.get('https://%s/' % host, headers={'User-Agent': 'Mozilla/5.0'}, timeout=15)
            out.append('  HTTPS ok: HTTP %s in %.1f s' % (r.status_code, time.time() - t2))
        except Exception as e:
            out.append('  HTTPS FEHLER nach %.1f s: %s' % (time.time() - t2, e))
    return '\n'.join(out)


@admin
async def adm_net(request):
    """Stand von DNS-Wechsler und Schutz vor Sperren (pro Host: Anfragen, Bremsen, Abkühlzeit)."""
    return J({'dns': DNS.status(), 'hosts': RL.snapshot()})


@admin
async def adm_dns_test(request):
    d = await body_json(request)
    return J(await run_in_threadpool(DNS.test, str(d.get('mode') or 'system'), str(d.get('custom') or '')))


@admin
async def adm_nettest(request):
    return JSONResponse({'report': await run_in_threadpool(_net_test)})


@admin
async def adm_resolveurl(request):
    """Stand von ResolveURL; mit ?check=1 zusätzlich Abfrage der neuesten Version auf GitHub."""
    out = {'status': RS.status(), 'source': RS.get_source()}
    if request.query_params.get('check'):
        out['check'] = await run_in_threadpool(RS.check_update)
    return JSONResponse(out)


@admin
async def adm_resolveurl_source(request):
    d = await body_json(request)
    return JSONResponse({'source': RS.set_source(d.get('zip'), d.get('addon'))})


@admin
async def adm_resolveurl_update(request):
    st = await run_in_threadpool(RS.update)
    return JSONResponse({'status': st})


@admin
async def adm_import(request):
    data = await request.body()
    q = request.query_params
    res = await run_in_threadpool(SYS.import_zip, data, q.get('mode', 'merge'), q.get('bundled') in ('1', 'true'))
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, **res})


# ----------------------------------------------------------------------------- Mediaplayer: Verwaltung, Dateibrowser, Sicherung aus Datei

@admin
@_ml
async def adm_fs_list(request):
    q = request.query_params
    return J(await run_in_threadpool(ML.listdir, q.get('path', ''), q.get('only', '')))


@admin
@_ml
async def adm_fs_roots(request):
    return J({'roots': await run_in_threadpool(ML.roots)})


@admin
@_ml
async def adm_media_scan(request):
    d = await body_json(request)
    items = []
    for path in (d.get('paths') or [])[:20]:
        items.extend(await run_in_threadpool(ML.scan_adhoc, str(path)))
    return J({'items': items[:ML.MAX_SCAN]})


@admin
@_ml
async def adm_media_lib(request):
    return J({'lists': await run_in_threadpool(ML.library), 'names': ML.LIST_NAMES})


@admin
@_ml
async def adm_media_add(request):
    d = await body_json(request)
    res = await run_in_threadpool(ML.add, d.get('paths') or [], str(d.get('list') or ''))
    return J({**res, 'lists_all': await run_in_threadpool(ML.library)})


@admin
@_ml
async def adm_media_move(request):
    d = await body_json(request)
    if d.get('order') is not None and d.get('list'):
        await run_in_threadpool(ML.reorder, str(d['list']), [str(x) for x in (d.get('order') or [])])
        return J({'ok': True})
    res = await run_in_threadpool(ML.move, str(d.get('id') or ''), str(d.get('to') or ''), d.get('pos'), d.get('delta'))
    return J(res)


@admin
@_ml
async def adm_media_remove(request):
    d = await body_json(request)
    if d.get('clear'):
        return J(await run_in_threadpool(ML.clear, str(d['clear'])))
    return J(await run_in_threadpool(ML.remove, d.get('ids') or []))


@admin
async def adm_import_path(request):
    """Sicherung aus einem Ordner des Geräts einspielen (ohne Dateiauswahl-Fenster des Systems)."""
    d = await body_json(request)
    p = str(d.get('path') or '')
    if not p.lower().endswith('.zip') or not os.path.isfile(p):
        return err('Bitte eine ZIP-Datei wählen.', 400)
    if os.path.getsize(p) > SYS.MAX_ZIP:
        return err('Datei ist zu groß.', 400)

    def read():
        with open(p, 'rb') as f:
            return f.read()
    data = await run_in_threadpool(read)
    res = await run_in_threadpool(SYS.import_zip, data, str(d.get('mode') or 'merge'), bool(d.get('bundled')))
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, **res})


def _chat_zips():
    out = []
    try:
        for m in FILES_DIR.glob('*.json'):
            try:
                meta = json.loads(m.read_text('utf-8'))
            except Exception:                               # noqa: BLE001
                continue
            if str(meta.get('name', '')).lower().endswith('.zip') and m.with_suffix('.bin').is_file():
                out.append({'id': meta.get('id') or m.stem, 'name': meta.get('name'), 'size': meta.get('size') or 0,
                            'time': int(m.stat().st_mtime)})
    except Exception:                                       # noqa: BLE001
        pass
    out.sort(key=lambda x: -x['time'])
    return out[:20]


@admin
async def adm_chat_zips(request):
    return J({'files': await run_in_threadpool(_chat_zips)})


@admin
async def adm_import_chatfile(request):
    """Sicherung einspielen, die ein anderes Gerät über den Familienchat (Dateien senden) geschickt hat."""
    d = await body_json(request)
    fid = str(d.get('id') or '')
    if not _FID.match(fid):
        return err('Datei nicht gefunden.', 404)
    path = FILES_DIR / (fid + '.bin')
    if not path.is_file():
        return err('Die Datei ist nicht mehr vorhanden.', 404)
    data = await run_in_threadpool(path.read_bytes)
    res = await run_in_threadpool(SYS.import_zip, data, str(d.get('mode') or 'merge'), bool(d.get('bundled')))
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, **res})


# ----------------------------------------------------------------------------- System-Update (ohne neue APK)

def _update_source(d=None):
    """Update-Quelle: übergebene Adresse, sonst die gespeicherte, sonst (nie etwas gespeichert) die Vorlage."""
    if (d or {}).get('source'):
        return str(d['source']).strip()
    st = xbmcaddon.all_settings()
    return str(st['update_source'] if 'update_source' in st else URL_TEMPLATES['update_source']).strip()


def _update_view():
    st = UP.status()
    st['source'] = _update_source()
    st['embedded'] = os.environ.get('MOVIESCOUT_EMBEDDED') == '1'
    st['can_restart'] = os.environ.get('MOVIESCOUT_LAUNCHER') == '1'      # das Windows-Programm startet die Engine bei Bedarf neu
    return st


@admin
async def adm_framekey(request):
    return J({'key': _FRAME_KEY})


@admin
async def adm_update_status(request):
    return J(_update_view())


@admin
async def adm_update_check(request):
    d = await body_json(request)
    try:
        res = await run_in_threadpool(UP.check, _update_source(d))
    except UP.UpdateError as e:
        return err(e, 400)
    except Exception as e:                                   # noqa: BLE001
        return err('Quelle nicht erreichbar: %s' % e, 502)
    return J({**res, 'status': _update_view()})


@admin
async def adm_update_install(request):
    d = await body_json(request)
    try:
        res = await run_in_threadpool(UP.install_from_source, _update_source(d), bool(d.get('force')))
    except UP.UpdateError as e:
        return err(e, 400)
    except Exception as e:                                   # noqa: BLE001
        return err('Download fehlgeschlagen: %s' % e, 502)
    return J({**res, 'status': _update_view()})


def _install_and_deps(data):
    info = AH.install_zip(data)
    deps = AR.ensure(info, fetch=True)
    for aid in [info['id']] + deps['installed']:
        try:
            if AH._service_lib(aid):
                AH.start_service(aid)                  # Dienste (xbmc.service) laufen sofort, wie nach der Installation in Kodi
        except Exception:                              # noqa: BLE001
            pass
    return info, deps


@admin
async def adm_addon_install(request):
    data = await request.body()
    try:
        repo = await run_in_threadpool(AR.register_repo, data)      # repository.*.zip: nicht installieren, sondern als Quelle eintragen (wie „Aus ZIP installieren“ in Kodi)
    except AR.RepoError as e:
        return err(str(e), 400)
    if repo:
        AR._index['t'] = 0.0                                        # Katalog beim nächsten Öffnen neu laden
        return J({'ok': True, 'repo': repo})
    try:
        info, deps = await run_in_threadpool(_install_and_deps, data)
    except AH.AddonError as e:
        return err(e, 400)
    AR.clear_origin(info.get('id') or '')                           # von Hand installiert: keine feste Herkunft mehr
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, 'addon': info, 'deps': deps})


@admin
async def adm_addon_scan(request):
    """ZIP auf Kompatibilität prüfen, ohne zu installieren."""
    data = await request.body()
    try:
        info, rep = await run_in_threadpool(CP.scan_zip, data)
    except AH.AddonError as e:
        return err(e, 400)
    info.pop('compat_report', None)
    return J({'ok': True, 'addon': info, 'report': rep})


@admin
async def adm_addon_compat(request):
    """Kompatibilitäts-Bericht eines installierten Addons (frisch aus dem Code gelesen)."""
    aid = request.query_params.get('id') or ''
    if not AH.meta(aid):
        return err('Addon nicht installiert.', 404)
    try:
        return J({'ok': True, 'report': await run_in_threadpool(CP.scan_installed, aid)})
    except AH.AddonError as e:
        return err(e, 400)


@admin
async def adm_repo_search(request):
    """Kodi-Repository durchsuchen: ?q=…&group=video|audio|program|service|module&page=0"""
    qp = request.query_params
    try:
        page = int(qp.get('page') or 0)
    except ValueError:
        page = 0
    try:
        res = await run_in_threadpool(AR.search, qp.get('q') or '', qp.get('group') or '', page, 40, qp.get('src') or '')
    except AR.RepoError as e:
        return err(str(e), 502)
    return J(res)


@admin
async def adm_repo_check(request):
    """Paket aus dem Repository laden und prüfen (ohne Installation)."""
    try:
        return J({'ok': True, **(await run_in_threadpool(AR.check, request.query_params.get('id') or '', request.query_params.get('src') or ''))})
    except AR.RepoError as e:
        return err(str(e), 502)


@admin
async def adm_repo_install(request):
    body = await body_json(request)
    aid = str(body.get('id') or '')
    src = str(body.get('src') or '')

    def go():
        ent, data = AR.get_zip(aid, src)
        res = _install_and_deps(data)
        AR.record_origin(res[0].get('id') or aid, ent.get('srcid'), ent.get('srclabel'))      # Updates kommen künftig aus diesem Repository
        return res
    try:
        info, deps = await run_in_threadpool(go)
    except (AR.RepoError, AH.AddonError) as e:
        return err(str(e), 502 if isinstance(e, AR.RepoError) else 400)
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, 'addon': info, 'deps': deps})


@admin
async def adm_repo_updates(request):
    """Installierte Addons, für die das Repository eine neuere Version hat."""
    try:
        return J({'ok': True, 'items': await run_in_threadpool(AR.updates)})
    except AR.RepoError as e:
        return err(str(e), 502)


@admin
async def adm_repo_refresh(request):
    """Alle Repository-Kataloge neu laden (sonst gilt der Zwischenspeicher)."""
    try:
        return J({'ok': True, 'sources': await run_in_threadpool(AR.refresh)})
    except AR.RepoError as e:
        return err(str(e), 502)


@admin
async def adm_repo_add(request):
    """Weiteres Repository eintragen (Adresse wird vor dem Speichern wirklich geladen)."""
    body = await body_json(request)
    try:
        return J({'ok': True, **(await run_in_threadpool(AR.add_repo, body.get('url') or ''))})
    except AR.RepoError as e:
        return err(str(e), 400)


@admin
async def adm_repo_remove(request):
    body = await body_json(request)
    try:
        return J({'ok': True, **(await run_in_threadpool(AR.remove_repo, str(body.get('entry') or '')))})
    except AR.RepoError as e:
        return err(str(e), 404)


@admin
async def adm_addon_deps(request):
    """Fehlende Abhängigkeiten eines installierten Addons nachladen (oder nur anzeigen: fetch=false)."""
    body = await body_json(request)
    aid = str(body.get('id') or '')
    m = AH.meta(aid)
    if not m:
        return err('Addon nicht installiert.', 404)
    deps = await run_in_threadpool(AR.ensure, m, bool(body.get('fetch', True)))
    return J({'ok': True, 'deps': deps})


@admin
async def adm_addon_run(request):
    """Programm (script.*) starten wie RunScript(id, args …)."""
    body = await body_json(request)
    try:
        res = await run_in_threadpool(AH.run_script, str(body.get('id') or ''), [str(x) for x in (body.get('args') or [])], _rid(body))
    except AH.AddonError as e:
        return err(e, 400)
    return J(res)


def _rid(d):
    r = str((d or {}).get('rid') or '')
    return r if re.fullmatch(r'[A-Za-z0-9_-]{12,64}', r) else ''


async def api_dialog(request):
    """Rückfragen von Kodi-Addons: GET holt die offene Frage (Long-Poll), POST bringt die Antwort."""
    if request.method == 'POST':
        d = await body_json(request)
        rid = _rid(d)
        if not rid:
            return err('rid fehlt', 400)
        if d.get('win'):                                     # Taste/Klick in einem Addon-Fenster
            return J({'ok': UD.window_event(rid, str(d.get('win')), d.get('ev'))})
        ok = UD.answer(rid, str(d.get('id') or ''), d.get('value'), bool(d.get('cancel')))
        return J({'ok': ok})
    qp = request.query_params
    rid = _rid({'rid': qp.get('rid')})
    if not rid:
        return err('rid fehlt', 400)
    try:
        wait = max(0.0, min(20.0, float(qp.get('wait', 20))))
    except ValueError:
        wait = 20.0
    wid, wv = None, -1
    if qp.get('wv') is not None:                             # Oberfläche kann Addon-Fenster zeigen
        wid = qp.get('wid') or ''
        try:
            wv = int(qp.get('wv'))
        except ValueError:
            wv = -1
    return J(await run_in_threadpool(UD.poll, rid, wait, wid, wv))


async def api_dialog_file(request):
    """Bild eines Addon-Fensters (Hintergrund, Spielfiguren …). Nur Dateien, die ein offenes Fenster angemeldet hat."""
    path = UD.file_path(request.path_params.get('tok', ''))
    if not path or not os.path.isfile(path):
        return err('Nicht gefunden', 404)
    return FileResponse(path, headers={'Cache-Control': 'private, max-age=3600'})


@admin
async def adm_addon_settings(request):
    aid = request.query_params.get('id') or ''
    if not AH.meta(aid):
        return err('Addon nicht installiert.', 404)
    if request.method == 'POST':
        body = await request.json()
        try:
            if body.get('action'):
                rid = _rid(body)
                try:
                    res = await run_in_threadpool(AH.run_action, aid, str(body['action']), rid)
                finally:
                    UD.end(rid)
                return J({'ok': True, **res})
            saved = await run_in_threadpool(AH.save_settings, aid, body.get('values') or {})
        except AH.AddonError as e:
            return err(e, 400)
        R.clear_cache()
        return J({'ok': True, 'saved': saved})
    try:
        return J({'addon': AH.meta(aid), 'fields': await run_in_threadpool(AH.settings_schema, aid), 'service': AH.service_status(aid)})
    except AH.AddonError as e:
        return err(e, 400)


@admin
async def adm_addon_list(request):
    return J({'addons': [dict(m, missing=AR.missing(m)) for m in AH.installed()]})


@admin
async def adm_addon_remove(request):
    body = await request.json()
    try:
        m = await run_in_threadpool(AH.remove, str(body.get('id') or ''))
    except AH.AddonError as e:
        return err(e, 404)
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, 'removed': m.get('id')})


@admin
async def adm_update_upload(request):
    data = await request.body()
    try:
        res = await run_in_threadpool(UP.install_zip, data, 'Datei', request.query_params.get('force') in ('1', 'true'))
    except UP.UpdateError as e:
        return err(e, 400)
    return J({**res, 'status': _update_view()})


@admin
async def adm_update_rollback(request):
    try:
        res = UP.rollback()
    except UP.UpdateError as e:
        return err(e, 400)
    return J({**res, 'status': _update_view()})


@admin
async def adm_update_reset(request):
    return J({**UP.reset(), 'status': _update_view()})


@admin
async def adm_restart(request):
    """Engine neu starten (Desktop/Pydroid). In der Android-App läuft sie im App-Prozess: dort startet die Oberfläche
    die App neu (MovieScoutApp.restartApp)."""
    if os.environ.get('MOVIESCOUT_EMBEDDED') == '1':
        if (await body_json(request)).get('quit'):           # Android ohne Neustart-Schnittstelle: App-Prozess beenden (wie „Beenden erzwingen“)
            threading.Timer(0.8, lambda: os._exit(0)).start()
            return J({'ok': True, 'how': 'quit'})
        return J({'ok': False, 'how': 'app'})
    if os.environ.get('MOVIESCOUT_LAUNCHER') == '1':         # Windows-Programm: Engine beendet sich mit Code 75, das Programm startet sie neu
        threading.Timer(0.7, lambda: os._exit(75)).start()
        return J({'ok': True, 'how': 'launcher'})

    def _go():
        time.sleep(0.8)
        try:
            os.execv(sys.executable, [sys.executable] + AH.ENGINE_ARGV)
        except Exception:                                    # noqa: BLE001
            log.exception('Neustart')
    threading.Thread(target=_go, name='restart', daemon=True).start()
    return J({'ok': True, 'how': 'exec'})


AUTO_UPDATE_FIRST = 25            # Sekunden nach dem Start bis zur ersten Prüfung
AUTO_UPDATE_EVERY = 6 * 3600      # danach alle 6 Stunden (läuft MovieScout am TV tagelang durch)


def _auto_on(key):
    """Schalter 'auto_update_system' / 'auto_update_resolveurl' (Standard: an)."""
    return str(xbmcaddon.all_settings().get(key) or 'true').lower() != 'false'


def _auto_update_round():
    """Eine Runde: System-Update und ResolveURL prüfen und, wenn erlaubt, selbst einspielen. Jeder Fehler (kein Netz,
    Quelle weg) wird nur protokolliert – beim nächsten Durchlauf wird es erneut versucht."""
    src = _update_source()
    if src:
        try:
            if _auto_on('auto_update_system'):
                res = UP.auto_update(src)
                if res.get('installed'):
                    log.info('Automatisches Update: Version %s bereitgestellt', res['version'])
                    NF.push('ext', 'MovieScout aktualisiert', 'Version %s ist geladen und gilt nach dem nächsten Neustart '
                            '(Einstellungen → System → „Jetzt neu starten“).' % res['version'])
                elif res.get('reason', '').startswith('Version'):
                    log.info('Automatisches Update: %s', res['reason'])
            else:
                res = UP.check(src)
                if res.get('available') and xbmcaddon.all_settings().get('update_notify') != 'false':
                    NF.push('ext', 'MovieScout-Update', 'Version %s ist verfügbar (Einstellungen → System).' % res['version'])
        except Exception as e:                               # noqa: BLE001
            log.info('Update-Prüfung: %s', e)
    if _auto_on('auto_update_resolveurl'):
        try:
            c = RS.check_update()
            if c.get('newer'):
                st = RS.update()
                log.info('Automatisches Update: ResolveURL %s', st.get('version'))
                NF.push('ext', 'ResolveURL aktualisiert', 'Neue Version %s ist aktiv (Hoster-Auflösung).' % st.get('version'))
        except Exception as e:                               # noqa: BLE001
            log.info('ResolveURL-Prüfung: %s', e)


def _start_update_check():
    """Im Hintergrund: beim Start (nach kurzer Wartezeit) und danach alle paar Stunden. Mit dem Standard „automatisch“
    werden System-Update (gilt nach dem nächsten Start; startet es nicht, fällt MovieScout selbst zurück) und ResolveURL
    (gilt sofort) selbst eingespielt; ohne den Schalter wird nur gemeldet, dass es etwas Neues gibt."""
    def _run():
        time.sleep(AUTO_UPDATE_FIRST)                        # erst Start und Oberfläche fertig werden lassen
        while True:
            try:
                _auto_update_round()
            except Exception:                                # noqa: BLE001
                log.exception('Automatisches Update')
            time.sleep(AUTO_UPDATE_EVERY)
    threading.Thread(target=_run, name='update-check', daemon=True).start()


# ----------------------------------------------------------------------------- Erweiterungen: Oberfläche, Einstellungen, Beispiele

async def api_ext_ui(request):
    return J(X.ui_meta())


async def api_ext_items(request):
    q = request.query_params
    kind = 'menus' if q.get('kind') == 'menus' else 'rows'
    try:
        items, title = await run_in_threadpool(X.ui_items, kind, q.get('ext', ''), q.get('id', ''), q.get('fresh') == '1')
    except KeyError as e:
        return err(e.args[0] if e.args else e, 404)
    except X.UserError as e:
        return err(e, 400)
    except Exception as e:                                  # noqa: BLE001
        return err('%s: %s' % (type(e).__name__, e), 500)
    return J({'items': items, 'title': title})


async def api_ext_widgets(request):
    widgets = await run_in_threadpool(X.ui_widgets, request.query_params.get('fresh') == '1')
    return J({'widgets': widgets})


async def api_ext_action(request):
    if not _admin_ok(request):
        return err('Erweiterungs-Knöpfe nur über localhost, mit Token oder freigegebener Herkunft.', 403)
    d = await body_json(request)
    try:
        res = await run_in_threadpool(X.ui_action, d.get('ext') or '', d.get('id') or '', d.get('item') or {})
    except KeyError as e:
        return err(e.args[0] if e.args else e, 404)
    except X.UserError as e:
        return err(e, 400)
    except Exception as e:                                  # noqa: BLE001
        return err('%s: %s' % (type(e).__name__, e), 500)
    return J(res)


async def api_event(request):
    """Die Oberfläche meldet Wiedergabe-Beginn/-Ende (type = play | stop) an die Erweiterungen."""
    d = await body_json(request)
    kind = str(d.get('type') or '')
    info = d.get('info') if isinstance(d.get('info'), dict) else {}
    item = d.get('item') if isinstance(d.get('item'), dict) else {}
    return J({'ok': True, 'hooks': X.emit(kind, item, info)})


@admin
async def adm_ext_settings(request):
    if request.method == 'POST':
        d = await body_json(request)
        res = await run_in_threadpool(X.settings_set, d.get('ext') or '', d.get('values') or {})
        await run_in_threadpool(X.load_all)               # Zeitpläne u. Ä. lesen die neuen Werte
        return J(res)
    return J(await run_in_threadpool(X.settings_get, request.query_params.get('ext', '')))


@admin
async def adm_ext_run(request):
    d = await body_json(request)
    return J(await run_in_threadpool(X.run_task, d.get('ext') or '', d.get('task') or ''))


@admin
async def adm_examples(request):
    have = {r['file'] for r in SYS.list_files('extension')}
    return J({'examples': [{'id': e['id'], 'file': e['file'], 'title': e['title'], 'description': e['description'],
                            'installed': e['file'] in have, 'bulk': e['id'] not in EX.NOT_IN_BULK} for e in EX.EXAMPLES]})


@admin
async def adm_example_install(request):
    d = await body_json(request)
    if d.get('all'):                                    # alle Gadgets auf einmal (Filter, die Titel/Quellen verändern, bleiben außen vor)
        have = {r['file'] for r in SYS.list_files('extension')}
        done = []
        for e in EX.EXAMPLES:
            if e['id'] in EX.NOT_IN_BULK or e['file'] in have:
                continue
            SYS.save_file('extension', e['file'], e['code'], overwrite=False)
            done.append(e['id'])
        await run_in_threadpool(R.reload_all)
        return J({'ok': True, 'installed': done})
    ex = next((e for e in EX.EXAMPLES if e['id'] == d.get('id')), None)
    if ex is None:
        return err('Beispiel nicht gefunden', 404)
    res = SYS.save_file('extension', ex['file'], ex['code'], overwrite=False)
    await run_in_threadpool(R.reload_all)
    return J({'ok': True, 'file': res.get('file')})


# ----------------------------------------------------------------------------- Scraper-Assistent

def _assist(fn):
    @admin
    async def wrapper(request):
        d = await body_json(request)
        try:
            return J(await run_in_threadpool(fn, d))
        except AS.AssistError as e:
            return err(e, 400)
    wrapper.__name__ = fn.__name__
    return wrapper


def _assist_build(d):
    sid = re.sub(r'[^a-z0-9_]+', '_', str(d.get('id') or '').lower()).strip('_') or AS.slug_for(d.get('url') or '')
    base, n = sid, 2
    while sid in R.REGISTRY:                                # bestehende Quelle nie überschreiben
        sid, n = '%s_%d' % (base, n), n + 1
    code = AS.build(d.get('name') or '', sid, d.get('domain') or '', d.get('url') or '', d.get('spec') or {},
                    d.get('next') or '', d.get('search') or '', bool(d.get('movies', True)))
    return {'code': code, 'file': sid + '.py', 'id': sid}


adm_assist_analyze = _assist(lambda d: AS.analyze(d.get('url') or ''))
adm_assist_preview = _assist(lambda d: AS.preview(d.get('url') or '', d.get('spec') or {}))
adm_assist_detail = _assist(lambda d: AS.analyze_detail(d.get('url') or ''))
adm_assist_build = _assist(_assist_build)


async def api_ext(request):
    if not _admin_ok(request):
        return err('Erweiterungs-Routen nur über localhost, mit Token oder freigegebener Herkunft (MOVIESCOUT_ADMIN_ORIGINS).', 403)
    ext, rest = request.path_params['ext'], request.path_params.get('rest', '')
    body = await request.body()
    req = X.Request(request.method, dict(request.query_params), body, dict(request.headers), rest)
    try:
        res, status = await run_in_threadpool(X.dispatch, ext, rest, req)
    except KeyError as e:
        return err(e.args[0] if e.args else e, 404)
    except Exception as e:
        log.exception('Erweiterung %s/%s', ext, rest)
        return err('%s: %s' % (type(e).__name__, e), 500)
    if isinstance(res, (dict, list)):
        return J(res, status)
    if isinstance(res, bytes):
        mt = 'application/octet-stream'
        for magic, t in ((b'\xff\xd8\xff', 'image/jpeg'), (b'\x89PNG', 'image/png'), (b'GIF8', 'image/gif'), (b'RIFF', 'image/webp')):
            if res.startswith(magic):
                mt = t
                break
        return Response(res, status_code=status, media_type=mt)
    html = str(res)
    if '<meta name="ms-game">' in html:
        html = html.replace('</head>', _GAME_GUARD + '</head>', 1)
    return Response(html, status_code=status, media_type='text/html; charset=utf-8')


# Spiele-Seiten (Marke <meta name="ms-game">): Die Seite darf nie scrollen oder sich verschieben (Tippen, Tastatur, Pfeiltasten),
# und sie ist so hoch wie der sichtbare Bereich (dvh), nicht wie der Bildschirm mit eingefahrener Adressleiste.
_GAME_GUARD = '''<style>html,body{height:100%;max-height:100dvh;overflow:hidden!important;overscroll-behavior:none}body{position:fixed;inset:0;width:100%;height:100dvh}</style>
<script>(function(){var z=function(){try{window.scrollTo(0,0);var e=document.scrollingElement;if(e){e.scrollTop=0;e.scrollLeft=0}if(document.body){document.body.scrollTop=0;document.body.scrollLeft=0}}catch(x){}};
addEventListener('scroll',z,{passive:true});addEventListener('resize',z);addEventListener('focusin',function(){setTimeout(z,0);setTimeout(z,250)});
if(window.visualViewport){visualViewport.addEventListener('resize',z);visualViewport.addEventListener('scroll',z)}
addEventListener('touchmove',function(e){if(e.target&&e.target.closest&&e.target.closest('input,textarea,select'))return;if(e.cancelable)e.preventDefault()},{passive:false});
addEventListener('keydown',function(e){if(e.key==='ArrowUp'||e.key==='ArrowDown'||e.key===' '||e.key==='PageUp'||e.key==='PageDown'){var t=e.target&&e.target.tagName;if(t!=='INPUT'&&t!=='TEXTAREA'&&t!=='SELECT'&&t!=='BUTTON')e.preventDefault()}},true);
})();</script>'''


# ----------------------------------------------------------------------------- App

class _NoCacheStatic(StaticFiles):
    """Oberfläche nie aus dem Browser-Cache laden: nach einem Update der Dateien sieht man sofort die neue Version."""

    async def get_response(self, path, scope):
        resp = await super().get_response(path, scope)
        resp.headers['Cache-Control'] = 'no-cache'
        return resp


# ----------------------------------------------------------------------------- Fernbedienung (Handy als Second Screen)
# Kopplung per sechsstelligem Code: das Handy öffnet /remote?code=XXXXXX (vom Fernseher angezeigt) und
# verbindet sich per WebSocket mit genau diesem "Raum". Die Engine reicht Nachrichten nur zwischen den
# beiden Seiten eines Raums durch - es wird nichts interpretiert oder gespeichert (außer dem letzten
# Zustand, damit ein später verbundenes Handy nicht "blind" ist).
_REMOTE_ROOMS = {}        # code -> {'tv': WebSocket|None, 'phone': WebSocket|None, 'created': float}
_REMOTE_ROOM_TTL = 900    # ungenutzte Codes (keine Seite verbunden) nach 15 Minuten verwerfen


def _remote_sweep():
    now = time.time()
    for code in [c for c, r in _REMOTE_ROOMS.items()
                 if r['tv'] is None and r['phone'] is None and now - r['created'] > _REMOTE_ROOM_TTL
                 and now - max(r.get('seen_tv', 0), r.get('seen_phone', 0)) > _REMOTE_ROOM_TTL]:
        _REMOTE_ROOMS.pop(code, None)


async def api_remote_code(request):
    _remote_sweep()
    code = ''.join(secrets.choice('0123456789') for _ in range(6))
    while code in _REMOTE_ROOMS:
        code = ''.join(secrets.choice('0123456789') for _ in range(6))
    _REMOTE_ROOMS[code] = {'tv': None, 'phone': None, 'created': time.time(), 'last_state': {}}
    server = request.scope.get('server') or (None, None)
    return J({'code': code, 'ip': _lan_ip(), 'port': request.url.port or server[1] or 0})


async def api_lan(request):
    """Adresse dieses Geräts im WLAN (für die Kopplung Handy <-> Fernseher)."""
    server = request.scope.get('server') or (None, None)
    return J({'ip': _lan_ip(), 'port': request.url.port or server[1] or 0})


# ----------------------------------------------------------------------------- Freigabe im WLAN (Passwort)

def _client_ip(request):
    return (request.client.host if request.client else '') or ''


def _share_urls(request):
    port = request.url.port or (request.scope.get('server') or (None, 0))[1] or 0
    ips = []
    for fn in (_ifaddrs_v4, _java_ips):
        try:
            ips += [ip for n, ip in fn() if _private_v4(ip) and not n.startswith(('lo', 'rmnet', 'ccmni', 'tun', 'docker', 'veth'))]
        except Exception:                                   # noqa: BLE001
            pass
    best = _lan_ip()
    if best:
        ips.insert(0, best)
    out = []
    for ip in ips:
        u = 'http://%s:%s/' % (ip, port)
        if u not in out:
            out.append(u)
    return out, port


def _share_view(request):
    conf = SH.config()
    local = _is_self(_client_ip(request))
    out = {'role': 'host' if local else ('guest' if conf['enabled'] else 'none'), 'enabled': conf['enabled'],
           'name': socket.gethostname()}
    if local:
        urls, port = _share_urls(request)
        out.update(password=conf['password'], urls=urls, port=port, seen=SH.seen(), min_len=SH.MIN_LEN)
    return out


async def share_page(request):
    return Response(SH.login_page(enabled=SH.config()['enabled']), media_type='text/html; charset=utf-8',
                    headers={'Cache-Control': 'no-store'})


async def api_share_login(request):
    ip = _client_ip(request)
    conf = SH.config()
    if not conf['enabled']:
        return err('Die Freigabe ist ausgeschaltet.', 403)
    if SH.blocked(ip):
        return err('Zu viele Versuche. Bitte kurz warten.', 429)
    d = await body_json(request)
    if not SH.check_password(d.get('password'), conf):
        SH.fail(ip)
        await asyncio.sleep(0.4)
        return err('Passwort falsch.', 401)
    SH.clear_fails(ip)
    tok = SH.token_for(conf['password'])
    resp = J({'ok': True, 'token': tok, 'name': socket.gethostname()})
    resp.set_cookie(SH.COOKIE, tok, max_age=30 * 86400, httponly=True, samesite='lax', path='/')
    return resp


async def api_share_logout(request):
    resp = J({'ok': True})
    resp.delete_cookie(SH.COOKIE, path='/')
    return resp


async def api_share_status(request):
    return J(_share_view(request))


@admin
async def adm_share_set(request):
    d = await body_json(request)
    try:
        SH.set_config(bool(d.get('enabled')), d.get('password'), bool(d.get('regenerate')))
    except ValueError as e:
        return err(e, 400)
    if d.get('forget'):
        SH.forget()
    return J(_share_view(request))


_REMOTE_FAILS = {}        # Client-Adresse -> Zeitpunkte falscher Codes (gegen Durchprobieren aus dem WLAN)


def _remote_fail_ok(host):
    now = time.time()
    lst = [t for t in _REMOTE_FAILS.get(host, []) if now - t < 60]
    _REMOTE_FAILS[host] = lst
    return len(lst) < 8


async def ws_remote(websocket):
    lan = bool(websocket.scope.get('ms_lan'))
    if TOKEN and not lan and (websocket.query_params.get('token') or '') != TOKEN:
        await websocket.close(code=4401)
        return
    code = (websocket.query_params.get('code') or '').strip()
    role = (websocket.query_params.get('role') or '').strip()
    if role not in ('tv', 'phone') or not re.match(r'^\d{6}$', code):
        await websocket.close(code=4400)
        return
    if lan:                                                 # von außen nur mit einem Code, den ein Fernseher gerade angelegt hat
        host = (websocket.scope.get('client') or ('', 0))[0]
        if not _remote_fail_ok(host):
            await websocket.accept()
            await websocket.close(code=4429)                # erst annehmen, damit das Handy den Grund erfährt
            return
        if role != 'phone' or code not in _REMOTE_ROOMS:
            _REMOTE_FAILS.setdefault(host, []).append(time.time())
            await websocket.accept()
            await websocket.close(code=4404)
            return
    await websocket.accept()
    room = _REMOTE_ROOMS.setdefault(code, {'tv': None, 'phone': None, 'created': time.time(), 'last_state': {}})
    other_role = 'phone' if role == 'tv' else 'tv'
    room[role] = websocket
    try:
        await websocket.send_json({'type': 'hello', 'role': role, 'paired': _remote_online(room, other_role)})
        for m in room.pop('q_' + role, []) or []:           # Nachrichten, die ein Gerät ohne WebSocket vorher hinterlegt hat
            await websocket.send_json(m)
        await _remote_deliver(room, other_role, {'type': 'peer', 'connected': True})
        while True:
            msg = await websocket.receive_json()
            if not isinstance(msg, dict):
                continue
            await _remote_deliver(room, other_role, msg)
    except WebSocketDisconnect:
        pass
    except Exception:                                       # noqa: BLE001
        pass
    finally:
        if room.get(role) is websocket:
            room[role] = None
        await _remote_deliver(room, other_role, {'type': 'peer', 'connected': False})
        if not _remote_online(room, 'tv') and not _remote_online(room, 'phone'):
            _REMOTE_ROOMS.pop(code, None)


# Ersatz für Geräte ohne WebSocket-Paket (z. B. Pydroid): dieselben Nachrichten per HTTP-Abfrage (Long-Polling).
# Beide Wege lassen sich mischen (z. B. Fernseher mit WebSocket, Handy per Abfrage).
_REMOTE_POLL_SEEN = 12     # Sekunden, die eine Seite nach der letzten Abfrage noch als „verbunden“ gilt


async def _remote_deliver(room, role, msg):
    """Nachricht an die Seite `role` des Raums: per WebSocket, sonst in deren Warteschlange."""
    target = room.get(role)
    if target is not None:
        try:
            await target.send_json(msg)
            return
        except Exception:                                   # noqa: BLE001
            pass
    q = room.setdefault('q_' + role, [])
    q.append(msg)
    del q[:-200]


def _remote_online(room, role):
    return room.get(role) is not None or time.time() - room.get('seen_' + role, 0) < _REMOTE_POLL_SEEN


def _remote_http_room(request):
    """Prüft Code/Rolle wie ws_remote; liefert (room, role, fehler_antwort)."""
    lan = bool(request.scope.get('ms_lan'))
    q = request.query_params
    if TOKEN and not lan and (q.get('token') or '') != TOKEN:
        return None, '', J({'error': 'Token fehlt oder ist falsch'}, 401)
    code = (q.get('code') or '').strip()
    role = (q.get('role') or '').strip()
    if role not in ('tv', 'phone') or not re.match(r'^\d{6}$', code):
        return None, '', J({'error': 'Code oder Rolle ungültig'}, 400)
    if lan:
        host = (request.client.host if request.client else '') or ''
        if not _remote_fail_ok(host):
            return None, '', J({'error': 'Zu viele Versuche'}, 429)
        if role != 'phone' or code not in _REMOTE_ROOMS:
            _REMOTE_FAILS.setdefault(host, []).append(time.time())
            return None, '', J({'error': 'Code unbekannt'}, 404)
    room = _REMOTE_ROOMS.setdefault(code, {'tv': None, 'phone': None, 'created': time.time(), 'last_state': {}})
    return room, role, None


async def api_remote_send(request):
    room, role, err = _remote_http_room(request)
    if err is not None:
        return err
    room['seen_' + role] = time.time()
    try:
        msg = json.loads(request.query_params.get('m') or '{}')
    except ValueError:
        msg = None
    if not isinstance(msg, dict):
        return J({'error': 'Nachricht ungültig'}, 400)
    other = 'phone' if role == 'tv' else 'tv'
    await _remote_deliver(room, other, msg)
    return J({'ok': True, 'peer': _remote_online(room, other)})


async def api_remote_poll(request):
    room, role, err = _remote_http_room(request)
    if err is not None:
        return err
    other = 'phone' if role == 'tv' else 'tv'
    try:
        wait = max(0.0, min(25.0, float(request.query_params.get('wait') or 0)))
    except ValueError:
        wait = 0.0
    first = not room.get('seen_' + role)
    room['seen_' + role] = time.time()
    if first:                                               # Gegenstelle erfährt, dass diese Seite jetzt da ist
        await _remote_deliver(room, other, {'type': 'peer', 'connected': True})
    end = time.time() + wait
    qn = 'q_' + role
    while not room.get(qn) and time.time() < end:
        await asyncio.sleep(0.15)
        room['seen_' + role] = time.time()
    msgs = room.get(qn) or []
    room[qn] = []
    return J({'messages': msgs, 'peer': _remote_online(room, other)})


_REMOTE_HTML = r"""<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0e1824">
<meta name="color-scheme" content="dark">
<title>MovieScout Fernbedienung</title>
<style>
:root{
  --bg:#0e1824; --panel:#1a2d44; --line:#2a4262; --ink:#e9f0f7; --mut:#93a8bf;
  --acc:#ffbf3c; --acc-ink:#1b1400; --ok:#41d6a0; --bad:#ff6b7a;
}
*{box-sizing:border-box}
html{background:var(--bg);color:var(--ink)}
body{margin:0;min-height:100vh;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  padding:max(14px,env(safe-area-inset-top)) 14px max(14px,env(safe-area-inset-bottom));
  display:flex;flex-direction:column;gap:14px;max-width:460px;margin:0 auto}
h1{font-size:1.15rem;margin:4px 0 0;text-align:center}
h1 b{color:var(--acc)}
.status{text-align:center;font-size:.92rem;color:var(--mut);padding:6px 10px;border-radius:999px;background:var(--panel)}
.status.on{color:var(--ok)}
.status.off{color:var(--bad)}
.card{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:14px;display:flex;flex-direction:column;gap:10px}
input,textarea,button{font:inherit;color:inherit}
textarea{width:100%;min-height:76px;resize:vertical;background:var(--bg);border:1px solid var(--line);
  border-radius:10px;color:var(--ink);padding:10px;font-size:1.05rem}
input[type=text]{width:100%;background:var(--bg);border:1px solid var(--line);border-radius:10px;
  color:var(--ink);padding:12px;font-size:1.3rem;text-align:center;letter-spacing:.1em}
.row{display:flex;gap:8px}
button{cursor:pointer;border:1px solid var(--line);background:var(--bg);color:var(--ink);
  border-radius:10px;padding:12px;font-size:1rem;flex:1}
button.pri{background:var(--acc);color:var(--acc-ink);border-color:var(--acc);font-weight:700}
button:active{transform:scale(.97)}
.pad{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;max-width:280px;margin:0 auto;width:100%}
.pad button{aspect-ratio:1;font-size:1.4rem;padding:0}
.pad .ok{background:var(--acc);color:var(--acc-ink);border-color:var(--acc);font-weight:700;font-size:.95rem}
.hint{font-size:.82rem;color:var(--mut);text-align:center;margin:0}
</style>
</head>
<body>
  <h1>Movie<b>Scout</b> Fernbedienung</h1>
  <div class="status off" id="status">Verbinde …</div>

  <div class="card" id="pairCard" hidden>
    <p class="hint">Code auf dem Fernseher eingeben:</p>
    <input type="text" id="codeIn" inputmode="numeric" maxlength="6" placeholder="123456" autocomplete="off">
    <button class="pri" id="pairBtn">Verbinden</button>
  </div>

  <div class="card">
    <p class="hint">Tippen – erscheint sofort auf dem Fernseher:</p>
    <textarea id="txt" autocomplete="off" autocapitalize="off" placeholder="Suchbegriff, URL, MAC-Adresse …"></textarea>
    <div class="row">
      <button id="clearBtn">Löschen</button>
      <button class="pri" id="sendBtn">Senden ⏎</button>
    </div>
  </div>

  <div class="card">
    <div class="pad">
      <span></span><button data-k="up">▲</button><span></span>
      <button data-k="left">◄</button><button class="ok" data-k="ok">OK</button><button data-k="right">►</button>
      <span></span><button data-k="down">▼</button><span></span>
    </div>
    <div class="row">
      <button data-k="back">⟵ Zurück</button>
      <button data-k="home">⌂ Start</button>
      <button data-k="playpause">⏯ Play/Pause</button>
    </div>
  </div>
<script>
const q = new URLSearchParams(location.search);
let code = (q.get('code') || '').replace(/\D/g, '').slice(0, 6);
const token = q.get('token') || '';
const statusEl = document.getElementById('status');
const pairCard = document.getElementById('pairCard');
const codeIn = document.getElementById('codeIn');
const txt = document.getElementById('txt');
let ws = null, sendTimer = null;

function setStatus(text, cls) { statusEl.textContent = text; statusEl.className = 'status' + (cls ? ' ' + cls : ''); }

function connect() {
  if (!code) { pairCard.hidden = false; setStatus('Code eingeben', 'off'); return; }
  pairCard.hidden = true;
  setStatus('Verbinde …', 'off');
  const proto = location.protocol === 'https:' ? 'wss://' : 'ws://';
  const url = proto + location.host + '/ws/remote?code=' + encodeURIComponent(code) + '&role=phone'
    + (token ? '&token=' + encodeURIComponent(token) : '');
  ws = new WebSocket(url);
  ws.onopen = () => setStatus('Verbunden – warte auf Fernseher …', 'on');
  ws.onmessage = (ev) => {
    let msg; try { msg = JSON.parse(ev.data); } catch { return; }
    if (msg.type === 'peer') setStatus(msg.connected ? 'Verbunden mit dem Fernseher' : 'Fernseher getrennt', msg.connected ? 'on' : 'off');
    else if (msg.type === 'hello') setStatus(msg.paired ? 'Verbunden mit dem Fernseher' : 'Verbunden – warte auf Fernseher …', msg.paired ? 'on' : 'off');
  };
  ws.onclose = () => { setStatus('Getrennt – versuche erneut …', 'off'); setTimeout(connect, 2000); };
  ws.onerror = () => {};
}
function send(msg) { try { ws && ws.readyState === 1 && ws.send(JSON.stringify(msg)); } catch {} }

document.getElementById('pairBtn').addEventListener('click', () => {
  code = codeIn.value.replace(/\D/g, '').slice(0, 6);
  if (code.length === 6) connect(); else setStatus('6-stelligen Code eingeben', 'off');
});
txt.addEventListener('input', () => {
  clearTimeout(sendTimer);
  sendTimer = setTimeout(() => send({ type: 'text', value: txt.value }), 120);
});
txt.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send({ type: 'submit' }); } });
document.getElementById('sendBtn').addEventListener('click', () => send({ type: 'submit' }));
document.getElementById('clearBtn').addEventListener('click', () => { txt.value = ''; send({ type: 'text', value: '' }); txt.focus(); });
document.querySelectorAll('[data-k]').forEach((b) => b.addEventListener('click', () => send({ type: 'key', key: b.dataset.k })));
connect();
</script>
</body>
</html>
"""


async def remote_page(request):
    # Die ausführliche Fernbedienung (static/remote.html, gleiche Seite wie im Kodi-Addon „Kodi Web Remote“);
    # fehlt die Datei, gibt es die einfache eingebaute Seite.
    try:
        html = (ROOT / 'static' / 'remote.html').read_text('utf-8')
    except OSError:
        html = _REMOTE_HTML
    return Response(html, media_type='text/html; charset=utf-8', headers={'Cache-Control': 'no-store'})



# ----------------------------------------------------------------------------- Familienchat
# Eine einzige geteilte Nachrichtenliste pro Engine (nicht pro Gerät/Rolle wie die Fernbedienung oben) -
# jedes Gerät im selben Netzwerk, das sich mit dieser Engine verbindet, sieht dieselben Nachrichten.
# Verlauf wird in einer Datei gehalten (überlebt einen Neustart), Live-Zustellung per WebSocket-Broadcast
# an alle verbundenen Geräte gleichzeitig (kein Pairing-Code nötig, anders als bei /ws/remote).
CHAT_FILE = _paths.DATA_DIR / 'chat.json'
CHAT_MAX = 400
_CHAT_LOCK = threading.Lock()
_CHAT_CLIENTS = set()


def _chat_load():
    try:
        data = json.loads(CHAT_FILE.read_text('utf-8'))
        return data if isinstance(data, list) else []
    except Exception:                                       # noqa: BLE001
        return []


def _chat_save():
    try:
        CHAT_FILE.write_text(json.dumps(_CHAT[-CHAT_MAX:], ensure_ascii=False), 'utf-8')
    except Exception:                                       # noqa: BLE001
        pass


_CHAT = _chat_load()
_CHAT_NEXT_ID = max([m.get('id', 0) for m in _CHAT], default=0) + 1


async def api_chat_list(request):
    _note_loop()
    since = request.query_params.get('since')
    with _CHAT_LOCK:
        msgs = list(_CHAT)
    if since:
        try:
            since_id = int(since)
            msgs = [m for m in msgs if m['id'] > since_id]
        except ValueError:
            pass
    return J({'messages': msgs})


async def _chat_broadcast(msg):
    dead = []
    for ws in list(_CHAT_CLIENTS):
        try:
            await ws.send_json({'type': 'chat', 'message': msg})
        except Exception:                                   # noqa: BLE001
            dead.append(ws)
    for ws in dead:
        _CHAT_CLIENTS.discard(ws)


_LOOP = None            # Ereignisschleife der Engine (für Chat-Nachrichten aus Hintergrund-Threads von Erweiterungen)


def _note_loop():
    global _LOOP
    try:
        _LOOP = asyncio.get_running_loop()
    except RuntimeError:
        pass


def _chat_add(author, text, item, file=None, kind='chat'):
    global _CHAT_NEXT_ID
    with _CHAT_LOCK:
        msg = {'id': _CHAT_NEXT_ID, 'author': author, 'text': text, 'item': item, 'ts': int(time.time())}
        if file:
            msg['file'] = file
        _CHAT_NEXT_ID += 1
        _CHAT.append(msg)
        _chat_save()
    try:                                                    # Meldung für die Android-App (Benachrichtigung)
        body = text or (item or {}).get('title') or ('\U0001F4CE ' + str(file.get('name') or 'Datei') if file else '')
        NF.push(kind, author, body, chat_id=msg['id'])
    except Exception:                                       # noqa: BLE001  (darf den Chat nie stören)
        pass
    return msg


def _chat_post_external(text, author, item):
    """Für Erweiterungen (api.chat): läuft in einem Hintergrund-Thread, verteilt die Nachricht aber an alle Geräte."""
    text = str(text or '').strip()[:2000]
    author = str(author or '').strip()[:40] or 'Erweiterung'
    if item is not None and len(json.dumps(item, ensure_ascii=False)) > 6000:
        item = None
    if not text and not item:
        raise ValueError('Nachricht ist leer')
    msg = _chat_add(author, text, item, kind='ext')
    loop = _LOOP
    if loop is not None and loop.is_running():
        asyncio.run_coroutine_threadsafe(_chat_broadcast(msg), loop)
    return msg


async def api_chat_send(request):
    _note_loop()
    d = await body_json(request)
    text = str(d.get('text') or '').strip()[:2000]
    author = str(d.get('author') or '').strip()[:40] or 'Jemand'
    item = d.get('item') if isinstance(d.get('item'), dict) else None
    if not text and not item:
        return err('Nachricht ist leer', 400)
    msg = _chat_add(author, text, item)
    await _chat_broadcast(msg)
    return J({'message': msg})


# ----------------------------------------------------------------------------- Dateien zwischen Geräten
# Eine Datei wird auf das Chat-Gerät hochgeladen (roh, in Stücken auf die Platte geschrieben) und erscheint als
# Chat-Nachricht mit {id, name, size, mime}. Andere Geräte laden sie mit dem Chat-Schlüssel ab.
FILES_DIR = _paths.DATA_DIR / 'chatfiles'
FILE_MAX = int(os.environ.get('MOVIESCOUT_FILE_MAX_MB', '250')) * 1024 * 1024
FILES_KEEP_DAYS = 30
FILES_TOTAL_MAX = 3 * 1024 ** 3
_FID = re.compile(r'^[0-9a-f]{16}$')
_INLINE_MIME = re.compile(r'^(image/(png|jpe?g|gif|webp)|audio/[a-z0-9.+-]+|video/(mp4|webm|ogg)|application/pdf)$')


def _safe_name(name):
    name = os.path.basename(str(name or '').replace('\\', '/')).strip()
    name = re.sub(r'[\x00-\x1f<>:"|?*]+', '_', name)[:120].strip(' .')
    return name or 'Datei'


def _file_mime(mime, name):
    m = str(mime or '').lower().strip()
    if not re.fullmatch(r'[a-z0-9.+-]+/[a-z0-9.+-]+', m) or m == 'application/octet-stream':
        m = (mimetypes.guess_type(name)[0] or 'application/octet-stream').lower()
    if m in ('text/html', 'application/xhtml+xml', 'image/svg+xml', 'text/javascript', 'application/javascript', 'text/xml', 'application/xml'):
        m = 'application/octet-stream'                     # nie als Seite ausliefern (Schutz vor Skripten in fremden Dateien)
    return m


def _files_cleanup():
    try:
        items = []
        for f in FILES_DIR.glob('*.bin'):
            st = f.stat()
            items.append((st.st_mtime, st.st_size, f))
        now = time.time()
        items.sort()
        total = sum(i[1] for i in items)
        for mt, sz, f in items:
            if now - mt > FILES_KEEP_DAYS * 86400 or total > FILES_TOTAL_MAX:
                total -= sz
                f.unlink(missing_ok=True)
                f.with_suffix('.json').unlink(missing_ok=True)
    except Exception:                                       # noqa: BLE001
        pass


def _fmt_size(n):
    return '%.1f MB' % (n / 1048576) if n >= 1048576 else '%d KB' % max(1, round(n / 1024))


async def api_files_upload(request):
    _note_loop()
    q = request.query_params
    name = _safe_name(q.get('name'))
    mime = _file_mime(q.get('mime'), name)
    author = str(q.get('author') or '').strip()[:40] or 'Jemand'
    text = str(q.get('text') or '').strip()[:2000]
    declared = request.headers.get('content-length')
    if declared and declared.isdigit() and int(declared) > FILE_MAX:
        return err('Datei zu groß (höchstens %d MB).' % (FILE_MAX // 1048576), 413)
    FILES_DIR.mkdir(parents=True, exist_ok=True)
    fid = secrets.token_hex(8)
    path = FILES_DIR / (fid + '.bin')
    total = 0
    try:
        with open(path, 'wb') as fh:
            async for chunk in request.stream():
                total += len(chunk)
                if total > FILE_MAX:
                    raise ValueError('Datei zu groß (höchstens %d MB).' % (FILE_MAX // 1048576))
                fh.write(chunk)
        if total == 0:
            raise ValueError('Die Datei ist leer.')
    except Exception as e:                                  # noqa: BLE001
        path.unlink(missing_ok=True)
        return err(str(e) if isinstance(e, ValueError) else 'Hochladen abgebrochen.', 413 if isinstance(e, ValueError) else 400)
    meta = {'id': fid, 'name': name, 'size': total, 'mime': mime}
    path.with_suffix('.json').write_text(json.dumps(meta, ensure_ascii=False), 'utf-8')
    await run_in_threadpool(_files_cleanup)
    msg = _chat_add(author, text, None, meta)
    await _chat_broadcast(msg)
    return J({'message': msg})


async def api_files_get(request):
    fid = request.path_params.get('fid', '')
    if not _FID.match(fid):
        return err('Datei nicht gefunden', 404)
    path = FILES_DIR / (fid + '.bin')
    try:
        meta = json.loads(path.with_suffix('.json').read_text('utf-8'))
    except Exception:                                       # noqa: BLE001
        return err('Die Datei ist nicht mehr vorhanden (sie wird nach %d Tagen gelöscht).' % FILES_KEEP_DAYS, 404)
    if not path.is_file():
        return err('Die Datei ist nicht mehr vorhanden.', 404)
    inline = bool(_INLINE_MIME.match(meta.get('mime', ''))) and request.query_params.get('dl') != '1'
    resp = FileResponse(path, media_type=meta.get('mime') or 'application/octet-stream', filename=meta.get('name') or 'Datei',
                        content_disposition_type='inline' if inline else 'attachment')
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['Content-Security-Policy'] = "sandbox; default-src 'none'; media-src 'self'; img-src 'self'; style-src 'unsafe-inline'"
    resp.headers['Cache-Control'] = 'private, max-age=3600'
    return resp


async def api_notify(request):
    """Meldungen für die Android-App (nur von diesem Gerät aus erreichbar, siehe LanGate).
    ?since=<id>: nur neuere Meldungen. ?wait=<Sekunden, max. 25>: wartet, bis es etwas Neues gibt (Long-Poll).
    "last" ist die höchste vergebene ID: Damit fängt die App nach einem Neustart der Engine bei 0 an."""
    try:
        after = int(request.query_params.get('since') or 0)
    except ValueError:
        after = 0
    try:
        wait = max(0.0, min(25.0, float(request.query_params.get('wait') or 0)))
    except ValueError:
        wait = 0.0
    end = time.time() + wait
    while True:
        last = NF.last_id()
        if after > last:                                    # Engine wurde neu gestartet: IDs zählen wieder von vorn
            after = 0
        events = NF.since(after)
        if events or time.time() >= end:
            return J({'events': events, 'last': last})
        await asyncio.sleep(0.4)


async def api_chat_host(request):
    """Adresse und Schlüssel dieses Geräts als Chat-Gerät (nur lokal: von außen nicht erreichbar)."""
    server = request.scope.get('server') or (None, None)
    return J({'ip': _lan_ip(), 'port': request.url.port or server[1] or 0, 'key': _chat_key(), 'max_mb': FILE_MAX // 1048576})


async def ws_chat(websocket):
    if TOKEN and (websocket.query_params.get('token') or '') != TOKEN and not _scope_key_ok(websocket.scope):
        await websocket.close(code=4401)
        return
    await websocket.accept()
    _note_loop()
    _CHAT_CLIENTS.add(websocket)
    try:
        await websocket.send_json({'type': 'hello'})
        while True:
            await websocket.receive_text()      # Client schickt nichts Nennenswertes - hält die Verbindung nur offen
    except WebSocketDisconnect:
        pass
    except Exception:                                       # noqa: BLE001
        pass
    finally:
        _CHAT_CLIENTS.discard(websocket)


# ---- Haus: Synchron-Player + Kamera-Übertragung für alle Geräte im Haus ------------------------------------------------
# Ein Gerät (das Chat-Gerät) ist die Zentrale. Alle anderen verbinden sich mit /ws/haus?key=<Chat-Schlüssel>.
# Die Zentrale merkt sich nur: wer ist da, was läuft gerade (Titel, Quelle, Position) und wer sendet Kamerabilder.
# Die Kamerabilder selbst laufen direkt zwischen den Geräten (WebRTC, nur im Heimnetz); hier gehen nur die
# Verbindungsnachrichten (offer/answer/ice) durch.
_HAUS = {}          # websocket -> {'id': str, 'name': str, 'cam': bool}
_HAUS_STATE = {}    # letzter gemeinsamer Wiedergabezustand (leer = nichts läuft)


def _haus_now():
    return int(time.time() * 1000)


def _haus_peers():
    return [{'id': m['id'], 'name': m['name'], 'cam': m['cam']} for m in _HAUS.values()]


async def _haus_send(ws, msg):
    try:
        await ws.send_json(msg)
    except Exception:                                       # noqa: BLE001
        _HAUS.pop(ws, None)


async def _haus_broadcast(msg, skip=None):
    for ws in list(_HAUS):
        if ws is not skip:
            await _haus_send(ws, msg)


async def ws_haus(websocket):
    if TOKEN and (websocket.query_params.get('token') or '') != TOKEN and not _scope_key_ok(websocket.scope):
        await websocket.close(code=4401)
        return
    await websocket.accept()
    _note_loop()
    me = {'id': secrets.token_hex(4), 'name': 'Gerät', 'cam': False}
    _HAUS[websocket] = me
    try:
        await websocket.send_json({'t': 'hello', 'id': me['id'], 'now': _haus_now(), 'peers': _haus_peers(),
                                   'state': _HAUS_STATE or None})
        await _haus_broadcast({'t': 'peers', 'peers': _haus_peers()}, skip=websocket)
        while True:
            raw = await websocket.receive_text()
            if len(raw) > 65536:
                continue
            try:
                m = json.loads(raw)
            except ValueError:
                continue
            if not isinstance(m, dict):
                continue
            t = m.get('t')
            if t == 'ping':                                 # Uhrenabgleich: Client misst die Laufzeit selbst
                await _haus_send(websocket, {'t': 'pong', 'c': m.get('c'), 's': _haus_now()})
            elif t == 'name':
                me['name'] = re.sub(r'\s+', ' ', str(m.get('name') or 'Gerät')).strip()[:30] or 'Gerät'
                await _haus_broadcast({'t': 'peers', 'peers': _haus_peers()})
            elif t == 'state':                              # gemeinsamer Zustand: merken und an alle anderen weiterreichen
                st = m.get('s')
                if st is None:
                    _HAUS_STATE.clear()
                elif isinstance(st, dict):
                    _HAUS_STATE.clear()
                    _HAUS_STATE.update(st)
                    _HAUS_STATE['by'] = me['id']
                await _haus_broadcast({'t': 'state', 's': _HAUS_STATE or None, 'from': me['id']}, skip=websocket)
            elif t == 'cam':                                # dieses Gerät sendet (oder beendet) Kamerabilder
                me['cam'] = bool(m.get('on'))
                await _haus_broadcast({'t': 'peers', 'peers': _haus_peers()})
            elif t == 'sig':                                # Verbindungsnachricht an genau ein Gerät
                to = str(m.get('to') or '')
                for ws, mm in list(_HAUS.items()):
                    if mm['id'] == to:
                        await _haus_send(ws, {'t': 'sig', 'from': me['id'], 'd': m.get('d')})
                        break
    except WebSocketDisconnect:
        pass
    except Exception:                                       # noqa: BLE001
        pass
    finally:
        _HAUS.pop(websocket, None)
        if not _HAUS:
            _HAUS_STATE.clear()
        await _haus_broadcast({'t': 'peers', 'peers': _haus_peers()})
        await _haus_broadcast({'t': 'gone', 'id': me['id']})


def create_app():
    R.setup_logging()
    R.load_providers()
    X.CHAT_POST = _chat_post_external
    multiquest.HOOK = RL                  # Schutz vor Sperren + optionaler Umweg-Proxy für alle Scraper-Abfragen
    X.load_all()
    _start_github_sync()      # nur wenn in den Einstellungen ein GitHub-Link steht; leeres Feld = nichts tun
    _start_health_watch()      # passive Überwachung aller Quellen, läuft von selbst im Hintergrund
    _start_update_check()
    routes = [
        Route('/', root),
        Route('/api/info', info),
        Route('/api/providers', providers),
        Route('/api/open', api_open, methods=['GET', 'POST']),
        Route('/api/load', api_open, methods=['GET', 'POST']),
        Route('/api/resolve', api_resolve, methods=['POST']),
        Route('/api/play', api_play, methods=['POST']),
        Route('/api/localfile/{token}/{name:path}', api_localfile, methods=['GET', 'HEAD']),
        Route('/api/media/file/{eid}', api_media_file, methods=['GET', 'HEAD']),
        Route('/api/media/lib', adm_media_lib),
        Route('/api/media/add', adm_media_add, methods=['POST']),
        Route('/api/media/scan', adm_media_scan, methods=['POST']),
        Route('/api/media/move', adm_media_move, methods=['POST']),
        Route('/api/media/remove', adm_media_remove, methods=['POST']),
        Route('/api/discover', adm_discover),
        Route('/api/discover/meta', adm_discover_meta),
        Route('/api/trailer', adm_trailer, methods=['POST']),
        Route('/api/feed', adm_feed),
        Route('/api/trakt/auth', adm_trakt_auth, methods=['POST']),
        Route('/api/trakt/list', adm_trakt_list),
        Route('/api/fs/list', adm_fs_list),
        Route('/api/fs/roots', adm_fs_roots),
        Route('/api/admin/import_path', adm_import_path, methods=['POST']),
        Route('/api/admin/chatzips', adm_chat_zips),
        Route('/api/admin/import_chatfile', adm_import_chatfile, methods=['POST']),
        Route('/api/search', api_search),
        Route('/api/meta', api_meta, methods=['POST']),
        Route('/api/meta/ratings', api_meta_ratings, methods=['POST']),
        Route('/api/mylib', api_mylib),
        Route('/api/mylib/get', api_mylib_get, methods=['POST']),
        Route('/api/mylib/set', api_mylib_set, methods=['POST']),
        Route('/api/mylib/delete', api_mylib_delete, methods=['POST']),
        Route('/api/health', api_health),
        Route('/api/logs', api_logs),
        Route('/api/settings', api_settings, methods=['GET', 'POST']),
        Route('/api/cache/clear', api_cache_clear, methods=['POST']),
        Route('/api/cache/stats', api_cache_stats),
        Route('/api/downloads', api_downloads_list),
        Route('/api/downloads', api_downloads_start, methods=['POST']),
        Route('/api/downloads/{id}', api_downloads_one),
        Route('/api/downloads/{id}', api_downloads_delete, methods=['DELETE']),
        Route('/api/downloads/{id}/moved', api_downloads_moved, methods=['POST']),
        Route('/api/downloads/{id}/file', api_downloads_file),
        Route('/api/admin/list', adm_list),
        Route('/api/admin/source', adm_source),
        Route('/api/admin/templates', adm_templates),
        Route('/api/admin/save', adm_save, methods=['POST']),
        Route('/api/admin/check', adm_check, methods=['POST']),
        Route('/api/admin/github_sync', adm_github_sync, methods=['POST']),
        Route('/api/ext/framekey', adm_framekey),
        Route('/api/admin/update', adm_update_status),
        Route('/api/admin/update/check', adm_update_check, methods=['POST']),
        Route('/api/admin/update/install', adm_update_install, methods=['POST']),
        Route('/api/admin/update/upload', adm_update_upload, methods=['POST']),
        Route('/api/admin/addon/install', adm_addon_install, methods=['POST']),
        Route('/api/admin/addon/deps', adm_addon_deps, methods=['POST']),
        Route('/api/admin/addon/scan', adm_addon_scan, methods=['POST']),
        Route('/api/admin/addon/compat', adm_addon_compat),
        Route('/api/admin/repo/search', adm_repo_search),
        Route('/api/admin/repo/check', adm_repo_check),
        Route('/api/admin/repo/install', adm_repo_install, methods=['POST']),
        Route('/api/admin/repo/add', adm_repo_add, methods=['POST']),
        Route('/api/admin/repo/updates', adm_repo_updates),
        Route('/api/admin/repo/refresh', adm_repo_refresh, methods=['POST']),
        Route('/api/admin/repo/remove', adm_repo_remove, methods=['POST']),
        Route('/api/admin/addon/run', adm_addon_run, methods=['POST']),
        Route('/api/admin/addons', adm_addon_list),
        Route('/api/dialog', api_dialog, methods=['GET', 'POST']),
        Route('/api/dialog/file/{tok}', api_dialog_file),
    Route('/api/admin/addon/settings', adm_addon_settings, methods=['GET', 'POST']),
        Route('/api/admin/addon/remove', adm_addon_remove, methods=['POST']),
        Route('/api/admin/update/rollback', adm_update_rollback, methods=['POST']),
        Route('/api/admin/update/reset', adm_update_reset, methods=['POST']),
        Route('/api/admin/restart', adm_restart, methods=['POST']),
        Route('/api/admin/enable', adm_enable, methods=['POST']),
        Route('/api/admin/delete', adm_delete, methods=['POST']),
        Route('/api/admin/restore', adm_restore, methods=['POST']),
        Route('/api/admin/reload', adm_reload, methods=['POST']),
        Route('/api/admin/export', adm_export, methods=['POST']),
        Route('/api/admin/import', adm_import, methods=['POST']),
        Route('/api/admin/nettest', adm_nettest, methods=['GET']),
        Route('/api/admin/net', adm_net),
        Route('/api/admin/dns/test', adm_dns_test, methods=['POST']),
        Route('/api/admin/resolveurl', adm_resolveurl, methods=['GET']),
        Route('/api/admin/resolveurl/update', adm_resolveurl_update, methods=['POST']),
        Route('/api/admin/resolveurl/source', adm_resolveurl_source, methods=['POST']),
        Route('/api/admin/ext/settings', adm_ext_settings, methods=['GET', 'POST']),
        Route('/api/admin/ext/run', adm_ext_run, methods=['POST']),
        Route('/api/admin/examples', adm_examples),
        Route('/api/admin/examples/install', adm_example_install, methods=['POST']),
        Route('/api/admin/assist/analyze', adm_assist_analyze, methods=['POST']),
        Route('/api/admin/assist/preview', adm_assist_preview, methods=['POST']),
        Route('/api/admin/assist/detail', adm_assist_detail, methods=['POST']),
        Route('/api/admin/assist/build', adm_assist_build, methods=['POST']),
        Route('/api/ext/ui', api_ext_ui),
        Route('/api/ext/items', api_ext_items),
        Route('/api/ext/widgets', api_ext_widgets),
        Route('/api/ext/action', api_ext_action, methods=['POST']),
        Route('/api/event', api_event, methods=['POST']),
        Route('/api/x/{ext}/{rest:path}', api_ext, methods=['GET', 'POST', 'PUT', 'DELETE']),
        Route('/api/proxy', api_proxy, methods=['GET', 'HEAD', 'POST']),
        Route('/api/subtitle', api_subtitle, methods=['GET', 'POST']),
        Route('/api/img', api_img, methods=['GET']),
        Route('/api/imgcache', adm_imgcache, methods=['GET', 'POST']),
        Route('/api/admin/cleanup', adm_cleanup, methods=['GET', 'POST']),
        Route('/api/p/{tok}/{rest:path}', api_proxy_path, methods=['GET', 'HEAD', 'POST']),
        Route('/api/remote/code', api_remote_code),
        Route('/api/lan', api_lan),
        Route('/share', share_page),
        Route('/api/share/login', api_share_login, methods=['POST']),
        Route('/api/share/logout', api_share_logout, methods=['POST']),
        Route('/api/share/status', api_share_status),
        Route('/api/admin/share', adm_share_set, methods=['POST']),
        Route('/remote', remote_page),
        Route('/remote/poll', api_remote_poll),
        Route('/remote/send', api_remote_send),
        WebSocketRoute('/ws/remote', ws_remote),
        Route('/api/chat', api_chat_list),
        Route('/api/chat', api_chat_send, methods=['POST']),
        Route('/api/chat/host', api_chat_host),
        Route('/api/notify', api_notify),
        Route('/api/files', api_files_upload, methods=['POST']),
        Route('/api/files/{fid}', api_files_get),
        WebSocketRoute('/ws/chat', ws_chat),
        WebSocketRoute('/ws/haus', ws_haus),
        Mount('/ui', _NoCacheStatic(directory=str(ROOT / 'static'), html=True), name='ui'),
    ]
    import inspect
    cors_kw = dict(allow_origins=['*'], allow_methods=['*'], allow_headers=['*'],
                   expose_headers=['Content-Length', 'Content-Range', 'Accept-Ranges'], max_age=86400)
    middleware = []
    if 'allow_private_network' in inspect.signature(CORSMiddleware.__init__).parameters:
        cors_kw['allow_private_network'] = True
    else:
        middleware.append(Middleware(PrivateNetwork))
    middleware += [Middleware(CORSMiddleware, **cors_kw), Middleware(Guard)]
    @asynccontextmanager
    async def _lifespan(_app):
        UP.mark_ok()                  # Engine ist oben: ein eingespieltes Update gilt als gestartet
        def _guard_test():
            try:
                from kodi_runtime import safere as _sf
                time.sleep(2)
                if not _sf.selftest():
                    log.warning('Schutz vor hängenden Suchmustern greift auf diesem Gerät nicht: %s', _sf.status())
                else:
                    log.info('Schutz vor hängenden Suchmustern: %s', _sf.status())
            except Exception:         # noqa: BLE001
                log.warning('Selbsttest des Suchmuster-Schutzes fehlgeschlagen', exc_info=True)
        threading.Thread(target=_guard_test, name='re-guard-test', daemon=True).start()
        if not WS_OK:
            log.warning('Live-Verbindungen (Chat, Handy-Fernbedienung) sind aus: Python-Paket „websockets“ fehlt (pip install websockets). '
                        'Der Chat läuft ersatzweise über Abfragen.')
        try:
            AH.start_all_services()   # Addon-Dienste (xbmc.service) starten wie beim Kodi-Start
        except Exception:         # noqa: BLE001
            pass
        try:
            CLEAN.start_background(lambda: (xbmcaddon.all_settings().get('autoclean') or 'true') != 'false')
        except Exception:         # noqa: BLE001
            pass
        yield
    app = Starlette(routes=routes, middleware=middleware, lifespan=_lifespan)
    return LanGate(app, strict=os.environ.get('MOVIESCOUT_LAN_GATE') == '1')
