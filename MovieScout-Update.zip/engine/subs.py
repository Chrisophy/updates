# -*- coding: utf-8 -*-
"""Untertitel: Dateien (SRT, ASS/SSA, VTT) in WebVTT umwandeln und Listen aus Scrapern/Kodi vereinheitlichen."""
import re

MAX_BYTES = 3 * 1024 * 1024
_ARROW = re.compile(r'^\s*(\d+:)?(\d+):(\d+)[,.](\d{1,3})\s*-->\s*(\d+:)?(\d+):(\d+)[,.](\d{1,3})')
_LANGS = ('de', 'en', 'fr', 'es', 'it', 'tr', 'ru', 'nl', 'pl', 'pt', 'ar', 'sv', 'da', 'no', 'fi', 'cs', 'el', 'hu', 'ro', 'uk')
_LANG_RX = re.compile(r'(?:^|[^a-z])(%s)(?:[^a-z]|$)' % '|'.join(_LANGS), re.I)
_NAMES = {'deutsch': 'de', 'german': 'de', 'english': 'en', 'englisch': 'en', 'french': 'fr', 'französisch': 'fr', 'spanish': 'es', 'italian': 'it', 'turkish': 'tr'}


def decode(data):
    """Bytes -> Text. UTF-8 (mit/ohne BOM), UTF-16 mit BOM, sonst Windows-1252."""
    if isinstance(data, str):
        return data
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return data.decode('utf-16', 'replace')
    try:
        return data.decode('utf-8-sig')
    except UnicodeDecodeError:
        return data.decode('cp1252', 'replace')


def _ts(h, m, s, ms):
    return '%02d:%02d:%02d.%s' % (int((h or '0:').rstrip(':') or 0), int(m), int(s), (ms + '00')[:3])


def _clean(line):
    line = re.sub(r'\{\\[^}]*\}', '', line)              # ASS-Formatierung {\an8} …
    return line


def _srt(text):
    out = ['WEBVTT', '']
    for line in text.split('\n'):
        m = _ARROW.match(line)
        if m:
            g = m.groups()
            out.append('%s --> %s' % (_ts(g[0], g[1], g[2], g[3]), _ts(g[4], g[5], g[6], g[7])))
        else:
            out.append(_clean(line))
    return '\n'.join(out)


def _ass_time(t):
    m = re.match(r'(\d+):(\d+):(\d+)[.,](\d+)', t.strip())
    if not m:
        return None
    h, mi, s, cs = m.groups()
    return '%02d:%02d:%02d.%s' % (int(h), int(mi), int(s), (cs + '000')[:3])


def _ass(text):
    fmt, cues = None, []
    in_ev = False
    for line in text.split('\n'):
        ls = line.strip()
        if ls.startswith('['):
            in_ev = ls.lower() == '[events]'
            continue
        if not in_ev:
            continue
        if ls.lower().startswith('format:'):
            fmt = [x.strip().lower() for x in ls.split(':', 1)[1].split(',')]
        elif ls.lower().startswith('dialogue:'):
            f = fmt or ['layer', 'start', 'end', 'style', 'name', 'marginl', 'marginr', 'marginv', 'effect', 'text']
            parts = ls.split(':', 1)[1].split(',', len(f) - 1)
            if len(parts) < len(f):
                continue
            row = dict(zip(f, parts))
            a, b = _ass_time(row.get('start', '')), _ass_time(row.get('end', ''))
            if not a or not b:
                continue
            t = _clean(row.get('text', '')).replace('\\N', '\n').replace('\\n', '\n').strip()
            if t:
                cues.append((a, b, t))
    cues.sort()
    out = ['WEBVTT', '']
    for a, b, t in cues:
        out += ['%s --> %s' % (a, b), t, '']
    return '\n'.join(out)


def to_vtt(data):
    """Beliebige Untertitel-Datei (Bytes oder Text) -> WebVTT-Text. ValueError, wenn nichts Brauchbares darin ist."""
    text = decode(data).replace('\r\n', '\n').replace('\r', '\n').lstrip('﻿')
    head = text.lstrip()[:12]
    if head.startswith('WEBVTT'):
        vtt = text.lstrip()
    elif '[script info]' in text[:400].lower() or '[events]' in text.lower():
        vtt = _ass(text)
    else:
        vtt = _srt(text)
    if '-->' not in vtt:
        raise ValueError('Das ist keine Untertitel-Datei (SRT, ASS oder VTT).')
    return vtt


def guess_lang(*names):
    for n in names:
        n = str(n or '').lower()
        for k, v in _NAMES.items():
            if k in n:
                return v
        m = _LANG_RX.search(n)
        if m:
            return m.group(1).lower()
    return ''


def norm_subtitles(raw):
    """Liste aus Scraper/Kodi (Adressen oder dicts mit url/lang/label) -> [{'url','lang','label'}]. Nur http(s)."""
    out, seen = [], set()
    if isinstance(raw, (str, dict)):
        raw = [raw]
    for i, s in enumerate(raw or []):
        if isinstance(s, dict):
            url = str(s.get('url') or s.get('file') or s.get('path') or '').strip()
            lang = str(s.get('lang') or s.get('language') or '').strip().lower()[:8]
            label = str(s.get('label') or s.get('name') or '').strip()
        else:
            url, lang, label = str(s or '').strip(), '', ''
        if url.startswith('//'):
            url = 'https:' + url
        if not url.startswith(('http://', 'https://')) or url in seen:
            continue
        seen.add(url)
        lang = lang or guess_lang(label, url.rsplit('/', 1)[-1])
        out.append({'url': url, 'lang': lang, 'label': label or (lang.upper() if lang else 'Untertitel %d' % (len(out) + 1))})
    return out[:12]
