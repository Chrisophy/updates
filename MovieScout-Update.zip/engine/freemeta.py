# -*- coding: utf-8 -*-
"""Kostenlose Filminfos ohne Anmeldung und ohne API-Schlüssel (nur Deutschland, deutsche Texte).

Quellen:
  Wikipedia (de)  Beschreibung, Poster              IMDb           Bewertung, Länge, FSK, Besetzung, Poster
  Moviepilot      Bewertung                         Filmstarts     Bewertung (Presse, Nutzer)
  Rotten Tomatoes Tomatometer

Kein Schlüssel, kein Konto: es wird nur das gelesen, was auch ein Browser ohne Anmeldung sieht (JSON-LD der
Filmseite, Such-APIs). Jede Quelle ist unabhängig und darf ausfallen - was fehlt, bleibt leer, nichts wird erfunden.
Die Seiten ändern sich gelegentlich; deshalb nur wenige, robuste Muster (schema.org-JSON-LD zuerst).
"""
import html as _html
import json
import logging
import os
import re
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, wait

from . import cache as _cachemod

log = logging.getLogger('engine.freemeta')

UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36'
TIMEOUT = 7
TOTAL_TIMEOUT = 11
_C = _cachemod.Cache('freemeta', ttl=7 * 86400, max_mem=300, persist=True)
NEG_TTL = 6 * 3600
_POOL = ThreadPoolExecutor(max_workers=8, thread_name_prefix='freemeta')

NAMES = {'imdb': 'IMDb', 'rt': 'Rotten Tomatoes', 'filmstarts': 'Filmstarts', 'moviepilot': 'Moviepilot', 'wiki': 'Wikipedia'}


def _get(url, accept='text/html,application/json;q=0.9,*/*;q=0.5'):
    req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': accept, 'Accept-Language': 'de-DE,de;q=0.9'})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        return r.read(2_500_000).decode('utf-8', 'replace')


def _json(url):
    return json.loads(_get(url, 'application/json'))


def _norm(s):
    s = _html.unescape(str(s or '')).lower()
    for a, b in (('ä', 'ae'), ('ö', 'oe'), ('ü', 'ue'), ('ß', 'ss')):
        s = s.replace(a, b)
    return re.sub(r'[^a-z0-9]+', ' ', s).strip()


def _num(v):
    try:
        return float(str(v).replace(',', '.').strip().rstrip('%'))
    except (TypeError, ValueError):
        return None


def _minutes(d):
    m = re.match(r'^PT(?:(\d+)H)?(?:(\d+)M)?', str(d or ''))
    return (int(m.group(1) or 0) * 60 + int(m.group(2) or 0)) if m else 0


# ----------------------------------------------------------------------------- JSON-LD

def jsonld(html_text):
    """Erstes schema.org-Objekt vom Typ Movie/TVSeries/CreativeWork … -> dict (leer, wenn keins da ist)."""
    best = {}
    for m in re.finditer(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>', html_text or '', re.S | re.I):
        try:
            data = json.loads(m.group(1).strip())
        except ValueError:
            continue
        stack = data if isinstance(data, list) else [data]
        while stack:
            o = stack.pop(0)
            if not isinstance(o, dict):
                continue
            if isinstance(o.get('@graph'), list):
                stack.extend(o['@graph'])
            t = o.get('@type')
            t = ' '.join(t) if isinstance(t, list) else str(t or '')
            if any(k in t for k in ('Movie', 'TVSeries', 'TVEpisode', 'CreativeWork', 'VideoObject')) and (o.get('aggregateRating') or o.get('name') or o.get('duration')):
                if o.get('aggregateRating') and not best.get('aggregateRating'):
                    best = o
                elif not best:
                    best = o
    return best


def _rating_of(ld, scale_default=10.0):
    ar = ld.get('aggregateRating') if isinstance(ld, dict) else None
    if isinstance(ar, list):
        ar = ar[0] if ar else None
    if not isinstance(ar, dict):
        return None
    val = _num(ar.get('ratingValue'))
    if val is None:
        return None
    best = _num(ar.get('bestRating')) or scale_default
    return {'value': val, 'best': best, 'count': int(_num(ar.get('ratingCount') or ar.get('reviewCount')) or 0)}


def _rating(src, val, best, url, count=0, label=''):
    """Einheitlicher Eintrag: 'score' immer 0-10 (zum Sortieren/Mitteln), 'text' so wie die Seite es zeigt."""
    if val is None or val <= 0:
        return None
    if best == 100:
        text = '%d %%' % round(val)
    else:
        text = ('%s/%s' % (('%.1f' % val).replace('.', ',').rstrip('0').rstrip(','), ('%g' % best)))
    return {'src': src, 'name': NAMES[src], 'label': label, 'score': round(val / best * 10, 1), 'text': text, 'url': url, 'count': count}


def _first_link(html_text, pattern):
    m = re.search(pattern, html_text or '')
    return m.group(1) if m else ''


# ----------------------------------------------------------------------------- Quellen

def src_wiki(title, year, tv):
    q = urllib.parse.urlencode({'action': 'query', 'list': 'search', 'format': 'json', 'srlimit': 4, 'srsearch': '%s %s' % (title, 'Fernsehserie' if tv else 'Film')})
    hits = (_json('https://de.wikipedia.org/w/api.php?' + q).get('query') or {}).get('search') or []
    want = _norm(title)
    for h in hits:
        t = h.get('title') or ''
        if _norm(re.sub(r'\s*\(.*?\)\s*$', '', t)) != want:
            continue
        d = _json('https://de.wikipedia.org/api/rest_v1/page/summary/' + urllib.parse.quote(t.replace(' ', '_'), safe=''))
        desc = str(d.get('description') or '').lower()
        if not any(k in desc for k in ('film', 'serie', 'fernseh', 'zeichentrick', 'anime')):
            continue
        if year and re.search(r'\b(19|20)\d\d\b', desc) and str(year) not in desc and not tv:
            continue
        return {'plot': d.get('extract') or '', 'poster': ((d.get('originalimage') or d.get('thumbnail') or {}).get('source') or ''),
                'url': ((d.get('content_urls') or {}).get('desktop') or {}).get('page') or ''}
    return {}


def src_imdb(title, year, tv):
    q = urllib.parse.quote(_norm(title).replace(' ', '_') or title, safe='_')
    d = _json('https://v3.sg.media-imdb.com/suggestion/x/%s.json' % q)
    want = _norm(title)
    pick = None
    for it in d.get('d') or []:
        if not str(it.get('id') or '').startswith('tt'):
            continue
        qid = str(it.get('qid') or '')
        if tv and 'tv' not in qid.lower():
            continue
        if not tv and qid not in ('movie', 'tvMovie', 'video', ''):
            continue
        if _norm(it.get('l')) != want:
            continue
        if year and it.get('y') and abs(int(it['y']) - int(year)) > 1:
            continue
        pick = it
        break
    if not pick:
        return {}
    out = {'imdb': pick['id'], 'year': pick.get('y') or 0, 'poster': (pick.get('i') or {}).get('imageUrl') or '',
           'cast': [{'name': n.strip(), 'role': ''} for n in str(pick.get('s') or '').split(',') if n.strip()][:8],
           'url': 'https://www.imdb.com/title/%s/' % pick['id']}
    try:
        ld = jsonld(_get(out['url']))
        r = _rating_of(ld)
        if r:
            out['rating'] = _rating('imdb', r['value'], r['best'], out['url'], r['count'])
        out['runtime'] = _minutes(ld.get('duration'))
        out['fsk_raw'] = str(ld.get('contentRating') or '')
        out['plot_en'] = str(ld.get('description') or '')
        g = ld.get('genre')
        out['genres_en'] = g if isinstance(g, list) else ([g] if g else [])
    except Exception as e:                       # noqa: BLE001  (IMDb blockt manchmal Abrufe ohne Browser: dann gibt es nur die Suchdaten)
        log.info('IMDb-Seite: %s', e)
    return out


def _search_page(url_tpl, title, link_re, year):
    html_text = _get(url_tpl % urllib.parse.quote(title))
    links = []
    for m in re.finditer(link_re, html_text):
        if m.group(1) not in links:
            links.append(m.group(1))
    return links[:3]


def src_rt(title, year, tv):
    base = 'https://www.rottentomatoes.com'
    links = _search_page(base + '/search?search=%s', title, r'href="((?:https://www\.rottentomatoes\.com)?/%s/[a-z0-9_]+)"' % ('tv' if tv else 'm'), year)
    want = _norm(title).replace(' ', '_')
    links.sort(key=lambda u: u.rsplit('/', 1)[-1].replace('-', '_') not in (want, 'the_' + want))
    for u in links[:2]:
        u = u if u.startswith('http') else base + u
        ld = jsonld(_get(u))
        if ld.get('name') and _norm(ld.get('name')) != _norm(title) and want not in u:
            continue
        r = _rating_of(ld, 100.0)
        if r:
            return {'rating': _rating('rt', r['value'], 100, u, r['count'], 'Tomatometer')}
    return {}


def src_moviepilot(title, year, tv):
    base = 'https://www.moviepilot.de'
    links = _search_page(base + '/suche?q=%s', title, r'href="((?:https://www\.moviepilot\.de)?/%s/[a-z0-9\-]+)"' % ('serie' if tv else 'movies'), year)
    for u in links[:2]:
        u = u if u.startswith('http') else base + u
        ld = jsonld(_get(u))
        if ld.get('name') and _norm(ld.get('name')) != _norm(title):
            continue
        r = _rating_of(ld, 10.0)
        if r:
            return {'rating': _rating('moviepilot', r['value'], r['best'], u, r['count'])}
    return {}


def src_filmstarts(title, year, tv):
    base = 'https://www.filmstarts.de'
    links = _search_page(base + '/suche/?q=%s', title, r'href="((?:https://www\.filmstarts\.de)?/%s/[^"#?]*?\d+\.html)"' % ('serien/serie' if tv else 'kritiken'), year)
    for u in links[:2]:
        u = u if u.startswith('http') else base + u
        page = _get(u)
        ld = jsonld(page)
        if ld.get('name') and _norm(ld.get('name')) != _norm(title):
            continue
        r = _rating_of(ld, 5.0)
        if r:
            return {'rating': _rating('filmstarts', r['value'], r['best'], u, r['count'], 'Nutzer')}
        tt = _first_link(page, r'<title[^>]*>(.*?)</title>')
        if _norm(title) not in _norm(tt):                  # ohne JSON-LD wenigstens am Seitentitel prüfen, dass es der richtige Film ist
            continue
        vals = re.findall(r'class="[^"]*stareval-note[^"]*"[^>]*>\s*([0-5][,.]\d)\s*<', page)       # Presse, Nutzer (so zeigt es die Seite)
        if vals:
            return {'rating': _rating('filmstarts', _num(vals[0]), 5.0, u, 0, 'Presse')}
    return {}


SOURCES = {'wiki': src_wiki, 'imdb': src_imdb, 'rt': src_rt, 'moviepilot': src_moviepilot, 'filmstarts': src_filmstarts}
_FSK = {'0': '0', '6': '6', '12': '12', '16': '16', '18': '18'}


def _fsk(raw):
    m = re.search(r'\b(0|6|12|16|18)\b', str(raw or ''))
    return _FSK.get(m.group(1), '') if m else ''


# ----------------------------------------------------------------------------- Zusammenfassung

def enabled():
    if os.environ.get('MOVIESCOUT_FREE') == '0':
        return False
    try:
        from kodi_runtime import xbmcaddon
        return (xbmcaddon.all_settings().get('meta.free') or 'an') != 'aus'
    except Exception:                                    # noqa: BLE001
        return True


def lookup(title, year=0, tv=False, sources=None):
    """-> {'plot','poster','year','runtime','fsk','cast','imdb','links':{src:url},'ratings':[…],'errors':{src:text}}  (alles optional)."""
    title = str(title or '').strip()
    if not title or not enabled():                       # Einstellung „Kostenlose Filminfos“ = Aus (oder MOVIESCOUT_FREE=0)
        return {}
    names = [s for s in (sources or SOURCES) if s in SOURCES]
    ck = '|'.join([title.lower(), str(year or 0), '1' if tv else '0', ','.join(sorted(names))])
    hit = _C.get(ck)
    if hit is not None:
        return hit
    futs = {_POOL.submit(SOURCES[n], title, year, tv): n for n in names}
    done, pending = wait(futs, timeout=TOTAL_TIMEOUT)
    res, errs = {}, {}
    for f in done:
        n = futs[f]
        try:
            res[n] = f.result() or {}
        except urllib.error.HTTPError as e:
            errs[n] = 'HTTP %d' % e.code
        except Exception as e:                   # noqa: BLE001
            errs[n] = type(e).__name__
    for f in pending:
        errs[futs[f]] = 'Zeitüberschreitung'
        f.cancel()
    wk, im = res.get('wiki', {}), res.get('imdb', {})
    out = {
        'plot': wk.get('plot') or '', 'poster': im.get('poster') or wk.get('poster') or '', 'year': im.get('year') or 0,
        'runtime': im.get('runtime') or 0, 'fsk': _fsk(im.get('fsk_raw')), 'cast': im.get('cast') or [], 'imdb': im.get('imdb') or '',
        'ratings': [r['rating'] for n in ('imdb', 'rt', 'moviepilot', 'filmstarts') for r in [res.get(n) or {}] if r.get('rating')],
        'links': {n: v for n, v in (('imdb', im.get('url')), ('wiki', wk.get('url'))) if v},
        'errors': errs, 'found': bool(any(res.values())),
    }
    for r in out['ratings']:
        out['links'][r['src']] = r['url']
    if not out['found'] and errs and len(errs) == len(names):
        return out                                # alles ausgefallen (offline): nichts merken
    _C.put(ck, out, ttl=None if out['found'] else NEG_TTL)
    return out


def ratings_only(title, year=0, tv=False):
    """Nur die Bewertungen der Bewertungsseiten (für die Anzeige in der Titel-Info; wird nachgeladen)."""
    if not enabled():
        return {'ratings': [], 'avg': 0, 'errors': {}, 'off': True}
    r = lookup(title, year, tv, sources=['imdb', 'rt', 'moviepilot', 'filmstarts'])
    sc = [x['score'] for x in r.get('ratings') or []]
    return {'ratings': r.get('ratings') or [], 'avg': round(sum(sc) / len(sc), 1) if sc else 0, 'errors': r.get('errors') or {}}
