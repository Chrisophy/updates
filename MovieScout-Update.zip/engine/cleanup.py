# -*- coding: utf-8 -*-
"""Speicher-Aufräumer: zeigt, was in userData Platz belegt, und räumt nur auf, was sich von selbst neu aufbaut.

Aufgeräumt wird ausschließlich (Zwischenspeicher, nie Einstellungen oder Eigenes):
  img    Poster-Speicher (imgcache)
  temp   temporäre Ordner (temp, cache, thumbnails, Bildschirmfotos)
  logs   Protokolldateien
  addon  Zwischenspeicher der Kodi-Addons (z. B. xStream "htmlcache", Vavoo "vavoo_cache", resolveurl "cache")
  db     Zwischenspeicher-Datenbank der Engine (cache.sqlite samt -wal/-shm)
  trash  gelöschte Scraper-Sicherungen (Papierkorb)
  pyc    übersetzte Python-Dateien der Addons (werden beim nächsten Start neu erzeugt - nur auf Wunsch)

Nie angefasst: Downloads, installierte Addons, Einstellungen/Anmeldedaten der Addons (settings.json), Datenbanken
(Verlauf, Lesezeichen), eigene Scraper, Tastenbelegung.
Dateien, die in den letzten 2 Minuten geändert wurden, bleiben stehen (könnten gerade benutzt werden).
"""
import logging
import os
import re
import shutil
import threading
import time
from pathlib import Path

from kodi_runtime import paths as _paths

log = logging.getLogger('minikodi.cleanup')
DATA = _paths.DATA_DIR
BUSY_SECS = 120
LOW_FREE_PCT = 12                  # darunter wird beim automatischen Lauf alles Aufräumbare geleert
_lock = threading.Lock()
_last = {'ts': 0, 'freed': 0, 'files': 0, 'why': ''}

_ADDON_DIR = re.compile(r'^(plugin|script|service|resource|context|weather|metadata|xbmc)\.[\w.-]+$')
_CACHEY = re.compile(r'(cache|caches|^tmp$|^temp$|^thumbs?$|^thumbnails?$|^logs?$|\.tmp$|\.log$|\.cache$)', re.I)
_SKIP_TOP = {'addons', 'addon_data', 'database', 'downloads', 'user', 'keymaps', 'imgcache', 'temp', 'cache',
             'thumbnails', 'screenshots', 'logpath', 'system', 'storage'}

# Kennung -> (Titel, Hinweis, automatisch nach Tagen (0 = ganz), im Standard-Lauf enthalten)
CATS = {
    'img': ('Poster-Speicher', 'Bereits gesehene Poster. Werden bei Bedarf neu geladen.', 0, True),
    'temp': ('Temporäre Dateien', 'Arbeitsordner (temp, cache, thumbnails). Reiner Zwischenstand.', 1, True),
    'logs': ('Protokolle', 'Protokolldateien von Engine und Addons.', 7, True),
    'addon': ('Addon-Zwischenspeicher', 'Gemerkte Webseiten und Listen der Addons (xStream, Vavoo, resolveurl …). '
                                        'Einstellungen und Anmeldungen bleiben.', 14, True),
    'db': ('Engine-Zwischenspeicher', 'Gemerkte Filminfos, Hoster-Links und Suchen (cache.sqlite).', 0, True),
    'trash': ('Papierkorb der Scraper', 'Gelöschte oder überschriebene eigene Scraper (Sicherungen).', 30, True),
    'pyc': ('Übersetzte Python-Dateien', 'Beschleunigen den Start der Addons. Werden neu erzeugt, '
                                          'der nächste Start dauert dann etwas länger.', 0, False),
}
ORDER = ['img', 'addon', 'temp', 'db', 'logs', 'trash', 'pyc']


# ----------------------------------------------------------------------------- Hilfen
def _size(p):
    try:
        return p.lstat().st_size
    except OSError:
        return 0


def _tree(root):
    """Alle Dateien unter root als (Pfad, Größe, mtime). Ohne Symlinks zu folgen."""
    out = []
    try:
        stack = [str(root)]
        while stack:
            d = stack.pop()
            try:
                it = os.scandir(d)
            except OSError:
                continue
            with it:
                for e in it:
                    try:
                        if e.is_symlink():
                            continue
                        if e.is_dir(follow_symlinks=False):
                            stack.append(e.path)
                        else:
                            st = e.stat(follow_symlinks=False)
                            out.append((e.path, st.st_size, st.st_mtime))
                    except OSError:
                        continue
    except Exception:                                   # noqa: BLE001
        pass
    return out


def _targets(cat):
    """Dateien, die zu einer Gruppe gehören: Liste (Pfad, Größe, mtime)."""
    files = []
    if cat == 'img':
        files = _tree(DATA / 'imgcache')
    elif cat == 'temp':
        for n in ('temp', 'cache', 'thumbnails', 'screenshots', 'recordings'):
            files += _tree(DATA / n)
    elif cat == 'logs':
        files = _tree(DATA / 'logpath')
        try:
            for e in os.scandir(str(DATA)):
                if e.is_file() and e.name.lower().endswith(('.log', '.log.1', '.old')):
                    st = e.stat()
                    files.append((e.path, st.st_size, st.st_mtime))
        except OSError:
            pass
    elif cat == 'addon':
        try:
            tops = [e for e in os.scandir(str(DATA)) if e.is_dir() and e.name not in _SKIP_TOP and _ADDON_DIR.match(e.name)]
        except OSError:
            tops = []
        for t in tops:
            files += _addon_cache_files(Path(t.path))
    elif cat == 'db':
        for n in ('cache.sqlite', 'cache.sqlite-wal', 'cache.sqlite-shm'):
            p = DATA / n
            try:
                st = p.stat()
                files.append((str(p), st.st_size, st.st_mtime))
            except OSError:
                pass
    elif cat == 'trash':
        files = _tree(DATA / 'user' / 'trash')
    elif cat == 'pyc':
        for n in ('addons',):
            files += [f for f in _tree(DATA / n) if '__pycache__' in f[0].replace('\\', '/') or f[0].endswith('.pyc')]
    return files


def _addon_cache_files(adir, depth=0):
    """Dateien unterhalb eines Addon-Datenordners, deren Ordner/Datei wie ein Zwischenspeicher heißt (settings.json nie)."""
    out = []
    try:
        for e in os.scandir(str(adir)):
            name = e.name
            if name.lower() in ('settings.json', 'settings.xml'):
                continue
            try:
                if e.is_symlink():
                    continue
                if e.is_dir(follow_symlinks=False):
                    if _CACHEY.search(name):
                        out += _tree(e.path)
                    elif depth < 2:
                        out += _addon_cache_files(Path(e.path), depth + 1)
                elif _CACHEY.search(name):
                    st = e.stat(follow_symlinks=False)
                    out.append((e.path, st.st_size, st.st_mtime))
            except OSError:
                continue
    except OSError:
        pass
    return out


def _dir_bytes(p):
    return sum(s for _, s, _ in _tree(p))


# ----------------------------------------------------------------------------- Überblick
def disk():
    try:
        u = shutil.disk_usage(str(DATA))
        return {'total': u.total, 'free': u.free, 'used_pct': round(100.0 * (u.total - u.free) / u.total, 1) if u.total else 0}
    except OSError:
        return {'total': 0, 'free': 0, 'used_pct': 0}


def scan():
    cats = []
    counted = set()
    for cid in ORDER:
        title, hint, days, std = CATS[cid]
        files = _targets(cid)
        counted.update(f[0] for f in files)
        cats.append({'id': cid, 'title': title, 'hint': hint, 'bytes': sum(f[1] for f in files), 'files': len(files),
                     'auto_days': days, 'default': std})
    protected = []
    for label, sub in (('Downloads (nur von Hand löschen)', 'downloads'), ('Installierte Addons', 'addons'),
                       ('Addon-Einstellungen & Datenbanken', None), ('Eigene Scraper & Erweiterungen', 'user')):
        if sub:
            b = sum(s for p, s, _ in _tree(DATA / sub) if p not in counted)
        else:
            b = 0
            try:
                for e in os.scandir(str(DATA)):
                    if e.is_dir() and e.name not in _SKIP_TOP and e.name != 'downloads':
                        b += sum(s for p, s, _ in _tree(e.path) if p not in counted)
                    elif e.is_dir() and e.name == 'database':
                        b += _dir_bytes(e.path)
                    elif e.is_file() and e.path not in counted:
                        b += _size(Path(e.path))
            except OSError:
                pass
        protected.append({'title': label, 'bytes': b})
    total = sum(c['bytes'] for c in cats) + sum(p['bytes'] for p in protected)
    return {'disk': disk(), 'total': total, 'categories': cats, 'protected': protected, 'last': dict(_last),
            'cleanable': sum(c['bytes'] for c in cats if c['default'])}


# ----------------------------------------------------------------------------- Aufräumen
def _remove(files, older_days):
    now = time.time()
    cut = now - older_days * 86400 if older_days else now
    freed = n = 0
    dirs = set()
    for path, size, mt in files:
        if now - mt < BUSY_SECS:
            continue
        if older_days and mt > cut:
            continue
        try:
            os.unlink(path)
            freed += size
            n += 1
            dirs.add(os.path.dirname(path))
        except OSError:
            pass
    for d in sorted(dirs, key=len, reverse=True):            # leer gewordene Unterordner mit aufräumen (Hauptordner bleiben)
        try:
            if len(Path(d).relative_to(DATA).parts) >= 3:       # Hauptordner (z. B. htmlcache) bleiben stehen
                os.rmdir(d)
        except (OSError, ValueError):
            pass
    return freed, n


def _clean_db(full):
    """Engine-Zwischenspeicher: abgelaufene Einträge (oder alle) löschen, Datei verkleinern."""
    before = sum(f[1] for f in _targets('db'))
    try:
        from . import cache as C
        C.maintain(full=full)
    except Exception as e:                                  # noqa: BLE001
        log.warning('Engine-Zwischenspeicher: %s', e)
    after = sum(f[1] for f in _targets('db'))
    return max(0, before - after), 0


def _clean_img(full):
    from . import imgcache as IMG
    before = sum(f[1] for f in _targets('img'))
    if full:
        n = IMG.clear()
    else:
        try:
            from kodi_runtime import xbmcaddon
            mb = int(xbmcaddon.all_settings().get('imgcache_mb') or IMG.DEFAULT_MB)
        except Exception:                                   # noqa: BLE001
            mb = IMG.DEFAULT_MB
        n = IMG.prune(mb)
    return max(0, before - sum(f[1] for f in _targets('img'))), n


def clean(ids, full=True):
    """Gruppen aufräumen. full=True: alles der Gruppe (Knopf); full=False: nur Altes/Überschuss (automatisch)."""
    res = []
    tf = tn = 0
    with _lock:
        for cid in ids:
            if cid not in CATS:
                continue
            days = 0 if full else CATS[cid][2]
            if cid == 'db':
                freed, n = _clean_db(full)
            elif cid == 'img':
                freed, n = _clean_img(full)
            elif cid == 'pyc':
                freed, n = _remove(_targets('pyc'), 0)
            else:
                freed, n = _remove(_targets(cid), days)
            res.append({'id': cid, 'freed': freed, 'files': n})
            tf += freed
            tn += n
        _last.update({'ts': int(time.time()), 'freed': tf, 'files': tn, 'why': 'manuell' if full else 'automatisch'})
    return {'freed': tf, 'files': tn, 'results': res, 'scan': scan()}


def auto_run():
    """Automatischer Lauf: Altes/Überschuss; bei knappem Speicher alles Aufräumbare (ohne pyc)."""
    d = disk()
    low = d['total'] and (100.0 - d['used_pct']) < LOW_FREE_PCT
    ids = [c for c in ORDER if CATS[c][3]]
    r = clean(ids, full=bool(low))
    _last['why'] = 'automatisch (Speicher knapp)' if low else 'automatisch'
    return r


# ----------------------------------------------------------------------------- Hintergrund
_started = False


def start_background(enabled=lambda: True, first_delay=90, every=6 * 3600):
    """Startet einen Dauer-Thread: nach first_delay Sekunden und dann alle `every` Sekunden aufräumen, wenn enabled()."""
    global _started
    if _started:
        return
    _started = True

    def loop():
        time.sleep(first_delay)
        while True:
            try:
                if enabled():
                    r = auto_run()
                    if r['files']:
                        log.info('Aufgeräumt: %d Dateien, %.1f MB', r['files'], r['freed'] / 1048576)
            except Exception:                               # noqa: BLE001
                log.exception('Automatisches Aufräumen')
            time.sleep(every)
    threading.Thread(target=loop, name='cleanup', daemon=True).start()
