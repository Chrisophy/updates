# -*- coding: utf-8 -*-
"""Hilfsprozess für safere.py: wertet reguläre Ausdrücke aus. Hängt ein Muster (katastrophales Backtracking), wird dieser Prozess beendet -
die Engine selbst bleibt bedienbar. Protokoll: 4 Byte Länge + pickle, auf stdin/stdout."""
import pickle
import re
import struct
import sys

_in, _out = sys.stdin.buffer, sys.stdout.buffer


def _read(n):
    buf = b''
    while len(buf) < n:
        c = _in.read(n - len(buf))
        if not c:
            raise SystemExit(0)
        buf += c
    return buf


def _run(req):
    op, pat, fl, text = req[:4]
    a = req[4:]
    p = re.compile(pat, fl)
    if op == 'findall':
        return p.findall(text, *a)
    if op in ('search', 'match', 'fullmatch'):
        m = getattr(p, op)(text, *a)
        return None if m is None else m.start()
    if op == 'finditer':
        return [m.start() for m in p.finditer(text, *a)]
    if op == 'subn':
        return p.subn(a[0], text, a[1])
    if op == 'split':
        return p.split(text, a[0])
    if op == 'sleep':
        import time
        time.sleep(a[0])
        return None
    raise ValueError(op)


while True:
    try:
        req = pickle.loads(_read(struct.unpack('<I', _read(4))[0]))
        try:
            out = ('ok', _run(req))
        except re.error as e:
            out = ('re', str(e))
        except Exception as e:                    # noqa: BLE001
            out = ('exc', repr(e))
        data = pickle.dumps(out, 4)
        _out.write(struct.pack('<I', len(data)) + data)
        _out.flush()
    except SystemExit:
        break
    except (BrokenPipeError, EOFError):
        break
