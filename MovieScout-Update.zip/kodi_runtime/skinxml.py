# -*- coding: utf-8 -*-
"""Kodi-Skin-XML für WindowXML / WindowXMLDialog.

Addons mit `class W(xbmcgui.WindowXMLDialog)` liefern ihr Fenster als XML (resources/skins/Default/720p/<name>.xml). Dieses Modul liest
das XML, löst <include>-Bausteine auf, baut daraus die Steuerelemente (dieselben Control-Klassen wie bei selbst gebauten Fenstern) und
rechnet bei jedem Abruf aus, was die Oberfläche zeichnen soll: Lage (Gruppen, Gruppenlisten, 1080i→720p), Sichtbarkeit (<visible>),
Texte ($INFO, $LOCALIZE, Fenster-Eigenschaften), Bilder und Listenzeilen. Tasten, Fokus und Klicks laufen über xbmcgui.Window.

Bewusst vereinfacht: Animationen, Listen-Layouts (itemlayout/focusedlayout) und Skin-eigene Texturen fehlen; Listen zeigen Symbol, Titel und
zweite Zeile, Knöpfe ohne eigene Bilder bekommen die Standarddarstellung.
"""
import copy
import logging
import os
import re
import threading
import xml.etree.ElementTree as ET
from pathlib import Path

from . import context

_log = logging.getLogger('kodi.skinxml')

RES_SIZE = {'720p': (1280, 720), '1080i': (1920, 1080), '1080p': (1920, 1080), '16x9': (1280, 720), '4x3': (1024, 768), 'ntsc': (720, 480),
            'ntsc16x9': (720, 480), 'pal': (720, 576), 'pal16x9': (720, 576), '720': (1280, 720), '1080': (1920, 1080)}
FOCUSABLE = ('button', 'radio', 'list', 'edit', 'slider', 'spin')
MAX_DEPTH = 14
MAX_NODES = 1500

# Zeichenketten, die Addons häufig aus Kodis eigener Sprachdatei brauchen (Kodi-Kernstrings)
CORE_STRINGS = {186: 'OK', 222: 'Abbrechen', 224: 'Beenden', 106: 'Ja', 107: 'Nein', 13: 'Einstellungen', 15: 'Aktualisieren', 12:'Info',
                16: 'Lösche', 118: 'Umbenennen', 128: 'Abbrechen', 190: 'Auswählen', 209: 'Schließen', 79: 'Zurück', 216: 'Weiter', 10004: 'Einstellungen',
                15067: 'Alles', 20053: 'Zurück', 10: 'Videos'}


# ----------------------------------------------------------------------------- Dateien finden

def _ci(path):
    """Datei/Ordner ohne Rücksicht auf Groß-/Kleinschreibung finden (Kodi tut das auch, Android-Speicher nicht)."""
    p = Path(path)
    if p.exists():
        return p
    cur = Path(p.anchor) if p.is_absolute() else Path('.')
    for part in p.parts[1:] if p.is_absolute() else p.parts:
        nxt = cur / part
        if not nxt.exists():
            try:
                low = part.lower()
                nxt = next((c for c in cur.iterdir() if c.name.lower() == low), None)
            except OSError:
                nxt = None
            if nxt is None:
                return None
        cur = nxt
    return cur


def find_xml(name, script_path='', skin='Default', res='720p'):
    """-> (Pfad, Auflösungsordner) oder (None, '')."""
    name = str(name or '').replace('\\', '/').strip()
    if not name:
        return None, ''
    if os.path.isabs(name):
        p = _ci(name)
        return (p, p.parent.name) if p and p.is_file() else (None, '')
    base = Path(str(script_path)) if script_path else None
    if base is None or not base.is_dir():
        return None, ''
    skins = base / 'resources' / 'skins'
    order = []
    for sk in (skin or 'Default', 'Default'):
        d = _ci(skins / sk)
        if d and d.is_dir():
            subs = [c.name for c in d.iterdir() if c.is_dir()]
            pref = [res, '720p', '1080i', '16x9'] + sorted(subs)
            for r in pref:
                if r and (d.name, r) not in [(x[0].parent.parent.name, x[1]) for x in order]:
                    order.append((d / r, r))
    if skins.is_dir():                                      # irgendein anderer Skin-Ordner
        for d in sorted(c for c in skins.iterdir() if c.is_dir()):
            for sub in sorted(c for c in d.iterdir() if c.is_dir()):
                order.append((sub, sub.name))
    for folder, r in order:
        p = _ci(folder / name)
        if p and p.is_file():
            return p, p.parent.name
    for p in (base / name, base / 'resources' / name, base / 'resources' / 'skins' / name):
        q = _ci(p)
        if q and q.is_file():
            return q, q.parent.name
    return None, ''


# ----------------------------------------------------------------------------- Bausteine (Includes.xml)

class SkinDefs:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.defs, self.consts, self.exprs, self.vars = {}, {}, {}, {}
        self._seen = set()
        for nm in ('Includes.xml', 'includes.xml'):
            p = _ci(self.folder / nm)
            if p and p.is_file():
                self._load(p)
                break

    def _load(self, path, depth=0):
        if depth > 6 or str(path) in self._seen:
            return
        self._seen.add(str(path))
        try:
            root = ET.parse(str(path)).getroot()
        except (ET.ParseError, OSError) as e:
            _log.warning('Includes nicht lesbar: %s (%s)', path, e)
            return
        for el in list(root):
            t = el.tag
            if t == 'include' and el.get('file'):
                q = _ci(Path(path).parent / el.get('file'))
                if q and q.is_file():
                    self._load(q, depth + 1)
            elif t == 'include' and el.get('name'):
                self.defs[el.get('name')] = el
            elif t == 'constant' and el.get('name'):
                self.consts[el.get('name')] = (el.text or '').strip()
            elif t == 'expression' and el.get('name'):
                self.exprs[el.get('name')] = (el.text or '').strip()
            elif t == 'variable' and el.get('name'):
                self.vars[el.get('name')] = [(v.get('condition') or '', (v.text or '').strip()) for v in el.findall('value')]
            elif t == 'includes':
                for sub in list(el):
                    root.append(sub)                       # <includes> verschachtelt: Inhalt eine Ebene hochziehen


_PARAM = re.compile(r'\$PARAM\[([^\]]+)\]')
_CONST = re.compile(r'\$CONSTANT\[([^\]]+)\]')
_EXP = re.compile(r'\$EXP\[([^\]]+)\]')


def _sub(text, params, defs):
    if not text or '$' not in text:
        return text
    for _ in range(3):
        old = text
        text = _PARAM.sub(lambda m: str(params.get(m.group(1).strip(), '')), text)
        text = _CONST.sub(lambda m: str(defs.consts.get(m.group(1).strip(), '')), text)
        text = _EXP.sub(lambda m: '(' + str(defs.exprs.get(m.group(1).strip(), '')) + ')', text)
        if text == old:
            break
    return text


class _Budget:
    def __init__(self):
        self.n = 0


def _clone(el, defs, params, depth, bud):
    bud.n += 1
    if bud.n > 20000 or depth > MAX_DEPTH:
        return ET.Element(el.tag)
    new = ET.Element(el.tag, {k: _sub(v, params, defs) for k, v in el.attrib.items()})
    new.text = _sub(el.text, params, defs)
    for ch in el:
        if ch.tag == 'include':
            for x in _include(ch, defs, params, depth, bud):
                new.append(x)
        else:
            new.append(_clone(ch, defs, params, depth, bud))
    return new


def _include(ch, defs, params, depth, bud):
    name = _sub((ch.get('content') or ch.text or ch.get('name') or '').strip(), params, defs)
    cond = _sub(ch.get('condition') or '', params, defs)
    if cond and not _eval_static(cond):
        return []
    d = defs.defs.get(name)
    if d is None or depth > MAX_DEPTH:
        return []
    local = {}
    for p in d.findall('param'):                            # Vorgaben der Definition
        if p.get('name'):
            local[p.get('name')] = p.get('default') if p.get('default') is not None else (p.get('value') or p.text or '')
    for p in ch.findall('param'):                           # Werte beim Aufruf
        if p.get('name'):
            v = p.get('value') if p.get('value') is not None else (p.text or '')
            local[p.get('name')] = _sub(v, params, defs)
    body = d.find('definition')
    kids = list(body) if body is not None else [k for k in d if k.tag != 'param']
    out = []
    for k in kids:
        if k.tag == 'include':
            out.extend(_include(k, defs, local, depth + 1, bud))
        else:
            out.append(_clone(k, defs, local, depth + 1, bud))
    return out


def _eval_static(cond):
    from . import skin
    try:
        return skin.cond_visible(_brackets(cond))
    except Exception:                                      # noqa: BLE001
        return False


def _brackets(cond):
    """Kodi erlaubt [ ] zum Gruppieren in Bedingungen; der Auswerter kennt ( )."""
    return str(cond or '').replace('[', '(').replace(']', ')')


# ----------------------------------------------------------------------------- Knoten

class Node:
    def __init__(self, el, parent=None):
        self.type = (el.get('type') or '').lower()
        try:
            self.id = int(el.get('id') or 0)
        except ValueError:
            self.id = 0
        self.el = el
        self.parent = parent
        self.kids = []
        self.cid = 0                                       # Kennung des Steuerelements im Fenster (bei id-losen: künstlich)
        self.ctl = None
        self.props = {}
        for ch in el:
            if ch.tag != 'control':
                self.props.setdefault(ch.tag, []).append(ch)

    def text(self, tag, default=''):
        els = self.props.get(tag)
        return (els[0].text or '').strip() if els else default

    def texts(self, tag):
        return [(e.text or '').strip() for e in self.props.get(tag, []) if (e.text or '').strip()]

    def attr(self, tag, name, default=''):
        els = self.props.get(tag)
        return (els[0].get(name) or default) if els else default


def _build(el, parent, win_nodes, counter):
    n = Node(el, parent)
    counter[0] += 1
    if counter[0] > MAX_NODES:
        return n
    win_nodes.append(n)
    for ch in el:
        if ch.tag == 'control' and counter[0] <= MAX_NODES:
            n.kids.append(_build(ch, n, win_nodes, counter))
    return n


# ----------------------------------------------------------------------------- Fenster laden

class XmlWindow:
    """Ergebnis von load(): Knoten, Auflösung, Standard-Fokus, Start-/Ende-Befehle."""

    def __init__(self):
        self.path = None
        self.res = '720p'
        self.size = (1280, 720)
        self.scale = 1.0
        self.origin = (0, 0)
        self.roots = []
        self.nodes = []
        self.default_focus = 0
        self.onload = []
        self.onunload = []
        self.defs = None
        self.media = []
        self.visible_cache = {}
        self.by_cid = {}
        self.addon_id = ''


def load(win, xml_name, script_path, skin, res):
    """XML laden und Steuerelemente anlegen. Wirft ValueError mit Klartext, wenn die Datei fehlt/kaputt ist."""
    path, resdir = find_xml(xml_name, script_path, skin, res)
    if path is None:
        raise ValueError('Fensterdatei %s nicht gefunden (gesucht unter %s/resources/skins).' % (xml_name, script_path or '?'))
    try:
        root = ET.parse(str(path)).getroot()
    except (ET.ParseError, OSError) as e:
        raise ValueError('Fensterdatei %s ist ungültig: %s' % (Path(path).name, e))
    if root.tag != 'window':
        raise ValueError('Fensterdatei %s ist kein Kodi-Fenster (<window> fehlt).' % Path(path).name)
    xw = XmlWindow()
    xw.path = path
    xw.addon_id = getattr(context.peek(), 'addon_id', '') or ''
    xw.res = (resdir or res or '720p').lower()
    xw.size = RES_SIZE.get(xw.res, RES_SIZE.get(str(res).lower(), (1280, 720)))
    xw.scale = 1280.0 / xw.size[0]
    xw.defs = SkinDefs(Path(path).parent)
    bud = _Budget()
    clone = _clone(root, xw.defs, {}, 0, bud)
    co = clone.find('coordinates')
    if co is not None:
        def _v(tag):
            try:
                return float((co.findtext(tag) or '0').strip() or 0)
            except ValueError:
                return 0.0
        xw.origin = (_v('posx') or _v('left'), _v('posy') or _v('top'))
    dc = clone.findtext('defaultcontrol')
    try:
        xw.default_focus = int((dc or '0').strip())
    except ValueError:
        xw.default_focus = 0
    xw.onload = [(e.text or '').strip() for e in clone.findall('onload') if (e.text or '').strip()]
    xw.onunload = [(e.text or '').strip() for e in clone.findall('onunload') if (e.text or '').strip()]
    cs = clone.find('controls')
    counter = [0]
    if cs is not None:
        for ch in cs:
            if ch.tag == 'control':
                xw.roots.append(_build(ch, None, xw.nodes, counter))
    _create_controls(win, xw)
    win._xml = xw
    return xw


def _classes():
    from . import xbmcgui as G
    return {
        'label': G.ControlLabel, 'fadelabel': G.ControlFadeLabel, 'textbox': G.ControlTextBox, 'image': G.ControlImage, 'multiimage': G.ControlImage,
        'button': G.ControlButton, 'togglebutton': G.ControlButton, 'radiobutton': G.ControlRadioButton, 'checkmark': G.ControlCheckMark,
        'progress': G.ControlProgress, 'slider': G.ControlSlider, 'sliderex': G.ControlSlider, 'edit': G.ControlEdit,
        'list': G.ControlList, 'fixedlist': G.ControlList, 'wraplist': G.ControlList, 'panel': G.ControlList, 'epggrid': G.ControlList,
        'group': G.ControlGroup, 'grouplist': G.ControlGroupList, 'spincontrol': G.ControlSpin, 'spincontrolex': G.ControlSpin,
    }, G.Control


def _create_controls(win, xw):
    cls, base = _classes()
    used = set()
    syn = [90000]
    for n in xw.nodes:
        c = cls.get(n.type, base)()
        c._spec = n
        n.ctl = c
        cid = n.id
        if not cid or cid in used:
            syn[0] += 1
            cid = syn[0]
        used.add(cid)
        c.id = cid
        n.cid = cid
        xw.by_cid[cid] = n
        c._win = win
        if n.type in ('list', 'fixedlist', 'wraplist', 'panel', 'epggrid'):
            lay = n.props.get('itemlayout') or n.props.get('focusedlayout')
            if lay:
                try:
                    c._item_h = int(float(lay[0].get('height') or 0) * xw.scale)
                    c._item_w = int(float(lay[0].get('width') or 0) * xw.scale)
                except ValueError:
                    pass
        win._controls[cid] = c
        win._order.append(cid)
    for n in xw.nodes:                                      # Navigationsziele (<onup> usw.) -> Steuerelement-Verweise
        for d in ('up', 'down', 'left', 'right'):
            t = n.text('on' + d)
            if t.isdigit() and int(t) in win._controls:
                n.ctl._nav[d] = win._controls[int(t)]
    win._next_cid = max(win._next_cid, syn[0])


# ----------------------------------------------------------------------------- Auswertung (Bedingungen, Texte)

class Scope:
    """Gibt dem Bedingungs-Auswerter (skin.py) den Blick auf dieses Fenster: eigene Eigenschaften, Steuerelemente, Listeneintrag."""

    def __init__(self, win, item=None, list_id=0):
        self.win = win
        self.item = item
        self.list_id = list_id

    def _ctl(self, cid):
        try:
            return self.win._controls.get(int(str(cid).strip()))
        except (TypeError, ValueError):
            return None

    def info(self, raw):
        from . import skin
        s = str(raw or '').strip()
        low = s.lower()
        m = re.match(r'^window(?:\(([^)]*)\))?\.property\((.*)\)$', s, re.I | re.S)
        if m:
            wid = (m.group(1) or '').strip().lower()
            if wid in ('', str(self.win.id), 'current', 'dialog'):
                return skin.win_get(self.win.id, m.group(2).strip('"\''))
            return None
        m = re.match(r'^container\((\d+)\)\.(.+)$', s, re.I)
        if m:
            c = self._ctl(m.group(1))
            rest = m.group(2).lower()
            if c is None:
                return ''
            if rest == 'numitems':
                return str(len(c._items))
            if rest in ('currentitem', 'position'):
                return str((c._sel + 1) if rest == 'currentitem' else c._sel) if c._items else '0'
            mm = re.match(r'^listitem(?:\((-?\d+)\))?\.(.+)$', m.group(2), re.I)
            if mm:
                idx = c._sel + (int(mm.group(1)) if mm.group(1) else 0)
                it = c._items[idx] if 0 <= idx < len(c._items) else None
                return _item_info(it, mm.group(2))
            return ''
        if low.startswith('listitem.') or low.startswith('container.listitem.'):
            return _item_info(self.item, s.split('.', 1)[1] if low.startswith('listitem.') else s.split('.', 2)[2])
        m = re.match(r'^control\.getlabel\((\d+)\)$', low)
        if m:
            c = self._ctl(m.group(1))
            return str(c._label) if c is not None else ''
        return None

    def cond(self, text, name, args):
        if name in ('control.hasfocus', 'control.isvisible', 'control.isenabled'):
            try:
                cid = int(str(args[0]).strip()) if args else 0
            except ValueError:
                return False
            if name == 'control.hasfocus':
                return cid == self.win._focus_id
            if name == 'control.isenabled':
                c = self._ctl(cid)
                return bool(c is not None and c._enabled)
            return node_visible(self.win, cid)
        m = re.match(r'^container\((\d+)\)\.(hasfocus|hasnext|hasprevious|isupdating|onnext|onprevious)(?:\((.*)\))?$', text.strip(), re.I)
        if m:
            c = self._ctl(m.group(1))
            what = m.group(2).lower()
            if what == 'hasfocus':
                return c is not None and c.id == self.win._focus_id
            if c is None:
                return False
            if what == 'hasnext':
                return c._sel < len(c._items) - 1
            if what == 'hasprevious':
                return c._sel > 0
            return False
        if name in ('window.isactive', 'window.isvisible'):
            return True if args and str(args[0]).strip().lower() in (str(self.win.id), 'dialog', 'current') else None
        return None


def _item_info(it, key):
    low = str(key or '').lower()
    if it is None:
        return ''
    try:
        if low == 'label' or low == 'title':
            return str(it.getLabel())
        if low == 'label2':
            return str(it.getLabel2())
        if low in ('icon', 'thumb'):
            return str(it.getArt('icon') or it.getArt('thumb') or it.getArt('poster') or '')
        m = re.match(r'^art\((.+)\)$', key, re.I)
        if m:
            return str(it.getArt(m.group(1).strip('"\'')) or '')
        m = re.match(r'^property\((.+)\)$', key, re.I)
        if m:
            return str(it.getProperty(m.group(1).strip('"\'')) or '')
        if low in ('plot', 'year', 'genre', 'director', 'rating', 'duration', 'tagline'):
            v = it.info.get(low, '')
            return str(v) if v is not None else ''
    except Exception:                                      # noqa: BLE001
        return ''
    return ''


_INFO = re.compile(r'\$(INFO|ESCINFO|LOCALIZE|VAR|ADDON|NUMBER)\[((?:[^\[\]]|\[[^\[\]]*\])*)\]')


def _localized(n, aid=''):
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ''
    if not aid:
        ctx = context.peek()
        aid = getattr(ctx, 'addon_id', '') if ctx is not None else ''
    if aid:
        try:
            from . import xbmcaddon
            s = xbmcaddon.Addon(aid).getLocalizedString(n)
            if s:
                return s
        except Exception:                                  # noqa: BLE001
            pass
    return CORE_STRINGS.get(n, '')


def expand(win, text, item=None):
    """$INFO[…], $LOCALIZE[n], $VAR[name], $ADDON[id n] und reine Zahlen (= Textnummer) in einem Label auflösen."""
    from . import skin
    s = str(text or '')
    if not s:
        return ''
    xw = getattr(win, '_xml', None)
    aid = xw.addon_id if xw is not None else ''
    if s.strip().isdigit():
        return _localized(s.strip(), aid) or s
    if '$' not in s:
        return s

    def one(m):
        kind, arg = m.group(1), m.group(2)
        if kind == 'LOCALIZE':
            return _localized(arg.strip(), aid)
        if kind == 'NUMBER':
            return arg
        if kind == 'ADDON':
            parts = arg.split(None, 1)
            if len(parts) == 2 and parts[1].strip().isdigit():
                try:
                    from . import xbmcaddon
                    return xbmcaddon.Addon(parts[0]).getLocalizedString(int(parts[1])) or ''
                except Exception:                          # noqa: BLE001
                    return ''
            return ''
        if kind == 'VAR':
            for cond, val in (xw.defs.vars.get(arg.strip(), []) if xw is not None and xw.defs else []):
                if not cond or _eval_cond(win, cond, item):
                    return expand(win, val, item)
            return ''
        parts = [x.strip() for x in arg.split(',')]               # INFO[label,Vorsatz,Nachsatz]
        with skin.scoped(Scope(win, item)):
            v = skin.info_label(parts[0])
        if v and len(parts) > 1:
            v = parts[1] + v + (parts[2] if len(parts) > 2 else '')
        return v or ''
    for _ in range(3):
        new = _INFO.sub(one, s)
        if new == s:
            break
        s = new
    return s


def _eval_cond(win, cond, item=None):
    from . import skin
    try:
        with skin.scoped(Scope(win, item)):
            return bool(skin.cond_visible(_brackets(cond)))
    except Exception:                                      # noqa: BLE001
        return False


# ----------------------------------------------------------------------------- Lage und Sichtbarkeit

def _calc(text):
    """Rechenausdruck aus <expression> (nur Zahlen, + - * /, Klammern) -> Zahl oder None."""
    import ast
    import operator
    ops = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv}

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)) and not isinstance(n.value, bool):
            return float(n.value)
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, (ast.USub, ast.UAdd)):
            return -ev(n.operand) if isinstance(n.op, ast.USub) else ev(n.operand)
        if isinstance(n, ast.BinOp) and type(n.op) in ops:
            return ops[type(n.op)](ev(n.left), ev(n.right))
        raise ValueError('nicht erlaubt')
    try:
        return ev(ast.parse(text.strip(), mode='eval'))
    except (SyntaxError, ValueError, ZeroDivisionError, RecursionError):
        return None


def _dim(val, total):
    """Kodi-Maß: 100, 50%, 20r (von rechts/unten), (60+30) -> Zahl (Skin-Einheiten); auto -> None."""
    v = str(val or '').strip().lower()
    if not v or v in ('auto', 'max', 'min'):
        return None
    if re.search(r'[()+*/]|\d\s*-', v) and not v.endswith(('%', 'r')):
        return _calc(v)
    try:
        if v.endswith('%'):
            return float(v[:-1]) * total / 100.0
        if v.endswith('r'):
            return total - float(v[:-1])
        return float(v)
    except ValueError:
        return None


def node_visible(win, cid):
    xw = getattr(win, '_xml', None)
    if xw is None:
        c = win._controls.get(cid)
        return bool(c is not None and c._visible)
    cache = xw.visible_cache
    if cid in cache:
        return cache[cid]
    n = xw.by_cid.get(cid)
    if n is None:
        c = win._controls.get(cid)
        return bool(c is not None and c._visible)
    cache[cid] = True                                      # gegen Kreisbezüge
    v = True
    cur = n
    while cur is not None:
        v = v and _own_visible(win, cur)
        cur = cur.parent
        if not v:
            break
    cache[cid] = v
    return v


def _own_visible(win, n):
    c = n.ctl
    if c is not None and not c._visible:
        return False                                       # setVisible(False) des Programms gilt immer
    conds = n.texts('visible')
    return all(_eval_cond(win, x) for x in conds) if conds else True


def compute(win):
    """-> {cid: (x, y, w, h, sichtbar)} in Bühnen-Koordinaten (1280x720)."""
    xw = win._xml
    xw.visible_cache = {}
    sc = xw.scale
    out = {}
    ox, oy = xw.origin

    def walk(nodes, bx, by, pw, ph, vis, glist=None):
        cursor = 0.0
        for n in nodes:
            own = _own_visible(win, n)
            v = vis and own
            xw.visible_cache[n.cid] = v
            w = _dim(n.text('width'), pw)
            h = _dim(n.text('height'), ph)
            x = _dim(n.text('posx') or n.text('left'), pw)
            y = _dim(n.text('posy') or n.text('top'), ph)
            if x is None and n.text('right'):
                r = _dim(n.text('right'), pw)
                x = pw - (r or 0) - (w or 0) if r is not None else 0
            if y is None and n.text('bottom'):
                b = _dim(n.text('bottom'), ph)
                y = ph - (b or 0) - (h or 0) if b is not None else 0
            if n.text('centerleft') and w is not None:
                x = (_dim(n.text('centerleft'), pw) or 0) - w / 2.0
            if n.text('centertop') and h is not None:
                y = (_dim(n.text('centertop'), ph) or 0) - h / 2.0
            x, y = x or 0.0, y or 0.0
            w = w if w is not None else 0.0
            h = h if h is not None else 0.0
            if glist is not None:                           # Gruppenliste legt die Kinder hintereinander
                vertical, gap = glist
                if not own:
                    out[n.cid] = (0, 0, 0, 0, False)
                    if n.kids:
                        walk(n.kids, 0, 0, w, h, False)
                    continue
                if vertical:
                    y = cursor
                    cursor += h + gap
                else:
                    x = cursor
                    cursor += w + gap
            ax, ay = bx + x, by + y
            out[n.cid] = (int(round(ax * sc)), int(round(ay * sc)), int(round(w * sc)), int(round(h * sc)), v)
            if n.kids:
                gl = None
                if n.type == 'grouplist':
                    gap = _dim(n.text('itemgap'), 0) or 0.0
                    gl = ((n.text('orientation') or 'vertical').lower() != 'horizontal', gap)
                walk(n.kids, ax, ay, w, h, v, gl)

    walk(xw.roots, ox, oy, xw.size[0], xw.size[1], True)
    return out


# ----------------------------------------------------------------------------- Zustand für die Oberfläche

def _align(n):
    a = n.text('align').lower()
    ay = n.text('aligny').lower()
    flags = 0
    if a == 'right':
        flags |= 1
    elif a == 'center':
        flags |= 2
    elif a == 'justify':
        flags |= 16
    if ay == 'center':
        flags |= 4
    return flags


_ASPECT = {'stretch': 0, 'scale': 1, 'keep': 2, 'center': 2}


def resolve_texture(win, name):
    """Texturname -> lokale Datei oder Internetadresse; unbekannte (Skin-eigene) Texturen -> ''."""
    from . import xbmcvfs
    s = str(name or '').strip()
    if not s:
        return ''
    if s.lower().startswith(('http://', 'https://')):
        return s
    if s.startswith('special://'):
        s = xbmcvfs.translatePath(s)
    if os.path.isabs(s):
        return s if os.path.isfile(s) else ''
    xw = getattr(win, '_xml', None)
    if xw is None or xw.path is None:
        return ''
    res_dir = Path(xw.path).parent
    skin_dir = res_dir.parent
    roots = [res_dir / 'media', skin_dir / 'media', skin_dir.parent / 'Default' / 'media', skin_dir.parent.parent / 'media', res_dir.parent.parent.parent / 'media', res_dir]
    for r in roots:
        p = _ci(r / s)
        if p and p.is_file():
            return str(p)
    return ''


def _row(it):
    try:
        icon = it.getArt('icon') or it.getArt('thumb') or it.getArt('poster') or ''
        from . import ui_dialogs
        return [str(it.getLabel()), str(it.getLabel2() or ''), ui_dialogs.file_url(icon) if icon else '']
    except Exception:                                      # noqa: BLE001
        return ['', '', '']


def state(win, c, geom):
    """Zustand eines Steuerelements aus dem XML: Python-Aufrufe (setLabel …) gehen vor, sonst gilt, was im XML steht."""
    n = c._spec
    d = c.__class__._ms_state(c)                            # Grundwerte (Python-seitig gesetzt)
    x, y, w, h, vis = geom.get(c.id, (c._x, c._y, c._w, c._h, True))
    d.update({'x': x, 'y': y, 'w': w, 'h': h, 'vis': bool(vis)})
    ovr = c._ovr
    en = n.texts('enable')
    d['en'] = bool(c._enabled) if 'en' in ovr or not en else all(_eval_cond(win, e) for e in en)
    t = c._TYPE
    labels = n.texts('label') or (n.texts('hinttext') if t == 'edit' else [])
    infos = n.texts('info')
    if t in ('label', 'button', 'radio', 'edit', 'spin', 'fadelabel'):
        if 'label' not in ovr:
            parts = [expand(win, x_) for x_ in labels] + [expand(win, '$INFO[%s]' % i) for i in infos]
            val = ' '.join(p for p in parts if p).strip() if t != 'fadelabel' else (parts[0] if parts else '')
            d['label'] = val
    if 'label2' not in ovr:
        l2 = n.texts('label2')
        if l2:
            d['label2'] = expand(win, l2[0])
    if t == 'textbox' and 'text' not in ovr:
        parts = [expand(win, x_) for x_ in labels] + [expand(win, '$INFO[%s]' % i) for i in infos]
        d['text'] = '\n'.join(p for p in parts if p)
    for tag, key in (('textcolor', 'color'), ('focusedcolor', 'fcolor'), ('disabledcolor', 'dcolor'), ('selectedcolor', 'selcolor')):
        v = n.text(tag)
        if v and key not in d:
            d[key] = _color_name(v)
    f = n.text('font')
    if f and not d.get('font'):
        d['font'] = f
    al = _align(n)
    if al and 'align' not in d:
        d['align'] = al
    if t == 'image':
        if 'img' not in ovr:
            tex = n.texts('texture')
            val = expand(win, tex[0]) if tex else ''
            d['img'] = _url(resolve_texture(win, val))
        asp = _ASPECT.get(n.text('aspectratio').lower())
        if asp is not None and not c._aspect:
            d['aspect'] = asp
        dif = n.attr('texture', 'colordiffuse') or n.text('colordiffuse')
        if dif and 'diffuse' not in d:
            d['diffuse'] = _color_name(dif)
    if t in ('button', 'radio') and not (c._ftex or c._nftex):
        ft = resolve_texture(win, n.text('texturefocus'))
        nf = resolve_texture(win, n.text('texturenofocus'))
        if ft or nf:
            d['ftex'], d['nftex'] = _url(ft), _url(nf)
    if t == 'radio' and 'val' not in ovr:
        sel = n.texts('selected')
        if sel:
            d['on'] = all(_eval_cond(win, s_) for s_ in sel)
    if t == 'list':
        d['rows'] = [_row(it) for it in c._items[:500]]
        if getattr(c, '_item_w', 0):
            d['iw'] = c._item_w
        if n.type == 'panel' or (n.text('orientation').lower() == 'horizontal' and n.type != 'list'):
            d['grid'] = n.type == 'panel'
    if t in ('progress',) and 'val' not in ovr and infos:
        try:
            d['pct'] = max(0.0, min(100.0, float(expand(win, '$INFO[%s]' % infos[0]) or 0)))
        except ValueError:
            pass
    return d


def _url(path):
    from . import ui_dialogs
    return ui_dialogs.file_url(path) if path else ''


def _color_name(v):
    from . import xbmcgui as G
    return G._color(v)


# ----------------------------------------------------------------------------- Befehle aus dem XML (<onclick>, <onload>)

def run_action(win, text):
    """Kodi-Befehl aus dem Skin ausführen; nur, was in MovieScout einen Sinn hat."""
    from . import skin
    s = str(text or '').strip()
    if not s:
        return
    cond = ''
    name, args = skin._name_args(s)
    try:
        if name == 'setfocus' and args:
            win.setFocusId(int(str(args[0]).strip()))
        elif name == 'setproperty' and len(args) >= 2:
            wid = args[2].strip().lower() if len(args) > 2 else ''
            skin.win_set(win.id if wid in ('', str(win.id), 'current') else wid, args[0], expand(win, args[1]))
        elif name == 'clearproperty' and args:
            wid = args[1].strip().lower() if len(args) > 1 else ''
            skin.win_clear(win.id if wid in ('', str(win.id), 'current') else wid, args[0])
        elif name in ('dialog.close', 'closedialog', 'close', 'action'):
            if name == 'action':
                if args and args[0].strip().lower() in ('close', 'back', 'previousmenu', 'parentdir'):
                    win.close()
            else:
                win.close()
        elif name == 'activatewindow' and args and args[0].strip().lower() in ('home', '10000'):
            win.close()
        else:
            skin.builtin(s)
    except Exception:                                      # noqa: BLE001
        _log.debug('Skin-Befehl nicht ausgeführt: %s', s, exc_info=True)


def click_actions(win, c):
    n = getattr(c, '_spec', None)
    if n is None:
        return
    for e in n.props.get('onclick', []):
        cond = e.get('condition')
        if cond and not _eval_cond(win, cond):
            continue
        run_action(win, e.text or '')


# ----------------------------------------------------------------------------- Fokus bewegen

_DIRS = {1: 'left', 2: 'right', 3: 'up', 4: 'down'}


def _focusable(win, geom):
    out = []
    for cid in win._order:
        c = win._controls.get(cid)
        if c is None or c._TYPE not in FOCUSABLE:
            continue
        g = geom.get(cid)
        if g is None or not g[4] or not c._enabled:
            continue
        en = c._spec.texts('enable') if getattr(c, '_spec', None) is not None else []
        if en and 'en' not in c._ovr and not all(_eval_cond(win, e) for e in en):
            continue
        out.append((cid, g))
    return out


def default_focus(win):
    xw = win._xml
    geom = compute(win)
    cand = _focusable(win, geom)
    ids = [cid for cid, _g in cand]
    if xw.default_focus and xw.default_focus in ids:
        return xw.default_focus
    return ids[0] if ids else 0


def move_focus(win, aid):
    """Pfeiltaste im XML-Fenster: Liste blättern, dann Navigationsziel aus dem XML, sonst nächstes Steuerelement in dieser Richtung."""
    d = _DIRS.get(aid)
    if d is None:
        return False
    cur = win._controls.get(win._focus_id)
    geom = compute(win)
    cand = {cid: g for cid, g in _focusable(win, geom)}
    if cur is not None and cur._TYPE == 'list' and cur._items:
        n = cur._spec
        horizontal = n is not None and n.text('orientation').lower() == 'horizontal' and n.type != 'panel'
        cols = 1
        if n is not None and n.type == 'panel' and getattr(cur, '_item_w', 0) and cur._item_w > 0 and cand.get(cur.id):
            cols = max(1, int(cand[cur.id][2] // cur._item_w))
        step = {'up': -cols, 'down': cols, 'left': -1, 'right': 1}[d]
        if horizontal and d in ('left', 'right') or not horizontal and (d in ('up', 'down') or (cols > 1 and d in ('left', 'right'))):
            if cols == 1 and not horizontal:
                step = {'up': -1, 'down': 1}[d]
            nxt = cur._sel + step
            if 0 <= nxt < len(cur._items):
                cur.selectItem(nxt)
                return True
            wrap = n is not None and (n.type == 'wraplist' or n.text('wrap').lower() == 'true')
            if wrap:
                cur.selectItem(0 if nxt >= len(cur._items) else len(cur._items) - 1)
                return True
    tgt = cur._nav.get(d) if cur is not None else None
    if tgt is not None and getattr(tgt, 'id', 0) in cand:
        win.setFocusId(tgt.id)
        win.onFocus(tgt.id)
        return True
    if cur is None or cur.id not in cand:
        if cand:
            first = next(iter(cand))
            win.setFocusId(first)
            win.onFocus(first)
            return True
        return False
    x, y, w, h, _v = cand[cur.id]
    cx, cy = x + w / 2.0, y + h / 2.0
    best, best_s = None, None
    for cid, (gx, gy, gw, gh, _vv) in cand.items():
        if cid == cur.id:
            continue
        mx, my = gx + gw / 2.0, gy + gh / 2.0
        dx, dy = mx - cx, my - cy
        if d == 'down' and dy <= 1 or d == 'up' and dy >= -1 or d == 'right' and dx <= 1 or d == 'left' and dx >= -1:
            continue
        main, cross = (abs(dy), abs(dx)) if d in ('up', 'down') else (abs(dx), abs(dy))
        s = main + 2.0 * cross
        if best_s is None or s < best_s:
            best, best_s = cid, s
    if best is None:
        return False
    win.setFocusId(best)
    win.onFocus(best)
    return True
