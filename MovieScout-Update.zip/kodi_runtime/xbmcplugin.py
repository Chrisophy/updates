# -*- coding: utf-8 -*-
"""Kodi xbmcplugin-Modul (Emulation).

Einträge, die ein Scraper per addDirectoryItem registriert, werden im
Request-Kontext gesammelt und von der Engine in JSON-Items umgewandelt.
"""
from urllib.parse import urlparse, parse_qsl

from . import context

SORT_METHOD_NONE = 0
SORT_METHOD_LABEL = 1
SORT_METHOD_LABEL_IGNORE_THE = 2
SORT_METHOD_DATE = 3
SORT_METHOD_SIZE = 4
SORT_METHOD_FILE = 5
SORT_METHOD_TITLE = 9
SORT_METHOD_TITLE_IGNORE_THE = 10
SORT_METHOD_VIDEO_YEAR = 18
SORT_METHOD_VIDEO_RATING = 19
SORT_METHOD_VIDEO_TITLE = 20
SORT_METHOD_VIDEO_RUNTIME = 21
SORT_METHOD_UNSORTED = 40
SORT_METHOD_DRIVE_TYPE = 100
SORT_METHOD_TRACKNUM = 101
SORT_METHOD_DURATION = 102
SORT_METHOD_ARTIST = 103
SORT_METHOD_ARTIST_IGNORE_THE = 104
SORT_METHOD_ALBUM = 105
SORT_METHOD_ALBUM_IGNORE_THE = 106
SORT_METHOD_GENRE = 107
SORT_METHOD_COUNTRY = 108
SORT_METHOD_DATEADDED = 109
SORT_METHOD_VIDEO_USER_RATING = 110
SORT_METHOD_VIDEO_SORT_TITLE = 111
SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE = 112
SORT_METHOD_PRODUCTIONCODE = 113
SORT_METHOD_SONG_RATING = 114
SORT_METHOD_SONG_USER_RATING = 115
SORT_METHOD_MPAA_RATING = 116
SORT_METHOD_PROGRAM_COUNT = 117
SORT_METHOD_PLAYLIST_ORDER = 118
SORT_METHOD_EPISODE = 119
SORT_METHOD_BITRATE = 120
SORT_METHOD_LISTENERS = 121
SORT_METHOD_PLAYCOUNT = 122
SORT_METHOD_LASTPLAYED = 123
SORT_METHOD_CHANNEL = 124
SORT_METHOD_DATE_TAKEN = 125
SORT_METHOD_FULLPATH = 126
SORT_METHOD_LABEL_IGNORE_FOLDERS = 127
SORT_METHOD_CLIENT_PROVIDED = 128


def _art(li):
    art = dict(getattr(li, 'art', {}) or {})
    # alte Scraper legen Art teils in properties['art'] ab
    p_art = (getattr(li, 'properties', {}) or {}).get('art')
    if isinstance(p_art, dict):
        art.update(p_art)
    return art


def listitem_to_item(url, li, is_folder):
    info = dict(getattr(li, 'info', {}) or {})
    art = _art(li)
    item = {
        'title': getattr(li, 'getLabel', lambda: '')() or info.get('title') or 'Unbekannt',
        'url': url,
        'is_playable': not is_folder,
        'poster': art.get('poster') or art.get('thumb') or art.get('icon') or '',
        'icon': art.get('icon') or art.get('thumb') or '',
        'fanart': art.get('fanart') or '',
        'plot': info.get('plot') or info.get('plotoutline') or '',
        'year': info.get('year') or '',
        'mediatype': info.get('mediatype') or '',
        'rating': info.get('rating') or '',
        'duration': info.get('duration') or '',
    }
    # plugin://...?url=..&next_func=..  ->  Felder übernehmen
    if isinstance(url, str) and (url.startswith('plugin://') or '?' in url and 'next_func=' in url):
        q = dict(parse_qsl(urlparse(url).query, keep_blank_values=True))
        if 'url' in q:
            item['url'] = q.pop('url')
        for k in ('next_func', 'season', 'episode', 'imdb', 'tmdb', 'year'):
            if k in q and q[k] != '':
                item[k] = q.pop(k)
        if q:
            item['params'] = q
    return item


def addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=0):
    ctx = context.current()
    item = listitem_to_item(url, listitem, isFolder)
    if getattr(ctx, 'addon_id', ''):                       # läuft ein installiertes Kodi-Addon: plugin://-Adresse unverändert behalten
        from engine import addonhost
        item['url'] = str(url)
        item = addonhost.decorate(item, ctx.addon_id)
    if item is not None:
        ctx.items.append(item)
    return True


def addDirectoryItems(handle, items, totalItems=0):
    for entry in items or []:
        try:
            url, li, is_folder = entry[0], entry[1], entry[2] if len(entry) > 2 else False
        except Exception:
            continue
        addDirectoryItem(handle, url, li, is_folder)
    return True


def endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=True):
    pass


def setContent(handle, content):
    pass


def setPluginCategory(handle, category):
    pass


def setPluginFanart(handle, image=None, color1=None, color2=None, color3=None):
    pass


def addSortMethod(handle, sortMethod, label2Mask=''):
    pass


def setProperty(handle, key, value):
    pass


def setResolvedUrl(handle, succeeded, listitem):
    if succeeded and listitem is not None:
        context.current().resolved.append({'path': getattr(listitem, 'getPath', lambda: '')(),
                                           'listitem': listitem})
        from . import xbmc as _xb
        _xb._playback_started(context.current())


def getSetting(handle, settingID):
    from . import xbmcaddon
    return xbmcaddon.Addon().getSetting(settingID)


def setSetting(handle, settingID, value):
    from . import xbmcaddon
    xbmcaddon.Addon().setSetting(settingID, value)


def get_and_clear_items():
    """Abwärtskompatibel zu main.py v1."""
    ctx = context.current()
    items, ctx.items = list(ctx.items), []
    return items
