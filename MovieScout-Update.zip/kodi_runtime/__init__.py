# -*- coding: utf-8 -*-
"""Emuliert die Kodi-Python-API (xbmc, xbmcgui, xbmcaddon, xbmcplugin, xbmcvfs).

`import kodi_runtime` registriert die Module in sys.modules, sodass die Scraper
unverändert `import xbmc` usw. benutzen können.
"""
import sys

import os as _os

# Umgebungsvariablen: MOVIESCOUT_* (neu) gelten auch unter dem alten Namen MINIKODI_*.
for _k, _v in list(_os.environ.items()):
    if _k.startswith('MOVIESCOUT_'):
        _os.environ.setdefault('MINIKODI_' + _k[len('MOVIESCOUT_'):], _v)

from . import context, paths  # noqa: F401
from . import inputstreamhelper, skin, xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

for _name, _mod in (('xbmc', xbmc), ('xbmcgui', xbmcgui), ('xbmcaddon', xbmcaddon),
                    ('xbmcvfs', xbmcvfs), ('xbmcplugin', xbmcplugin), ('inputstreamhelper', inputstreamhelper)):
    sys.modules[_name] = _mod
