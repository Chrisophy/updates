# -*- coding: utf-8 -*-
"""Kodi xbmcvfs-Modul (Emulation) auf Basis des lokalen Dateisystems."""
import os
import re
import shutil
from pathlib import Path

from . import paths


def _stub_databases():
    """Kodi-Datenbanken (special://database/), die manche Addons per sqlite lesen (MyVideos*.db, Addons*.db). Leer, aber mit den üblichen Tabellen."""
    import sqlite3
    d = paths.DATA_DIR / 'database'
    try:
        d.mkdir(parents=True, exist_ok=True)
        for name, sql in (('MyVideos131.db', ('CREATE TABLE IF NOT EXISTS files (idFile INTEGER PRIMARY KEY, idPath INTEGER, strFilename TEXT, playCount INTEGER, lastPlayed TEXT, dateAdded TEXT)',
                                              'CREATE TABLE IF NOT EXISTS bookmark (idBookmark INTEGER PRIMARY KEY, idFile INTEGER, timeInSeconds REAL, totalTimeInSeconds REAL, thumbNailImage TEXT, player TEXT, playerState TEXT, type INTEGER)')),
                          ('Addons33.db', ('CREATE TABLE IF NOT EXISTS installed (id INTEGER PRIMARY KEY, addonID TEXT UNIQUE, enabled BOOLEAN, installDate TEXT, lastUpdated TEXT, lastUsed TEXT, origin TEXT DEFAULT "")',)),
                          ('Textures13.db', ())):
            f = d / name
            if f.exists():
                continue
            con = sqlite3.connect(str(f))
            for q in sql:
                con.execute(q)
            con.commit(); con.close()
    except Exception:                                      # noqa: BLE001
        pass


def translatePath(path):
    p = str(path)
    if p.startswith('special://profile/addon_data/'):
        target = paths.DATA_DIR / p[len('special://profile/addon_data/'):]
    elif p.startswith('special://home/addons/') or p.startswith('special://xbmc/addons/'):
        target = paths.DATA_DIR / 'addons' / p.split('/addons/', 1)[1]
    elif p.startswith('special://profile/') or p.startswith('special://userdata/'):
        target = paths.DATA_DIR / p.split('/', 3)[-1] if p.count('/') >= 3 else paths.DATA_DIR
    elif p.startswith('special://database'):
        _stub_databases()
        target = paths.DATA_DIR / 'database' / p[len('special://database'):].lstrip('/')
    elif p.startswith('special://masterprofile'):
        target = paths.DATA_DIR / p[len('special://masterprofile'):].lstrip('/')
    elif re.match(r'special://(logpath|cache|subtitles|thumbnails|recordings|screenshots|videoplaylists|musicplaylists|skin)\b', p):
        name, _, rest = p[len('special://'):].partition('/')
        target = paths.DATA_DIR / name / rest
    elif p.startswith('special://temp'):
        target = paths.DATA_DIR / 'temp' / p[len('special://temp'):].lstrip('/')
    elif p.startswith('special://home') or p.startswith('special://xbmc'):
        target = paths.ROOT / p.split('/', 3)[-1] if p.count('/') >= 3 else paths.ROOT
    else:
        return p
    target = Path(target)
    # Verzeichnisartige Pfade (ohne Dateiendung) sofort anlegen, wie es Kodi tut
    try:
        if p.endswith('/') or not target.suffix:
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return str(target) + (os.sep if p.endswith('/') else '')


def mkdirs(path):
    try:
        os.makedirs(translatePath(path), exist_ok=True)
        return True
    except OSError:
        return False


def mkdir(path):
    try:
        os.mkdir(translatePath(path))
        return True
    except OSError:
        return False


def exists(path):
    return os.path.exists(translatePath(path))


def delete(path):
    try:
        os.remove(translatePath(path))
        return True
    except OSError:
        return False


def rmdir(path, force=False):
    try:
        if force:
            shutil.rmtree(translatePath(path))
        else:
            os.rmdir(translatePath(path))
        return True
    except OSError:
        return False


def copy(src, dst):
    try:
        shutil.copyfile(translatePath(src), translatePath(dst))
        return True
    except OSError:
        return False


def rename(src, dst):
    try:
        os.replace(translatePath(src), translatePath(dst))
        return True
    except OSError:
        return False


def listdir(path):
    p = translatePath(path)
    dirs, files = [], []
    try:
        for e in os.scandir(p):
            (dirs if e.is_dir() else files).append(e.name)
    except OSError:
        pass
    return dirs, files


class Stat:
    def __init__(self, path):
        self._st = os.stat(translatePath(path))

    def st_size(self):
        return self._st.st_size

    def st_mtime(self):
        return self._st.st_mtime


class File:
    def __init__(self, filepath, mode='r'):
        self._mode = mode
        self._f = open(translatePath(filepath), mode + ('' if 'b' in mode else ''),
                       **({} if 'b' in mode else {'encoding': 'utf-8'}))

    def read(self, numBytes=0):
        return self._f.read(numBytes) if numBytes else self._f.read()

    def readBytes(self, numBytes=0):
        data = self._f.read(numBytes) if numBytes else self._f.read()
        return bytearray(data if isinstance(data, bytes) else data.encode('utf-8'))

    def write(self, data):
        if 'b' in self._mode and isinstance(data, str):
            data = data.encode('utf-8')
        self._f.write(data)
        return True

    def size(self):
        return os.fstat(self._f.fileno()).st_size

    def seek(self, offset, whence=0):
        return self._f.seek(offset, whence)

    def close(self):
        self._f.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
