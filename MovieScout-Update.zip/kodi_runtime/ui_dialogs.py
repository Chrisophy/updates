# -*- coding: utf-8 -*-
"""Rückfragen von Kodi-Addons (Ja/Nein, Auswahl, Eingabe, Hinweis) an die Web-Oberfläche.

Läuft ein Addon-Aufruf mit einer Abfrage-ID (rid), blockiert Dialog().yesno() & Co. den Addon-Thread, bis die
Oberfläche geantwortet hat (GET /api/dialog holt die offene Frage, POST /api/dialog bringt die Antwort).
Ohne rid (Suche, Hintergrundjobs, Tests) bleibt es bei den Standardantworten - nichts blockiert."""
import threading
import time
import uuid
import contextvars

RID = contextvars.ContextVar('ms_rid', default='')
_S = {}
_L = threading.Lock()
_CANCEL = object()
import os
GONE_AFTER = float(os.environ.get('MOVIESCOUT_DIALOG_GONE') or 25)          # Sekunden ohne Abruf durch die Oberfläche -> Frage verfällt (Standardantwort)
MAX_WAIT = 600


def _sess(rid):
    with _L:
        s = _S.get(rid)
        if s is None:
            if len(_S) > 200:
                for k in [k for k, v in _S.items() if time.time() - v['seen'] > 300][:100]:
                    _S.pop(k, None)
            s = _S[rid] = {'cur': None, 'evt': threading.Event(), 'ans': None, 'seen': time.time(), 'progress': None}
        return s


def active():
    from . import context
    return bool(getattr(context.current(), 'rid', ''))


def ask(kind, default=None, **spec):
    """Frage stellen und auf die Antwort warten; ohne Oberfläche: default."""
    from . import context
    ctx = context.current()
    rid = getattr(ctx, 'rid', '')
    if not rid:
        return default
    s = _sess(rid)
    spec = dict(spec, kind=kind, id=uuid.uuid4().hex[:10], addon=getattr(ctx, 'addon_id', '') or '')
    s['evt'].clear()
    s['ans'] = _CANCEL
    s['seen'] = time.time()
    s['cur'] = spec
    t0 = time.time()
    marks = context.begin_wait(ctx)
    try:
        while True:
            if s['evt'].wait(0.25):
                break
            if ctx.cancelled.is_set() or time.time() - s['seen'] > GONE_AFTER or time.time() - t0 > MAX_WAIT:
                s['ans'] = _CANCEL
                break
    finally:
        s['cur'] = None
        context.end_wait(marks)
    return default if s['ans'] is _CANCEL else s['ans']


def poll(rid, wait=20, wid=None, wv=-1):
    """Offene Frage (oder Fortschritt) für die Oberfläche; wartet bis zu `wait` Sekunden.
    Mit wid/wv (die Oberfläche kann eigene Kodi-Fenster zeigen): kommt auch zurück, sobald sich das oberste Fenster geändert hat, und
    liefert dann dessen Stand (nur die geänderten Steuerelemente seit Version wv)."""
    s = _sess(rid)
    end = time.time() + wait
    want_win = wid is not None

    def winfo():
        top = s['wins'][-1] if s.get('wins') else None
        if top is None:
            return None
        return top.snapshot(wv if top.wid == wid else -1)

    def changed():
        top = s['wins'][-1] if s.get('wins') else None
        if top is None:
            return bool(wid)
        return top.wid != wid or top.version() > wv

    while True:
        s['seen'] = time.time()
        if s['cur']:
            out = {'dialog': s['cur'], 'progress': s['progress']}
            if want_win:
                out['window'] = winfo()
            return out
        if want_win and changed():
            time.sleep(0.03)                                     # mehrere Änderungen kurz nacheinander (Spielfeld + Punkte) zusammenfassen
            return {'dialog': None, 'progress': s['progress'], 'window': winfo()}
        if time.time() >= end or s.get('done'):
            out = {'dialog': None, 'progress': s['progress'], 'done': bool(s.get('done'))}
            if want_win:
                out['window'] = winfo()
            return out
        time.sleep(0.05 if want_win and s.get('wins') else 0.15)


def answer(rid, did, value, cancel=False):
    s = _sess(rid)
    cur = s['cur']
    if not cur or cur['id'] != did:
        return False
    s['ans'] = _CANCEL if cancel else value
    s['cur'] = None                  # sofort frei, damit der nächste Abruf nicht dieselbe Frage noch einmal bekommt
    s['evt'].set()
    return True


def set_progress(rid, st):
    if rid:
        _sess(rid)['progress'] = st if st and st.get('open') else None


# ----------------------------------------------------------------------------- Eigene Kodi-Fenster (xbmcgui.Window/WindowDialog mit addControl)

class WinHandle:
    """Verbindung eines offenen Addon-Fensters zur Oberfläche: Ereignis-Warteschlange und Zustand (über das Fensterobjekt)."""

    def __init__(self, win, rid):
        import queue
        self.win = win
        self.rid = rid
        self.wid = uuid.uuid4().hex[:10]
        self.q = queue.Queue()

    def version(self):
        return self.win._ms_version()

    def snapshot(self, since=-1):
        st = self.win._ms_snapshot(since)
        st['id'] = self.wid
        return st


def window_open(win):
    """Fenster anmelden (ohne Oberfläche: None)."""
    from . import context
    rid = getattr(context.current(), 'rid', '')
    if not rid:
        return None
    try:
        context.current().window_shown = True
    except Exception:                                       # noqa: BLE001
        pass
    s = _sess(rid)
    hd = WinHandle(win, rid)
    with _L:
        s.setdefault('wins', []).append(hd)
    s['seen'] = time.time()
    return hd


def window_close(hd):
    if hd is None:
        return
    s = _S.get(hd.rid)
    if s:
        with _L:
            if hd in s.get('wins', []):
                s['wins'].remove(hd)


def window_gone(hd):
    """Oberfläche fragt nicht mehr nach (App zu, Seite gewechselt) oder Aufruf beendet."""
    s = _S.get(hd.rid)
    return s is None or s.get('done') or time.time() - s['seen'] > GONE_AFTER


def window_event(rid, wid, ev):
    s = _S.get(rid)
    if not s or not isinstance(ev, dict):
        return False
    for hd in list(s.get('wins', [])):
        if hd.wid == wid:
            s['seen'] = time.time()
            hd.q.put(ev)
            return True
    return False


def close_windows(rid):
    s = _S.get(rid)
    for hd in list((s or {}).get('wins', [])):
        try:
            hd.win.close()
        except Exception:                                    # noqa: BLE001
            pass
        window_close(hd)


RUN_YIELD = None          # vom Addon-Host gesetzt: gibt die Sperre für Addon-Läufe frei, solange ein Fenster offen ist


def run_yield():
    """Solange ein Addon-Fenster auf den Nutzer wartet (Spiel läuft), dürfen andere Addons (Quellen, Trailer) weiterlaufen."""
    import contextlib
    f = RUN_YIELD
    return f() if f else contextlib.nullcontext()


_FILES = {}


def file_url(path):
    """Bild eines Fensters (lokale Datei) -> Adresse der Engine. http(s) bleibt, wie es ist."""
    import hashlib
    p = str(path or '').strip()
    if not p:
        return ''
    if p.lower().startswith(('http://', 'https://')):
        return p
    if p.startswith('special://'):
        from . import xbmcvfs
        p = xbmcvfs.translatePath(p)
    if not os.path.isfile(p):
        return ''
    tok = hashlib.sha1(p.encode('utf-8', 'replace')).hexdigest()[:16]
    if len(_FILES) > 500:
        _FILES.clear()
    _FILES[tok] = p
    try:
        mt = int(os.path.getmtime(p))
    except OSError:
        mt = 0
    return '/api/dialog/file/%s?v=%d' % (tok, mt)


def file_path(tok):
    return _FILES.get(tok)


def end(rid):
    if rid:
        with _L:
            s = _S.pop(rid, None)
        if s:
            s['done'] = True
            s['evt'].set()
