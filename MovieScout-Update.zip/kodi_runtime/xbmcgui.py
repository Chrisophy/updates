# -*- coding: utf-8 -*-
"""Kodi xbmcgui-Modul (Emulation). Dialoge werden in Log/Hinweise der UI umgeleitet."""
import logging
import threading

from . import context
from . import ui_dialogs

_log = logging.getLogger('kodi.gui')

NOTIFICATION_INFO = 'info'
NOTIFICATION_WARNING = 'warning'
NOTIFICATION_ERROR = 'error'

INPUT_ALPHANUM = 0
INPUT_NUMERIC = 1
INPUT_DATE = 2
INPUT_TIME = 3
INPUT_IPADDRESS = 4
INPUT_PASSWORD = 5

ALPHANUM_HIDE_INPUT = 2
ICON_OVERLAY_NONE = 0

_window_props = {}
_window_lock = threading.Lock()


def _label(x):
    try:
        return str(x.getLabel())
    except Exception:                                      # noqa: BLE001
        return str(x)


def _msg(message, rest):
    return '\n'.join(str(x) for x in (message,) + tuple(r for r in rest if isinstance(r, str)) if x)


class Dialog:
    def notification(self, heading, message, icon='', time=3000, sound=True):
        _log.info('[NOTIFICATION] %s: %s', heading, message)
        context.current().note(icon if icon in ('info', 'warning', 'error') else 'info',
                               str(heading), str(message))

    def input(self, heading, defaultt='', type=INPUT_ALPHANUM, option=0, autoclose=0, **kw):
        # Suche: Die Web-Oberfläche reicht den Suchbegriff als ?q= mit. Sonst wird der Nutzer gefragt (falls möglich).
        q = context.current().query
        if q:
            return q
        dflt = defaultt or kw.get('default', '') or ''
        r = ui_dialogs.ask('input', dflt, heading=str(heading or ''), value=str(dflt), hidden=(type == INPUT_PASSWORD or option == ALPHANUM_HIDE_INPUT),
                           numeric=(type == INPUT_NUMERIC))
        return dflt if r is None else str(r)

    def ok(self, heading, message='', *a, **k):
        _log.info('[DIALOG OK] %s: %s', heading, message)
        if ui_dialogs.active():
            ui_dialogs.ask('ok', True, heading=str(heading or ''), message=_msg(message, a))
        else:
            context.current().note('info', str(heading), str(message))
        return True

    def yesno(self, heading, message='', *a, **k):
        labels = [x for x in a if isinstance(x, str)]
        no = k.get('nolabel') or (labels[0] if len(labels) > 0 else '')
        yes = k.get('yeslabel') or (labels[1] if len(labels) > 1 else '')
        return bool(ui_dialogs.ask('yesno', False, heading=str(heading or ''), message=str(message or ''), no=str(no or ''), yes=str(yes or '')))

    def yesnocustom(self, heading, message='', customlabel='', *a, **k):
        labels = [x for x in a if isinstance(x, str)]
        no = k.get('nolabel') or (labels[0] if len(labels) > 0 else '')
        yes = k.get('yeslabel') or (labels[1] if len(labels) > 1 else '')
        r = ui_dialogs.ask('yesnocustom', -1, heading=str(heading or ''), message=str(message or ''), custom=str(customlabel or ''), no=str(no or ''), yes=str(yes or ''))
        return r if isinstance(r, int) else -1

    def select(self, heading, list, *a, **k):
        if not list:
            return -1
        r = ui_dialogs.ask('select', 0, heading=str(heading or ''), options=[_label(x) for x in list])
        return r if isinstance(r, int) else 0

    def multiselect(self, heading, options, *a, **k):
        r = ui_dialogs.ask('multiselect', [], heading=str(heading or ''), options=[_label(x) for x in options or []])
        return [int(i) for i in r] if isinstance(r, (list, tuple)) else []

    def textviewer(self, heading, text, *a, **k):
        ui_dialogs.ask('text', None, heading=str(heading or ''), message=str(text or ''))

    def browse(self, type=0, heading='', shares='', mask='', useThumbs=False, treatAsFolder=False, defaultt='', *a, **k):
        # Dateimanager gibt es hier nicht: Pfad (auf dem Gerät der Engine) von Hand eingeben
        r = ui_dialogs.ask('input', defaultt or '', heading=str(heading or 'Pfad'), value=str(defaultt or ''), hidden=False, numeric=False,
                           hint='Pfad auf dem Gerät, auf dem die Engine läuft')
        return defaultt or '' if r is None else str(r)

    def numeric(self, type=0, heading='', defaultt='', *a, **k):
        r = ui_dialogs.ask('input', defaultt or '', heading=str(heading or ''), value=str(defaultt or ''), hidden=False, numeric=True)
        return defaultt or '' if r is None else str(r)

    def contextmenu(self, list, *a, **k):
        r = ui_dialogs.ask('select', -1, heading='', options=[_label(x) for x in list or []])
        return r if isinstance(r, int) else -1

    def colorpicker(self, *a, **k):
        return ''

    def info(self, *a, **k):
        return False


def _report(state, heading, message, percent, is_open):
    state['heading'], state['message'], state['percent'], state['open'] = heading, message, percent, is_open
    try:
        ctx = context.current()
        ctx.progress = dict(state)
        ui_dialogs.set_progress(getattr(ctx, 'rid', ''), ctx.progress)
    except Exception:                                      # noqa: BLE001
        pass
    _log.debug('[PROGRESS] %s%% %s: %s', percent, heading, message)


class DialogProgressBG:
    """Fortschritt im Hintergrund. Die Engine zeigt nichts an, merkt sich aber den Stand (context.progress) und
    hält die Aufrufreihenfolge wie Kodi ein (isFinished() ist erst nach create() False, nach close() True)."""

    def __init__(self):
        self._st = {'heading': '', 'message': '', 'percent': 0, 'open': False}

    def create(self, heading, message=''):
        _report(self._st, str(heading or ''), str(message or ''), 0, True)

    def update(self, percent=0, heading=None, message=None):
        st = self._st
        _report(st, st['heading'] if heading in (None, '') else str(heading),
                st['message'] if message in (None, '') else str(message), max(0, min(100, int(percent or 0))), True)

    def close(self):
        _report(self._st, self._st['heading'], self._st['message'], self._st['percent'], False)

    def isFinished(self):
        return not self._st['open']


class DialogProgress(DialogProgressBG):
    """Fortschrittsdialog mit Abbrechen. Kodi 18: create(heading, line1, line2, line3) / update(percent, line1, …);
    Kodi 19+: create(heading, message) / update(percent, message). Beides geht. iscanceled() wird True, sobald die
    Engine den Aufruf abbricht (Zeitüberschreitung) - Schleifen mit `while not dp.iscanceled()` enden dann von selbst."""

    @staticmethod
    def _join(*lines):
        return '\n'.join(str(x) for x in lines if x not in (None, ''))

    def create(self, heading, line1='', line2='', line3='', message=''):
        _report(self._st, str(heading or ''), self._join(message or line1, line2, line3), 0, True)

    def update(self, percent=0, line1=None, line2=None, line3=None, message=None):
        text = self._join(message if message not in (None, '') else line1, line2, line3)
        st = self._st
        _report(st, st['heading'], text if text else st['message'], max(0, min(100, int(percent or 0))), True)

    def iscanceled(self):
        try:
            return context.current().cancelled.is_set()
        except Exception:                                  # noqa: BLE001
            return False


class DialogBusy:
    def create(self):
        pass

    def close(self):
        pass

    def isFinished(self):
        return True


class ListItem:
    """Datencontainer für Verzeichnis-/Abspiel-Einträge."""

    def __init__(self, label='', label2='', path='', offscreen=False, **kw):
        self._label = label
        self._label2 = label2
        self._path = path
        self.properties = {}
        self.info = {}
        self.art = {}
        self.stream_info = []
        self.is_folder = False
        self.subtitles = []
        self.mime = ''
        self.ctx_menu = []

    # -- Getter / Setter
    def getLabel(self):
        return self._label

    def setLabel(self, label):
        self._label = label

    def getLabel2(self):
        return self._label2

    def setLabel2(self, label):
        self._label2 = label

    def getPath(self):
        return self._path

    def setPath(self, path):
        self._path = path

    def setInfo(self, type, infoLabels):
        if isinstance(infoLabels, dict):
            self.info.update(infoLabels)

    def setArt(self, art):
        if isinstance(art, dict):
            self.art.update(art)

    def getArt(self, key):
        return self.art.get(key, '')

    def setProperty(self, key, value):
        self.properties[str(key)] = value

    def getProperty(self, key):
        return self.properties.get(str(key), '')

    def setProperties(self, values):
        for k, v in (values or {}).items():
            self.setProperty(k, v)

    def setContentLookup(self, enable):
        pass

    def setMimeType(self, mime):
        self.mime = mime

    def getMimeType(self):
        return self.mime

    def setIsFolder(self, v):
        self.is_folder = bool(v)

    def setSubtitles(self, subs):
        self.subtitles = list(subs or [])

    def addStreamInfo(self, cType, dictionary):
        self.stream_info.append((cType, dictionary))

    def addContextMenuItems(self, items, replaceItems=False):
        self.ctx_menu = list(items or [])

    def setUniqueIDs(self, ids, default=''):
        self.info.update({'uniqueids': ids})

    def setRating(self, *a, **k):
        pass

    def select(self, selected):
        pass

    def getVideoInfoTag(self):
        return _InfoTag(self)

    def setDateTime(self, s):
        pass

    def setCast(self, c):
        pass


class _InfoTag:
    """Kompatibler Ersatz für InfoTagVideo-Setter (liest/schreibt in ListItem.info)."""

    def __init__(self, li):
        self._li = li

    def __getattr__(self, name):
        if name.startswith('set'):
            key = name[3:].lower()

            def _setter(value=None, *a, **k):
                self._li.info[key] = value
            return _setter
        if name.startswith('add'):                         # addVideoStream, addAudioStream, addSubtitleStream, addAvailableArtwork …
            return lambda *a, **k: None
        if name.startswith('get'):
            key = name[3:].lower()
            return lambda *a, **k: self._li.info.get(key, '')
        raise AttributeError(name)


# ----------------------------------------------------------------------------- Fenster und Steuerelemente
# Kodi-Fenster, die ein Addon selbst zusammenbaut (xbmcgui.Window/WindowDialog + addControl: Spiele, kleine Programme), zeigt die
# Web-Oberfläche nach: Die Engine hält den Zustand (Position, Text, Bild, Sichtbarkeit, Fokus), die Oberfläche zeichnet ihn auf einer
# 1280x720-Bühne (Kodis Koordinaten für Python-Fenster) und schickt Tasten/Klicks zurück -> onAction/onControl wie in Kodi.
# Fenster aus Skin-XML (WindowXML/WindowXMLDialog) gibt es weiterhin nicht.

_FOCUSABLE = ('button', 'radio', 'list', 'edit', 'slider', 'spin')


class Window:
    """Window(10000) / Window('home') wird von Scrapern als Property-Speicher genutzt (getrennt je Fenster-ID,
    gleiche Werte wie Window(Home).Property(x) in Infolabels/Bedingungen). Mit addControl + doModal/show ist es ein echtes Fenster."""

    def __init__(self, existingWindowId=10000):
        self.id = existingWindowId
        self._controls = {}
        self._order = []
        self._next_cid = 3000
        self._focus_id = 0
        self._wver = 0
        self._sver = 0
        self._wlock = threading.RLock()
        self._closed = threading.Event()
        self._hd = None

    def _ms_init(self):                                     # Unterklassen, die __init__ nicht aufrufen
        if '_wlock' not in self.__dict__:
            Window.__init__(self, getattr(self, 'id', 10000))

    # -- Eigenschaften (wie bisher)
    def getProperty(self, key):
        from . import skin
        return skin.win_get(self.id, key)

    def setProperty(self, key, value):
        from . import skin
        skin.win_set(self.id, key, value)

    def clearProperty(self, key):
        from . import skin
        skin.win_clear(self.id, key)

    def clearProperties(self):
        from . import skin
        skin.win_clear(self.id)

    # -- Zustand für die Oberfläche
    def _ms_bump(self, ctl=None, struct=False):
        self._ms_init()
        with self._wlock:
            self._wver += 1
            if ctl is not None:
                ctl._ver = self._wver
            if struct:
                self._sver = self._wver

    def _ms_version(self):
        self._ms_init()
        return self._wver

    def _ms_snapshot(self, since=-1):
        self._ms_init()
        with self._wlock:
            full = since < 0 or self._sver > since
            ctls = [self._controls[c] for c in self._order if c in self._controls]
            out = {'ver': self._wver, 'focus': self._focus_id, 'full': full,
                   'controls': [c._ms_state() for c in ctls if full or c._ver > since]}
            if full:
                out['order'] = [c.id for c in ctls]
                out['title'] = getattr(context.current(), 'addon_id', '') or ''
            return out

    # -- Steuerelemente
    def addControl(self, control):
        self._ms_init()
        with self._wlock:
            if not getattr(control, 'id', 0) or control.id in self._controls and self._controls[control.id] is not control:
                self._next_cid += 1
                control.id = self._next_cid
            self._controls[control.id] = control
            if control.id not in self._order:
                self._order.append(control.id)
            control._win = self
        self._ms_bump(control, struct=True)

    def addControls(self, controls):
        for c in controls:
            self.addControl(c)

    def removeControl(self, control):
        self._ms_init()
        with self._wlock:
            cid = getattr(control, 'id', None)
            self._controls.pop(cid, None)
            if cid in self._order:
                self._order.remove(cid)
            if self._focus_id == cid:
                self._focus_id = 0
        self._ms_bump(struct=True)

    def removeControls(self, controls):
        for c in controls:
            self.removeControl(c)

    def getControl(self, controlId):
        self._ms_init()
        c = self._controls.get(controlId)
        if c is None:
            c = Control()
            c.id = controlId
            self._controls[controlId] = c                  # Steuerelement aus Skin-XML: nur Merker, wird nicht gezeichnet
        return c

    def setFocus(self, control):
        self.setFocusId(getattr(control, 'id', 0))

    def setFocusId(self, controlId):
        self._ms_init()
        self._focus_id = int(controlId or 0)
        self._ms_bump()

    def getFocus(self):
        self._ms_init()
        if self._focus_id and self._focus_id in self._controls:
            return self._controls[self._focus_id]
        c = Control()                                       # Kodi wirft hier einen Fehler; ein leeres Element ist für Addons gutmütiger
        return c

    def getFocusId(self):
        self._ms_init()
        return self._focus_id

    def getWidth(self):
        return 1280

    def getHeight(self):
        return 720

    def getResolution(self):
        return 3

    def setCoordinateResolution(self, res):
        pass

    # -- Ablauf
    def onAction(self, action):
        pass

    def onClick(self, controlId):
        pass

    def onControl(self, control):
        pass

    def onFocus(self, controlId):
        pass

    def onInit(self):
        pass

    def close(self):
        self._ms_init()
        self._closed.set()

    def show(self):
        self._ms_init()
        if not self._order:
            return
        if self._hd is not None:
            return
        self._closed.clear()
        hd = ui_dialogs.window_open(self)
        if hd is None:
            _no_screen()
            return
        self._hd = hd
        ctx = context.current()

        def loop():
            with context.use(ctx):
                self._ms_loop(hd)
        threading.Thread(target=loop, name='kodi-window', daemon=True).start()

    def doModal(self):
        self._ms_init()
        if not self._order:
            return                                          # nichts zu zeigen (Fenster nur als Eigenschafts-Speicher)
        if self._hd is not None:                            # schon per show() offen: bis zum Schließen warten
            while not self._closed.wait(0.25):
                if ui_dialogs.window_gone(self._hd):
                    break
            return
        self._closed.clear()
        hd = ui_dialogs.window_open(self)
        if hd is None:
            _no_screen()
            return
        self._hd = hd
        self._ms_loop(hd)

    def _ms_loop(self, hd):
        import queue as _q
        ctx = context.current()
        marks = context.begin_wait(ctx)
        yld = ui_dialogs.run_yield()
        try:
            with yld:
                while not self._closed.is_set():
                    try:
                        ev = hd.q.get(timeout=0.25)
                    except _q.Empty:
                        if ui_dialogs.window_gone(hd) or ctx.cancelled.is_set():
                            break
                        continue
                    try:
                        self._ms_dispatch(ev)
                    except Exception:                       # noqa: BLE001 - wie Kodi: Fehler im Rückruf protokollieren, Fenster bleibt
                        _log.warning('Fehler im Fenster des Addons', exc_info=True)
                        ctx.note('error', getattr(ctx, 'addon_id', '') or 'Addon', 'Fehler im Programm – Details im Protokoll.')
        finally:
            self._closed.set()
            ui_dialogs.window_close(hd)
            self._hd = None
            context.end_wait(marks)

    def _ms_dispatch(self, ev):
        t = ev.get('t')
        if t == 'close':
            self.close()
            return
        if t == 'act':
            aid = int(ev.get('id') or 0)
            cur = self._controls.get(self._focus_id)
            if aid in (1, 2, 3, 4) and cur is not None:
                nxt = cur._nav.get({1: 'left', 2: 'right', 3: 'up', 4: 'down'}[aid])
                if nxt is not None and getattr(nxt, 'id', 0) in self._controls:
                    self.setFocusId(nxt.id)
                    self.onFocus(nxt.id)
            if aid == 7 and cur is not None and cur._TYPE in _FOCUSABLE and cur._visible and cur._enabled:
                self._ms_click(cur, ev)                     # OK auf dem markierten Knopf = Klick (onControl)
                return
            self.onAction(Action(aid))
            return
        if t in ('click', 'text'):
            c = self._controls.get(int(ev.get('cid') or 0))
            if c is None or not c._visible or not c._enabled:
                return
            if c._TYPE in _FOCUSABLE and self._focus_id != c.id:
                self.setFocusId(c.id)
                self.onFocus(c.id)
            if t == 'text':
                c._text = str(ev.get('text') or '')[:2000]
                c._touch()
                return
            self._ms_click(c, ev)

    def _ms_click(self, c, ev):
        if c._TYPE == 'radio':
            c._value = not bool(c._value)
            c._touch()
        elif c._TYPE == 'list' and ev.get('pos') is not None:
            try:
                c.selectItem(int(ev['pos']))
            except (TypeError, ValueError):
                pass
        if isinstance(self, WindowXML):
            self.onClick(c.id)
        else:
            self.onControl(c)


def _no_screen():
    ctx = context.current()
    if not getattr(ctx, '_nowin', False):
        ctx._nowin = True
        ctx.note('warning', getattr(ctx, 'addon_id', '') or 'Addon', 'Dieses Programm öffnet ein eigenes Fenster – das geht nur, wenn es aus '
                                                                     'der Oberfläche gestartet wird.')


class WindowDialog(Window):
    pass


def _no_window():
    """Fenster aus Skin-XML (WindowXML / pyxbmct-Skins) gibt es hier nicht: einmal pro Lauf ehrlich melden statt still nichts zu tun."""
    ctx = context.current()
    if not getattr(ctx, '_nowin', False):
        ctx._nowin = True
        who = getattr(ctx, 'addon_id', '') or 'Das Addon'
        ctx.note('warning', who, 'Dieses Programm will ein Kodi-Fenster aus einer Skin-Datei (WindowXML) öffnen. Solche Fenster gibt es in '
                                 'MovieScout nicht – das Programm ist hier nur eingeschränkt nutzbar.')


class WindowXML(Window):
    def __init__(self, xmlFilename='', scriptPath='', defaultSkin='Default', defaultRes='720p', *a, **k):
        super().__init__(10000)

    def doModal(self):
        _no_window()

    def show(self):
        _no_window()


class WindowXMLDialog(WindowXML):
    pass


class Control:
    """Grundlage aller Steuerelemente: merkt sich Lage, Text, Bild und Werte. Gehört es zu einem angezeigten Fenster, sieht die
    Oberfläche jede Änderung."""
    _ARGS = ()
    _TYPE = 'control'

    def __init__(self, *a, **k):
        vals = dict(zip(('x', 'y', 'width', 'height') + self._ARGS, a))
        vals.update(k)
        self.id = 0
        self._win = None
        self._ver = 0
        self._x, self._y = _num(vals.get('x')), _num(vals.get('y'))
        self._w, self._h = _num(vals.get('width')), _num(vals.get('height'))
        self._label = str(vals.get('label') or '')
        self._label2 = ''
        self._text = ''
        self._font = str(vals.get('font') or '')
        self._color = str(vals.get('textColor') or '')
        self._fcolor = str(vals.get('focusedColor') or '')
        self._dcolor = str(vals.get('disabledColor') or '')
        self._selcolor = str(vals.get('selectedColor') or '')
        al = vals.get('alignment', vals.get('_alignment'))
        self._align = int(al) if isinstance(al, int) or (isinstance(al, str) and al.isdigit()) else None
        self._img = str(vals.get('filename') or '')
        self._aspect = _num(vals.get('aspectRatio'))
        self._diffuse = str(vals.get('colorDiffuse') or '')
        self._ftex = str(vals.get('focusTexture') or '')
        self._nftex = str(vals.get('noFocusTexture') or '')
        self._pw = bool(vals.get('isPassword'))
        self._item_h = _num(vals.get('itemHeight')) or 0
        self._visible = True
        self._enabled = True
        self._value = 0
        self._items = []
        self._sel = 0
        self._labels = []
        self._nav = {}

    def _touch(self, struct=False):
        if self._win is not None:
            self._win._ms_bump(self, struct)

    def _ms_state(self):
        d = {'id': self.id, 't': self._TYPE, 'x': self._x, 'y': self._y, 'w': self._w, 'h': self._h, 'vis': self._visible, 'en': self._enabled}
        if self._TYPE in ('label', 'button', 'radio', 'edit', 'fadelabel'):
            d['label'] = self._labels[0] if self._TYPE == 'fadelabel' and self._labels else self._label
        if self._label2:
            d['label2'] = self._label2
        for k, v in (('font', self._font), ('color', self._color), ('fcolor', self._fcolor), ('dcolor', self._dcolor), ('selcolor', self._selcolor),
                     ('diffuse', self._diffuse)):
            if v:
                d[k] = _color(v) if k != 'font' else v
        if self._align is not None:
            d['align'] = self._align
        if self._TYPE == 'image':
            d['img'] = ui_dialogs.file_url(self._img)
            d['aspect'] = self._aspect
        if self._TYPE in ('button', 'radio') and (self._ftex or self._nftex):
            d['ftex'], d['nftex'] = ui_dialogs.file_url(self._ftex), ui_dialogs.file_url(self._nftex)
        if self._TYPE in ('textbox', 'edit'):
            d['text'] = self._text
            d['pw'] = self._pw
        if self._TYPE in ('radio',):
            d['on'] = bool(self._value)
        if self._TYPE in ('progress', 'slider'):
            try:
                d['pct'] = max(0.0, min(100.0, float(self._value)))
            except (TypeError, ValueError):
                d['pct'] = 0
        if self._TYPE == 'list':
            d['items'] = [str(i.getLabel()) for i in self._items[:500]]
            d['sel'] = self._sel
            d['ih'] = self._item_h
        return d

    def getId(self):
        return self.id

    def setLabel(self, label='', font=None, textColor=None, disabledColor=None, shadowColor=None, focusedColor=None, label2=None, *a, **k):
        self._label = str(label if label is not None else '')
        if textColor:
            self._color = str(textColor)
        if focusedColor:
            self._fcolor = str(focusedColor)
        if font:
            self._font = str(font)
        if label2 is not None:
            self._label2 = str(label2)
        self._touch()

    def getLabel(self):
        return self._label

    def setLabel2(self, label):
        self._label2 = str(label)
        self._touch()

    def getLabel2(self):
        return self._label2

    def setText(self, text=''):
        self._text = str(text)
        self._touch()

    def getText(self):
        return self._text

    def setVisible(self, v):
        self._visible = bool(v)
        self._touch()

    def isVisible(self):
        return self._visible

    def setEnabled(self, v):
        self._enabled = bool(v)
        self._touch()

    def isEnabled(self):
        return self._enabled

    def setImage(self, filename='', useCache=True, *a, **k):
        self._img = str(filename or '')
        self._touch()

    def setColorDiffuse(self, color):
        self._diffuse = str(color or '')
        self._touch()

    def setPercent(self, p):
        self._value = p
        self._touch()

    def getPercent(self):
        return self._value

    def setInt(self, value, *a):
        self._value = value
        self._touch()

    def getInt(self):
        return int(self._value or 0)

    def setFloat(self, value, *a):
        self._value = value
        self._touch()

    def getFloat(self):
        return float(self._value or 0)

    def setValue(self, v):
        self._value = v
        self._touch()

    def getValue(self):
        return self._value

    def setSelected(self, v):
        self._value = bool(v)
        self._touch()

    def isSelected(self):
        return bool(self._value)

    def addLabel(self, label):
        self._labels.append(str(label))
        self._touch()

    def setLabels(self, labels):
        self._labels = [str(x) for x in labels or []]
        self._touch()

    def addItem(self, item, *a, **k):
        self._items.append(item if isinstance(item, ListItem) else ListItem(str(item)))
        self._touch()

    def addItems(self, items):
        for it in items or []:
            self._items.append(it if isinstance(it, ListItem) else ListItem(str(it)))
        self._touch()

    def removeItem(self, index):
        if 0 <= index < len(self._items):
            self._items.pop(index)
            self._sel = min(self._sel, max(0, len(self._items) - 1))
            self._touch()

    def reset(self):
        self._items = []
        self._labels = []
        self._sel = 0
        self._touch()

    def size(self):
        return len(self._items)

    def getSelectedPosition(self):
        return self._sel if self._items else -1

    def getSelectedItem(self):
        return self._items[self._sel] if 0 <= self._sel < len(self._items) else None

    def selectItem(self, i):
        if 0 <= int(i) < len(self._items):
            self._sel = int(i)
            self._touch()

    def getListItem(self, i):
        return self._items[i] if 0 <= i < len(self._items) else ListItem()

    def getItemHeight(self):
        return self._item_h

    def setPosition(self, x, y):
        self._x, self._y = _num(x), _num(y)
        self._touch()

    def getPosition(self):
        return (self._x, self._y)

    def getX(self):
        return self._x

    def getY(self):
        return self._y

    def setWidth(self, w):
        self._w = _num(w)
        self._touch()

    def setHeight(self, h):
        self._h = _num(h)
        self._touch()

    def getWidth(self):
        return self._w

    def getHeight(self):
        return self._h

    def setNavigation(self, up=None, down=None, left=None, right=None):
        self._nav.update({k: v for k, v in (('up', up), ('down', down), ('left', left), ('right', right)) if v is not None})

    def controlUp(self, control):
        self._nav['up'] = control

    def controlDown(self, control):
        self._nav['down'] = control

    def controlLeft(self, control):
        self._nav['left'] = control

    def controlRight(self, control):
        self._nav['right'] = control

    def __getattr__(self, name):                           # alles Übrige (setAnimations, setVisibleCondition, scroll …) ist ein No-op
        if name.startswith('__'):
            raise AttributeError(name)
        return lambda *a, **k: None


def _num(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


_KODI_COLORS = {'white': 'FFFFFFFF', 'black': 'FF000000', 'red': 'FFFF0000', 'green': 'FF00FF00', 'blue': 'FF0000FF', 'yellow': 'FFFFFF00',
                'orange': 'FFFFA500', 'grey': 'FF808080', 'gray': 'FF808080', 'cyan': 'FF00FFFF', 'aqua': 'FF00FFFF', 'magenta': 'FFFF00FF',
                'lime': 'FF00FF00', 'gold': 'FFFFD700', 'purple': 'FF800080', 'pink': 'FFFFC0CB', 'brown': 'FFA52A2A', 'silver': 'FFC0C0C0'}


def _color(v):
    """Kodi-Farbe (0xAARRGGBB, AARRGGBB oder Name) -> 'AARRGGBB' (die Oberfläche rechnet um)."""
    s = str(v or '').strip()
    if s.lower().startswith('0x'):
        s = s[2:]
    if len(s) == 8 and all(c in '0123456789abcdefABCDEF' for c in s):
        return s.upper()
    if len(s) == 6 and all(c in '0123456789abcdefABCDEF' for c in s):
        return 'FF' + s.upper()
    return _KODI_COLORS.get(s.lower(), s)


class ControlButton(Control):
    _TYPE = 'button'
    _ARGS = ('label', 'focusTexture', 'noFocusTexture', 'textOffsetX', 'textOffsetY', 'alignment', 'font', 'textColor', 'disabledColor',
             'angle', 'shadowColor', 'focusedColor')


class ControlLabel(Control):
    _TYPE = 'label'
    _ARGS = ('label', 'font', 'textColor', 'disabledColor', 'alignment', 'hasPath', 'angle')


class ControlFadeLabel(Control):
    _TYPE = 'fadelabel'
    _ARGS = ('font', 'textColor', '_alignment')


class ControlTextBox(Control):
    _TYPE = 'textbox'
    _ARGS = ('font', 'textColor')


class ControlImage(Control):
    _TYPE = 'image'
    _ARGS = ('filename', 'aspectRatio', 'colorDiffuse')


class ControlList(Control):
    _TYPE = 'list'
    _ARGS = ('font', 'textColor', 'buttonTexture', 'buttonFocusTexture', 'selectedColor', '_imageWidth', '_imageHeight', '_itemTextXOffset',
             '_itemTextYOffset', 'itemHeight', '_space', '_alignmentY')


class ControlGroup(Control):
    _TYPE = 'group'


class ControlEdit(Control):
    _TYPE = 'edit'
    _ARGS = ('label', 'font', 'textColor', 'disabledColor', '_alignment', 'focusTexture', 'noFocusTexture', 'isPassword')


class ControlRadioButton(Control):
    _TYPE = 'radio'
    _ARGS = ('label', 'focusTexture', 'noFocusTexture', 'textOffsetX', 'textOffsetY', '_alignment', 'font', 'textColor', 'disabledColor',
             'angle', 'shadowColor', 'focusedColor', 'focusOnTexture', 'noFocusOnTexture', 'focusOffTexture', 'noFocusOffTexture')


class ControlCheckMark(Control):
    _TYPE = 'radio'


class ControlProgress(Control):
    _TYPE = 'progress'
    _ARGS = ('texturebg', 'textureleft', 'texturemid', 'textureright', 'textureoverlay')


class ControlSlider(Control):
    _TYPE = 'slider'
    _ARGS = ('textureback', 'texture', 'texturefocus', 'orientation')


class ControlSpin(Control):
    _TYPE = 'spin'


class ControlGroupList(Control):
    _TYPE = 'group'


class Action:
    def __init__(self, action_id=0):
        self._id = action_id

    def getId(self):
        return self._id

    def getButtonCode(self):
        return 0

    def getAmount1(self):
        return 0.0

    def getAmount2(self):
        return 0.0


ACTION_NONE = 0
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7
ACTION_HIGHLIGHT_ITEM = 8
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_SHOW_INFO = 11
ACTION_NAV_BACK = 92
ACTION_STOP = 13
ACTION_PAUSE = 12
ACTION_CONTEXT_MENU = 117


def getScreenWidth():
    return 1920


def getScreenHeight():
    return 1080


def getCurrentWindowId():
    return 10000


def getCurrentWindowDialogId():
    return 9999
