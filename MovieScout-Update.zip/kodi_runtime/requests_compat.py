# -*- coding: utf-8 -*-
"""Notfall-Ersatz für `requests` (Kodi: script.module.requests), nur auf urllib gebaut.

Viele Kodi-Addons machen `import requests`. Auf manchen Geräten (z. B. Pydroid) ist das Paket nicht
installiert. Dann trägt `install()` diesen Ersatz unter dem Namen `requests` ein. Ist das echte Paket
da, passiert nichts. Abgedeckt ist das, was Addons üblicherweise nutzen: get/post/put/delete/head/patch,
Session, Header, Parameter, data/json/files, Cookies, Zeitlimit, verify=False, Weiterleitungen,
Response (text/content/json/ok/url/headers/cookies/iter_content/raise_for_status), exceptions.
"""
import gzip
import http.cookiejar
import io
import json as _json
import mimetypes
import ssl
import sys
import types
import uuid
import zlib
from urllib import error as _uerr, parse as _parse, request as _ureq


MIN_TIMEOUT = 8.0          # Sekunden; kürzere Zeitlimits der Addons werden auf diesen Wert angehoben (bewusste Abweichung vom Original)


# ---------------------------------------------------------------- Fehler
class RequestException(IOError):
    def __init__(self, *a, **k):
        self.response = k.pop('response', None)
        self.request = k.pop('request', None)
        super().__init__(*a)


class HTTPError(RequestException):
    pass


class ConnectionError(RequestException):          # noqa: A001 - wie im Original
    pass


class ProxyError(ConnectionError):
    pass


class SSLError(ConnectionError):
    pass


class Timeout(RequestException):
    pass


class ConnectTimeout(ConnectionError, Timeout):
    pass


class ReadTimeout(Timeout):
    pass


class URLRequired(RequestException):
    pass


class TooManyRedirects(RequestException):
    pass


class MissingSchema(RequestException, ValueError):
    pass


class InvalidSchema(RequestException, ValueError):
    pass


class InvalidURL(RequestException, ValueError):
    pass


class JSONDecodeError(RequestException, ValueError):
    pass


class ChunkedEncodingError(RequestException):
    pass


class ContentDecodingError(RequestException):
    pass


# ---------------------------------------------------------------- Hilfsklassen
class CaseInsensitiveDict(dict):
    def __init__(self, data=None, **kw):
        super().__init__()
        self._k = {}
        for k, v in dict(data or {}, **kw).items():
            self[k] = v

    def __setitem__(self, k, v):
        old = self._k.get(k.lower())
        if old is not None and old != k:
            super().__delitem__(old)
        self._k[k.lower()] = k
        super().__setitem__(k, v)

    def __getitem__(self, k):
        return super().__getitem__(self._k[k.lower()])

    def __delitem__(self, k):
        real = self._k.pop(k.lower())
        super().__delitem__(real)

    def __contains__(self, k):
        return isinstance(k, str) and k.lower() in self._k

    def get(self, k, default=None):
        try:
            return self[k]
        except KeyError:
            return default

    def pop(self, k, *d):
        if k in self:
            v = self[k]
            del self[k]
            return v
        if d:
            return d[0]
        raise KeyError(k)

    def setdefault(self, k, v=None):
        if k not in self:
            self[k] = v
        return self[k]

    def update(self, *a, **kw):
        for k, v in dict(*a, **kw).items():
            self[k] = v

    def copy(self):
        return CaseInsensitiveDict(self)


class RequestsCookieJar(http.cookiejar.CookieJar):
    def set(self, name, value, **kw):
        c = http.cookiejar.Cookie(
            0, name, value, None, False, kw.get('domain', ''), bool(kw.get('domain')), str(kw.get('domain', '')).startswith('.'),
            kw.get('path', '/'), True, bool(kw.get('secure', False)), kw.get('expires'), False, None, None, {})
        self.set_cookie(c)
        return c

    def get(self, name, default=None, domain=None, path=None):
        for c in self:
            if c.name == name and (domain is None or c.domain == domain) and (path is None or c.path == path):
                return c.value
        return default

    def get_dict(self, domain=None, path=None):
        return {c.name: c.value for c in self if (domain is None or c.domain == domain) and (path is None or c.path == path)}

    def update(self, other):
        if isinstance(other, http.cookiejar.CookieJar):
            for c in other:
                self.set_cookie(c)
        else:
            for k, v in dict(other).items():
                self.set(k, v)

    def keys(self):
        return [c.name for c in self]

    def values(self):
        return [c.value for c in self]

    def items(self):
        return [(c.name, c.value) for c in self]

    def __getitem__(self, name):
        v = self.get(name)
        if v is None:
            raise KeyError(name)
        return v

    def __setitem__(self, name, value):
        self.set(name, value)

    def __contains__(self, name):
        return self.get(name) is not None


def cookiejar_from_dict(d, cookiejar=None):
    jar = cookiejar if cookiejar is not None else RequestsCookieJar()
    for k, v in (d or {}).items():
        jar.set(k, v)
    return jar


class _Codes(dict):
    def __getattr__(self, k):
        try:
            return self[k]
        except KeyError:
            raise AttributeError(k)


codes = _Codes(ok=200, created=201, accepted=202, no_content=204, moved_permanently=301, found=302, see_other=303,
               not_modified=304, temporary_redirect=307, permanent_redirect=308, bad_request=400, unauthorized=401,
               forbidden=403, not_found=404, method_not_allowed=405, too_many_requests=429,
               internal_server_error=500, bad_gateway=502, service_unavailable=503, gateway_timeout=504)


class Response:
    def __init__(self):
        self.status_code = None
        self.headers = CaseInsensitiveDict()
        self.url = ''
        self.reason = ''
        self.encoding = None
        self.history = []
        self.cookies = RequestsCookieJar()
        self.request = None
        self.elapsed = None
        self._content = b''
        self.raw = None

    # --- Inhalt
    @property
    def content(self):
        return self._content

    @property
    def text(self):
        enc = self.encoding or self.apparent_encoding or 'utf-8'
        try:
            return self._content.decode(enc, errors='replace')
        except LookupError:
            return self._content.decode('utf-8', errors='replace')

    @property
    def apparent_encoding(self):
        return 'utf-8'

    def json(self, **kw):
        try:
            txt = self._content.decode(self.encoding or 'utf-8-sig') if self.encoding else self._content.decode('utf-8-sig')
            return _json.loads(txt, **kw)
        except ValueError as e:
            raise JSONDecodeError(str(e), response=self)

    def iter_content(self, chunk_size=1, decode_unicode=False):
        data = self._content
        chunk_size = chunk_size or len(data) or 1
        for i in range(0, len(data), chunk_size):
            part = data[i:i + chunk_size]
            yield part.decode(self.encoding or 'utf-8', errors='replace') if decode_unicode else part

    def iter_lines(self, chunk_size=512, decode_unicode=False, delimiter=None):
        for ln in self._content.splitlines():
            yield ln.decode(self.encoding or 'utf-8', errors='replace') if decode_unicode else ln

    # --- Status
    @property
    def ok(self):
        return self.status_code is not None and self.status_code < 400

    @property
    def is_redirect(self):
        return 'location' in self.headers and self.status_code in (301, 302, 303, 307, 308)

    @property
    def links(self):
        return {}

    def raise_for_status(self):
        if self.status_code is not None and 400 <= self.status_code < 600:
            kind = 'Client' if self.status_code < 500 else 'Server'
            raise HTTPError('%s %s Error: %s for url: %s' % (self.status_code, kind, self.reason, self.url), response=self)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __bool__(self):
        return self.ok

    def __repr__(self):
        return '<Response [%s]>' % self.status_code


# ---------------------------------------------------------------- Anfrage
class _NoRedirect(_ureq.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class _Follow(_ureq.HTTPRedirectHandler):
    max_redirections = 30

    def __init__(self, hist):
        self.hist = hist

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        self.hist.append((code, req.full_url))
        if len(self.hist) > 30:
            raise TooManyRedirects('Exceeded 30 redirects.')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _ctx(verify):
    if verify is False:
        c = ssl.create_default_context()
        c.check_hostname = False
        c.verify_mode = ssl.CERT_NONE
        return c
    if isinstance(verify, str):
        return ssl.create_default_context(cafile=verify)
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:                                # noqa: BLE001
        return ssl.create_default_context()


def _enc_params(params):
    if not params:
        return ''
    if isinstance(params, (str, bytes)):
        return params.decode() if isinstance(params, bytes) else params
    return _parse.urlencode(params, doseq=True)


def _multipart(data, files):
    b = uuid.uuid4().hex
    out = io.BytesIO()
    for k, v in (data.items() if isinstance(data, dict) else data or []):
        for one in (v if isinstance(v, (list, tuple)) else [v]):
            out.write(('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n' % (b, k)).encode())
            out.write(one if isinstance(one, bytes) else str(one).encode())
            out.write(b'\r\n')
    for k, v in (files.items() if isinstance(files, dict) else files):
        fn, content, ctype = None, v, None
        if isinstance(v, (tuple, list)):
            fn, content = v[0], v[1]
            ctype = v[2] if len(v) > 2 else None
        if hasattr(content, 'read'):
            content = content.read()
        if isinstance(content, str):
            content = content.encode()
        fn = fn or getattr(v, 'name', None) or k
        ctype = ctype or mimetypes.guess_type(str(fn))[0] or 'application/octet-stream'
        out.write(('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\nContent-Type: %s\r\n\r\n' % (b, k, fn, ctype)).encode())
        out.write(content)
        out.write(b'\r\n')
    out.write(('--%s--\r\n' % b).encode())
    return out.getvalue(), 'multipart/form-data; boundary=' + b


def _decode_body(raw, enc):
    enc = (enc or '').lower()
    try:
        if enc == 'gzip' or raw[:2] == b'\x1f\x8b':
            return gzip.decompress(raw)
        if enc == 'deflate':
            try:
                return zlib.decompress(raw)
            except zlib.error:
                return zlib.decompress(raw, -zlib.MAX_WBITS)
    except Exception:                                # noqa: BLE001
        pass
    return raw


class Session:
    def __init__(self):
        self.headers = CaseInsensitiveDict({'User-Agent': 'python-requests/2.31.0', 'Accept-Encoding': 'gzip, deflate',
                                            'Accept': '*/*', 'Connection': 'keep-alive'})
        self.cookies = RequestsCookieJar()
        self.auth = None
        self.proxies = {}
        self.verify = True
        self.cert = None
        self.params = {}
        self.stream = False
        self.max_redirects = 30
        self.trust_env = True
        self.hooks = {}
        self.adapters = {}

    def mount(self, prefix, adapter):
        self.adapters[prefix] = adapter

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    # --- Kern
    def request(self, method, url, params=None, data=None, headers=None, cookies=None, files=None, auth=None,
                timeout=None, allow_redirects=True, proxies=None, hooks=None, stream=None, verify=None, cert=None, json=None):
        if not url:
            raise URLRequired('Invalid URL')
        url = url.decode() if isinstance(url, bytes) else str(url)
        if '://' not in url:
            raise MissingSchema("Invalid URL %r: No scheme supplied. Perhaps you meant https://%s?" % (url, url))
        if not url.lower().startswith(('http://', 'https://')):
            raise InvalidSchema('No connection adapters were found for %r' % url)
        allp = dict(self.params or {})
        if isinstance(params, dict):
            allp.update(params)
            qs = _enc_params(allp)
        else:
            qs = _enc_params(allp) if allp and not params else ''
            if params:
                qs = (qs + '&' if qs else '') + _enc_params(params)
        if qs:
            url += ('&' if '?' in url else '?') + qs
        hdr = CaseInsensitiveDict(self.headers)
        for k, v in (headers or {}).items():
            if v is None:
                hdr.pop(k, None)
            else:
                hdr[k] = v.decode() if isinstance(v, bytes) else v
        body = None
        if files:
            body, ctype = _multipart(data, files)
            hdr['Content-Type'] = ctype
        elif json is not None:
            body = _json.dumps(json).encode()
            hdr.setdefault('Content-Type', 'application/json')
        elif data is not None:
            if isinstance(data, (dict, list, tuple)):
                body = _parse.urlencode(data, doseq=True).encode()
                hdr.setdefault('Content-Type', 'application/x-www-form-urlencoded')
            elif isinstance(data, str):
                body = data.encode()
            elif hasattr(data, 'read'):
                body = data.read()
            else:
                body = data
        auth = auth or self.auth
        if isinstance(auth, tuple):
            import base64
            hdr['Authorization'] = 'Basic ' + base64.b64encode(('%s:%s' % auth).encode()).decode()
        elif callable(auth):
            pass
        if cookies:
            ck = '; '.join('%s=%s' % kv for kv in dict(cookies).items())
            hdr['Cookie'] = (hdr['Cookie'] + '; ' if 'Cookie' in hdr else '') + ck
        tmo = timeout[0] if isinstance(timeout, (tuple, list)) else timeout
        if tmo is not None and tmo < MIN_TIMEOUT:                   # Addons prüfen Seiten oft mit timeout=2; auf dem Handy (viele Dienste gleichzeitig, mobiles Netz) meldet das fälschlich „tot“
            tmo = MIN_TIMEOUT
        hist = []
        handlers = [_ureq.HTTPCookieProcessor(self.cookies),
                    _ureq.HTTPSHandler(context=_ctx(self.verify if verify is None else verify))]
        px = proxies or self.proxies
        if px:
            handlers.append(_ureq.ProxyHandler(px))
        else:
            handlers.append(_ureq.ProxyHandler())
        handlers.append(_Follow(hist) if allow_redirects else _NoRedirect())
        opener = _ureq.build_opener(*handlers)
        req = _ureq.Request(url, data=body, method=method.upper())
        for k, v in hdr.items():
            req.add_header(k, v)
        resp = Response()
        try:
            try:
                r = opener.open(req, timeout=tmo)
            except _uerr.HTTPError as e:           # 3xx ohne Folgen und 4xx/5xx: normale Antwort, kein Fehler
                r = e
            raw = r.read()
        except _uerr.URLError as e:
            reason = getattr(e, 'reason', e)
            if isinstance(reason, ssl.SSLError):
                raise SSLError(str(reason), request=req)
            if 'timed out' in str(reason):
                raise ConnectTimeout(str(reason), request=req)
            raise ConnectionError(str(reason), request=req)
        except (TimeoutError, ssl.SSLError) as e:
            if isinstance(e, ssl.SSLError):
                raise SSLError(str(e), request=req)
            raise ReadTimeout(str(e), request=req)
        except OSError as e:
            raise ConnectionError(str(e), request=req)
        resp.status_code = getattr(r, 'status', None) or getattr(r, 'code', 0)
        resp.reason = getattr(r, 'reason', '') or ''
        resp.url = r.geturl() if hasattr(r, 'geturl') else url
        for k, v in r.headers.items():
            if k in resp.headers:
                resp.headers[k] = resp.headers[k] + ', ' + v
            else:
                resp.headers[k] = v
        resp._content = _decode_body(raw, r.headers.get('Content-Encoding'))
        ct = r.headers.get('Content-Type', '')
        if 'charset=' in ct:
            resp.encoding = ct.split('charset=')[-1].split(';')[0].strip().strip('"\'')
        elif ct.startswith('text/'):
            resp.encoding = 'ISO-8859-1'
        resp.cookies = self.cookies
        for code, u in hist:
            h = Response()
            h.status_code, h.url = code, u
            resp.history.append(h)
        resp.request = req
        return resp

    def get(self, url, **kw):
        kw.setdefault('allow_redirects', True)
        return self.request('GET', url, **kw)

    def options(self, url, **kw):
        return self.request('OPTIONS', url, **kw)

    def head(self, url, **kw):
        kw.setdefault('allow_redirects', False)
        return self.request('HEAD', url, **kw)

    def post(self, url, data=None, json=None, **kw):
        return self.request('POST', url, data=data, json=json, **kw)

    def put(self, url, data=None, **kw):
        return self.request('PUT', url, data=data, **kw)

    def patch(self, url, data=None, **kw):
        return self.request('PATCH', url, data=data, **kw)

    def delete(self, url, **kw):
        return self.request('DELETE', url, **kw)


def session():
    return Session()


def request(method, url, **kw):
    with Session() as s:
        return s.request(method, url, **kw)


def get(url, params=None, **kw):
    return request('GET', url, params=params, **kw)


def options(url, **kw):
    return request('OPTIONS', url, **kw)


def head(url, **kw):
    kw.setdefault('allow_redirects', False)
    return request('HEAD', url, **kw)


def post(url, data=None, json=None, **kw):
    return request('POST', url, data=data, json=json, **kw)


def put(url, data=None, **kw):
    return request('PUT', url, data=data, **kw)


def patch(url, data=None, **kw):
    return request('PATCH', url, data=data, **kw)


def delete(url, **kw):
    return request('DELETE', url, **kw)


class HTTPAdapter:
    def __init__(self, *a, **k):
        pass


class PreparedRequest:
    pass


class Request:
    def __init__(self, method=None, url=None, headers=None, data=None, params=None, **k):
        self.method, self.url, self.headers, self.data, self.params = method, url, headers, data, params


def disable_warnings(*a, **k):
    pass


# ---------------------------------------------------------------- einbauen
def _mod(name, **attrs):
    m = types.ModuleType(name)
    m.__dict__.update(attrs)
    return m


def build():
    """Das Modul-Gebilde `requests` (+ Untermodule, + schlanker urllib3-Ersatz) aufbauen."""
    me = sys.modules[__name__]
    req = types.ModuleType('requests')
    for k in ('RequestException', 'HTTPError', 'ConnectionError', 'ProxyError', 'SSLError', 'Timeout', 'ConnectTimeout',
              'ReadTimeout', 'URLRequired', 'TooManyRedirects', 'MissingSchema', 'InvalidSchema', 'InvalidURL',
              'JSONDecodeError', 'ChunkedEncodingError', 'ContentDecodingError', 'Response', 'Session', 'Request',
              'PreparedRequest', 'session', 'request', 'get', 'options', 'head', 'post', 'put', 'patch', 'delete', 'codes'):
        setattr(req, k, getattr(me, k))
    req.__version__ = '2.31.0'
    req.__is_movie_scout_compat__ = True
    req.exceptions = _mod('requests.exceptions', **{k: getattr(me, k) for k in (
        'RequestException', 'HTTPError', 'ConnectionError', 'ProxyError', 'SSLError', 'Timeout', 'ConnectTimeout',
        'ReadTimeout', 'URLRequired', 'TooManyRedirects', 'MissingSchema', 'InvalidSchema', 'InvalidURL',
        'JSONDecodeError', 'ChunkedEncodingError', 'ContentDecodingError')})
    req.structures = _mod('requests.structures', CaseInsensitiveDict=CaseInsensitiveDict)
    req.cookies = _mod('requests.cookies', RequestsCookieJar=RequestsCookieJar, cookiejar_from_dict=cookiejar_from_dict)
    req.adapters = _mod('requests.adapters', HTTPAdapter=HTTPAdapter)
    req.sessions = _mod('requests.sessions', Session=Session, session=session)
    req.models = _mod('requests.models', Response=Response, Request=Request, PreparedRequest=PreparedRequest)
    req.status_codes = _mod('requests.status_codes', codes=codes)
    req.utils = _mod('requests.utils', quote=_parse.quote, unquote=_parse.unquote, urlparse=_parse.urlparse,
                     dict_from_cookiejar=lambda j: {c.name: c.value for c in j},
                     add_dict_to_cookiejar=lambda j, d: cookiejar_from_dict(d, j),
                     default_user_agent=lambda *a: 'python-requests/2.31.0')
    req.compat = _mod('requests.compat', urlparse=_parse.urlparse, urlencode=_parse.urlencode, quote=_parse.quote,
                      unquote=_parse.unquote, urljoin=_parse.urljoin, urlsplit=_parse.urlsplit, str=str, bytes=bytes,
                      basestring=str, is_py3=True)
    u3_exc = _mod('urllib3.exceptions', HTTPError=RequestException, InsecureRequestWarning=Warning,
                  MaxRetryError=RequestException, NewConnectionError=ConnectionError, ReadTimeoutError=ReadTimeout,
                  ProtocolError=ConnectionError, SSLError=SSLError)
    u3 = _mod('urllib3', disable_warnings=disable_warnings, exceptions=u3_exc, PoolManager=object, Retry=object,
              __version__='2.0.0')
    u3.util = _mod('urllib3.util', Retry=object)
    u3.util.retry = _mod('urllib3.util.retry', Retry=object)
    req.packages = _mod('requests.packages', urllib3=u3)
    req.packages.urllib3.__dict__.setdefault('contrib', _mod('urllib3.contrib'))
    mods = {'requests': req, 'requests.exceptions': req.exceptions, 'requests.structures': req.structures,
            'requests.cookies': req.cookies, 'requests.adapters': req.adapters, 'requests.sessions': req.sessions,
            'requests.models': req.models, 'requests.status_codes': req.status_codes, 'requests.utils': req.utils,
            'requests.compat': req.compat, 'requests.packages': req.packages,
            'requests.packages.urllib3': u3, 'requests.packages.urllib3.exceptions': u3_exc}
    return mods, u3, u3_exc


def install():
    """`requests` bereitstellen, falls es fehlt. Gibt True zurück, wenn der Ersatz eingetragen wurde."""
    try:
        import requests            # noqa: F401
        return False
    except ImportError:
        pass
    mods, u3, u3_exc = build()
    sys.modules.update(mods)
    try:
        import urllib3             # noqa: F401
    except ImportError:
        sys.modules['urllib3'] = u3
        sys.modules['urllib3.exceptions'] = u3_exc
        sys.modules['urllib3.util'] = u3.util
        sys.modules['urllib3.util.retry'] = u3.util.retry
    return True
