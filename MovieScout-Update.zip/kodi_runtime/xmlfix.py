# -*- coding: utf-8 -*-
"""Kodi liest auch fehlerhaftes XML (z. B. ein „<“ oder „&“ mitten in einem Attributwert, wie in settings.xml von ARDundZDF).
Python lehnt das ab. `parse` versucht es erst streng und repariert dann nur die Attributwerte."""
import re
import xml.etree.ElementTree as ET

_AMP = re.compile(r'&(?!(?:#\d+|#x[0-9a-fA-F]+|[A-Za-z][A-Za-z0-9]*);)')


def repair(text):
    """Maskiert „<“ und lose „&“ innerhalb von Attributwerten in Tags; alles andere bleibt unverändert."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c != '<':
            out.append(c); i += 1; continue
        if text.startswith('<!--', i):                      # Kommentar unverändert übernehmen
            j = text.find('-->', i + 4); j = n if j < 0 else j + 3
            out.append(text[i:j]); i = j; continue
        if text.startswith('<![CDATA[', i):
            j = text.find(']]>', i + 9); j = n if j < 0 else j + 3
            out.append(text[i:j]); i = j; continue
        if text.startswith(('<?', '<!'), i):
            j = text.find('>', i); j = n if j < 0 else j + 1
            out.append(text[i:j]); i = j; continue
        j, q = i + 1, ''                                    # normales Tag: bis zum schließenden „>“ außerhalb von Anführungszeichen
        buf = ['<']
        while j < n:
            d = text[j]
            if q:
                if d == q:
                    q = ''; buf.append(d)
                elif d == '<':
                    buf.append('&lt;')
                elif d == '&':
                    buf.append('&amp;' if _AMP.match(text, j) else '&')
                else:
                    buf.append(d)
            else:
                buf.append(d)
                if d in '"\'':
                    q = d
                elif d == '>':
                    j += 1; break
            j += 1
        out.append(''.join(buf)); i = j
    return ''.join(out)


def fromstring(text):
    if isinstance(text, bytes):
        text = text.decode('utf-8-sig', 'replace')
    else:
        text = text.lstrip('﻿')
    try:
        return ET.fromstring(text)
    except ET.ParseError:
        return ET.fromstring(repair(text))


def parse_file(path):
    with open(str(path), 'rb') as f:
        return fromstring(f.read())
