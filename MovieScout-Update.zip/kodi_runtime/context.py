# -*- coding: utf-8 -*-
"""Pro-Request-Kontext (thread-lokal).

Die Engine führt Scraper parallel in Threads aus. Alles, was ein Kodi-Addon
"nebenbei" erzeugt (Verzeichniseinträge, abzuspielende Streams, Eingaben des
Nutzers), landet deshalb hier und nicht in globalen Listen.
"""
import re
import threading

_tls = threading.local()


_MARKUP = re.compile(r'\[/?(?:B|I|U|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|COLOR[^\]]*|CR)\]', re.I)


def clean_text(t):
    """Kodi-Textauszeichnung ([COLOR red], [B] …) aus Meldungen entfernen."""
    return re.sub(r'[ \t]+', ' ', _MARKUP.sub(lambda m: '\n' if m.group(0).upper() == '[CR]' else '', str(t))).strip()


class RequestContext:
    def __init__(self, query='', params=None, client=None):
        self.query = query or ''        # Antwort auf Dialog().input() / Keyboard()
        self.params = params or {}
        self.client = client or {}      # was der abspielende Browser kann (Widevine-Stufe, Android?)
        self.items = []                 # xbmcplugin.addDirectoryItem
        self.resolved = []              # xbmcplugin.setResolvedUrl / Player().play
        self.notes = []                 # Benachrichtigungen (für die UI)
        self.cancelled = threading.Event()   # gesetzt, wenn die Engine den Aufruf abbricht (Zeitüberschreitung) -> DialogProgress.iscanceled()
        self.addon_id = ''               # gesetzt, solange ein installiertes Kodi-Addon läuft (engine/addonhost.py)
        self.rid = ''                   # Abfrage-ID der Oberfläche: Dialoge des Addons werden dort beantwortet (ui_dialogs)
        self.paused = 0.0               # Sekunden, die der Aufruf auf Antworten des Nutzers gewartet hat
        self.wait_since = 0
        self.svc_log = None             # deque mit den letzten Meldungen eines Addon-Dienstes (für die Diagnose in den Einstellungen)
        self.abort = None               # threading.Event eines Addon-Dienstes: xbmc.Monitor().abortRequested()/waitForAbort() hängen daran
        self.runlog = None              # Meldungen (xbmc.log) des laufenden Addon-Aufrufs: bei leerem Ergebnis zeigt die Engine die Fehlermeldungen an
        self.follow = ''                # plugin://-Adresse des Addons, die nach dem Lauf noch aufzulösen ist (Player().play(Wiedergabeliste))
        self.ui = {}                    # Wunsch des Addons an die Oberfläche: {'refresh': True} oder {'goto': 'plugin://…'} (Container.Refresh/Update)
        self.players = []               # schwache Verweise auf Instanzen von xbmc.Player-Unterklassen dieses Laufs (bekommen onAVStarted, sobald die Engine die Wiedergabe übernimmt)
        self.playing = False            # die Engine hat die Wiedergabe übernommen: Warteschleifen des Addons (Monitor, sleep) enden sofort
        self.progress = None            # letzter Stand von DialogProgress/DialogProgressBG: {'heading','message','percent','open'}
        self.parent = None              # Kontext des Aufrufers (RunScript/Programm): Wartezeiten auf den Nutzer zählen auch dort als Pause

    def paused_now(self):
        return self.paused + ((__import__('time').time() - self.wait_since) if self.wait_since else 0)

    def note(self, level, heading, message):
        self.notes.append({'level': level, 'heading': clean_text(heading), 'message': clean_text(message)})
        del self.notes[:-20]


def begin_wait(ctx):
    """Ab jetzt wartet das Addon auf den Nutzer (Dialog, eigenes Fenster): Zeit zählt nicht für Zeitüberschreitungen – auch nicht bei
    den aufrufenden Kontexten. -> Merker für end_wait (nur Kontexte, die nicht schon warten; Verschachtelung zählt nicht doppelt)."""
    import time as _t
    now, marks, c, seen = _t.time(), [], ctx, set()
    while c is not None and id(c) not in seen:
        seen.add(id(c))
        if not c.wait_since:
            c.wait_since = now
            marks.append(c)
        c = getattr(c, 'parent', None)
    return marks


def end_wait(marks):
    import time as _t
    now = _t.time()
    for c in marks or []:
        if c.wait_since:
            c.paused += now - c.wait_since
            c.wait_since = 0


def peek():
    return getattr(_tls, 'ctx', None)


def current():
    ctx = getattr(_tls, 'ctx', None)
    if ctx is None:
        ctx = RequestContext()
        _tls.ctx = ctx
    return ctx


class use:
    """with use(RequestContext(...)) as ctx: ..."""

    def __init__(self, ctx):
        self.ctx = ctx
        self._prev = None

    def __enter__(self):
        self._prev = getattr(_tls, 'ctx', None)
        _tls.ctx = self.ctx
        return self.ctx

    def __exit__(self, *exc):
        _tls.ctx = self._prev
        return False
