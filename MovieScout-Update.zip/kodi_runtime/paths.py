# -*- coding: utf-8 -*-
"""Speicherorte für userData (Cache, Einstellungen, Geräte-IDs)."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get('MINIKODI_DATA', str(ROOT / 'userData'))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)


def addon_dir(addon_id='plugin.video.moviescout'):
    p = DATA_DIR / addon_id
    p.mkdir(parents=True, exist_ok=True)
    return p
