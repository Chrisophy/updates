# -*- coding: utf-8 -*-
"""Kodi-Infolabels, Sichtbarkeits-Bedingungen, Skin-Variablen und eingebaute Befehle (Emulation).

Viele Kodi-Addons fragen vor dem Abspielen oder beim Aufbau ihrer Menüs ab:
    xbmc.getInfoLabel('System.BuildVersion'), 'Window(Home).Property(x)', 'Skin.String(x)', 'Container.FolderPath' …
    xbmc.getCondVisibility('System.Platform.Android + !Skin.HasSetting(x)'), 'System.HasAddon(inputstream.adaptive)' …
    xbmc.executebuiltin('Skin.SetString(x,y)'), 'SetProperty(k,v,Home)', 'Notification(…)', 'PlayMedia(url)' …
Hier steckt die Auswertung. Unbekanntes liefert leere Texte / False statt Fehler - so laufen mehr Addons unverändert.
"""
import json
import logging
import platform
import re
import socket
import threading
import time

from . import context, paths

_log = logging.getLogger('kodi.skin')
_lock = threading.RLock()

# ----------------------------------------------------------------------------- Fenster-Eigenschaften

_WINDOWS = {'home': 10000, 'programs': 10001, 'pictures': 10002, 'videos': 10025, 'video': 10025, 'music': 10005,
            'settings': 10004, 'fullscreenvideo': 12005, 'visualisation': 12006, 'busydialog': 10138}
_window_props = {}                     # Fenster-ID -> {Schlüssel (klein): Wert}


def window_id(w):
    if isinstance(w, int):
        return w
    s = str(w or '').strip().lower()
    if s.isdigit():
        return int(s)
    return _WINDOWS.get(s, s or 10000)


def win_get(w, key):
    with _lock:
        return _window_props.get(window_id(w), {}).get(str(key).lower(), '')


def win_set(w, key, value):
    with _lock:
        _window_props.setdefault(window_id(w), {})[str(key).lower()] = str(value)


def win_clear(w, key=None):
    with _lock:
        d = _window_props.get(window_id(w), {})
        if key is None:
            d.clear()
        else:
            d.pop(str(key).lower(), None)


# ----------------------------------------------------------------------------- Skin-Einstellungen (bleiben erhalten)

_SKIN_FILE = paths.DATA_DIR / 'skin.json'
_skin = None


def _skin_state():
    global _skin
    if _skin is None:
        try:
            d = json.loads(_SKIN_FILE.read_text('utf-8'))
        except Exception:                                      # noqa: BLE001
            d = {}
        _skin = {'strings': dict(d.get('strings') or {}), 'bools': set(d.get('bools') or [])}
    return _skin


def _skin_save():
    try:
        s = _skin_state()
        _SKIN_FILE.parent.mkdir(parents=True, exist_ok=True)
        _SKIN_FILE.write_text(json.dumps({'strings': s['strings'], 'bools': sorted(s['bools'])}, ensure_ascii=False), 'utf-8')
    except Exception:                                          # noqa: BLE001
        pass


def skin_string(name):
    with _lock:
        return _skin_state()['strings'].get(str(name).lower(), '')


def skin_set_string(name, value):
    with _lock:
        _skin_state()['strings'][str(name).lower()] = str(value)
        _skin_save()


def skin_has(name):
    with _lock:
        return str(name).lower() in _skin_state()['bools']


def skin_toggle(name, value=None):
    with _lock:
        b = _skin_state()['bools']
        k = str(name).lower()
        on = (k not in b) if value is None else bool(value)
        (b.add if on else b.discard)(k)
        _skin_save()


def skin_reset(name):
    with _lock:
        s = _skin_state()
        s['strings'].pop(str(name).lower(), None)
        s['bools'].discard(str(name).lower())
        _skin_save()


# ----------------------------------------------------------------------------- Hilfen

_DAYS = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag']
_MONTHS = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember']


def _profile():
    try:
        from . import xbmcaddon
        return (xbmcaddon.all_settings().get('platform_profile') or 'web').lower()
    except Exception:                                          # noqa: BLE001
        return 'web'


def _client():
    try:
        return context.current().client or {}
    except Exception:                                          # noqa: BLE001
        return {}


def _lan_ip():
    try:
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sk.connect(('10.255.255.255', 1))
        ip = sk.getsockname()[0]
        sk.close()
        return '' if ip.startswith('127.') else ip
    except Exception:                                          # noqa: BLE001
        return ''


def _fmt_time(fmt, t=None):
    """Kodi-Formate wie hh:mm:ss, hh:mm, dd-mm-yyyy (vereinfacht)."""
    t = time.localtime(t)
    out = str(fmt or '')
    for a, b in (('yyyy', '%Y'), ('yy', '%y'), ('mm', None), ('dd', '%d'), ('hh', '%H'), ('ss', '%S'), ('xx', '')):
        if b is not None:
            out = out.replace(a, time.strftime(b, t))
    # "mm" ist je nach Stellung Minute oder Monat: nach "hh:" Minute, sonst Monat
    out = re.sub(r'(?<=:)mm|mm(?=:)', time.strftime('%M', t), out)
    out = out.replace('mm', time.strftime('%m', t))
    return out


def _split_args(s):
    out, depth, cur, q = [], 0, [], ''
    for ch in s:
        if q:
            cur.append(ch)
            if ch == q:
                q = ''
        elif ch in '"\'':
            q = ch
            cur.append(ch)
        elif ch == '(':
            depth += 1
            cur.append(ch)
        elif ch == ')':
            depth -= 1
            cur.append(ch)
        elif ch == ',' and depth == 0:
            out.append(''.join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    out.append(''.join(cur).strip())
    return [a[1:-1] if len(a) >= 2 and a[0] == a[-1] and a[0] in '"\'' else a for a in out]


def _name_args(text):
    m = re.match(r'^([A-Za-z0-9_.]+)\s*(?:\((.*)\))?\s*$', text.strip(), re.S)
    if not m:
        return text.strip().lower(), []
    return m.group(1).lower(), (_split_args(m.group(2)) if m.group(2) is not None else [])


# ----------------------------------------------------------------------------- Infolabels

_INFO_PREFIXES = ('system.', 'window', 'skin.', 'container', 'listitem', 'player.', 'videoplayer.', 'control.', 'network.',
                  'weather.', 'library.', 'musicplayer.', 'pvr.', 'moviescout.', 'minikodi.')


def is_info(text):
    return str(text or '').strip().lower().startswith(_INFO_PREFIXES)


def info_label(label):
    raw = str(label or '').strip()
    low = raw.lower()
    if low in ('moviescout.client.widevine', 'minikodi.client.widevine'):
        return _client().get('widevine', '')
    m = re.match(r'^window(?:\(([^)]*)\))?\.property\((.*)\)$', raw, re.I | re.S)
    if m:
        return win_get(m.group(1) or 'home', m.group(2).strip('"\''))
    name, args = _name_args(raw)
    if name == 'skin.string':
        return skin_string(args[0]) if args else ''
    if name == 'skin.currenttheme' or name == 'skin.currentskin':
        return 'MovieScout'
    if name == 'system.date':
        t = time.localtime()
        if args:
            return _fmt_time(args[0])
        return '%s, %d. %s %d' % (_DAYS[t.tm_wday], t.tm_mday, _MONTHS[t.tm_mon - 1], t.tm_year)
    if name == 'system.time':
        return _fmt_time(args[0] if args else 'hh:mm')
    simple = {
        'system.builddate': 'Jan  1 2026', 'system.buildversion': '21.0 (MovieScout)',
        'system.buildversioncode': '21.0.0', 'system.friendlyname': 'MovieScout',
        'system.language': 'German', 'system.profilename': 'Master user',
        'system.screenwidth': str(_client().get('screen_w') or 1920), 'system.screenheight': str(_client().get('screen_h') or 1080),
        'system.screenresolution': '%sx%s @ 60.00000 Hz - Fullscreen' % (_client().get('screen_w') or 1920, _client().get('screen_h') or 1080),
        'system.kernelversion': 'Linux ' + platform.release(), 'system.osversioninfo': platform.platform(),
        'system.internetstate': 'Connected', 'system.freememory': '1024 MB', 'system.cpufrequency': '',
        'system.uptime': '', 'system.totaluptime': '',
        'container.folderpath': '', 'container.foldername': '', 'container.pluginname': 'plugin.video.moviescout',
        'container.pluginname ': '', 'container.content': '', 'container.viewmode': '', 'container.sortmethod': '',
        'container.numitems': '', 'container.currentpage': '', 'container.totalpages': '',
        'network.ipaddress': _lan_ip() if name == 'network.ipaddress' else '',
    }
    if name in simple:
        return simple[name]
    if name.startswith('listitem.') or name.startswith('container.listitem') or name.startswith('container(') :
        p = context.current().params or {}
        key = name.split('.')[-1]
        alias = {'label': 'title', 'label2': '', 'title': 'title', 'plot': 'plot', 'year': 'year', 'season': 'season',
                 'episode': 'episode', 'filenameandpath': 'url', 'path': 'url', 'folderpath': 'url', 'thumb': 'poster',
                 'icon': 'poster', 'tvshowtitle': 'parent_title', 'imdbnumber': 'imdb'}
        return str(p.get(alias.get(key, key), '') or '')
    if name.startswith('control.getlabel') or name.startswith('player') or name.startswith('videoplayer') \
            or name.startswith('musicplayer') or name.startswith('weather.') or name.startswith('pvr.'):
        return ''
    if name == 'addon.setting' or name.startswith('system.addonversion'):
        return ''
    return ''


# ----------------------------------------------------------------------------- Bedingungen

_KNOWN_ADDONS_PREFIX = ('inputstream.', 'script.module.', 'resource.language.', 'xbmc.', 'kodi.')


def _has_addon(aid):
    a = str(aid or '').lower()
    if a.startswith(_KNOWN_ADDONS_PREFIX) or a in ('skin.moviescout', 'plugin.video.moviescout'):
        return True
    try:
        from . import paths
        return bool(aid) and (paths.DATA_DIR / 'addons' / str(aid) / 'moviescout-addon.json').is_file()    # selbst installierte Addons (auch script.*)
    except Exception:                                          # noqa: BLE001
        return False


def _arg_value(a):
    """Argument einer Bedingung: Infolabel auswerten, sonst Text."""
    if is_info(a):
        return info_label(a)
    return a


def _atom(text):
    t = text.strip()
    low = t.lower()
    if low in ('true', '1', 'yes', 'on'):
        return True
    if low in ('false', '0', 'no', 'off', ''):
        return False
    c = _client()
    if 'client.android' in low and ('moviescout.' in low or 'minikodi.' in low):
        return bool(c.get('android'))
    name, args = _name_args(t)
    prof = _profile()
    plat = {'system.platform.android': prof == 'android', 'system.platform.windows': prof == 'windows',
            'system.platform.linux': prof in ('web', 'linux'), 'system.platform.linux.raspberrypi': False,
            'system.platform.osx': False, 'system.platform.darwin': False, 'system.platform.ios': False,
            'system.platform.tvos': False, 'system.platform.uwp': False, 'system.platform.xbox': False}
    if name in plat:
        return plat[name]
    if name in ('system.hasaddon', 'system.addonisenabled'):
        return _has_addon(args[0]) if args else False
    if name == 'system.internetstate':
        return True
    if name in ('system.canreboot', 'system.canshutdown', 'system.cansuspend', 'system.canhibernate', 'system.hasalarm',
                'system.hasmediadvd', 'system.hasloginscreen', 'system.screensaveractive', 'system.idletime'):
        return False
    if name == 'skin.hassetting':
        return skin_has(args[0]) if args else False
    if name == 'skin.string':
        v = skin_string(args[0]) if args else ''
        return (v == _arg_value(args[1])) if len(args) > 1 else bool(v)
    if name == 'skin.hastheme':
        return True
    if name in ('string.isempty', 'string.isempty'):
        return not str(_arg_value(args[0]) if args else '').strip()
    if name == 'string.isequal':
        return len(args) > 1 and str(_arg_value(args[0])).lower() == str(_arg_value(args[1])).lower()
    if name == 'string.contains':
        return len(args) > 1 and str(_arg_value(args[1])).lower() in str(_arg_value(args[0])).lower()
    if name == 'string.startswith':
        return len(args) > 1 and str(_arg_value(args[0])).lower().startswith(str(_arg_value(args[1])).lower())
    if name == 'string.endswith':
        return len(args) > 1 and str(_arg_value(args[0])).lower().endswith(str(_arg_value(args[1])).lower())
    if name in ('integer.isgreater', 'integer.isless', 'integer.isequal', 'integer.isgreaterorequal', 'integer.islessorequal'):
        try:
            a, b = int(float(_arg_value(args[0]) or 0)), int(float(_arg_value(args[1]) or 0))
        except (ValueError, IndexError):
            return False
        return {'integer.isgreater': a > b, 'integer.isless': a < b, 'integer.isequal': a == b,
                'integer.isgreaterorequal': a >= b, 'integer.islessorequal': a <= b}[name]
    if name in ('window.isvisible', 'window.isactive', 'window.ismedia', 'window.isdialogtopmost'):
        return bool(args) and str(args[0]).lower() in ('home', '10000')
    if name.startswith(('player.', 'videoplayer.', 'musicplayer.', 'container.', 'listitem.', 'control.', 'pvr.', 'library.',
                        'weather.', 'visualisation.', 'playlist.', 'slideshow.', 'system.')):
        return False
    return False


def _tokens(s):
    """Zerlegt eine Bedingung in Operatoren ( ) ! + | und Atome. Klammern direkt hinter einem Namen gehören zum Atom
    (Window(Home).Property(x)), alleinstehende Klammern gruppieren."""
    out, i, n = [], 0, len(s)
    while i < n:
        ch = s[i]
        if ch.isspace():
            i += 1
            continue
        if ch in '()!+|':
            out.append(('op', ch))
            i += 1
            continue
        j = i
        while j < n and s[j] not in '!+|)':
            if s[j] == '(':
                depth = 0
                while j < n:
                    if s[j] == '(':
                        depth += 1
                    elif s[j] == ')':
                        depth -= 1
                        if depth == 0:
                            j += 1
                            break
                    j += 1
                continue
            j += 1
        out.append(('atom', s[i:j].strip()))
        i = j
    return out


def cond_visible(expr):
    toks = _tokens(str(expr or ''))
    i = [0]

    def peek():
        return toks[i[0]] if i[0] < len(toks) else (None, None)

    def take():
        t = peek()
        i[0] += 1
        return t

    def p_or():
        v = p_and()
        while peek() == ('op', '|'):
            take()
            r = p_and()
            v = v or r
        return v

    def p_and():
        v = p_not()
        while peek() == ('op', '+'):
            take()
            r = p_not()
            v = v and r
        return v

    def p_not():
        if peek() == ('op', '!'):
            take()
            return not p_not()
        return p_prim()

    def p_prim():
        k, v = take()
        if k == 'op' and v == '(':
            r = p_or()
            if peek() == ('op', ')'):
                take()
            return r
        if k == 'atom':
            return _atom(v)
        return False
    try:
        return bool(p_or()) if toks else False
    except Exception:                                          # noqa: BLE001
        _log.debug('Bedingung nicht auswertbar: %s', expr)
        return False


# ----------------------------------------------------------------------------- Eingebaute Befehle

def builtin(function):
    """xbmc.executebuiltin(...) - nur was sinnvoll in der Engine geht; der Rest wird ruhig ignoriert."""
    name, args = _name_args(str(function or ''))
    a = args
    try:
        if name == 'skin.setstring' and a:
            skin_set_string(a[0], a[1] if len(a) > 1 else '')
        elif name == 'skin.setbool' and a:
            skin_toggle(a[0], True)
        elif name == 'skin.reset' and a:
            skin_reset(a[0])
        elif name == 'skin.togglesetting' and a:
            skin_toggle(a[0])
        elif name == 'skin.setnumeric' and a:
            skin_set_string(a[0], a[1] if len(a) > 1 else '0')
        elif name == 'setproperty' and len(a) >= 2:
            win_set(a[2] if len(a) > 2 else 'home', a[0], a[1])
        elif name == 'clearproperty' and a:
            win_clear(a[1] if len(a) > 1 else 'home', a[0])
        elif name == 'notification' and a:
            context.current().note('info', a[0], a[1] if len(a) > 1 else '')
        elif name in ('playmedia', 'playerdo') and a and name == 'playmedia':
            context.current().resolved.append({'path': a[0], 'listitem': None})
        elif name == 'showpicture' and a:
            target = a[0].strip()
            if target.startswith(('http://', 'https://')):
                context.current().ui = {'image': target}
            else:
                from engine import addonhost
                import os as _os
                if _os.path.isfile(target) and target.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp')):
                    tok = addonhost.local_file_url(target)              # msfile://<token>/<name> -> Adresse der Engine
                    context.current().ui = {'image': '/api/localfile/' + tok[len('msfile://'):]}
        elif name == 'container.refresh':
            context.current().ui = {'refresh': True}
        elif name in ('container.update', 'activatewindow', 'replacewindow') and a:
            args = [x for x in a]
            if name != 'container.update':
                args = args[1:]                                  # ActivateWindow(videos,plugin://…,return): erstes Argument ist das Fenster
            if args and args[-1].strip().lower() in ('replace', 'return'):
                args = args[:-1]
            target = ','.join(args).strip()
            if target.lower().startswith('plugin://'):
                context.current().ui = {'goto': target}
            elif name == 'container.update':
                context.current().ui = {'refresh': True}
        elif name in ('runscript', 'runaddon') and a:
            from engine import addonhost                       # RunScript(script.x, arg …) aus einem anderen Addon: Programm starten
            addonhost.run_script(a[0], a[1:])
        elif name == 'sleep' and a:
            time.sleep(min(5.0, max(0.0, float(a[0] or 0) / 1000.0)))
        else:
            _log.debug('executebuiltin ignoriert: %s', function)
    except Exception:                                          # noqa: BLE001
        _log.debug('executebuiltin fehlgeschlagen: %s', function, exc_info=True)


# ----------------------------------------------------------------------------- JSON-RPC (Teilmenge)

def jsonrpc(request_text):
    try:
        req = json.loads(request_text)
    except Exception:                                          # noqa: BLE001
        return json.dumps({'jsonrpc': '2.0', 'error': {'code': -32700, 'message': 'Parse error'}, 'id': None})
    if isinstance(req, list):
        return json.dumps([json.loads(jsonrpc(json.dumps(r))) for r in req])
    rid, method, p = req.get('id'), str(req.get('method') or ''), req.get('params') or {}
    res = {}
    if method == 'JSONRPC.Version':
        res = {'version': {'major': 13, 'minor': 5, 'patch': 0}}
    elif method == 'JSONRPC.Ping':
        res = 'pong'
    elif method == 'Application.GetProperties':
        res = {'name': 'Kodi', 'version': {'major': 21, 'minor': 0, 'revision': 'MovieScout', 'tag': 'stable'},
               'volume': 100, 'muted': False, 'language': 'de_de'}
    elif method == 'Addons.GetAddonDetails':
        aid = str(p.get('addonid') or '')
        res = {'addon': {'addonid': aid, 'enabled': _has_addon(aid), 'installed': _has_addon(aid), 'name': aid,
                         'version': '1.0.0', 'type': 'xbmc.python.script'}} if _has_addon(aid) else {}
        if not _has_addon(aid):
            return json.dumps({'jsonrpc': '2.0', 'error': {'code': -32602, 'message': 'Invalid params.'}, 'id': rid})
    elif method == 'Addons.GetAddons':
        res = {'addons': [], 'limits': {'start': 0, 'end': 0, 'total': 0}}
    elif method == 'Addons.SetAddonEnabled':
        res = 'OK'
    elif method == 'Settings.GetSettingValue':
        sid = str(p.get('setting') or '')
        res = {'value': {'locale.language': 'resource.language.de_de', 'locale.country': 'Deutschland',
                         'videoplayer.usedisplayasclock': False}.get(sid)}
    elif method == 'XBMC.GetInfoLabels':
        res = {l: info_label(l) for l in (p.get('labels') or [])}
    elif method == 'XBMC.GetInfoBooleans':
        res = {l: cond_visible(l) for l in (p.get('booleans') or [])}
    elif method == 'Player.GetActivePlayers':
        res = []
    elif method in ('Files.GetDirectory', 'VideoLibrary.GetMovies', 'VideoLibrary.GetTVShows', 'VideoLibrary.GetEpisodes'):
        res = {'files': [], 'limits': {'start': 0, 'end': 0, 'total': 0}}
    elif method == 'GUI.ShowNotification':
        context.current().note('info', str(p.get('title') or ''), str(p.get('message') or ''))
        res = 'OK'
    return json.dumps({'jsonrpc': '2.0', 'result': res, 'id': rid})
