# -*- coding: utf-8 -*-
"""Kodi xbmcaddon-Modul (Emulation) - Einstellungen werden in userData/settings.json gespeichert."""
import json
import os
import re
import threading

from . import paths, xmlfix

_lock = threading.Lock()

# xShip prueft per HEAD-Anfrage, ob Scraper-Seiten erreichbar sind, und laedt
# Scraper mit Status != 'ok' gar nicht. Viele Seiten antworten auf HEAD mit 403/405
# (oder der Check laeuft in ein Zeitlimit) -> es blieb nur Vavoo uebrig. Die
# Scraper selbst kommen mit Fehlern klar, daher gilt der Status hier immer als 'ok'.
_HEALTH_KEY = re.compile(r'^provider\.[\w-]+\.health$')

DEFAULTS = {
    'general.german_only': 'true',
    'filter_german': 'true',
    'hide_tv_films': 'false',
    'api.tmdb': '',
    'platform_profile': 'web',
    'rakuten_quality': 'auto',
}


def _resolveurl_default(sid):
    """Standardwerte, die bei Kodi aus ResolveURLs settings.xml kommen."""
    if sid.endswith('_enabled'):
        return 'true'
    if sid.endswith('_priority'):
        return '100'
    if sid == 'allow_popups' or sid == 'allow_universal':
        return 'false'
    if sid in ('use_cache', 'cache_enabled'):
        return 'false'
    return ''


def _file(addon_id):
    return paths.addon_dir(addon_id) / 'settings.json'


def _load(addon_id):
    try:
        with open(_file(addon_id), 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


ENGINE_ID = 'plugin.video.moviescout'


def store_id(addon_id):
    """Unter welchem Namen die Einstellungen/der Profilordner eines installierten Addons liegen. Das Kodi-Addon „MovieScout“ trägt dieselbe
    Kennung wie die Engine selbst - es bekommt einen eigenen Ordner (ao.<id>), damit es weder die Einstellungen der Engine liest noch überschreibt."""
    return 'ao.' + addon_id if addon_id == ENGINE_ID else addon_id


def all_settings(addon_id='plugin.video.moviescout'):
    d = dict(DEFAULTS)
    d.update(_load(addon_id))
    return d


def save_settings(values, addon_id='plugin.video.moviescout'):
    with _lock:
        cur = _load(addon_id)
        cur.update({str(k): str(v) for k, v in (values or {}).items()})
        f = _file(addon_id)
        tmp = str(f) + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:                 # atomar: Leser sehen nie eine halb geschriebene Datei (Dienste schreiben aus vielen Threads)
            json.dump(cur, fh, ensure_ascii=False, indent=1)
        os.replace(tmp, f)
    return all_settings(addon_id)


def _addon_defaults(addon_id):
    """Standardwerte aus der settings.xml eines installierten Kodi-Addons (nur wenn der Nutzer nichts gespeichert hat)."""
    p = paths.DATA_DIR / 'addons' / addon_id / 'resources' / 'settings.xml'
    out = {}
    try:
        import xml.etree.ElementTree as ET
        for el in xmlfix.parse_file(p).iter('setting'):
            sid = el.get('id')
            if not sid:
                continue
            d = el.get('default')
            if d is None:
                dn = el.find('default')
                d = dn.text if dn is not None and dn.text is not None else None
            if d is not None:
                if (el.get('type') or '').lower() in ('boolean', 'bool') and d.strip().lower() in ('true', 'false'):
                    d = d.strip().lower()                       # Kodi liefert Schalter immer klein geschrieben („True“ in der settings.xml → 'true')
                out[sid] = d
    except Exception:
        pass
    return out


def _addon_meta(addon_id):
    try:
        with open(paths.DATA_DIR / 'addons' / addon_id / 'moviescout-addon.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


_STR_CACHE = {}
# Addons mit eigener Kodi-Oberfläche (WindowXML-Skin) können hier nicht gezeigt werden: Schalter dafür gelten als „aus“,
# dann zeigt das Addon seine normalen Listen (Verzeichnisse).
_OWN_UI = __import__('re').compile(r'(^|_)(use_)?(custom_)?(skin|window|gui)(_menu|_ui)?$|skin_menu|use_custom_(skin|window|ui|gui)|(^|_)(own|eigene[rs]?)_(skin|ui|menu)', __import__('re').I)


def _strings(addon_id):
    """Texte aus resources/language/*/strings.po eines installierten Addons (Deutsch vor Englisch)."""
    if addon_id in _STR_CACHE:
        return _STR_CACHE[addon_id]
    import re
    out = {}
    base = paths.DATA_DIR / 'addons' / addon_id / 'resources' / 'language'
    for lang in ('resource.language.en_gb', 'resource.language.de_de'):       # später gelesen = gewinnt
        f = base / lang / 'strings.po'
        try:
            text = f.read_text('utf-8-sig')
        except Exception:
            continue
        for m in re.finditer(r'msgctxt\s+"#(\d+)"\s*\nmsgid\s+"((?:[^"\\]|\\.)*)"\s*\nmsgstr\s+"((?:[^"\\]|\\.)*)"', text):
            val = m.group(3) or m.group(2)
            if val:
                out[int(m.group(1))] = val.replace('\\"', '"').replace('\\n', '\n')
    _STR_CACHE[addon_id] = out
    return out


class Addon:
    def __init__(self, id=None):
        if not id:
            from . import context
            id = getattr(context.current(), 'addon_id', '') or 'plugin.video.moviescout'
        self._id = id
        from . import context
        hosted = id == ENGINE_ID and getattr(context.current(), 'addon_id', '') == ENGINE_ID and bool(_addon_meta(id))    # läuft gerade das installierte Kodi-Addon gleichen Namens?
        self._meta = _addon_meta(id) if (id != ENGINE_ID or hosted) else {}
        self._sid = store_id(id) if hosted else id

    def getAddonInfo(self, info_type):
        t = str(info_type)
        if t in ('profile', 'addon_data'):
            return str(paths.addon_dir(self._sid)) + os.sep         # wie Kodi: mit Schrägstrich am Ende (Addons hängen Dateinamen direkt an)
        m = self._meta
        if m:
            base = paths.DATA_DIR / 'addons' / self._id
            if t in ('icon', 'fanart'):
                f = m.get(t) or ''
                return str(base / f) if f else ''
            if t == 'path':
                return str(base)
            if t == 'id':
                return self._id
            if t == 'name':
                return m.get('name', self._id)
            if t == 'author':
                return m.get('author', '')
            if t == 'version':
                return m.get('version', '1.0.0')
            if t in ('summary', 'description'):
                return m.get('summary', '')
            return ''
        if t == 'icon' or t == 'fanart':
            return ''
        if t == 'path':
            return str(paths.ROOT)
        if t == 'id':
            return self._id
        if t in ('name', 'author'):
            return 'MovieScout'
        if t == 'version':
            return '19.0.0' if self._id.startswith('xbmc.') else '1.0.0'
        return ''

    def getSetting(self, setting_id):
        sid = str(setting_id)
        if self._meta and _OWN_UI.search(sid):
            return 'false'
        if self._meta and _HEALTH_KEY.match(sid):
            return 'ok'
        if self._id == 'plugin.video.xship':
            # Domain-Check abgeschaltet: er schrieb Domains/Scraper-Dateien nach Zufallsantworten um. Domains kommen aus den Scraper-Dateien.
            if sid == 'lastDomainCheck':
                return '9999999999'
            if re.match(r'^provider\.[\w-]+\.domain$', sid):
                return ''
            if sid == 'scrapers.timeout':   # 17 Scraper gleichzeitig brauchen auf dem Handy länger als die üblichen 35 s
                try:
                    return str(max(60, int(float(all_settings(self._sid).get(sid) or 0))))
                except ValueError:
                    return '60'
        val = all_settings(self._sid).get(sid)
        if val is not None:
            return val
        if self._id == 'script.module.resolveurl':
            return _resolveurl_default(sid)
        if self._meta:
            d = _addon_defaults(self._id).get(sid)
            if d is not None:
                return d
        return ''

    def getSettingBool(self, setting_id):
        return self.getSetting(setting_id).lower() in ('true', '1', 'yes')

    def getSettingInt(self, setting_id):
        try:
            return int(float(self.getSetting(setting_id) or 0))
        except ValueError:
            return 0

    def getSettingNumber(self, setting_id):
        try:
            return float(self.getSetting(setting_id) or 0)
        except ValueError:
            return 0.0

    def getSettingString(self, setting_id):
        return self.getSetting(setting_id)

    def setSetting(self, setting_id, value):
        save_settings({setting_id: value}, self._sid)

    setSettingString = setSetting

    def setSettingBool(self, setting_id, value):
        self.setSetting(setting_id, 'true' if value else 'false')

    def setSettingInt(self, setting_id, value):
        self.setSetting(setting_id, int(value))

    setSettingNumber = setSettingInt

    def getLocalizedString(self, id):
        if not self._meta:
            return ''
        return _strings(self._id).get(int(id), '') if str(id).lstrip('-').isdigit() else ''

    def openSettings(self):
        pass
