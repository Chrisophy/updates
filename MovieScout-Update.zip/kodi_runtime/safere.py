# -*- coding: utf-8 -*-
"""Schutz vor hängenden Suchmustern (reguläre Ausdrücke) in Kodi-Addons.

Kodi-Addons werten Webseiten oft mit Mustern wie '<div.*?<a.*?alt="(.*?)".*?</noscript>' aus. Ändert die Seite ihr Aussehen, passt das Muster nicht mehr und
Python rechnet minutenlang (katastrophales Backtracking). Ein solcher Aufruf hält den ganzen Interpreter an: die Engine antwortet nicht mehr, die App
lässt sich nur noch hart schließen. Hier werden Aufrufe auf großen Texten in einem Hilfsprozess ausgeführt, der bei Zeitüberschreitung oder Abbruch
beendet wird. Kleine Texte laufen wie bisher im eigenen Prozess (schnell).

    sys.modules['re'] = safere.module()      # während ein Addon läuft
"""
import os
import pickle
import queue
import re as _re
import select
import signal
import struct
import subprocess
import sys
import threading
import time
import types
import warnings

THRESHOLD = int(os.environ.get('MOVIESCOUT_RE_MIN', '6000'))     # Texte ab dieser Länge laufen im Hilfsprozess
TIMEOUT = float(os.environ.get('MOVIESCOUT_RE_TIMEOUT', '12'))   # Sekunden pro Aufruf
_WORKER = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_rework.py')
_NA = object()
_lock = threading.Lock()
_proc = None
_ok_once = False
_broken = False
_cancel_probe = None            # Funktion: True, wenn der laufende Aufruf abgebrochen wurde (Vorgabe: Kontext des aufrufenden Threads)


class RegexTimeout(RuntimeError):
    pass


_MSG = ('Ein Suchmuster des Addons hat zu lange gerechnet und wurde abgebrochen. Vermutlich hat die Webseite ihr Format geändert und das Addon ist '
        'dafür veraltet.')


def _kill():
    global _proc
    p, _proc = _proc, None
    if p is not None:
        try:
            p.kill()
        except OSError:
            pass
        try:
            p.wait(2)
        except Exception:                                  # noqa: BLE001
            pass


def _spawn():
    global _proc, _broken
    kw = {}
    if os.name == 'nt':
        kw['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    try:
        _proc = subprocess.Popen([sys.executable, '-I', '-S', _WORKER], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, **kw)
    except Exception:                                      # noqa: BLE001
        _proc = None
        _broken = True                                     # kein Hilfsprozess möglich (z. B. eingebettetes Python): wie früher im eigenen Prozess
    return _proc


def _readn(f, n):
    buf = b''
    while len(buf) < n:
        c = f.read(n - len(buf))
        if not c:
            raise EOFError
        buf += c
    return buf


def _compute(req):
    """Die eigentliche Auswertung (läuft im Hilfsprozess oder im abgespaltenen Kindprozess)."""
    op, pat, fl, text = req[:4]
    a = req[4:]
    p = _re.compile(pat, fl)
    if op == 'findall':
        return p.findall(text, *a)
    if op in ('search', 'match', 'fullmatch'):
        m = getattr(p, op)(text, *a)
        return None if m is None else m.start()
    if op == 'finditer':
        return [m.start() for m in p.finditer(text, *a)]
    if op == 'subn':
        return p.subn(a[0], text, a[1])
    if op == 'split':
        return p.split(text, a[0])
    if op == 'sleep':                                      # nur für den Selbsttest
        time.sleep(a[0])
        return None
    raise ValueError(op)


def _proc_usable():
    exe = sys.executable or ''
    return bool(exe) and os.path.basename(exe).lower().startswith('python') and os.path.exists(exe)


_MODE = os.environ.get('MOVIESCOUT_RE_MODE', '')      # 'fork' | 'proc' | 'local' ; leer = automatisch


def _mode():
    global _MODE
    if not _MODE:
        # Android-App (Chaquopy): kein Python-Programm zum Starten, aber fork() geht. Windows: kein fork, dafür ein echtes python.exe.
        _MODE = 'fork' if (os.name == 'posix' and hasattr(os, 'fork')) else ('proc' if _proc_usable() else 'local')
    return _MODE


def _cancelled():
    try:
        if _cancel_probe is not None:
            return bool(_cancel_probe())
        from . import context
        c = context.peek()
        return c is not None and c.cancelled.is_set()
    except Exception:                                      # noqa: BLE001
        return False


def _remote_fork(req):
    """Wie _remote_proc, aber mit fork(): das Kind erbt den Text ohne Kopie, rechnet und wird bei Zeitüberschreitung/Abbruch mit SIGKILL beendet."""
    global _ok_once
    r, w = os.pipe()
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            pid = os.fork()
    except OSError:
        os.close(r)
        os.close(w)
        return _NA
    if pid == 0:                                           # Kind: nur rechnen, schreiben, sofort beenden (keine atexit-Handler des Elternprozesses)
        code = 1
        try:
            os.close(r)
            try:
                out = ('ok', _compute(req))
            except _re.error as e:
                out = ('re', str(e))
            except BaseException as e:                     # noqa: BLE001
                out = ('exc', repr(e))
            mv = memoryview(pickle.dumps(out, 4))
            while len(mv):
                mv = mv[os.write(w, mv):]
            code = 0
        finally:
            os._exit(code)
    os.close(w)
    chunks, end, done = [], time.monotonic() + TIMEOUT, False
    try:
        while True:
            if select.select([r], [], [], 0.3)[0]:
                c = os.read(r, 1 << 16)
                if not c:
                    done = True
                    break
                chunks.append(c)
            elif _cancelled() or time.monotonic() > end:
                break
            if time.monotonic() > end:
                break
    finally:
        os.close(r)
        if not done:
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
        try:
            for _ in range(50):                            # Kind einsammeln (kein Zombie)
                if os.waitpid(pid, os.WNOHANG)[0]:
                    break
                time.sleep(0.02)
        except OSError:
            pass
    if not done:
        raise RegexTimeout(_MSG)
    try:
        kind, val = pickle.loads(b''.join(chunks))
    except Exception:                                      # noqa: BLE001
        if _ok_once:
            raise RegexTimeout(_MSG)                       # Kind ist ohne Ergebnis gestorben (z. B. zu wenig Speicher)
        return _NA                                         # beim allerersten Mal: Verfahren auf diesem Gerät nicht nutzbar
    _ok_once = True
    if kind == 're':
        raise _re.error(val)
    if kind != 'ok':
        raise RuntimeError(val)
    return val


STATS = {'calls': 0, 'timeouts': 0, 'selftest': 'nicht gelaufen'}


def status():
    return {'mode': _mode(), 'calls': STATS['calls'], 'timeouts': STATS['timeouts'], 'selftest': STATS['selftest']}


def selftest():
    """Prüft einmal beim Start, ob der Schutz auf diesem Gerät wirklich greift: ein Auftrag muss ein Ergebnis liefern, ein hängender Auftrag muss
    nach dem Zeitlimit beendet werden. Greift er nicht, wird auf ein anderes Verfahren umgestellt (fork -> Hilfsprozess -> ohne)."""
    global TIMEOUT, _MODE
    for _ in range(3):
        m = _mode()
        if m == 'local':
            break
        old, ok = TIMEOUT, False
        try:
            r = _remote('findall', 'a', 0, 'aaa')
            if r == ['a', 'a', 'a']:
                TIMEOUT = 1.0
                t0 = time.monotonic()
                try:
                    _remote('sleep', '', 0, '', 8)
                except RegexTimeout:
                    ok = time.monotonic() - t0 < 4
        except Exception as e:                             # noqa: BLE001
            STATS['selftest'] = 'Fehler (%s): %s' % (m, e)
        finally:
            TIMEOUT = old
        if ok:
            STATS['selftest'] = 'ok (%s)' % m
            return True
        STATS['selftest'] = 'Verfahren %s greift nicht' % m
        _MODE = 'proc' if (m == 'fork' and _proc_usable()) else 'local'
    STATS['selftest'] = (STATS['selftest'] + ' – ohne Schutz').strip()
    return False


def _remote(*req):
    """Ergebnis aus geschütztem Rechenweg oder _NA (nicht verfügbar -> lokal rechnen). Wirft RegexTimeout bei Zeitüberschreitung/Abbruch."""
    STATS['calls'] += 1
    try:
        return _remote2(*req)
    except RegexTimeout:
        STATS['timeouts'] += 1
        raise


def _remote2(*req):
    global _MODE
    for _ in range(3):
        m = _mode()
        if m == 'local':
            return _NA
        if m == 'fork':
            r = _remote_fork(req)
            if r is _NA:
                _MODE = 'proc' if _proc_usable() else 'local'
                continue
            return r
        return _remote_proc(*req)
    return _NA


def _remote_proc(*req):
    """Ergebnis aus dem Hilfsprozess oder _NA (nicht verfügbar -> lokal rechnen). Wirft RegexTimeout bei Zeitüberschreitung/Abbruch."""
    global _ok_once, _broken
    if _broken:
        return _NA
    data = pickle.dumps(req, 4)
    with _lock:
        p = _proc if (_proc is not None and _proc.poll() is None) else _spawn()
        if p is None:
            return _NA
        res = queue.Queue(1)
        try:
            p.stdin.write(struct.pack('<I', len(data)) + data)
            p.stdin.flush()
        except (OSError, ValueError):
            _kill()
            if not _ok_once:
                _broken = True
                return _NA
            raise RegexTimeout(_MSG)

        def rd():
            try:
                n = struct.unpack('<I', _readn(p.stdout, 4))[0]
                res.put(pickle.loads(_readn(p.stdout, n)))
            except Exception as e:                         # noqa: BLE001
                res.put(e)
        threading.Thread(target=rd, daemon=True, name='re-reader').start()
        end = time.monotonic() + TIMEOUT
        while True:
            try:
                r = res.get(timeout=0.3)
                break
            except queue.Empty:
                cancelled = False
                try:
                    if _cancel_probe is not None:
                        cancelled = bool(_cancel_probe())
                    else:
                        from . import context
                        c = context.peek()
                        cancelled = c is not None and c.cancelled.is_set()
                except Exception:                          # noqa: BLE001
                    pass
                if cancelled or time.monotonic() > end:
                    _kill()
                    raise RegexTimeout(_MSG)
        if isinstance(r, Exception):
            _kill()
            if not _ok_once:
                _broken = True
                return _NA
            raise RegexTimeout(_MSG)
        _ok_once = True
    kind, val = r
    if kind == 're':
        raise _re.error(val)
    if kind != 'ok':
        raise RuntimeError(val)
    return val


def _big(s):
    return isinstance(s, (str, bytes)) and len(s) >= THRESHOLD


def _unpack(pattern, flags=0):
    if isinstance(pattern, _SafePattern):
        pattern = pattern._p
    if isinstance(pattern, _re.Pattern):
        return pattern.pattern, pattern.flags
    return pattern, flags


class _SafePattern:
    """Wie re.Pattern, rechnet aber große Texte im Hilfsprozess."""

    def __init__(self, p):
        self._p = p

    @property
    def __class__(self):                                   # isinstance(x, re.Pattern) bleibt wahr
        return _re.Pattern

    def __getattr__(self, n):
        return getattr(self._p, n)

    def __repr__(self):
        return repr(self._p)

    def __eq__(self, o):
        return self._p == (o._p if isinstance(o, _SafePattern) else o)

    def __hash__(self):
        return hash(self._p)

    def __copy__(self):
        return self

    def __deepcopy__(self, memo):
        return self

    def __reduce__(self):
        return self._p.__reduce__()

    def search(self, string, pos=0, endpos=sys.maxsize):
        if _big(string):
            s = _remote('search', self._p.pattern, self._p.flags, string, pos, endpos)
            if s is not _NA:
                return None if s is None else self._p.match(string, s, endpos)
        return self._p.search(string, pos, endpos)

    def match(self, string, pos=0, endpos=sys.maxsize):
        if _big(string):
            s = _remote('match', self._p.pattern, self._p.flags, string, pos, endpos)
            if s is not _NA:
                return None if s is None else self._p.match(string, pos, endpos)
        return self._p.match(string, pos, endpos)

    def fullmatch(self, string, pos=0, endpos=sys.maxsize):
        if _big(string):
            s = _remote('fullmatch', self._p.pattern, self._p.flags, string, pos, endpos)
            if s is not _NA:
                return None if s is None else self._p.fullmatch(string, pos, endpos)
        return self._p.fullmatch(string, pos, endpos)

    def findall(self, string, pos=0, endpos=sys.maxsize):
        if _big(string):
            r = _remote('findall', self._p.pattern, self._p.flags, string, pos, endpos)
            if r is not _NA:
                return r
        return self._p.findall(string, pos, endpos)

    def finditer(self, string, pos=0, endpos=sys.maxsize):
        if _big(string):
            r = _remote('finditer', self._p.pattern, self._p.flags, string, pos, endpos)
            if r is not _NA:
                return (m for m in (self._p.match(string, s, endpos) for s in r) if m is not None)
        return self._p.finditer(string, pos, endpos)

    def subn(self, repl, string, count=0):
        if _big(string) and not callable(repl):
            r = _remote('subn', self._p.pattern, self._p.flags, string, repl, count)
            if r is not _NA:
                return tuple(r)
        return self._p.subn(repl, string, count)

    def sub(self, repl, string, count=0):
        return self.subn(repl, string, count)[0]

    def split(self, string, maxsplit=0):
        if _big(string):
            r = _remote('split', self._p.pattern, self._p.flags, string, maxsplit)
            if r is not _NA:
                return r
        return self._p.split(string, maxsplit)


def _pat(pattern, flags):
    if isinstance(pattern, _SafePattern):
        return pattern
    return _SafePattern(_re.compile(pattern, flags))


class _SafeRe(types.ModuleType):
    """Ersatz für das Modul re: alles wie gehabt, nur die Auswertefunktionen sind geschützt."""

    def __getattr__(self, name):
        return getattr(_re, name)

    def __dir__(self):
        return dir(_re)

    def compile(self, pattern, flags=0):
        return _pat(pattern, flags)

    def search(self, pattern, string, flags=0):
        return _pat(pattern, flags).search(string)

    def match(self, pattern, string, flags=0):
        return _pat(pattern, flags).match(string)

    def fullmatch(self, pattern, string, flags=0):
        return _pat(pattern, flags).fullmatch(string)

    def findall(self, pattern, string, flags=0):
        return _pat(pattern, flags).findall(string)

    def finditer(self, pattern, string, flags=0):
        return _pat(pattern, flags).finditer(string)

    def sub(self, pattern, repl, string, count=0, flags=0):
        return _pat(pattern, flags).sub(repl, string, count)

    def subn(self, pattern, repl, string, count=0, flags=0):
        return _pat(pattern, flags).subn(repl, string, count)

    def split(self, pattern, string, maxsplit=0, flags=0):
        return _pat(pattern, flags).split(string, maxsplit)


_MOD = None


def module():
    global _MOD
    if _MOD is None:
        _MOD = _SafeRe('re')
        _MOD.__doc__ = _re.__doc__
    return _MOD


def shutdown():
    with _lock:
        _kill()
