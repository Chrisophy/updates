# -*- coding: utf-8 -*-
"""Ersatz für script.module.inputstreamhelper (Emulation).

Kodi-Addons rufen vor DRM-/Adaptiv-Streams auf:

    import inputstreamhelper
    helper = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
    if helper.check_inputstream():
        li.setProperty('inputstream', helper.inputstream_addon)
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        li.setProperty('inputstream.adaptive.license_key', '…')

In MovieScout spielt der Browser/Player des Nutzers ab. check_inputstream() ist deshalb True, außer ein DRM-System wird
verlangt, das der abspielende Browser nicht kann (Widevine-Stufe 'NONE'). Die Eigenschaften des ListItems wertet die
Engine selbst aus (normalize.hoster_from_resolved).
"""
import logging

from . import context

_log = logging.getLogger('kodi.isa')

DRM_SCHEMES = {
    'widevine': 'com.widevine.alpha',
    'com.widevine.alpha': 'com.widevine.alpha',
    'playready': 'com.microsoft.playready',
    'com.microsoft.playready': 'com.microsoft.playready',
    'clearkey': 'org.w3.clearkey',
    'org.w3.clearkey': 'org.w3.clearkey',
    'fairplay': 'com.apple.fps.1_0',
}
PROTOCOLS = ('mpd', 'ism', 'hls', 'rtmp')


class Helper:
    def __init__(self, protocol, drm=None):
        self.protocol = str(protocol or '').lower()
        self.drm = DRM_SCHEMES.get(str(drm or '').lower(), str(drm or '')) if drm else ''
        # RTMP braucht inputstream.rtmp, alles Übrige inputstream.adaptive (wie im Original)
        self.inputstream_addon = 'inputstream.rtmp' if self.protocol == 'rtmp' else 'inputstream.adaptive'

    # -- Fähigkeiten
    def _widevine(self):
        try:
            return str((context.current().client or {}).get('widevine') or '').upper()
        except Exception:                                  # noqa: BLE001
            return ''

    def _supports_drm(self):
        if not self.drm:
            return True
        if self.drm == 'com.widevine.alpha':
            return self._widevine() != 'NONE'              # '' = unbekannt -> zulassen, der Browser entscheidet
        return True

    # -- API des Originals
    def check_inputstream(self):
        ok = self.protocol in PROTOCOLS or not self.protocol
        ok = ok and self._supports_drm()
        _log.debug('check_inputstream(%s, drm=%s) -> %s', self.protocol, self.drm, ok)
        return ok

    def has_inputstream(self):
        return True

    def info_dialog(self):
        return None

    def install_widevine(self):
        return self._supports_drm()

    def remove_widevine(self):
        return True

    def widevine_info(self):
        return None

    def rollback_libwv(self):
        return None

    def check_for_updates(self):
        return None

    def __getattr__(self, name):                           # seltene Zusatzfunktionen: ruhig ignorieren
        if name.startswith('__'):
            raise AttributeError(name)
        return lambda *a, **k: None


def get_setting(key, default=None):
    return default


def get_addon_info(key):
    return {'id': 'script.module.inputstreamhelper', 'version': '0.7.0', 'name': 'InputStream Helper'}.get(str(key), '')
