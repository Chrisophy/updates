# -*- coding: utf-8 -*-
"""Kodi xbmc-Modul (Emulation)."""
import sys
import time
import logging
import threading

from . import context

LOGDEBUG = 0
LOGINFO = 1
LOGNOTICE = 2                                   # Kodi 18 (alte Addons)
LOGWARNING = 2
LOGERROR = 3
LOGFATAL = 4
LOGNONE = 5

_levels = {0: 'DEBUG', 1: 'INFO', 2: 'WARNING', 3: 'ERROR', 4: 'FATAL', 5: 'NONE'}
_log = logging.getLogger('kodi')

PLAYLIST_VIDEO = 1
PLAYLIST_MUSIC = 0
ENGLISH_NAME = 1
ISO_639_1 = 2


def log(msg, level=LOGINFO):
    rl = getattr(context.peek(), 'runlog', None)
    if rl is not None:
        rl.append((level, str(msg)[:300]))
        del rl[:-80]
    sl = getattr(context.peek(), 'svc_log', None)
    if sl is not None:
        sl.append('%s %s' % (time.strftime('%H:%M:%S'), str(msg)[:300]))
    _log.log({0: 10, 1: 20, 2: 30, 3: 40, 4: 50}.get(level, 20), '%s', msg)


def _platform_profile():
    try:
        from . import xbmcaddon
        return (xbmcaddon.all_settings().get('platform_profile') or 'web').lower()
    except Exception:
        return 'web'


def getCondVisibility(condition):
    """Kodi-Bedingungen (System.Platform.*, System.HasAddon(), Skin.HasSetting(), String.IsEmpty() …, kombinierbar mit
    + | ! und Klammern). Abgespielt wird im Browser des Nutzers; Standard 'web': wir geben uns weder als Android- noch
    als Windows-Kodi aus. Umschaltbar in den Einstellungen (Gerätetyp)."""
    from . import skin
    return skin.cond_visible(condition)


def _client():
    try:
        from . import context
        return context.current().client or {}
    except Exception:
        return {}


def getInfoLabel(label):
    from . import skin
    return skin.info_label(label)


def getLanguage(format=ENGLISH_NAME, region=False):
    return 'German' if format == ENGLISH_NAME else 'de'


def getLocalizedString(id):
    return ''


def executebuiltin(function, wait=False):
    from . import skin
    skin.builtin(function)


def executeJSONRPC(jsonrpccommand):
    from . import skin
    return skin.jsonrpc(jsonrpccommand)


def sleep(timemillis):
    ctx = context.peek()
    if ctx is not None and ctx.playing:                         # Wiedergabe läuft bei der Engine: das Addon braucht nicht auf den Player zu warten
        return
    time.sleep(max(0, int(timemillis)) / 1000.0)


def _playback_started(ctx):
    """Die Engine übernimmt die Wiedergabe. Dem Addon wie Kodi „Bild da“ melden (onPlayBackStarted/onAVStarted seiner Player-Klassen)
    und seine Warteschleifen (`while not monitor.abortRequested() …`, `sleep`) beenden. Dienste (ctx.abort) bleiben unberührt."""
    if ctx is None or ctx.abort is not None or ctx.playing:
        return
    ctx.playing = True
    ctx.play_t = time.monotonic()
    for ref in list(ctx.players):
        p = ref()
        if p is None:
            continue
        for cb in ('onPlayBackStarted', 'onAVStarted'):
            fn = getattr(p, cb, None)
            if callable(fn):
                try:
                    fn()
                except Exception as e:                         # noqa: BLE001
                    log('Player.%s des Addons: %s' % (cb, e), LOGDEBUG)


def translatePath(path):
    from . import xbmcvfs
    return xbmcvfs.translatePath(path)


def playSFX(filename, useCached=True):
    pass                                                           # Klangdateien spielt die Engine nicht ab


def stopSFX():
    pass


def getGlobalIdleTime():
    return 0


def getRegion(id):
    return {'dateshort': '%d.%m.%Y', 'datelong': '%A, %d. %B %Y', 'time': '%H:%M:%S'}.get(id, '')


def getSkinDir():
    return 'skin.moviescout'


def getUserAgent():
    return 'Kodi/21.0 (Linux; Android 13) Kodi_Fork_ARCH/MovieScout'


def getSupportedMedia(media_type):
    return '.mp4|.mkv|.avi|.m3u8|.mpd|.ts'


def getFreeMem():
    return 1024


def getCacheThumbName(path):
    return ''


def makeLegalFilename(filename, fatx=True):
    import re
    return re.sub(r'[\\/:*?"<>|]+', '_', str(filename))


def convertLanguage(language, format):
    return language


class Monitor:
    def __init__(self, *a, **k):
        pass

    def abortRequested(self):
        ctx = context.current()
        ev = getattr(ctx, 'abort', None)
        return bool(ctx.playing or (ev is not None and ev.is_set()))

    def waitForAbort(self, timeout=0):
        ctx = context.current()
        if ctx.playing:                                         # Wiedergabe ist an die Engine übergeben: Warteschleifen des Addons beenden
            return True
        ev = getattr(ctx, 'abort', None)
        if ev is not None:                                      # Addon-Dienst: endet, wenn das Addon entfernt/ersetzt wird
            return ev.wait(max(0.0, float(timeout or 0)) if timeout else None)
        time.sleep(max(0.0, float(timeout or 0)))
        return False


class Keyboard:
    """Tastatur-Dialog: Die Web-Oberfläche liefert den Text als ?q= mit."""

    def __init__(self, default='', heading='', hidden=False):
        self._text = default or ''
        self._heading = heading or ''
        self._hidden = bool(hidden)
        self._confirmed = False

    def doModal(self, autoclose=0):
        q = context.current().query
        if q:
            self._text = q
            self._confirmed = True
            return
        from . import ui_dialogs
        r = ui_dialogs.ask('input', None, heading=str(self._heading), value=str(self._text), hidden=self._hidden, numeric=False)
        if r is not None:
            self._text = str(r)
            self._confirmed = True

    def setHeading(self, heading):
        self._heading = heading

    def setDefault(self, default):
        self._text = default

    def setHiddenInput(self, hidden):
        self._hidden = bool(hidden)

    def isConfirmed(self):
        return self._confirmed

    def getText(self):
        return self._text


class Player:
    """Zeichnet die Wiedergabe-Anforderung auf. Die Engine macht daraus einen Hoster
    inkl. DRM-Daten (Ersatz für inputstream.adaptive)."""

    def __new__(cls, *a, **k):
        obj = object.__new__(cls)
        ctx = context.peek()
        if ctx is not None:
            import weakref
            ctx.players.append(weakref.ref(obj))
            del ctx.players[:-20]
        return obj

    def __init__(self, *a, **k):
        pass

    def play(self, item='', listitem=None, windowed=False, startpos=-1):
        ctx = context.current()
        if isinstance(item, PlayList):                          # Wiedergabeliste: den Eintrag an startpos abspielen (die Oberfläche kennt keine Warteschlange)
            entries = item._items
            if not entries:
                return
            url, li = entries[min(max(int(startpos or 0), 0), len(entries) - 1)]
            item, listitem = url, (li if li is not None else listitem)
        if getattr(ctx, 'addon_id', '') and str(item).startswith('plugin://'):
            ctx.follow = str(item)                              # Adresse des Addons selbst: nach dem Lauf auflösen (engine/addonhost.py)
            return
        ctx.resolved.append({'path': item, 'listitem': listitem})
        _playback_started(ctx)
        if getattr(ctx, 'close_on_play', False) and getattr(ctx, 'window_shown', False):
            from . import ui_dialogs
            ui_dialogs.close_windows(getattr(ctx, 'rid', ''))   # Fenster des Addons zu: die Engine spielt jetzt ab

    def stop(self):
        pass

    def _alive(self):
        """Kodi: nach play()/setResolvedUrl() meldet der Player „läuft“. Addons warten darauf (`while not player.isPlaying(): sleep`, ARDundZDF)
        und würden hier ewig hängen. Darum gilt der Player für ein paar Sekunden nach der Übergabe an die Engine als laufend (danach „beendet“,
        damit auch Schleifen `while player.isPlaying()` enden). Dienste (ctx.abort) ausgenommen."""
        ctx = context.peek()
        return bool(ctx is not None and ctx.playing and ctx.abort is None and time.monotonic() - getattr(ctx, 'play_t', 0.0) < 3.0)

    def isPlaying(self):
        return self._alive()

    def isPlayingAudio(self):
        return False

    def getMusicInfoTag(self):
        return InfoTagMusic()

    def isPlayingVideo(self):
        return self._alive()

    def getPlayingFile(self):
        ctx = context.peek()
        r = (getattr(ctx, 'resolved', None) or [None])[-1] if self._alive() else None
        return str((r or {}).get('path') or '')

    def getTime(self):
        return 0.0

    def getTotalTime(self):
        return 0.0

    def seekTime(self, t):
        pass

    def pause(self):
        pass

    # -- Untertitel: Die Engine kennt nur die Untertitel, die das Addon mit der aufgelösten Adresse geliefert hat (ListItem.setSubtitles).
    #    Die Auswahl wird als „Vorgabe“ vermerkt; die Oberfläche schaltet sie beim Start des Videos ein (static/index.html: subAuto).
    def _subs(self):
        ctx = context.peek()
        for r in reversed(getattr(ctx, 'resolved', None) or []):
            li = r.get('listitem')
            if li is not None and getattr(li, 'subtitles', None):
                return li, list(li.subtitles)
        return None, []

    def getAvailableSubtitleStreams(self):
        from engine import subs as _s
        li, raw = self._subs()
        out = []
        for x in _s.norm_subtitles(raw):
            out.append(' '.join(t for t in (x.get('lang'), x.get('label')) if t).strip() or 'und')
        return out

    def setSubtitleStream(self, iStream):
        from engine import subs as _s
        li, raw = self._subs()
        norm = _s.norm_subtitles(raw)
        i = int(iStream)
        if li is None or not 0 <= i < len(norm):
            return
        pick = norm[i]
        li.subtitles = [dict(x, default=(x['url'] == pick['url'])) for x in norm]
        li.properties['moviescout.subtitle'] = '1'

    def showSubtitles(self, visible):
        li, raw = self._subs()
        if li is None:
            return
        if not visible:
            li.properties['moviescout.subtitle'] = '0'                  # Addon will keine Untertitel
        elif li.properties.get('moviescout.subtitle') != '1' and raw:
            li.properties['moviescout.subtitle'] = '1'

    def getSubtitles(self):
        return ''

    def getAvailableAudioStreams(self):
        return []

    def setAudioStream(self, iStream):
        pass


class PlayList:
    def __init__(self, playlist_type=PLAYLIST_VIDEO):
        self._items = []

    def add(self, url, listitem=None, index=-1):
        self._items.append((url, listitem))

    def clear(self):
        self._items = []

    def size(self):
        return len(self._items)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, i):
        url, li = self._items[i]
        return li if li is not None else ListItemStub(url)

    def getposition(self):
        return 0

    def shuffle(self):
        pass

    def unshuffle(self):
        pass


class InfoTagMusic:
    """Leere Musik-Infos (alle get…-Aufrufe liefern '' bzw. 0)."""

    def __getattr__(self, name):
        if name.startswith('get'):
            return lambda *a, **k: ('' if name not in ('getTrack', 'getDisc', 'getDuration', 'getYear', 'getPlayCount', 'getRating', 'getUserRating') else 0)
        raise AttributeError(name)


class ListItemStub:
    def __init__(self, path=''):
        self._path = path

    def getPath(self):
        return self._path

    getfilename = getPath


class InfoTagVideo:
    pass


class _StreamDetail:
    """VideoStreamDetail / AudioStreamDetail / SubtitleStreamDetail (InfoTagVideo.addVideoStream u. a.): hält nur die Werte."""

    def __init__(self, *a, **k):
        self.__dict__.update(k)
        self._args = a


class VideoStreamDetail(_StreamDetail):
    pass


class AudioStreamDetail(_StreamDetail):
    pass


class SubtitleStreamDetail(_StreamDetail):
    pass


class Actor:
    """xbmc.Actor (Kodi 20+): Darsteller für InfoTagVideo.setCast([...])."""

    def __init__(self, name='', role='', order=-1, thumbnail=''):
        self.name, self.role, self.order, self.thumbnail = name, role, order, thumbnail

    def getName(self):
        return self.name

    def getRole(self):
        return self.role

    def getOrder(self):
        return self.order

    def getThumbnail(self):
        return self.thumbnail

    def setName(self, v):
        self.name = v

    def setRole(self, v):
        self.role = v

    def setOrder(self, v):
        self.order = v

    def setThumbnail(self, v):
        self.thumbnail = v
