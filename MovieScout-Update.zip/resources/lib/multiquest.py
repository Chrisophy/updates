# -*- coding: utf-8 -*-
"""Universeller HTTP-Client für alle Scraper.

Bietet die Schnittstelle, die die Scraper erwarten:

    multiquest.get(url, headers=, params=, timeout=, allow_redirects=, use_cf=)
    multiquest.post(url, data=, json=, headers=, timeout=, ...)
    multiquest.Session(headers=, use_cf=)  (auch als Context-Manager)
    Response: .text .content .status_code .headers .url .cookies .history
              .ok .json() .raise_for_status()

Backends (automatisch gewählt):
    use_cf=True -> curl_cffi (Chrome-Fingerprint) oder cloudscraper, falls installiert
    sonst       -> httpx, falls installiert
    sonst       -> urllib (Standardbibliothek, läuft überall - auch in Android/Chaquopy)
"""

import gzip
import http.cookiejar
import io
import json as _json
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import threading
import zlib

try:  # optional
    import httpx as _httpx
except Exception:  # pragma: no cover - hängt von der Umgebung ab
    _httpx = None

_DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36'
)
# Ein normaler deutscher Browser schickt immer Accept-Language mit; fehlt der Header, wirkt der Aufruf wie ein Skript.
_DEFAULT_LANG = 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7'
_DEFAULT_TIMEOUT = 15

_STATUS_TEXT = {
    200: 'OK', 301: 'Moved Permanently', 302: 'Found', 400: 'Bad Request',
    401: 'Unauthorized', 403: 'Forbidden', 404: 'Not Found', 429: 'Too Many Requests',
    500: 'Internal Server Error', 502: 'Bad Gateway', 503: 'Service Unavailable',
}


class HTTPError(Exception):
    """Wird von Response.raise_for_status() bei Status >= 400 geworfen."""

    def __init__(self, message, response=None):
        super().__init__(message)
        self.response = response


class CaseInsensitiveDict(dict):
    """Minimales Header-Dict, Schlüssel unabhängig von Groß-/Kleinschreibung."""

    def __init__(self, data=None):
        super().__init__()
        self._keys = {}
        if data:
            for k, v in (data.items() if hasattr(data, 'items') else data):
                self[k] = v

    def __setitem__(self, key, value):
        lk = str(key).lower()
        old = self._keys.get(lk)
        if old is not None and old != key:
            super().__delitem__(old)
        self._keys[lk] = key
        super().__setitem__(key, value)

    def __getitem__(self, key):
        real = self._keys.get(str(key).lower())
        if real is None:
            raise KeyError(key)
        return super().__getitem__(real)

    def __contains__(self, key):
        return str(key).lower() in self._keys

    def __delitem__(self, key):
        real = self._keys.pop(str(key).lower())
        super().__delitem__(real)

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default

    def update(self, *args, **kwargs):
        for k, v in dict(*args, **kwargs).items():
            self[k] = v

    def pop(self, key, *default):
        lk = str(key).lower()
        if lk in self._keys:
            real = self._keys.pop(lk)
            return super().pop(real)
        if default:
            return default[0]
        raise KeyError(key)

    def copy(self):
        return CaseInsensitiveDict(self)


def _decode(content, content_type=''):
    """bytes -> str mit Charset aus Header, <meta>, sonst UTF-8 (Fallback cp1252)."""
    if not content:
        return ''
    charset = None
    m = re.search(r'charset=["\']?([\w\-]+)', content_type or '', re.I)
    if m:
        charset = m.group(1)
    if not charset:
        head = content[:2048].decode('ascii', 'ignore')
        m = re.search(r'<meta[^>]+charset=["\']?([\w\-]+)', head, re.I)
        if m:
            charset = m.group(1)
    for enc in ([charset] if charset else []) + ['utf-8']:
        try:
            return content.decode(enc)
        except (LookupError, UnicodeDecodeError):
            continue
    return content.decode('cp1252', 'replace')


class Response:
    def __init__(self, status_code, headers, content, url, history=None, cookies=None,
                 elapsed=0.0):
        self.status_code = int(status_code)
        self.headers = headers if isinstance(headers, CaseInsensitiveDict) else CaseInsensitiveDict(headers)
        self.content = content or b''
        self.url = url
        self.history = history or []
        self.cookies = cookies or {}
        self.elapsed = elapsed
        self._text = None
        self.encoding = None

    @property
    def text(self):
        if self._text is None:
            self._text = _decode(self.content, self.headers.get('Content-Type', ''))
        return self._text

    @property
    def ok(self):
        return self.status_code < 400

    @property
    def reason(self):
        return _STATUS_TEXT.get(self.status_code, '')

    def json(self, **kw):
        return _json.loads(self.text, **kw)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise HTTPError('HTTP Error %s for url: %s' % (self.status_code, self.url), self)

    def iter_content(self, chunk_size=8192):
        for i in range(0, len(self.content), chunk_size):
            yield self.content[i:i + chunk_size]

    def __repr__(self):
        return '<Response [%s]>' % self.status_code

    def __bool__(self):
        return self.ok


# --------------------------------------------------------------------------- helpers

def _build_url(url, params=None):
    if not params:
        return url
    if isinstance(params, dict):
        params = [(k, v) for k, v in params.items() if v is not None]
    q = urllib.parse.urlencode(params, doseq=True)
    sep = '&' if '?' in url else '?'
    return url + sep + q if q else url


def _encode_body(data, json_obj, headers):
    """Gibt (bytes|None) zurück und ergänzt ggf. Content-Type."""
    if json_obj is not None:
        if 'Content-Type' not in headers:
            headers['Content-Type'] = 'application/json'
        return _json.dumps(json_obj, separators=(',', ':')).encode('utf-8')
    if data is None:
        return None
    if isinstance(data, (bytes, bytearray)):
        return bytes(data)
    if isinstance(data, str):
        return data.encode('utf-8')
    if 'Content-Type' not in headers:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
    return urllib.parse.urlencode(data, doseq=True).encode('utf-8')


def _ssl_context():
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


# --------------------------------------------------------------------------- engines

class _UrllibEngine:
    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self._ctx = _ssl_context()

    def _opener(self, allow_redirects, history, proxy=''):
        class _Redirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                history.append(code)
                if not allow_redirects:
                    return None
                return super().redirect_request(req, fp, code, msg, headers, newurl)

        handlers = [urllib.request.HTTPCookieProcessor(self.jar),
                    urllib.request.HTTPSHandler(context=self._ctx),
                    _Redirect()]
        if proxy:                                   # eigener Umweg-Proxy (Einstellung „Proxy“)
            handlers.insert(0, urllib.request.ProxyHandler({'http': proxy, 'https': proxy}))
        return urllib.request.build_opener(*handlers)

    def request(self, method, url, headers, body, timeout, allow_redirects, verify=True, proxy=''):
        history = []
        h = dict(headers)
        h.setdefault('Accept-Encoding', 'gzip, deflate')
        req = urllib.request.Request(url, data=body, method=method, headers=h)
        opener = self._opener(allow_redirects, history, proxy)
        t0 = time.time()
        try:
            resp = opener.open(req, timeout=timeout)
        except urllib.error.HTTPError as e:  # 3xx (ohne Redirect) / 4xx / 5xx
            resp = e
        raw = resp.read()
        hdrs = CaseInsensitiveDict()
        for k, v in resp.headers.items():
            hdrs[k] = v if k not in hdrs else hdrs[k] + ', ' + v
        enc = (hdrs.get('Content-Encoding') or '').lower()
        try:
            if 'gzip' in enc:
                raw = gzip.decompress(raw)
            elif 'deflate' in enc:
                try:
                    raw = zlib.decompress(raw)
                except zlib.error:
                    raw = zlib.decompress(raw, -zlib.MAX_WBITS)
        except Exception:
            pass
        status = getattr(resp, 'status', None) or getattr(resp, 'code', 200)
        return Response(status, hdrs, raw, resp.geturl() if hasattr(resp, 'geturl') else url,
                        history, {c.name: c.value for c in self.jar}, time.time() - t0)

    @property
    def cookies(self):
        return {c.name: c.value for c in self.jar}

    def close(self):
        pass


class _HttpxEngine:
    def __init__(self):
        self.client = _httpx.Client(timeout=_DEFAULT_TIMEOUT, verify=_ssl_context())

    def request(self, method, url, headers, body, timeout, allow_redirects, verify=True, proxy=''):
        t0 = time.time()
        if proxy:
            try:
                c = _httpx.Client(timeout=_DEFAULT_TIMEOUT, verify=_ssl_context(), proxy=proxy)
            except TypeError:                       # ältere httpx-Versionen
                c = _httpx.Client(timeout=_DEFAULT_TIMEOUT, verify=_ssl_context(), proxies=proxy)
            with c:
                r = c.request(method, url, headers=headers, content=body, timeout=timeout, follow_redirects=allow_redirects)
            return Response(r.status_code, CaseInsensitiveDict(r.headers.items()), r.content,
                            str(r.url), [x.status_code for x in r.history], dict(c.cookies.items()), time.time() - t0)
        r = self.client.request(method, url, headers=headers, content=body,
                                timeout=timeout, follow_redirects=allow_redirects)
        return Response(r.status_code, CaseInsensitiveDict(r.headers.items()), r.content,
                        str(r.url), [x.status_code for x in r.history],
                        dict(self.client.cookies.items()), time.time() - t0)

    @property
    def cookies(self):
        return dict(self.client.cookies.items())

    def close(self):
        try:
            self.client.close()
        except Exception:
            pass


class _CurlEngine:
    """curl_cffi mit Browser-Fingerprint (für use_cf)."""

    def __init__(self, cr):
        self.s = cr.Session(impersonate='chrome')

    def request(self, method, url, headers, body, timeout, allow_redirects, verify=True, proxy=''):
        t0 = time.time()
        h = {k: v for k, v in headers.items() if k.lower() != 'user-agent'}
        r = self.s.request(method, url, headers=h, data=body, timeout=timeout,
                           allow_redirects=allow_redirects)
        return Response(r.status_code, CaseInsensitiveDict(r.headers.items()), r.content,
                        str(r.url), [], dict(self.s.cookies.items()), time.time() - t0)

    @property
    def cookies(self):
        return dict(self.s.cookies.items())

    def close(self):
        try:
            self.s.close()
        except Exception:
            pass


class _CloudscraperEngine:
    def __init__(self, cs):
        self.s = cs.create_scraper()

    def request(self, method, url, headers, body, timeout, allow_redirects, verify=True, proxy=''):
        t0 = time.time()
        r = self.s.request(method, url, headers=headers, data=body, timeout=timeout,
                           allow_redirects=allow_redirects)
        return Response(r.status_code, CaseInsensitiveDict(r.headers.items()), r.content,
                        r.url, [x.status_code for x in r.history],
                        r.cookies.get_dict(), time.time() - t0)

    @property
    def cookies(self):
        return self.s.cookies.get_dict()

    def close(self):
        try:
            self.s.close()
        except Exception:
            pass


def _make_engine(use_cf=False):
    if use_cf:
        try:
            from curl_cffi import requests as cr
            return _CurlEngine(cr)
        except Exception:
            pass
        try:
            import cloudscraper
            return _CloudscraperEngine(cloudscraper)
        except Exception:
            pass
    if _httpx is not None:
        try:
            return _HttpxEngine()
        except Exception:
            pass
    return _UrllibEngine()


# --------------------------------------------------------------------------- Session / Funktionen

HOOK = None          # optional: Objekt mit call(url, method, fn) und proxy_for(url) - setzt die Engine (Schutz vor Sperren)


class Session:
    def __init__(self, headers=None, use_cf=False, cookies=None, **_ignored):
        self.use_cf = bool(use_cf)
        self.headers = CaseInsensitiveDict(headers or {})
        self._engine = _make_engine(self.use_cf)
        self.max_redirects = 20
        if cookies and isinstance(self._engine, _UrllibEngine):
            for k, v in dict(cookies).items():
                self._engine.jar.set_cookie(http.cookiejar.Cookie(
                    0, k, v, None, False, '', False, False, '/', False, False, None, False,
                    None, None, {}))

    @property
    def cookies(self):
        return self._engine.cookies

    def request(self, method, url, headers=None, params=None, data=None, json=None,
                timeout=_DEFAULT_TIMEOUT, allow_redirects=True, **_ignored):
        h = CaseInsensitiveDict(self.headers)
        if 'User-Agent' not in h:
            h['User-Agent'] = _DEFAULT_UA
        if 'Accept' not in h:
            h['Accept'] = '*/*'
        if 'Accept-Language' not in h:
            h['Accept-Language'] = _DEFAULT_LANG
        if headers:
            h.update(dict(headers))
        body = _encode_body(data, json, h)
        full = _build_url(url, params)
        hook = HOOK
        proxy = ''
        if hook is not None:
            try:
                proxy = hook.proxy_for(full)
            except Exception:
                proxy = ''

        def run():
            if proxy and isinstance(self._engine, (_UrllibEngine, _HttpxEngine)):
                return self._engine.request(method.upper(), full, dict(h), body,
                                            timeout or _DEFAULT_TIMEOUT, allow_redirects, proxy=proxy)
            return self._engine.request(method.upper(), full, dict(h), body,
                                        timeout or _DEFAULT_TIMEOUT, allow_redirects)
        return hook.call(full, method.upper(), run) if hook is not None else run()

    def get(self, url, **kw):
        return self.request('GET', url, **kw)

    def post(self, url, **kw):
        return self.request('POST', url, **kw)

    def head(self, url, **kw):
        return self.request('HEAD', url, **kw)

    def close(self):
        self._engine.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


_tls = threading.local()


def _shared_cf_session():
    """Pro Thread eine dauerhafte Sitzung für Cloudflare-Seiten: Cookies (cf_clearance) und die TLS-Verbindung bleiben
    erhalten, genau wie in einem Browser. Ohne das müsste jede Anfrage die Prüfung neu bestehen."""
    s = getattr(_tls, 'cf', None)
    if s is None:
        s = _tls.cf = Session(use_cf=True)
    return s


def request(method, url, **kw):
    use_cf = kw.pop('use_cf', False)
    if use_cf:
        return _shared_cf_session().request(method, url, **kw)
    sess = Session(use_cf=False)
    try:
        return sess.request(method, url, **kw)
    finally:
        sess.close()


def get(url, headers=None, params=None, timeout=_DEFAULT_TIMEOUT, **kw):
    return request('GET', url, headers=headers, params=params, timeout=timeout, **kw)


def post(url, data=None, json=None, headers=None, timeout=_DEFAULT_TIMEOUT, **kw):
    return request('POST', url, data=data, json=json, headers=headers, timeout=timeout, **kw)


def head(url, headers=None, timeout=_DEFAULT_TIMEOUT, **kw):
    return request('HEAD', url, headers=headers, timeout=timeout, **kw)
