# -*- coding: utf-8 -*-
"""Captcha-Solver-Hook für MovieScout (bs.to) – alle Dienste in einer Datei.

Unterstützt: capsolver, 2captcha, anticaptcha, capmonster, 9kw, deathbycaptcha
(reCAPTCHA v2 und Cloudflare Turnstile, ohne Proxy; Turnstile nicht bei 9kw/deathbycaptcha). Braucht nur "requests" – kein cloudscraper, kein polling.

EINRICHTEN (einfachster Weg, ohne Umgebungsvariablen)
-----------------------------------------------------
1. captcha_solver.py und captcha_solver.json in den Ordner legen, in dem auch
   captcha_helper.py liegt (resources/lib/captcha).
2. In captcha_solver.json den API-Schlüssel eintragen:

       {"provider": "2captcha",
        "keys": {"2captcha": "DEIN_API_KEY"}}

   Mehrere Dienste als Reihenfolge (der nächste springt ein, wenn einer scheitert):

       {"provider": "capsolver,2captcha,anticaptcha",
        "keys": {"capsolver": "KEY1", "2captcha": "KEY2", "anticaptcha": "KEY3"}}

   Dienste: capsolver, 2captcha, anticaptcha, capmonster, 9kw, deathbycaptcha
   (deathbycaptcha: Wert "benutzername:passwort").
3. Engine neu starten. Der aktualisierte captcha_helper.py findet diese Datei
   von selbst, MOVIESCOUT_CAPTCHA_HOOK muss dann nicht gesetzt werden.

ALTERNATIV per Umgebungsvariablen (haben Vorrang vor der JSON-Datei):

       MOVIESCOUT_CAPTCHA_PROVIDER=2captcha
       MOVIESCOUT_CAPTCHA_KEY=DEIN_API_KEY
   oder je Dienst MOVIESCOUT_CAPTCHA_KEY_<DIENST> (CAPSOLVER, 2CAPTCHA,
   ANTICAPTCHA, CAPMONSTER, 9KW, DEATHBYCAPTCHA).

   Ohne Angabe des Dienstes werden alle Dienste mit hinterlegtem Schlüssel der
   Reihe nach probiert.

Optional:
    MOVIESCOUT_CAPTCHA_TIMEOUT   max. Wartezeit pro Dienst in Sekunden (Standard 150)

TEST (kostet beim Dienst ein Captcha):
    python captcha_solver.py SITEKEY SEITEN_URL
"""
import json
import logging
import os
import re
import sys
import time

try:
    import requests
except ImportError:  # pragma: no cover
    raise ImportError("Das Modul 'requests' fehlt (pip install requests)")

log = logging.getLogger('captcha_solver')

PROVIDERS = ('capsolver', '2captcha', 'anticaptcha', 'capmonster', '9kw', 'deathbycaptcha')
DEFAULT_TIMEOUT = 150
_HTTP_TIMEOUT = 30


class SolverError(Exception):
    pass


# --------------------------------------------------------------------------- #
# Konfiguration
# --------------------------------------------------------------------------- #

def _env_name(provider):
    return 'MOVIESCOUT_CAPTCHA_KEY_' + re.sub(r'[^A-Z0-9]', '_', provider.upper())


def _load_file_config():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'captcha_solver.json')
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception as e:
        log.warning('captcha_solver.json nicht lesbar: %s', e)
        return {}


def is_configured():
    """True, wenn mindestens ein Dienst mit Schlüssel eingerichtet ist (ohne Logmeldungen)."""
    try:
        return bool(_configured())
    except Exception:
        return False


def _timeout():
    try:
        return max(30, int(os.environ.get('MOVIESCOUT_CAPTCHA_TIMEOUT', DEFAULT_TIMEOUT)))
    except ValueError:
        return DEFAULT_TIMEOUT


def _app_settings():
    """Einstellungen der App (Einstellungen → Konten: Captcha-Dienst und Schlüssel). Leer, wenn nicht lesbar."""
    try:
        import xbmcaddon
        st = xbmcaddon.all_settings()
        return st if isinstance(st, dict) else {}
    except Exception:                                   # noqa: BLE001
        return {}


def _configured():
    """Liste (dienst, schlüssel) in der Reihenfolge, in der sie probiert werden.
    Vorrang: Umgebungsvariablen, dann Einstellungen der App, dann captcha_solver.json."""
    cfg = _load_file_config()
    app = _app_settings()
    file_keys = cfg.get('keys') if isinstance(cfg.get('keys'), dict) else {}
    spec = (os.environ.get('MOVIESCOUT_CAPTCHA_PROVIDER') or app.get('captcha_provider') or cfg.get('provider') or '').strip()
    if spec.lower() == 'auto':
        spec = ''
    names = [p.strip().lower() for p in spec.split(',') if p.strip()] if spec else list(PROVIDERS)
    generic = (os.environ.get('MOVIESCOUT_CAPTCHA_KEY') or app.get('captcha_key') or cfg.get('key') or '').strip()

    out = []
    for name in names:
        alias = {'anti-captcha': 'anticaptcha', 'dbc': 'deathbycaptcha', 'death_by_captcha': 'deathbycaptcha',
                 'twocaptcha': '2captcha', 'cap_solver': 'capsolver', 'cap_monster': 'capmonster'}.get(name, name)
        if alias not in PROVIDERS:
            log.warning('Unbekannter Captcha-Dienst "%s" (erlaubt: %s)', name, ', '.join(PROVIDERS))
            continue
        key = (os.environ.get(_env_name(alias)) or '').strip()
        if not key and spec and len(names) == 1:
            key = generic          # ein einzelner Dienst darf den allgemeinen Schlüssel nutzen (App-Einstellung)
        if not key:
            key = str(file_keys.get(alias) or '').strip()
        if key.upper().startswith('HIER_DEIN'):
            key = ''               # Platzhalter aus der mitgelieferten captcha_solver.json
        if key:
            out.append((alias, key))
        elif spec:
            log.warning('Für Dienst "%s" ist kein API-Schlüssel gesetzt (%s)', alias, _env_name(alias))
    return out


# --------------------------------------------------------------------------- #
# HTTP-Helfer
# --------------------------------------------------------------------------- #

def _json(resp, what):
    if resp.status_code >= 500:
        raise SolverError('%s: Serverfehler HTTP %s' % (what, resp.status_code))
    try:
        return resp.json()
    except Exception:
        raise SolverError('%s: keine JSON-Antwort (HTTP %s): %s' % (
            what, resp.status_code, (resp.text or '')[:150].replace('\n', ' ')))


def _wait(deadline, seconds):
    if time.time() + seconds > deadline:
        raise SolverError('Zeitüberschreitung')
    time.sleep(seconds)


# --------------------------------------------------------------------------- #
# Dienste
# --------------------------------------------------------------------------- #

def _solve_2captcha(key, sitekey, url, deadline, s, ctype='recaptcha'):
    host = 'https://2captcha.com'
    if ctype == 'turnstile':
        payload = {'key': key, 'method': 'turnstile', 'sitekey': sitekey, 'pageurl': url, 'json': 1}
    else:
        payload = {'key': key, 'method': 'userrecaptcha', 'googlekey': sitekey, 'pageurl': url, 'json': 1}
    r = _json(s.post(host + '/in.php', timeout=_HTTP_TIMEOUT, data=payload), '2captcha in.php')
    if r.get('status') != 1:
        raise SolverError('2captcha: %s' % r.get('request'))
    job = r['request']
    _wait(deadline, 15)
    while True:
        r = _json(s.get(host + '/res.php', timeout=_HTTP_TIMEOUT, params={
            'key': key, 'action': 'get', 'id': job, 'json': 1}), '2captcha res.php')
        if r.get('status') == 1:
            return r['request']
        if r.get('request') != 'CAPCHA_NOT_READY':
            raise SolverError('2captcha: %s' % r.get('request'))
        _wait(deadline, 5)


def _solve_task_api(name, host, task_type, extra, key, sitekey, url, deadline, s):
    """Gemeinsamer Ablauf für anticaptcha / capmonster / capsolver (createTask/getTaskResult)."""
    payload = {'clientKey': key, 'task': {'type': task_type, 'websiteURL': url, 'websiteKey': sitekey}}
    payload.update(extra)
    r = _json(s.post(host + '/createTask', json=payload, timeout=_HTTP_TIMEOUT), name + ' createTask')
    if r.get('errorId'):
        raise SolverError('%s: %s %s' % (name, r.get('errorCode'), r.get('errorDescription') or ''))
    task = r.get('taskId')
    if not task:
        raise SolverError('%s: keine taskId erhalten' % name)
    _wait(deadline, 5)
    while True:
        r = _json(s.post(host + '/getTaskResult', json={'clientKey': key, 'taskId': task},
                         timeout=_HTTP_TIMEOUT), name + ' getTaskResult')
        if r.get('errorId'):
            raise SolverError('%s: %s %s' % (name, r.get('errorCode'), r.get('errorDescription') or ''))
        status = r.get('status')
        if status == 'ready':
            sol = r.get('solution') or {}
            token = sol.get('gRecaptchaResponse') or sol.get('token') or ''
            if not token:
                raise SolverError('%s: Lösung ohne Token' % name)
            return token
        if status == 'failed':
            raise SolverError('%s: Aufgabe fehlgeschlagen' % name)
        _wait(deadline, 3)


def _solve_anticaptcha(key, sitekey, url, deadline, s, ctype='recaptcha'):
    task = 'TurnstileTaskProxyless' if ctype == 'turnstile' else 'NoCaptchaTaskProxyless'
    return _solve_task_api('anticaptcha', 'https://api.anti-captcha.com', task,
                           {'softId': 959}, key, sitekey, url, deadline, s)


def _solve_capmonster(key, sitekey, url, deadline, s, ctype='recaptcha'):
    task = 'TurnstileTaskProxyless' if ctype == 'turnstile' else 'NoCaptchaTaskProxyless'
    return _solve_task_api('capmonster', 'https://api.capmonster.cloud', task,
                           {}, key, sitekey, url, deadline, s)


def _solve_capsolver(key, sitekey, url, deadline, s, ctype='recaptcha'):
    task = 'AntiTurnstileTaskProxyLess' if ctype == 'turnstile' else 'ReCaptchaV2TaskProxyless'
    return _solve_task_api('capsolver', 'https://api.capsolver.com', task,
                           {}, key, sitekey, url, deadline, s)


def _solve_9kw(key, sitekey, url, deadline, s, ctype='recaptcha'):
    if ctype == 'turnstile':
        raise SolverError('9kw unterstützt kein Turnstile')
    host = 'https://www.9kw.eu/index.cgi'
    maxt = max(60, min(int(deadline - time.time()) - 10, 180))
    r = _json(s.post(host, timeout=_HTTP_TIMEOUT, data={
        'apikey': key, 'action': 'usercaptchaupload', 'interactive': 1,
        'file-upload-01': sitekey, 'oldsource': 'recaptchav2', 'pageurl': url,
        'maxtimeout': maxt, 'json': 1}), '9kw upload')
    if r.get('error'):
        raise SolverError('9kw: Fehlercode %s' % r.get('error'))
    job = r.get('captchaid')
    if not job:
        raise SolverError('9kw: keine captchaid erhalten')
    _wait(deadline, 10)
    while True:
        r = _json(s.get(host, timeout=_HTTP_TIMEOUT, params={
            'apikey': key, 'action': 'usercaptchacorrectdata', 'id': job,
            'info': 1, 'json': 1}), '9kw result')
        if r.get('error'):
            raise SolverError('9kw: Fehlercode %s' % r.get('error'))
        ans = r.get('answer')
        if ans and ans != 'NO DATA':
            return ans
        _wait(deadline, 10)


def _solve_deathbycaptcha(key, sitekey, url, deadline, s, ctype='recaptcha'):
    if ctype == 'turnstile':
        raise SolverError('deathbycaptcha unterstützt kein Turnstile')
    if ':' not in key:
        raise SolverError('deathbycaptcha: Schlüssel muss "benutzername:passwort" sein')
    user, pw = key.split(':', 1)
    host = 'http://api.dbcapi.me/api'
    hdr = {'Accept': 'application/json'}
    resp = s.post(host + '/captcha', headers=hdr, allow_redirects=False, timeout=_HTTP_TIMEOUT, data={
        'username': user, 'password': pw, 'type': '4',
        'token_params': json.dumps({'googlekey': sitekey, 'pageurl': url})})
    if resp.status_code == 403:
        raise SolverError('deathbycaptcha: Login falsch oder Guthaben leer (403)')
    if resp.status_code == 503:
        raise SolverError('deathbycaptcha: Dienst vorübergehend nicht verfügbar (503)')
    job = None
    try:
        job = resp.json().get('captcha')
    except Exception:
        pass
    if not job:
        loc = resp.headers.get('Location', '') if hasattr(resp, 'headers') else ''
        m = re.search(r'/captcha/(\d+)', loc or '')
        job = m.group(1) if m else None
    if not job:
        raise SolverError('deathbycaptcha: keine Captcha-ID erhalten (HTTP %s)' % resp.status_code)
    _wait(deadline, 15)
    while True:
        r = _json(s.get('%s/captcha/%s' % (host, job), headers=hdr, timeout=_HTTP_TIMEOUT), 'deathbycaptcha result')
        if r.get('text'):
            return r['text']
        if r.get('is_correct') is False or r.get('is_correct') == 0:
            raise SolverError('deathbycaptcha: Captcha als unlösbar markiert')
        _wait(deadline, 5)


_SOLVERS = {
    'capsolver':      _solve_capsolver,
    '2captcha':       _solve_2captcha,
    'anticaptcha':    _solve_anticaptcha,
    'capmonster':     _solve_capmonster,
    '9kw':            _solve_9kw,
    'deathbycaptcha': _solve_deathbycaptcha,
}


# --------------------------------------------------------------------------- #
# Einstiegspunkt für MOVIESCOUT_CAPTCHA_HOOK
# --------------------------------------------------------------------------- #

def solve(sitekey, page_url, captcha_type='recaptcha', **kw):
    """Löst ein reCAPTCHA v2 (Standard) oder Cloudflare Turnstile (captcha_type='turnstile')
    und gibt das Token zurück."""
    ctype = 'turnstile' if str(captcha_type or '').lower() == 'turnstile' else 'recaptcha'
    if not sitekey:
        raise SolverError('kein sitekey')
    chain = _configured()
    if not chain:
        raise SolverError('kein Captcha-Dienst konfiguriert (MOVIESCOUT_CAPTCHA_PROVIDER / '
                          'MOVIESCOUT_CAPTCHA_KEY_<DIENST> setzen)')
    errors = []
    for name, key in chain:
        t0 = time.time()
        deadline = t0 + _timeout()
        try:
            with requests.Session() as s:
                token = _SOLVERS[name](key, sitekey, page_url, deadline, s, ctype)
            token = (token or '').strip()
            if len(token) < 30:
                raise SolverError('Token zu kurz / leer')
            log.info('Captcha gelöst über %s in %.0fs', name, time.time() - t0)
            return token
        except Exception as e:
            msg = str(e).replace(key, '***') if key and len(key) >= 8 else str(e)
            log.warning('Captcha-Dienst %s fehlgeschlagen: %s', name, msg)
            errors.append(msg if msg.lower().startswith(name) else '%s: %s' % (name, msg))
    raise SolverError('; '.join(errors))


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
    if len(sys.argv) < 3:
        print('Aufruf: python captcha_solver.py SITEKEY SEITEN_URL')
        sys.exit(2)
    try:
        tok = solve(sys.argv[1], sys.argv[2])
        print('OK, Token-Länge %d: %s...' % (len(tok), tok[:20]))
    except Exception as exc:
        print('FEHLER:', exc)
        sys.exit(1)
