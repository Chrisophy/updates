# -*- coding: utf-8 -*-
"""Captcha-Hilfen für Scraper (bsto).

Standard: liegt captcha_solver.py (mit eingetragenem API-Schlüssel in
captcha_solver.json) im selben Ordner, wird es automatisch benutzt.

Alternativ Anbindung eines eigenen Solvers über eine Umgebungsvariable:

    MOVIESCOUT_CAPTCHA_HOOK="paket.modul:funktion"

(alter Name MINIKODI_CAPTCHA_HOOK funktioniert weiterhin.)

Die Funktion bekommt (sitekey, page_url) und gibt das Token zurück.
Akzeptiert werden: String-Token oder ein Dict mit einem der Schlüssel
'token', 'gRecaptchaResponse', 'g-recaptcha-response', 'text', 'code'.
Akzeptiert die Funktion zusätzlich **kwargs bzw. die Namen 'captcha_type',
'enterprise' oder 'action', werden diese ebenfalls übergeben.

Optional:
    MOVIESCOUT_CAPTCHA_TTL   Cache-Dauer für Tokens in Sekunden (Standard 100,
                             0 = Cache aus). reCAPTCHA-Tokens gelten ca. 2 Min.
    MOVIESCOUT_CAPTCHA_DEBUG 1 = Meldungen auf stderr ausgeben
"""
import html as _html
import importlib
import inspect
import logging
import os
import re
import sys
import threading
import time

log = logging.getLogger('captcha_helper')

HOOK_ENV_VARS = ('MOVIESCOUT_CAPTCHA_HOOK', 'MINIKODI_CAPTCHA_HOOK')
TOKEN_KEYS = ('token', 'gRecaptchaResponse', 'g-recaptcha-response', 'text', 'code')
DEFAULT_TTL = 100
MIN_TOKEN_LEN = 20

# Reihenfolge = Priorität. (Name, Typ, Regex)
_SITEKEY_PATTERNS = (
    # burningseries (wie in Moviescout)
    ('burningseries', 'recaptcha', r"series\.init\s*\(\s*\d+\s*,\s*\d+\s*,\s*'([^']+)'\s*\)"),
    # Turnstile / hCaptcha haben eigene Marker, daher vor dem generischen data-sitekey
    ('turnstile', 'turnstile', r'class=["\'][^"\']*cf-turnstile[^"\']*["\'][^>]*data-sitekey=["\']([\w\-]{10,})["\']'),
    ('turnstile', 'turnstile', r'turnstile\.render\([^)]*?sitekey["\']?\s*:\s*["\']([\w\-]{10,})["\']'),
    ('hcaptcha', 'hcaptcha', r'class=["\'][^"\']*h-captcha[^"\']*["\'][^>]*data-sitekey=["\']([\w\-]{10,})["\']'),
    ('hcaptcha', 'hcaptcha', r'hcaptcha\.render\([^)]*?sitekey["\']?\s*:\s*["\']([\w\-]{10,})["\']'),
    # reCAPTCHA
    ('data-sitekey', 'recaptcha', r'data-sitekey=["\']([\w\-]{20,})["\']'),
    ('grecaptcha', 'recaptcha', r'grecaptcha(?:\.enterprise)?\.(?:render|execute)\([^)]*?["\']([\w\-]{30,})["\']'),
    ('api.js', 'recaptcha', r'recaptcha/(?:api|enterprise)\.js\?[^"\']*render=([\w\-]{20,})'),
    ('sitekey', 'recaptcha', r'sitekey["\']?\s*[:=]\s*["\']([\w\-]{20,})["\']'),
)

_cache = {}
_cache_lock = threading.Lock()


def _debug(msg, *args):
    if os.environ.get('MOVIESCOUT_CAPTCHA_DEBUG', '') not in ('', '0'):
        try:
            sys.stderr.write('[captcha] ' + (msg % args) + '\n')
        except Exception:
            pass
    log.debug(msg, *args)


def extract_captcha_info(html):
    """Erkennt Captcha-Typ und Sitekey.

    Rückgabe: {'type': 'recaptcha'|'hcaptcha'|'turnstile', 'sitekey': str,
               'enterprise': bool, 'invisible': bool}  oder {} wenn nichts gefunden.
    """
    if not html:
        return {}
    for _name, ctype, pat in _SITEKEY_PATTERNS:
        m = re.search(pat, html, re.I | re.S)
        if m:
            sitekey = _html.unescape(m.group(1)).strip()
            if not sitekey:
                continue
            return {
                'type': ctype,
                'sitekey': sitekey,
                'enterprise': bool(re.search(r'recaptcha/enterprise\.js|grecaptcha\.enterprise', html, re.I)),
                'invisible': bool(re.search(r'data-size=["\']invisible["\']|grecaptcha\.execute\(', html, re.I)),
            }
    return {}


def extract_recaptcha_sitekey(html):
    """Wie bisher: nur der Sitekey als String ('' wenn nichts gefunden)."""
    return extract_captcha_info(html).get('sitekey', '')


DEFAULT_HOOK_MODULE = 'captcha_solver'
DEFAULT_HOOK = ((__package__ + '.') if __package__ else '') + DEFAULT_HOOK_MODULE + ':solve'

# Letzte Fehlermeldung des Solvers – damit der Aufrufer (z. B. bsto) im Log
# erklären kann, WARUM kein Token kam.
_last_error = ['']


def get_last_error():
    return _last_error[0]


def _get_hook_spec():
    for name in HOOK_ENV_VARS:
        val = (os.environ.get(name) or '').strip()
        if val:
            return val
    # Kein Hook per Umgebungsvariable: mitgelieferten captcha_solver benutzen,
    # sobald dort ein API-Schlüssel eingerichtet ist (captcha_solver.json / Env).
    try:
        mod = importlib.import_module(DEFAULT_HOOK.split(':', 1)[0])
        if getattr(mod, 'is_configured', lambda: False)():
            return DEFAULT_HOOK
    except Exception as e:
        _debug('Standard-Solver nicht verfügbar: %s', e)
    return ''


def _load_hook(spec):
    """Lädt 'paket.modul:funktion'. Gibt Callable oder None zurück."""
    if not spec or ':' not in spec:
        if spec:
            log.warning('Captcha-Hook "%s" ungültig, erwartet "modul:funktion"', spec)
        return None
    mod_name, fn_name = spec.split(':', 1)
    try:
        fn = getattr(importlib.import_module(mod_name.strip()), fn_name.strip())
    except Exception as e:
        log.warning('Captcha-Hook "%s" nicht ladbar: %s', spec, e)
        return None
    if not callable(fn):
        log.warning('Captcha-Hook "%s" ist nicht aufrufbar', spec)
        return None
    return fn


def _call_hook(fn, sitekey, page_url, extras):
    """Ruft den Hook mit (sitekey, page_url) auf und reicht passende Extras durch."""
    kwargs = {}
    try:
        params = inspect.signature(fn).parameters
        accepts_any = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())
        for k, v in extras.items():
            if accepts_any or k in params:
                kwargs[k] = v
    except (TypeError, ValueError):
        pass
    return fn(sitekey, page_url, **kwargs)


def _normalize_token(result):
    if isinstance(result, dict):
        for k in TOKEN_KEYS:
            if result.get(k):
                result = result[k]
                break
        else:
            return ''
    if isinstance(result, bytes):
        try:
            result = result.decode('utf-8', 'ignore')
        except Exception:
            return ''
    if not isinstance(result, str):
        return ''
    token = result.strip()
    return token if len(token) >= MIN_TOKEN_LEN else ''


def _ttl():
    try:
        return max(0, int(os.environ.get('MOVIESCOUT_CAPTCHA_TTL', DEFAULT_TTL)))
    except ValueError:
        return DEFAULT_TTL


def clear_token_cache():
    """Verwirft alle zwischengespeicherten Tokens (z. B. nach 'Token ungültig')."""
    with _cache_lock:
        _cache.clear()


def solve_recaptcha(sitekey, page_url, **kw):
    """Holt ein Captcha-Token über den konfigurierten Hook ('' bei Fehler/ohne Hook).

    Optionale kw: captcha_type, enterprise, action, use_cache (Standard True).
    Ein einmal verbrauchtes Token sollte der Aufrufer mit clear_token_cache()
    verwerfen, falls die Seite es ablehnt.
    """
    if not sitekey:
        return ''
    spec = _get_hook_spec()
    if not spec:
        _debug('kein Hook gesetzt (%s)', ' / '.join(HOOK_ENV_VARS))
        return ''

    _last_error[0] = ''
    use_cache = kw.pop('use_cache', True)
    ttl = _ttl() if use_cache else 0
    key = (sitekey, page_url or '')
    now = time.time()

    if ttl:
        with _cache_lock:
            hit = _cache.get(key)
            if hit and now - hit[1] < ttl:
                _debug('Token aus Cache (%s)', sitekey[:8])
                return hit[0]

    fn = _load_hook(spec)
    if fn is None:
        _last_error[0] = 'Hook "%s" nicht ladbar' % spec
        return ''

    try:
        token = _normalize_token(_call_hook(fn, sitekey, page_url, kw))
    except Exception as e:
        log.warning('Captcha-Hook "%s" fehlgeschlagen: %s', spec, e)
        _last_error[0] = str(e)
        return ''

    if not token:
        _debug('Hook lieferte kein gültiges Token')
        _last_error[0] = 'Hook lieferte kein gültiges Token'
        return ''

    if ttl:
        with _cache_lock:
            _cache[key] = (token, now)
            # alte Einträge aufräumen
            for k in [k for k, v in _cache.items() if now - v[1] >= ttl]:
                _cache.pop(k, None)
    return token


def solve_from_html(html, page_url, **kw):
    """Bequem: Sitekey und Typ aus dem HTML erkennen und direkt lösen lassen."""
    info = extract_captcha_info(html)
    if not info:
        return ''
    kw.setdefault('captcha_type', info['type'])
    kw.setdefault('enterprise', info['enterprise'])
    return solve_recaptcha(info['sitekey'], page_url, **kw)
