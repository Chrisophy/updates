# -*- coding: utf-8 -*-
"""Alias: `from resources.lib import cloud` zeigt auf resources.lib.evil."""
import sys

from resources.lib import evil

sys.modules[__name__] = evil
