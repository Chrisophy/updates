# -*- coding: utf-8 -*-
"""MovieScout – Kodi-lose Scraper-Engine (by IT('s) Possible).

Start:   python main.py            (Port 8000, im Heimnetz erreichbar - TV, Handy, PC)
         python main.py --local    (nur auf diesem Gerät erreichbar)
         python main.py --port 9000
         (--lan wird weiterhin akzeptiert, ist aber jetzt der Standard)

Umgebungsvariablen:
    MOVIESCOUT_TOKEN          Zugriffstoken für die API (empfohlen, sobald --lan/Internet)
    MOVIESCOUT_ALLOW_PRIVATE  1 = Proxy darf auch Ziele im lokalen Netz abrufen
    MOVIESCOUT_DATA           Ordner für Cache/Einstellungen/eigene Scraper (Standard: ./userData)
    MOVIESCOUT_ADMIN_ORIGINS  Seiten (kommagetrennt), die Scraper/Erweiterungen verwalten dürfen, z. B. https://name.github.io
    (Die alten Namen MINIKODI_* funktionieren weiter.)
"""
import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

# Absturz-Protokoll: stürzt eine native Bibliothek ab ("Segmentation fault"), steht der Python-Weg dorthin in <Daten>/crash.log
try:
    import faulthandler
    _dd = os.environ.get('MOVIESCOUT_DATA') or os.environ.get('MINIKODI_DATA') or str(Path(__file__).resolve().parent / 'userData')
    os.makedirs(_dd, exist_ok=True)
    _crash = open(os.path.join(_dd, 'crash.log'), 'a')
    _crash.write('--- Start %s ---\n' % __import__('time').strftime('%Y-%m-%d %H:%M:%S'))
    _crash.flush()
    faulthandler.enable(file=_crash, all_threads=True)
except Exception:                                          # noqa: BLE001
    pass

# Android (python-for-android / Buildozer): Einstellungen, Cache und eigene Scraper in den dauerhaften
# App-Ordner legen. Der Code-Ordner wird bei jedem App-Update ersetzt, die Daten wären sonst weg.
if os.environ.get('ANDROID_PRIVATE') or os.environ.get('ANDROID_ARGUMENT'):
    os.environ.setdefault('MOVIESCOUT_DATA', os.path.join(
        os.environ.get('ANDROID_PRIVATE') or os.path.expanduser('~'), 'userData'))

# ----------------------------------------------------------------------------- Update ohne neue APK
# Ein eingespieltes System-Update liegt unter <Daten>/update/current (siehe engine/updater.py). Ist es neuer als der
# mitgelieferte Stand, wird es statt des mitgelieferten Codes geladen. Kommt die Engine damit nicht hoch, fällt dieses
# Skript selbstständig auf den mitgelieferten Stand zurück. Dieses Bootstrap-Stück bleibt bewusst klein und stabil.
import json  # noqa: E402
import shutil  # noqa: E402
import traceback  # noqa: E402

_BASE = Path(__file__).resolve().parent
_USING = None            # Ordner des geladenen Updates, sonst None


def _vkey(d):
    try:
        t = next((l.strip() for l in (Path(d) / 'VERSION').read_text('utf-8').splitlines() if l.strip()), '')
    except Exception:
        t = ''
    import re
    n = [int(x) for x in re.findall(r'\d+', t)][:6]
    return tuple(n + [0] * (6 - len(n)))


def _note(upd, failed):
    try:
        f = upd / 'state.json'
        st = json.loads(f.read_text('utf-8')) if f.exists() else {}
        st['failed'] = failed
        f.write_text(json.dumps(st, ensure_ascii=False, indent=1), 'utf-8')
    except Exception:
        pass


def _quarantine(upd, why):
    """Defektes Update zur Seite legen; ab dem nächsten Start (und sofort) gilt der mitgelieferte Stand."""
    cur, bad = upd / 'current', upd / 'bad'
    try:
        shutil.rmtree(str(bad), ignore_errors=True)
        if cur.is_dir():
            os.replace(str(cur), str(bad))
        (upd / 'booting').unlink()
    except Exception:
        pass
    _note(upd, why)


def _pick_update():
    global _USING
    data = os.environ.get('MINIKODI_DATA') or os.environ.get('MOVIESCOUT_DATA') or str(_BASE / 'userData')
    # Datenordner festnageln: der Update-Ordner hat einen eigenen Code-Pfad, die Daten bleiben, wo sie sind
    os.environ['MOVIESCOUT_DATA'] = os.environ['MINIKODI_DATA'] = data
    os.environ['MOVIESCOUT_BASE'] = str(_BASE)
    upd = Path(data) / 'update'
    cur = upd / 'current'
    try:
        if (upd / 'booting').exists():
            _quarantine(upd, 'Das Update ließ die Engine nicht starten – es wurde zurückgesetzt.')
        if not cur.is_dir():
            return
        good = (cur / 'engine' / 'app.py').is_file() and (cur / 'static' / 'index.html').is_file()
        if not good:
            _quarantine(upd, 'Das Update war unvollständig – es wurde zurückgesetzt.')
        elif _vkey(cur) <= _vkey(_BASE):
            shutil.rmtree(str(cur), ignore_errors=True)       # die App bringt einen gleichen/neueren Stand mit
        else:
            (upd / 'booting').write_text(str(int(__import__('time').time())), 'utf-8')
            sys.path.insert(0, str(cur))
            _USING = cur
    except Exception:
        traceback.print_exc()


def _build_app():
    import kodi_runtime  # noqa: F401  (registriert xbmc, xbmcgui, ... bevor Scraper geladen werden)
    from engine.app import create_app
    return create_app()


_pick_update()
try:
    app = _build_app()
except BaseException:
    if _USING is None:
        raise
    err_text = traceback.format_exc()
    print('Update-Stand startet nicht - Rückfall auf den mitgelieferten Stand:\n' + err_text)
    _upd = _USING.parent
    _quarantine(_upd, 'Das Update startete nicht (%s) – es wurde zurückgesetzt.' % (err_text.strip().splitlines()[-1][:160]))
    try:
        sys.path.remove(str(_USING))
    except ValueError:
        pass
    _USING = None
    for _m in [k for k in list(sys.modules) if k.split('.')[0] in (
            'kodi_runtime', 'engine', 'resources', 'xbmc', 'xbmcgui', 'xbmcaddon', 'xbmcplugin', 'xbmcvfs', 'resolveurl')]:
        del sys.modules[_m]
    app = _build_app()

if __name__ == '__main__':
    import uvicorn

    def _lan_ip():
        import socket
        try:
            sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sk.connect(('10.255.255.255', 1))       # UDP: es wird nichts gesendet, nur die Route bestimmt
            ip = sk.getsockname()[0]
            sk.close()
            return '' if ip.startswith('127.') else ip
        except Exception:
            return ''

    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8000)
    ap.add_argument('--lan', action='store_true', help='auf 0.0.0.0 lauschen (Netzwerkzugriff) - ist der Standard')
    ap.add_argument('--local', action='store_true', help='nur auf diesem Gerät lauschen (127.0.0.1)')
    ap.add_argument('--host', default='')
    a = ap.parse_args()
    host = a.host or ('127.0.0.1' if a.local and not a.lan else '0.0.0.0')
    print('MovieScout läuft auf http://%s:%d/ui/' % ('127.0.0.1' if host == '0.0.0.0' else host, a.port))
    if host == '0.0.0.0':
        ip = _lan_ip()
        if not (os.environ.get('MOVIESCOUT_TOKEN') or os.environ.get('MINIKODI_TOKEN')):
            print('Hinweis: Ohne MOVIESCOUT_TOKEN kann jedes Gerät im WLAN die Engine benutzen. '
                  'Empfohlen: MOVIESCOUT_TOKEN=geheim python main.py   (oder mit --local nur lokal starten)')
        if ip:
            print('Im Heimnetz (Handy/TV): http://%s:%d/ui/' % (ip, a.port))
            print('  DRM-Videos (Rakuten, Joyn, RTL+) brauchen dort in Chrome einmalig: chrome://flags -> '
                  '"Insecure origins treated as secure" -> http://%s:%d eintragen.' % (ip, a.port))
    uvicorn.run(app, host=host, port=a.port, log_level='info')
