#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MovieScout von Hand aktualisieren (Pydroid, Termux, PC): ZIP über einen vorhandenen Ordner einspielen, ohne dass Altes liegen bleibt.

    python tools/update_install.py MovieScout-Komplett.zip                 # Standard: Code ersetzen, Einstellungen behalten
    python tools/update_install.py MovieScout-Komplett.zip --mode clean    # Neuinstallation: auch userData leeren (vorher gesichert)
    python tools/update_install.py MovieScout-Komplett.zip --mode custom   # je Eintrag in userData fragen: behalten oder löschen
    python tools/update_install.py ZIP --folder /pfad/zu/silent-main --yes # Ordner angeben, keine Rückfragen

Ablauf in jedem Modus
  1. Sicherung von userData als ZIP nach <Ordner>/backup/ (Zwischenspeicher wie Bilder, Downloads und Logs bleiben draußen).
  2. Programmordner (engine, kodi_runtime, providers, extensions, resources, static, system, vendor, tools, tests, android)
     werden gelöscht und aus dem ZIP neu angelegt - so bleibt keine alte Datei liegen, die Neues stören könnte.
  3. Ein früheres In-App-Update (userData/update) wird entfernt, damit nicht heimlich der alte Stand weiterläuft.
  4. userData je nach Modus: behalten (update), leeren (clean) oder einzeln wählen (custom).
Nichts außerhalb des angegebenen Ordners wird angefasst. Die Sicherung lässt sich in MovieScout oder per Entpacken in userData zurückspielen.
"""
import argparse
import os
import shutil
import sys
import time
import zipfile
from pathlib import Path

CODE_DIRS = ('engine', 'kodi_runtime', 'providers', 'extensions', 'resources', 'static', 'system', 'vendor', 'tools', 'tests', 'android')
ROOT_FILES = ('VERSION', 'main.py', 'README.md')
BACKUP_SKIP = {'cache', 'imgcache', 'repo_index', 'update', 'temp', 'tmp', 'logs', 'downloads', '__pycache__', 'trash'}
MAX_BACKUP_FILE = 80 * 1024 * 1024


def log(msg):
    print(msg, flush=True)


def norm(name):
    parts = [p for p in name.replace('\\', '/').split('/') if p and p != '.']
    if any(p == '..' for p in parts):
        raise SystemExit('Unsicherer Pfad im ZIP: ' + name)
    return parts


def read_zip(path):
    zf = zipfile.ZipFile(path)
    rows = [(norm(i.filename), i) for i in zf.infolist() if not i.is_dir()]
    rows = [(p, i) for p, i in rows if p]
    marker = lambda ps: any(p[:1] == ['VERSION'] or p[:2] == ['engine', 'app.py'] for p in ps)    # noqa: E731
    paths = [p for p, _ in rows]
    if paths and not marker(paths):                                  # GitHub-ZIP mit gemeinsamem Oberordner
        tops = {p[0] for p in paths if len(p) > 1}
        if len(tops) == 1:
            rows = [(p[1:], i) for p, i in rows if len(p) > 1]
    files = {}
    for p, i in rows:
        if '__pycache__' in p or p[-1].endswith(('.pyc', '.pyo')):
            continue
        if len(p) == 1 and p[0] in ROOT_FILES or (len(p) > 1 and p[0] in CODE_DIRS):
            files['/'.join(p)] = i
    if 'VERSION' not in files or 'engine/app.py' not in files:
        raise SystemExit('Das ist kein MovieScout-Paket (VERSION oder engine/app.py fehlt).')
    return zf, files


def rmtree(p):
    def fix(func, path, _exc):
        try:
            os.chmod(os.path.dirname(path) or '.', 0o755)
            os.chmod(path, 0o755)
            func(path)
        except OSError:
            pass
    shutil.rmtree(str(p), onerror=fix)


def backup(data, dest_dir):
    if not data.is_dir() or not any(data.iterdir()):
        return None
    dest_dir.mkdir(parents=True, exist_ok=True)
    out = dest_dir / ('userData-%s.zip' % time.strftime('%Y%m%d-%H%M%S'))
    n = 0
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, fs in os.walk(str(data)):
            dirs[:] = [d for d in dirs if d.lower() not in BACKUP_SKIP]
            for f in fs:
                p = Path(root) / f
                try:
                    if p.is_symlink() or p.stat().st_size > MAX_BACKUP_FILE or f.endswith(('.tmp', '.pyc')):
                        continue
                    z.write(str(p), 'userData/' + p.relative_to(data).as_posix())
                    n += 1
                except OSError:
                    pass
    log('Sicherung: %s (%d Dateien)' % (out, n))
    return out


def ask(question, default_yes):
    try:
        a = input('%s [%s] ' % (question, 'J/n' if default_yes else 'j/N')).strip().lower()
    except EOFError:
        return default_yes
    return default_yes if not a else a[0] in 'jy'


def main():
    ap = argparse.ArgumentParser(description='MovieScout von Hand aktualisieren')
    ap.add_argument('zip')
    ap.add_argument('--folder', default=str(Path(__file__).resolve().parent.parent), help='Installationsordner (Standard: der Ordner dieses Programms)')
    ap.add_argument('--mode', choices=('update', 'clean', 'custom'), default='update')
    ap.add_argument('--yes', action='store_true', help='keine Rückfragen')
    ap.add_argument('--keep', default='', help='custom ohne Fragen: Einträge von userData, die bleiben (kommagetrennt)')
    a = ap.parse_args()

    folder = Path(a.folder).resolve()
    data = Path(os.environ.get('MINIKODI_DATA') or folder / 'userData')
    zf, files = read_zip(a.zip)
    old = (folder / 'VERSION').read_text('utf-8').split()[0] if (folder / 'VERSION').is_file() else '?'
    new = zf.read(files['VERSION']).decode('utf-8').split()[0]
    log('Ordner: %s\nVersion: %s -> %s, Modus: %s' % (folder, old, new, a.mode))
    if not a.yes and not ask('Fortfahren?', True):
        raise SystemExit('Abgebrochen.')

    # custom: Auswahl vorab treffen (vor dem Löschen)
    drop = []
    if a.mode == 'custom' and data.is_dir():
        keep = {x.strip() for x in a.keep.split(',') if x.strip()}
        for e in sorted(os.scandir(str(data)), key=lambda x: x.name.lower()):
            if e.name == 'update':
                continue
            if a.keep or a.yes:
                if e.name not in keep:
                    drop.append(e.name)
            elif not ask('userData/%s behalten?' % e.name, True):
                drop.append(e.name)
    if a.mode == 'clean' and data.is_dir():
        drop = [e.name for e in os.scandir(str(data)) if e.name != 'update']

    backup(data, folder / 'backup')

    # Programmordner neu aufbauen
    dirs = {p.split('/')[0] for p in files if '/' in p}
    for d in sorted(dirs):
        if (folder / d).is_dir():
            rmtree(folder / d)
    n = 0
    for name, info in files.items():
        dst = folder / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            dst.unlink()
        except OSError:
            pass
        dst.write_bytes(zf.read(info))
        n += 1
    log('Programmdateien: %d geschrieben, Ordner neu angelegt: %s' % (n, ', '.join(sorted(dirs))))

    if (data / 'update').is_dir():
        rmtree(data / 'update')
        log('Altes In-App-Update (userData/update) entfernt')
    for name in drop:
        p = data / name
        if p.is_dir():
            rmtree(p)
        elif p.exists():
            p.unlink()
    if drop:
        log('Aus userData gelöscht: ' + ', '.join(drop))
    log('Fertig. MovieScout neu starten.')


if __name__ == '__main__':
    main()
