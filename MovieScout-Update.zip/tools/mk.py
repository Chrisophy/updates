# -*- coding: utf-8 -*-
"""mk – Kommandozeilen-Werkzeug zum Erweitern und Sichern von MovieScout (ohne laufende Engine).

  python tools/mk.py list                          alle Scraper + Erweiterungen mit Zustand
  python tools/mk.py new scraper meinsender        Vorlage anlegen (userData/user/providers/meinsender.py)
  python tools/mk.py new extension tuning --here   Vorlage in den aktuellen Ordner schreiben
  python tools/mk.py check datei.py [--run]        prüfen; --run führt load() testweise aus
  python tools/mk.py add datei.py|https://…        hinzufügen (Art wird erkannt, sonst --kind)
  python tools/mk.py enable|disable|delete NAME    Zustand ändern (delete = Papierkorb)
  python tools/mk.py trash [restore ID]            Papierkorb zeigen / zurückholen
  python tools/mk.py export sicherung.zip [--full] Gesamtsystem sichern
  python tools/mk.py import sicherung.zip [--replace] [--bundled]

Läuft die Engine gerade, danach in der Oberfläche „Neu laden“ drücken (Einstellungen → Quellen verwalten)
oder die Engine neu starten.
"""
import argparse
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import kodi_runtime  # noqa: E402,F401
from engine import system as S  # noqa: E402


def detect_kind(code):
    c = S.check_code('provider', 'x.py', code)
    if c['ok']:
        return 'provider'
    e = S.check_code('extension', 'x.py', code)
    return 'extension' if e['ok'] else None


def kind_arg(v):
    return {'scraper': 'provider', 'provider': 'provider', 'extension': 'extension', 'erweiterung': 'extension'}.get(v or '', None)


def cmd_list(a):
    for kind, title in (('provider', 'Scraper'), ('extension', 'Erweiterungen')):
        print('\n%s:' % title)
        for r in S.list_files(kind):
            print('  [%s] %-28s %s' % ('x' if r['enabled'] else ' ', r['file'], 'eigen' if r['origin'] == 'user' else 'mitgeliefert'))


def cmd_new(a):
    kind = kind_arg(a.what)
    if not kind:
        sys.exit('Art muss "scraper" oder "extension" sein.')
    name = S.clean_name(a.name)
    code = S.TEMPLATES[kind]
    if a.here:
        out = Path.cwd() / name
        if out.exists():
            sys.exit('%s gibt es schon.' % out)
        out.write_text(code, 'utf-8')
        print('Vorlage geschrieben:', out, '\nDanach: python tools/mk.py add', name)
    else:
        S.save_file(kind, name, code, overwrite=False)
        print('Angelegt:', S.kind_dir(kind) / name)


def _read_arg(src):
    if src.lower().startswith(('http://', 'https://')):
        from resources.lib import multiquest
        r = multiquest.get(src, timeout=25)
        if r.status_code != 200:
            sys.exit('Download fehlgeschlagen: HTTP %s' % r.status_code)
        return r.text, os.path.basename(src.split('?')[0]) or 'skript.py'
    p = Path(src)
    return p.read_text('utf-8'), p.name


def cmd_check(a):
    code, name = _read_arg(a.file)
    kind = kind_arg(a.kind) or detect_kind(code)
    if not kind:
        sys.exit('Weder als Scraper noch als Erweiterung gültig:\n  ' + '\n  '.join(S.check_code('provider', name, code)['errors']))
    res = S.check_code(kind, name, code)
    print('Art:', 'Scraper' if kind == 'provider' else 'Erweiterung')
    for e in res['errors']:
        print('FEHLER ', e)
    for w in res['warnings']:
        print('Hinweis', w)
    if res['ok'] and a.run:
        from engine import app as A
        r = A._dry_run(kind, name, code)
        print('Trockenlauf:', {k: v for k, v in r.items() if k != 'trace'})
        if r.get('trace'):
            print(r['trace'])
        if r.get('error'):
            sys.exit(1)
    sys.exit(0 if res['ok'] else 1)


def cmd_add(a):
    code, name = _read_arg(a.file)
    kind = kind_arg(a.kind) or detect_kind(code)
    if not kind:
        sys.exit('Konnte die Art nicht erkennen – mit --kind scraper|extension angeben.')
    res = S.save_file(kind, a.name or name, code)
    print('Hinzugefügt als %s: %s' % ('Scraper' if kind == 'provider' else 'Erweiterung', res['file']))
    for w in res['warnings']:
        print('Hinweis', w)


def _find_kind(name):
    name = S.clean_name(name)
    for kind in S.KINDS:
        if any(r['file'] == name for r in S.list_files(kind)):
            return kind, name
    sys.exit('Nicht gefunden: %s' % name)


def cmd_state(a):
    kind, name = _find_kind(a.name)
    if a.cmd == 'delete':
        print('Papierkorb' if S.delete_file(kind, name) == 'trash' else 'Ausgeblendet (wiederherstellbar)')
    else:
        S.set_enabled(kind, name, a.cmd == 'enable')
        print('%s: %s' % (name, 'aktiv' if a.cmd == 'enable' else 'deaktiviert'))


def cmd_trash(a):
    if a.sub == 'restore':
        print('Wiederhergestellt:', S.restore_trash(a.id))
        return
    for t in S.list_trash():
        print('%-48s %-9s %s' % (t['id'], t['kind'] or '-', t['what']))


def cmd_export(a):
    Path(a.out).write_bytes(S.export_zip(full=a.full))
    print('Gesichert:', a.out)


def cmd_import(a):
    res = S.import_zip(Path(a.zip).read_bytes(), 'replace' if a.replace else 'merge', a.bundled)
    print('\n'.join(res['report']) or 'Nichts zu tun.')
    if res['ui']:
        print('(Die Sicherung enthält auch Oberflächen-Daten – Skins, Favoriten …; sie lassen sich in der Oberfläche über „Sicherung wiederherstellen“ einspielen.)')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest='cmd', required=True)
    sp.add_parser('list').set_defaults(fn=cmd_list)
    p = sp.add_parser('new'); p.add_argument('what'); p.add_argument('name'); p.add_argument('--here', action='store_true'); p.set_defaults(fn=cmd_new)
    p = sp.add_parser('check'); p.add_argument('file'); p.add_argument('--kind'); p.add_argument('--run', action='store_true'); p.set_defaults(fn=cmd_check)
    p = sp.add_parser('add'); p.add_argument('file'); p.add_argument('--kind'); p.add_argument('--name'); p.set_defaults(fn=cmd_add)
    for c in ('enable', 'disable', 'delete'):
        p = sp.add_parser(c); p.add_argument('name'); p.set_defaults(fn=cmd_state)
    p = sp.add_parser('trash'); p.add_argument('sub', nargs='?'); p.add_argument('id', nargs='?'); p.set_defaults(fn=cmd_trash)
    p = sp.add_parser('export'); p.add_argument('out'); p.add_argument('--full', action='store_true'); p.set_defaults(fn=cmd_export)
    p = sp.add_parser('import'); p.add_argument('zip'); p.add_argument('--replace', action='store_true'); p.add_argument('--bundled', action='store_true'); p.set_defaults(fn=cmd_import)
    a = ap.parse_args()
    try:
        a.fn(a)
    except S.SystemError_ as e:
        sys.exit('Fehler: %s' % e)


if __name__ == '__main__':
    main()
