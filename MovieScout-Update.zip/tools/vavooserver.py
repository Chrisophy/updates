from flask import Flask, render_template_string, request, redirect, Response, jsonify, make_response
import requests
import time
import re
import json
import os

app = Flask(__name__)

# --- Favoriten Management ---
FAV_FILE = "favorites.json"
PROFILES = ["Profil 1", "Profil 2", "Profil 3", "Profil 4"]

def load_favorites():
    if os.path.exists(FAV_FILE):
        try:
            with open(FAV_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {p: [] for p in PROFILES}

def save_favorites(favs):
    with open(FAV_FILE, "w", encoding="utf-8") as f:
        json.dump(favs, f)

# --- Hilfsfunktion zum Bereinigen der Namen ---
def clean_channel_name(name: str) -> str:
    """Entfernt spezifische Wörter, .b/.c/.s Endungen sowie unerwünschte Sonderzeichen."""
    if not name:
        return ""
    name = re.sub(r'\s*\.[bcs]\b', '', name, flags=re.IGNORECASE)
    words_to_remove = ["backup", "hd", "fhd", "match time", "live during events only", "hevc", "raw", "only during events", "spieltag"]
    if words_to_remove:
        pattern = r'\b(' + '|'.join(map(re.escape, words_to_remove)) + r')\b'
        name = re.sub(pattern, '', name, flags=re.IGNORECASE)
    cleaned = re.sub(r'[^a-zA-Z0-9äöüÄÖÜß\s.,-]', '', name)
    return re.sub(r'\s+', ' ', cleaned).strip()

# --- Streamflix-Style Vavoo Provider Logik ---
class VavooLocalProvider:
    def __init__(self, language: str = "de"):
        self.language = language
        self.base_url = "https://vavoo.to"
        self.catalog_url = f"{self.base_url}/mediahubmx-catalog.json"
        self.resolve_url = f"{self.base_url}/mediahubmx-resolve.json"
        lang_config = {
            "de": ("de", "DE", ["Germany", "GERMANY"]),
        }
        self.config = lang_config.get(language, lang_config["de"])
        self.primary_groups = self.config[2]
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.1 (Windows NT 10.0; Win64; x64)",
            "Origin": self.base_url,
            "Referer": f"{self.base_url}/",
            "Content-Type": "application/json",
        })
        self._cache = {}
        self._cache_time = {}
        self.cache_ttl = 300
        self._resolve_cache = {}
        self._resolve_cache_time = {}
        self.resolve_cache_ttl = 180

    def get_all_channels(self, group: str):
        now = time.time()
        if group in self._cache and (now - self._cache_time.get(group, 0)) < self.cache_ttl:
            return self._cache[group]

        all_channels = []
        seen_ids = set()
        search_queries = [""] + list("abcdefghijklmnopqrstuvwxyz0123456789")
        
        for query in search_queries:
            payload = {
                "language": self.config[0],
                "region": self.config[1],
                "catalogId": "iptv",
                "id": "",
                "adult": False,
                "search": query,
                "sort": "name",
                "filter": {"group": group},
                "cursor": None,
            }
            try:
                response = self.session.post(self.catalog_url, json=payload, timeout=10)
                data = response.json()
                items = data.get("items", [])
                for item in items:
                    url = item.get("url")
                    raw_name = item.get("name")
                    if not url or not raw_name:
                        continue
                    channel_id = item.get("ids", {}).get("id") or url
                    if channel_id not in seen_ids:
                        seen_ids.add(channel_id)
                        cleaned_name = clean_channel_name(raw_name)
                        all_channels.append({"id": channel_id, "name": cleaned_name, "url": url})
            except Exception as e:
                pass

        all_channels.sort(key=lambda x: x["name"].lower())
        self._cache[group] = all_channels
        self._cache_time[group] = now
        return all_channels

    def search_channels(self, query: str):
        channels = []
        for group in self.primary_groups:
            payload = {
                "language": self.config[0],
                "region": self.config[1],
                "catalogId": "iptv",
                "id": "",
                "adult": False,
                "search": query,
                "sort": "name",
                "filter": {"group": group},
                "cursor": None,
            }
            try:
                response = self.session.post(self.catalog_url, json=payload, timeout=20)
                data = response.json()
                items = data.get("items", [])
                seen_ids = set()
                for item in items:
                    url = item.get("url")
                    raw_name = item.get("name")
                    if not url or not raw_name:
                        continue
                    channel_id = item.get("ids", {}).get("id") or url
                    if channel_id not in seen_ids:
                        seen_ids.add(channel_id)
                        cleaned_name = clean_channel_name(raw_name)
                        channels.append({"id": channel_id, "name": cleaned_name, "url": url})
            except Exception as e:
                pass
        channels.sort(key=lambda x: x["name"].lower())
        return channels

    def resolve_channel(self, channel_id: str):
        now = time.time()
        if channel_id in self._resolve_cache and (now - self._resolve_cache_time.get(channel_id, 0)) < self.resolve_cache_ttl:
            return self._resolve_cache[channel_id]

        vavoo_url = channel_id if channel_id.startswith("http") else f"{self.base_url}/vavoo-iptv/play/{channel_id}"
        payload = {"language": self.config[0], "region": self.config[1], "url": vavoo_url}
        try:
            response = self.session.post(self.resolve_url, json=payload, timeout=20)
            json_array = response.json()
            if isinstance(json_array, list) and len(json_array) > 0:
                obj = json_array[0]
                url = obj.get("url")
                if url:
                    self._resolve_cache[channel_id] = url
                    self._resolve_cache_time[channel_id] = now
                    return url
        except Exception as e:
            pass
        return None

    def get_channel_name(self, channel_id: str) -> str:
        for group in self.primary_groups:
            channels = self.get_all_channels(group)
            for ch in channels:
                if ch["id"] == channel_id:
                    return ch["name"]
        return channel_id

    def get_home(self, letter: str = "All", user_favs: list = None):
        categories = []
        for group in self.primary_groups:
            all_channels = self.get_all_channels(group)
            channels = []
            
            if letter == "Favoriten":
                if user_favs:
                    channels = [ch for ch in all_channels if ch["id"] in user_favs]
            elif letter == "All":
                channels = all_channels
            elif letter == "#":
                for ch in all_channels:
                    name = ch["name"].strip()
                    if name and not name[0].isalpha():
                        channels.append(ch)
            else:
                target = letter.upper()
                for ch in all_channels:
                    name = ch["name"].strip()
                    if name and name[0].upper() == target:
                        channels.append(ch)

            if channels:
                categories.append({
                    "group": group,
                    "channels": channels
                })
        return categories

provider = VavooLocalProvider("de")

# --- Streamflix UI Template ---
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Streamflix Python - Vavoo Edition</title>
    <script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
    <style>
        :root { 
            --bg-color: #f8fafc; --card-bg: #ffffff; --accent: #2563eb; 
            --accent-hover: #1d4ed8; --text: #0f172a; --text-muted: #64748b; 
            --border-color: #e2e8f0; --glossy-gradient: linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(241,245,249,0.9) 100%);
        }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-color); color: var(--text); margin: 0; padding: 0; scroll-behavior: smooth;}
        header { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(12px); border-bottom: 1px solid var(--border-color); padding: 15px 40px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100; flex-wrap: wrap; gap: 15px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.02);}
        .logo { color: var(--accent); font-size: 22px; font-weight: 700; text-decoration: none; text-transform: uppercase; }
        .controls-group { display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
        input[type="text"], select { padding: 8px 14px; background: #f1f5f9; border: 1px solid var(--border-color); border-radius: 6px; color: var(--text); outline: none; font-size: 14px; transition: all 0.2s;}
        input[type="text"]:focus, select:focus { border-color: var(--accent); background: #fff; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);}
        button, .btn { padding: 8px 16px; background: var(--accent); color: #fff; border: none; border-radius: 6px; cursor: pointer; text-decoration: none; font-weight: 600; font-size: 13px; transition: all 0.2s; box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2);}
        button:hover, .btn:hover { background: var(--accent-hover); transform: translateY(-1px);}
        .m3u-btn { background: #475569; } .m3u-btn:hover { background: #334155; }
        
        .container { padding: 30px 40px; max-width: 1400px; margin: 0 auto; }
        .az-bar { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 30px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color); align-items: center; }
        .az-btn { padding: 5px 10px; background: var(--card-bg); color: var(--text-muted); border: 1px solid var(--border-color); border-radius: 6px; text-decoration: none; font-size: 13px; font-weight: 600; transition: all 0.2s; }
        .az-btn:hover, .az-btn.active { background: var(--accent); color: #fff; border-color: var(--accent); }
        .az-btn.fav-tab { background: #fbbf24; color: #fff; border-color: #f59e0b; }
        .az-btn.fav-tab:hover, .az-btn.fav-tab.active { background: #f59e0b; }
        
        .category-title { font-size: 18px; margin-bottom: 15px; font-weight: 600; border-left: 4px solid var(--accent); padding-left: 10px; color: var(--text);}
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 12px; margin-bottom: 35px; }
        .card { background: var(--glossy-gradient); border-radius: 8px; padding: 12px; transition: all 0.2s ease; display: flex; flex-direction: column; justify-content: space-between; border: 1px solid var(--border-color); position: relative; }
        .card:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06); border-color: var(--accent); }
        
        .card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
        .card-title { font-size: 17px; font-weight: 900; white-space: normal; word-break: break-word; line-height: 1.2; color: var(--text); padding-right: 25px;}
        .card .btn { padding: 6px 10px; font-size: 12px; width: 100%; text-align: center; box-sizing: border-box; }
        
        .fav-star { position: absolute; top: 10px; right: 10px; cursor: pointer; font-size: 22px; color: #cbd5e1; transition: 0.2s; user-select: none; z-index: 10; }
        .fav-star.active { color: #f59e0b; }
        .fav-star:hover { transform: scale(1.2); }

        .player-container { background: #ffffff; padding: 25px; border-radius: 12px; margin-bottom: 30px; text-align: center; border: 1px solid var(--border-color); }
        video { width: 100%; max-width: 900px; height: 500px; background: #000; border-radius: 8px; }
        .actions { margin-top: 15px; display: flex; justify-content: center; gap: 15px; }
        #scrollTopBtn { display: none; position: fixed; bottom: 25px; right: 25px; z-index: 99; background: var(--accent); color: white; border: none; width: 45px; height: 45px; border-radius: 50%; cursor: pointer; font-size: 18px; transition: all 0.2s ease; align-items: center; justify-content: center;}
        #scrollTopBtn:hover { background: var(--accent-hover); transform: translateY(-3px);}
    </style>
</head>
<body>
    <header>
        <a href="/?profile={{ current_profile }}" class="logo">Streamflix Python</a>
        <div class="controls-group">
            <select id="profileSelect">
                {% for p in profiles %}
                    <option value="{{ p }}" {% if current_profile == p %}selected{% endif %}>{{ p }}</option>
                {% endfor %}
            </select>
            <button type="button" onclick="changeProfile()">Profil wechseln</button>
            <a href="/playlist.m3u?profile={{ current_profile }}" class="btn m3u-btn" target="_blank">📥 M3U Playlist</a>
            <form action="/" method="get" style="display:flex; gap:10px;">
                <input type="hidden" name="profile" value="{{ current_profile }}">
                <input type="text" name="q" placeholder="Sender suchen..." value="{{ query }}">
                <button type="submit">Suchen</button>
            </form>
        </div>
    </header>

    <div class="container">
        {% if play_url %}
            <div class="player-container">
                <h2 style="margin-top: 0; color: var(--text);">Wiedergabe: {{ channel_name }}</h2>
                <video controls autoplay id="videoPlayer"></video>
                <div class="actions">
                    <a href="{{ play_url }}" class="btn" target="_blank">Direkten Stream-Link öffnen</a>
                    <a href="/?profile={{ current_profile }}" class="btn m3u-btn">Zurück zur Übersicht</a>
                </div>
            </div>
            <script>
                var video = document.getElementById('videoPlayer');
                var videoSrc = '{{ play_url }}';
                if (window.hlsInstance) { window.hlsInstance.destroy(); }
                if (Hls && Hls.isSupported()) {
                    var hls = new Hls(); window.hlsInstance = hls;
                    hls.loadSource(videoSrc); hls.attachMedia(video);
                    hls.on(Hls.Events.MANIFEST_PARSED, function() { video.play(); });
                } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
                    video.src = videoSrc; video.addEventListener('loadedmetadata', function() { video.play(); });
                }
            </script>
        {% endif %}

        {% if not play_url %}
            <div class="az-bar">
                <a href="/?profile={{ current_profile }}&letter=Favoriten" class="az-btn fav-tab {% if selected_letter == 'Favoriten' %}active{% endif %}">⭐ Favoriten</a>
                <a href="/?profile={{ current_profile }}&letter=All" class="az-btn {% if selected_letter == 'All' %}active{% endif %}">Alle</a>
                <a href="/?profile={{ current_profile }}&letter=%23" class="az-btn {% if selected_letter == '#' %}active{% endif %}">#</a>
                {% for char in "ABCDEFGHIJKLMNOPQRSTUVWXYZ" %}
                    <a href="/?profile={{ current_profile }}&letter={{ char }}" class="az-btn {% if selected_letter == char %}active{% endif %}">{{ char }}</a>
                {% endfor %}
            </div>

            {% if search_results %}
                <div class="category-title">Suchergebnisse für "{{ query }}"</div>
                <div class="grid">
                    {% for ch in search_results %}
                        <div class="card">
                            <span class="fav-star {% if ch.id in user_favs %}active{% endif %}" onclick="toggleFav(this, '{{ ch.id }}')">★</span>
                            <div class="card-header"><div class="card-title" title="{{ ch.name }}">{{ ch.name }}</div></div>
                            <a href="/play?id={{ ch.id }}&profile={{ current_profile }}" class="btn">Abspielen</a>
                        </div>
                    {% endfor %}
                </div>
            {% elif categories %}
                {% for cat in categories %}
                    <div class="category-title">{{ cat.group }} – {% if selected_letter == 'Favoriten' %}Meine Favoriten{% else %}Sender mit "{{ selected_letter }}"{% endif %} ({{ cat.channels|length }})</div>
                    <div class="grid">
                        {% for ch in cat.channels %}
                            <div class="card">
                                <span class="fav-star {% if ch.id in user_favs %}active{% endif %}" onclick="toggleFav(this, '{{ ch.id }}')">★</span>
                                <div class="card-header"><div class="card-title" title="{{ ch.name }}">{{ ch.name }}</div></div>
                                <a href="/play?id={{ ch.id }}&profile={{ current_profile }}" class="btn">Abspielen</a>
                            </div>
                        {% endfor %}
                    </div>
                {% endfor %}
            {% else %}
                <div style="color: var(--text-muted); margin-top: 20px;">Keine Sender gefunden. Füge Sender über das Stern-Symbol zu deinen Favoriten hinzu.</div>
            {% endif %}
        {% endif %}
    </div>

    <button onclick="scrollToTop()" id="scrollTopBtn" title="Nach oben springen">▲</button>

    <script>
        // Profil über URL-Parameter direkt umschalten
        function changeProfile() {
            var select = document.getElementById('profileSelect');
            var profileName = select.options[select.selectedIndex].value;
            var urlParams = new URLSearchParams(window.location.search);
            urlParams.set('profile', profileName);
            window.location.href = window.location.pathname + '?' + urlParams.toString();
        }

        // Favoriten per Fetch API toggeln ohne Reload
        function toggleFav(element, channelId) {
            var profile = new URLSearchParams(window.location.search).get('profile') || '{{ current_profile }}';
            fetch('/toggle_fav', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: channelId, profile: profile })
            }).then(response => response.json()).then(data => {
                if(data.status === 'added') {
                    element.classList.add('active');
                } else {
                    element.classList.remove('active');
                    if(new URLSearchParams(window.location.search).get('letter') === 'Favoriten') {
                        element.closest('.card').style.display = 'none';
                    }
                }
            });
        }

        let scrollBtn = document.getElementById("scrollTopBtn");
        window.onscroll = function() {
            if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
                scrollBtn.style.display = "flex";
            } else {
                scrollBtn.style.display = "none";
            }
        };
        function scrollToTop() { window.scrollTo({ top: 0, behavior: 'smooth' }); }
    </script>
</body>
</html>
"""

# --- Hilfsfunktion fürs aktive Profil ---
def get_current_profile():
    # Schaut zuerst in den URL-Parameter, dann in Cookies, dann Fallback
    profile = request.args.get("profile") or request.cookies.get("streamflix_profile", "Profil 1")
    if profile not in PROFILES:
        profile = "Profil 1"
    return profile

# --- Flask Routen ---
@app.route("/")
def index():
    query = request.args.get("q", "")
    selected_letter = request.args.get("letter", "All")
    current_profile = get_current_profile()
    favs_data = load_favorites()
    user_favs = favs_data.get(current_profile, [])
    
    if query:
        results = provider.search_channels(query)
        html = render_template_string(HTML_TEMPLATE, profiles=PROFILES, current_profile=current_profile, user_favs=user_favs, query=query, search_results=results, categories=[], play_url=None, selected_letter=selected_letter)
    else:
        categories = provider.get_home(selected_letter, user_favs)
        html = render_template_string(HTML_TEMPLATE, profiles=PROFILES, current_profile=current_profile, user_favs=user_favs, query="", search_results=None, categories=categories, play_url=None, selected_letter=selected_letter)

    resp = make_response(html)
    resp.set_cookie("streamflix_profile", current_profile, max_age=31536000)
    return resp

@app.route("/toggle_fav", methods=["POST"])
def toggle_fav():
    data = request.json
    channel_id = data.get("id")
    # Profil aus dem JSON-Body oder Fallback nutzen
    current_profile = data.get("profile") or get_current_profile()
    
    favs_data = load_favorites()
    user_favs = favs_data.get(current_profile, [])
    
    if channel_id in user_favs:
        user_favs.remove(channel_id)
        status = "removed"
    else:
        user_favs.append(channel_id)
        status = "added"
        
    favs_data[current_profile] = user_favs
    save_favorites(favs_data)
    
    return jsonify({"status": status})

@app.route("/play")
def play():
    channel_id = request.args.get("id")
    if not channel_id:
        return redirect("/")
    
    stream_url = provider.resolve_channel(channel_id)
    if not stream_url:
        return "Fehler: Stream konnte nicht aufgelöst werden.", 400
        
    channel_name = provider.get_channel_name(channel_id)
    current_profile = get_current_profile()
    
    return render_template_string(
        HTML_TEMPLATE, 
        profiles=PROFILES,
        current_profile=current_profile,
        user_favs=[], 
        query="", 
        search_results=None, 
        categories=[], 
        play_url=stream_url, 
        channel_name=channel_name, 
        selected_letter="All"
    )

@app.route("/playlist.m3u")
def playlist():
    m3u = "#EXTM3U\n"
    for group in provider.primary_groups:
        channels = provider.get_all_channels(group)
        for ch in channels:
            m3u += f'#EXTINF:-1 group-title="{group}",{ch["name"]}\n'
            m3u += f'http://127.0.0.1:5000/resolve_m3u?id={ch["id"]}\n'
    return Response(m3u, mimetype="audio/x-mpegurl")

@app.route("/resolve_m3u")
def resolve_m3u():
    channel_id = request.args.get("id")
    stream_url = provider.resolve_channel(channel_id)
    if stream_url:
        return redirect(stream_url, code=302)
    return "Stream offline", 404

if __name__ == "__main__":
    print("🚀 Streamflix Python gestartet!")
    print("\n🔗 Öffne im Browser: http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
